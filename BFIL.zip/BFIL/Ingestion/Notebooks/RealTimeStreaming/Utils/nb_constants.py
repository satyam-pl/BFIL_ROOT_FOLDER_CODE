# Databricks notebook source
# Defining constants 
logger_level_debug = "DEBUG"
logger_level_info = "INFO"
logger_level_warn = "WARN"
logger_level_error = "ERROR"
log_error_success = "NO_ERROR"
log_error_failure = "ERROR"
log_status_failure = "FAILED"
log_status_success = "SUCCESS"

order_by = "current_ts"
key_split_delimeter = ","
columns_to_exclude = [ "ETL_CREATED_DATE", "ETL_LAST_UPDATED_DATE"]
meta_cols = ["ETL_CREATED_DATE" , "ETL_LAST_UPDATED_DATE"]
streaming_cols = ["after_snapshot_data.*", "body.current_ts" , "body.op_type"]


# adls constants
adb_secret_scope_name = "AKV_secret_scope"

#connection_string
at_loandaytransactions_key_vault = 'BFIL-EVENTHUB-CONNECTION-STRING-ATLOANDAYTRANSACTIONS'
clientloanproposal_key_vault = 'BFIL-EVENTHUB-CONNECTION-STRING-CLIENTLOANPROPOSAL'
audit_log_bk_proxy_req_key_vault = 'BFIL-EVENTHUB-CONNECTION-STRING-AUDIT-LOG-BK-PROXY-REQ'
audit_log_bk_proxy_res_key_vault = 'BFIL-EVENTHUB-CONNECTION-STRING-AUDIT-LOG-BK-PROXY-RES'
clientloansubscription_key_vault = 'BFIL-EVENTHUB-CONNECTION-STRING-CLIENTLOANSUBSCRIPTION'
centermaster_key_vault = 'BFIL-EVENTHUB-CONNECTION-STRING-CENTERMASTER'

at_loantransactions_key_vault = 'EVENTHUB-CONNECTION-STRING-BFIL-AT-LOANTRANSACTIONS'
grtmaster_key_vault = 'EVENTHUB-CONNECTION-STRING-BFIL-GRTMASTER'
clientmaster_key_vault = 'EVENTHUB-CONNECTION-STRING-BFIL-CLIENTMASTER'
processlog_key_vault = 'EVENTHUB-CONNECTION-STRING-BFIL-PROCESSLOG'
targetmaster_key_vault = 'EVENTHUB-CONNECTION-STRING-BFIL-TARGETMASTER'
groupmaster_key_vault = 'EVENTHUB-CONNECTION-STRING-BFIL-GROUPMASTER'

cashlessdisbursements_key_vault = "EVENTHUB-CONNECTION-STRING-BFIL-CASHLESSDISBURSEMENTS"
tabdbstaffprocessdetails_key_vault = "EVENTHUB-CONNECTION-STRING-BFIL-TABDBSTAFFPROCESSDETAILS"

#Processing 
processing_time = "10 Seconds"

# For execution log of pipeline.
execution_log_list = []
