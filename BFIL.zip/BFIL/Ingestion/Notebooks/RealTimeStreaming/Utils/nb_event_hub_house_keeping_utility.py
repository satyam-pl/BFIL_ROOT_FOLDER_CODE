# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/RealTimeStreaming/Streaming/nb_event_hub_import_libraries"

# COMMAND ----------

# Function to stop the workflow
def stop_workflow(job_ids):
    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/cancel-all"
    headers = {"Authorization": f"Bearer {TOKEN}"}
    
    for job_id in job_ids:
        data = {
            "job_id": job_id,
            "all_queued_runs": False
        }
        response = requests.post(url, headers=headers, data=json.dumps(data))
        if response.status_code == 200:
            print(f"Workflow for job_id {job_id} stopped successfully.")
        else:
            print(f"Failed to stop the workflow for job_id {job_id}: {response.text}")


#Function to delete the data from deleta table before the provide cutoff-date
def cleanup_old_data(table_list):
    for obj in table_list:    
        try:
            QueryVar = f"""
            DELETE FROM {catalog_schema_name}.{obj}
            WHERE TO_DATE(TO_UTC_TIMESTAMP(ETL_CREATED_DATE, 'IST')) < date_sub(current_date(), {cutoff_date})
            OR TO_DATE(TO_UTC_TIMESTAMP(ETL_LAST_UPDATED_DATE, 'IST')) < date_sub(current_date(), {cutoff_date})
            """
            spark.sql(QueryVar)
            print('Old data from', obj , 'was deleted successfully till T-',cutoff_date)
        except Exception as e:
            print(e)


# Function to start the workflow
def start_workflow(job_ids):
    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now"
    headers = {"Authorization": f"Bearer {TOKEN}"}
    
    for job_id in job_ids:
        data = {
            "job_id": job_id
        }
        response = requests.post(url, headers=headers, data=json.dumps(data))
        if response.status_code == 200:
            print("Workflow started successfully.")
        else:
            print("Failed to start the workflow:", response.text)

# Function to sleep for 1 minutes to ensure workflows are completely stopped
def sleep_time(sleep_time):
    print("\nSleeping for 1 minute to ensure workflows are completely stopped...\n")
    time.sleep(sleep_time)
 

# COMMAND ----------

# Define your Databricks workspace and job details
DATABRICKS_INSTANCE = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().getOrElse(None)
TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().getOrElse(None)

job_ids = dbutils.widgets.get("job_ids").split(',')
table_list = dbutils.widgets.get("table_list").split(',')
cutoff_date = dbutils.widgets.get("cutoff_date").lower()
catalog_schema_name = dbutils.widgets.get("catalog_schema_name").lower()


# Stop the workflow
stop_workflow(job_ids)
 
# Sleep for 1 minutes to ensure workflows are completely stopped
sleep_time(60)

# Delete the data from delta table till the provide cutoff-date
cleanup_old_data(table_list)

# # Start the workflow
start_workflow(job_ids)