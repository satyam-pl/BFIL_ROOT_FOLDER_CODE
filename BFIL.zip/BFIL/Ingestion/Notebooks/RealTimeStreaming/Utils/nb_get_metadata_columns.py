# Databricks notebook source
def MetaDataColumns(ColNames, ETLCHANGEFLAG =None, exec_log_id=None,etl_user_id=None,current_timestamp=None,pipeline_run_id=None ):
    gendict = {
                "ETL_CHANGE_FLAG": f"lit(\"{ETLCHANGEFLAG}\")",
                "ETL_DQ_FINAL_STATUS": "lit(\"1\")",
                "ETL_DQ_ERROR": "lit(None)",
                "ETL_EXEC_LOG_ID": f"lit(str({exec_log_id}))",
                "ETL_CREATED_BY": f"lit({etl_user_id})",
                "ETL_CREATED_DATE": f"lit(str({current_timestamp}))",
                "ETL_LAST_UPDATED_BY": f"lit({etl_user_id})",
                "ETL_LAST_UPDATED_DATE": "lit(\"{9999-12-31T23:59:59Z}\")",
                "ETL_AUDIT_ID": f"lit(str({pipeline_run_id}))",
                "ETL_EFFECTIVE_FROM_DATE": "lit(\"1990-01-01T00:00:00Z\"))",
                "ETL_EFFECTIVE_TO_DATE": f"lit(\"9999-12-31T23:59:59Z\"))" 
            }
                     
    StringList = []
 
    for ColumnName in ColNames:
        StringList.append(str(f".withColumn(\"{ColumnName}\", {gendict[ColumnName]})"))
 
    return "".join(StringList)