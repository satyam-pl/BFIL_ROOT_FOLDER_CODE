# Databricks notebook source
def insert_log(source_df ,micro_batch_df, starttime, batch_id):
    
    initial_count = micro_batch_df.count()
    created_date = rettimestamp()
    insert_count = source_df.filter(col("op_type") == "I").count()
    update_count = source_df.filter(col("op_type") == "U").count()
    delete_count = source_df.filter(col("op_type") == "D").count()
    final_count = source_df.count()
    processing_time = (datetime.now() - starttime).total_seconds()

    # Create a DataFrame with the counts
    log_df = spark.createDataFrame([(table_name, batch_id, created_date, initial_count, final_count, insert_count, update_count, delete_count ,processing_time)], ["TABLE_NAME", "BATCH_ID", "CREATED_DATE", "INITIAL_RECORDS_COUNT", "FINAL_RECORDS_COUNT", "INSERT_COUNT", "UPDATE_COUNT", "DELETE_COUNT", "PROCESSING_TIME_sec"])

    log_df.write.format("delta").mode("append").option("path", f"abfss://curated-layer@ibldevadls09.dfs.core.windows.net/BFIL/EVENTHUB/{table_name}_log_table").saveAsTable(f"edp_curated_dev.bfil.{table_name}_log_table")

    print("Log inserted...")