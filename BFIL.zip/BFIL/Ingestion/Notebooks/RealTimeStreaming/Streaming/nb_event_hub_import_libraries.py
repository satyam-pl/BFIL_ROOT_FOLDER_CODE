# Databricks notebook source
from pyspark.sql.types import StructType, StructField , StringType , IntegerType
from pyspark.sql.functions import col, expr, lit, get_json_object, row_number, when, struct, coalesce ,from_json
from pyspark.sql.window import Window
from pyspark.sql import SparkSession

# COMMAND ----------

from datetime import datetime
import pytz, json, inspect, requests, time
from delta.tables import DeltaTable