# Databricks notebook source
# DBTITLE 1,imports
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/RealTimeStreaming/Streaming/nb_event_hub_import_libraries"

# COMMAND ----------

# DBTITLE 1,logger
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# DBTITLE 1,contansts
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/RealTimeStreaming/Utils/nb_constants"

# COMMAND ----------

# DBTITLE 1,schema
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/RealTimeStreaming/Streaming/nb_event_hub_source_schema"

# COMMAND ----------

# DBTITLE 1,primary_keys
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/RealTimeStreaming/Streaming/nb_event_hub_primary_keys"

# COMMAND ----------

# DBTITLE 1,Functions
def rettimestamp():
    return datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

def add_metadata_column(df):
    return df.withColumn("body", from_json(col("body").cast("string"), json_schema))\
        .withColumn("ETL_CREATED_DATE", lit(rettimestamp()))\
        .withColumn("ETL_LAST_UPDATED_DATE", lit(rettimestamp()))\
        .withColumn("after_snapshot_data", when(col("body.op_type") == "D", coalesce(col("body.before"), col("body.after"))).otherwise(col("body.after")))

def upsert_delta_table(micro_batch_df, batch_id):
    try:
        starttime = datetime.now()
        print("Processing started for",table_name,str(rettimestamp()), "for total", str(micro_batch_df.count()),"records")

        micro_batch_df = add_metadata_column(micro_batch_df)
        micro_batch_df = micro_batch_df.select(streaming_cols + meta_cols).withColumnRenamed("op_type","ETL_OP_TYPE")

        for col_name in boolean_col_names:
            micro_batch_df = micro_batch_df.withColumn(col_name, when(col(col_name).isNull(), lit(None)).when(col(col_name) == "AQ==", "1").otherwise("0"))
    
        windowSpec = Window.partitionBy(*primary_key.split(key_split_delimeter)).orderBy(col(f'{order_by}').desc())
        ranked_df = micro_batch_df.withColumn("row_number", row_number().over(windowSpec))
        source_df = ranked_df.filter(col("row_number") == 1).drop("row_number").drop(order_by)

        source_df = source_df.withColumn("ETL_IS_ACTIVE", when(col("ETL_OP_TYPE") == "D", lit(0)).otherwise(lit(1)))

        #Required Parameters in merge
        spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
        update_condition = ", ".join([f"target.{column} = source.{column}" for column in source_df.columns if column not in columns_to_exclude])
        join_condition = " AND ".join([f"target.{key} = source.{key}" for key in primary_key.split(key_split_delimeter)])        


        source_df.createTempView("source_df_view")
        delta_table = f"{catalog_schema_name}.{table_name.lower()}_RTS"         
        output_df = source_df._jdf.sparkSession().sql(f"""
                                MERGE INTO {delta_table} AS target 
                                USING source_df_view AS source
                                    ON {join_condition}
                                WHEN MATCHED AND source.ETL_OP_TYPE != "I" THEN
                                    UPDATE SET 
                                        {update_condition},target.ETL_LAST_UPDATED_DATE = '{rettimestamp()}'
                                WHEN NOT MATCHED THEN
                                    INSERT *
                            """)
        source_df.sparkSession.catalog.dropTempView("source_df_view")

        print("Processing Ended at", str(rettimestamp()), "for total", str(micro_batch_df.count()),"records", "Time taken",(datetime.now() - starttime).total_seconds(), "Seconds \n")


    except Exception as e:
        filename = "nb_event_hub_read_write"
        logger(logger_level_info, f"Error in upsert_delta_table : {e} " , execution_log_list ,filename)
        raise Exception("Error in upsert_delta_table : ", str(e))
        query.stop()




# COMMAND ----------

# DBTITLE 1,Read&Write

# Details from workflow
try:
    table_name = dbutils.widgets.get("table_name").lower()
    primary_key = eval(f'{table_name}_primary_key')
    boolean_col_names = eval(f'{table_name}_boolean_col_names')
    connection_string = dbutils.secrets.get(scope = adb_secret_scope_name, key = eval(f'{table_name}_key_vault'))
    checkpoint_path = dbutils.widgets.get("check_point_path")
    catalog_schema_name = dbutils.widgets.get("catalog_schema_name")
    json_schema = eval(f'{table_name}_schema')

    try:
        data_frame_batch_size = dbutils.widgets.get("df_size")
    except Exception as e:
        data_frame_batch_size = 1000

    if not data_frame_batch_size:
        data_frame_batch_size = 1000

except Exception as e:
    filename = "nb_event_hub_read_write"
    logger(logger_level_info, f"Error while getting input from workflow parameter(i.e not provided or incorrect) : {str(e)} ", execution_log_list, filename) 
    raise Exception("Error while fetching parameters from workflow : ", str(e))

try:
    spark.conf.set("spark.databricks.delta.properties.defaults.enableChangeDataFeed", True)
    event_hub_config = {}
    event_hub_config["eventhubs.connectionString"] = sc._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(connection_string)
    event_hub_config["eventhubs.consumerGroup"] = "$Default"


    # Read streaming data from Event Hubs
    streaming_df = (
        spark.readStream.format("eventhubs")
        .options(**event_hub_config)
        .option("maxEventsPerTrigger", data_frame_batch_size)
        .load()
    )

    # Write Streaming data to delta table
    query = streaming_df.writeStream \
    .format("delta") \
    .foreachBatch(upsert_delta_table) \
    .option("checkpointLocation", f'{checkpoint_path}{table_name}_checkpoint')\
    .trigger(processingTime=f'{processing_time}') \
    .start()
    query.awaitTermination()

except Exception as e:
    filename = "nb_event_hub_read_write"
    logger(logger_level_info, f"Error while Connecting To EventHub : {e} ", execution_log_list, filename) 
    raise Exception("Error while Connecting to eventhub : ", str(e))
