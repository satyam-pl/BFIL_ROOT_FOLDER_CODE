# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_dim_bfil_acid_vw.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    # Fetching parameters from ADF widgets
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FINACLE/DIM_BFIL_ACID_VW"
    desti_path = "BFIL-MART/FINACLE/DIM_BFIL_ACID_VW"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """Select  A.SOL_ID,
        A.ACID,
        A.CIF_ID As CIFID,
        A.ForacID,
        A.ACCT_NAME,
        C.AccountType,
        A.SCHM_Code,
        A.SCHM_TYPE,
        B.Free_Code_10 As C5Code,
        IFF(B.Free_Code_8 ='NBF','BMS - Non Member',C.SBU) As SBU
From edp_curated_prod.finacle.gam As A
Join edp_curated_prod.finacle.gac As B On B.ACID = A.ACID
Join edp_bfil_prod.finacle.dim_bfil_schmcode As C On Upper(C.SCHM_Code) = Upper(A.SCHM_Code) and Upper(C.SCHM_TYPE) = Upper(A.SCHM_TYPE) 
and Upper(B.Free_Code_10) = Upper(C.C5Code) and C.Status = 1
Where Upper(C.C5Code) Is Not Null

Union

Select  A.SOL_ID,
        A.ACID,
        A.CIF_ID As CIFID,
        A.ForacID,
        A.ACCT_NAME,
        C.AccountType,
        A.SCHM_Code,
        A.SCHM_TYPE,
        B.Free_Code_10 As C5Code,
        IFF(B.Free_Code_8 ='NBF','BMS - Non Member',C.SBU) As SBU
From edp_curated_prod.finacle.gam As A
Left Join edp_curated_prod.finacle.gac As B On B.ACID = A.ACID
Join edp_bfil_prod.finacle.dim_bfil_schmcode As C On Upper(C.SCHM_Code) = Upper(A.SCHM_Code) and Upper(C.SCHM_TYPE) = Upper(A.SCHM_TYPE) and C.Status = 1
Where Upper(C.C5Code) Is Null

Union

Select  A.SOL_ID,
        A.ACID,
        A.CIF_ID As CIFID,
        A.ForacID,
        A.ACCT_NAME,
        C.AccountType,
        A.SCHM_Code,
        A.SCHM_TYPE,
        B.Free_Code_10 As C5Code,
       'BFIL/POOL ACCOUNTS' As SBU
From edp_curated_prod.finacle.gam As A
Left Join edp_curated_prod.finacle.gac As B On B.ACID = A.ACID
Join edp_bfil_prod.finacle.dim_bfil_PoolAccounts As C On C.ForacID = A.ForacID and Status = 1"""
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"dim_bfil_acid_vw Query has been successfully completed",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on dim_bfil_acid_vw: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on dim_bfil_acid_vw : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.finacle.dim_bfil_acid_vw")

    logger(
            logger_level_info,
            f"dim_bfil_acid_vw writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table dim_bfil_acid_vw : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table dim_bfil_acid_vw : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, 'NULL','NULL', execution_log_list)