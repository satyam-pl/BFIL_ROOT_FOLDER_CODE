# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_ibl_rdmic_acct_dump.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    # Fetching parameters from ADF widgets
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FINACLE/IBL_RDMIC_ACCT_DUMP"
    desti_path = "BFIL-MART/FINACLE/IBL_RDMIC_ACCT_DUMP"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """Select	'SKS' As Promo_Code,
			A.schm_code As SCHM_CODE,
			A.sol_id As BRANCH_CODE,
			sol.sol_desc As BRANCH_NAME,
			A.cif_id As CUSTOMER_NO,
			A1.foracid As MATURITY_SB_AC,
			A1.acct_cls_flg As REPAYMENT_ACCT_CLS_FLG,
			A1.acct_cls_date As REPAYMENT_ACCT_CLS_DATE,
			Smt.acct_status As REPAYMENT_ACCT_STAT_FLG,
			 A2.Contra_ACCT As FUNDING_SB_ACCT,
			 A2.TRAN_AMT As FUNDING_SB_ACCT_BAL,
			A.acct_name As CUSTOMER_NAME,
			A.acct_cls_date As ACCT_CLS_DATE,
            gac.free_code_10 As C5_CODE,
			A.rcre_user_id As CREATED_BY,
			SubString(gender, 1, 1) AS GENDER,
			Cast(cust_dob AS DATE) As DATE_OF_BIRTH,
			c.localetext  as CUSTOMER_CATEGORY,
			B.FATHER_HUSBAND_NAME,
			CONCAT(COALESCE(CAST(CAST(DEPOSIT_PERIOD_MTHS AS INT) AS STRING), '0'), ' MNTHS ', 
			COALESCE(CAST(CAST(DEPOSIT_PERIOD_DAYS AS INT) AS STRING), '0'), ' DAYS ') AS RD_TENURE,
			-- CUSTOM.GETCRINTRATE2(GAM.ACID,tam.open_effective_date) As ROI,
			A.acct_opn_date As RD_ACCT_OPN_DATE,
			A.foracid  As RD_ACCT_NUMBER,
			C.maturity_date As RD_MATURITY_DATE,
			C.maturity_amount As RD_MATURITY_AMOUNT,
			edp_bfil_prod.bfil_mart.EABBalAsOnDate (a.acid,current_timestamp(),'01') as RD_BALANCE,
			Smt1.acct_status As ACCT_STATUS

From edp_curated_prod.finacle.gam As A
Left Join edp_curated_prod.finacle.accounts As B On B.orgkey = A.cif_id
Left Join edp_curated_prod.finacle.tam As C On C.ACID = A.ACID
Left Join edp_curated_prod.finacle.sol As Sol On Sol.sol_id = A.sol_id
Left Join edp_curated_prod.finacle.smt As Smt On Smt.acid = C.repayment_acid
Left Join edp_curated_prod.finacle.gac As gac On gac.acid = A.acid
Left Join edp_curated_prod.finacle.smt As Smt1 On Smt1.acid = A.acid

/* Linked Account Number */
Left Join edp_curated_prod.finacle.gam As A1 On A1.acid = C.repayment_acid

/* Linked Account Balance */
Left Join (Select	ForacID,
							Contra_ACCT,
							TRAN_AMT,
							ROW_NUMBER() OVER (PARTITION BY tran_id,tran_date ORDER BY tran_id,tran_date Desc) AS rn
				From edp_bfil_prod.finacle.ibl_transactions
				Where part_tran_type = 'D' and TRAN_PARTICULAR Like '%Closure proceeds%') As A2 On A2.ForacID = A.ForacID and A2.rn=1

Left Join (Select	localetext,
							value,
							ROW_NUMBER() OVER (PARTITION BY value ORDER BY value) AS rnl
				From edp_curated_prod.finacle.categories c
				Join edp_curated_prod.finacle.category_lang cl ON cl.categoryid = c.categoryid
				Where categorytype IN ('CUST_TYPE1', 'CUST_TYPE_DESC')) c ON c.value = b.cust_type AND c.rnl = 1

Where A.schm_code IN ('RDMIC','RDMIS')
-- and trunc(A.rcre_time) = Cast(GetDate()-1 As Date)
and A.entity_cre_flg = 'Y' and A.del_flg ='N' """
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"ibl_rdmic_acct_dump Query has been successfully completed",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on ibl_rdmic_acct_dump: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on ibl_rdmic_acct_dump : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.finacle.ibl_rdmic_acct_dump")

    logger(
            logger_level_info,
            f"ibl_rdmic_acct_dump writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table ibl_rdmic_acct_dump : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table ibl_rdmic_acct_dump : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, 'NULL','NULL', execution_log_list)