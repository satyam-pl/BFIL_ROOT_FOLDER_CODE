# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_ibl_transactions.dbc"

# COMMAND ----------

query_htd = f"""
SELECT
    tran_id,
    tran_date,
    part_tran_type,
    acid,
    dth_init_sol_id,
    htd.TRAN_ID,
    GL_DATE,
    TRAN_DATE,
    VALUE_DATE,
    TRAN_AMT,
    TRAN_TYPE,
    TRAN_SUB_TYPE,
    PART_TRAN_TYPE,
    TRAN_PARTICULAR_CODE,
    REF_NUM,
    PART_TRAN_SRL_NUM,
    tran_particular,
    TRAN_PARTICULAR_2,
    INSTRMNT_TYPE,
    INSTRMNT_DATE,
    INSTRMNT_NUM,
    ENTRY_USER_ID,
    PSTD_USER_ID,
    VFD_USER_ID,
    ENTRY_DATE,
    PSTD_DATE,
    VFD_DATE,
    del_flg,
    pstd_flg,
    TRAN_RMKS
FROM
    edp_curated_prod.finacle.htd
WHERE
    pstd_flg = 'Y'
    AND del_flg = 'N'
    AND CAST(TRAN_DATE AS DATE) = CAST(from_utc_timestamp(current_date(), 'Asia/Kolkata') - INTERVAL 1 DAY AS DATE)
"""


# COMMAND ----------

source_df = spark.sql(query_htd).cache().repartition(50)
source_df.createOrReplaceTempView("htd")

# COMMAND ----------

query = f"""Select	ForacID,
			h.tran_id,
			h.tran_date,
			h.part_tran_type
From  htd h
Join  edp_curated_prod.finacle.gam g On h.acid = g.acid"""


source_df1 = spark.sql(query).cache().repartition(50)

# COMMAND ----------

source_df1.createOrReplaceTempView("ContraAcct")

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    # Fetching parameters from ADF widgets
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    pipeline_run_id = dbutils.widgets.get("pipeline_run_id")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FINACLE/IBL_TRANSACTIONS"
    desti_path = "BFIL-MART/FINACLE/IBL_TRANSACTIONS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """Select	htd.dth_init_sol_id As INPUT_BR,
			gam.sol_id As ACCT_BR,
			gam.CIFID As CIF_ID,
			gam.foracid As FORACID,
			gam.schm_code As SCHM_CODE,
			gam.schm_type As SCHM_TYPE,
			C.FORACID As Contra_ACCT,
			gam.ACCT_NAME As ACCT_NAME,
			htd.TRAN_ID As TRAN_ID,
			htd.GL_DATE As GL_DATE,
			htd.TRAN_DATE As TRAN_DATE,
			htd.VALUE_DATE As VALUE_DATE,
			htd.TRAN_AMT As TRAN_AMT,
			htd.TRAN_TYPE As TRAN_TYPE,
			htd.TRAN_SUB_TYPE As TRAN_SUB_TYPE,
			htd.PART_TRAN_TYPE As PART_TRAN_TYPE,
			Replace(htd.TRAN_RMKS,char(13),'') As TRAN_RMKS,
			htd.TRAN_PARTICULAR_CODE As TRAN_PARTICULAR_CODE,
			htd.REF_NUM As REF_NUM,
			htd.PART_TRAN_SRL_NUM As PART_TRAN_SRL_NUM,
			 Replace(htd.tran_particular,char(13),'') As TRAN_PARTICULAR,
			htd.TRAN_PARTICULAR_2 As TRAN_PARTICULAR_2,
			htd.INSTRMNT_TYPE As INSTRMNT_TYPE,
			htd.INSTRMNT_DATE As INSTRMNT_DATE,
			htd.INSTRMNT_NUM As INSTRMNT_NUM,
			htd.ENTRY_USER_ID As ENTRY_USER_ID,
			htd.PSTD_USER_ID As PSTD_USER_ID,
			htd.VFD_USER_ID As VFD_USER_ID,
			htd.ENTRY_DATE As ENTRY_DATE,
			htd.PSTD_DATE As PSTD_DATE,
			htd.VFD_DATE As VFD_DATE
From htd
Join edp_bfil_prod.finacle.dim_bfil_acid_vw gam on htd.acid = gam.acid 
Left Join ContraAcct C On C.tran_id = htd.tran_id and C.tran_date = htd.tran_date and C.part_tran_type = (Case When htd.part_tran_type ='D' Then 'C'  When htd.part_tran_type ='C' Then 'D'  End)"""
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    # df = spark.sql(query).repartition(50).cache()
    df = spark.sql(query).coalesce(50).cache()
    logger(
        logger_level_info,
        f"ibl_transactions Query has been successfully completed",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on ibl_transactions: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on ibl_transactions : ", str(e))

# COMMAND ----------

# DBTITLE 1,metadata function
# Extra columns has been added into source data frame based on requirement.
def add_meta_data_into_source_df_mart(source_data_df,pipeline_run_id) :

    # Declaring the notebook name
    filename = 'nb_add_meta_data_columns_mart.dbc'

    try :
        # Defining current timestamp
        current_timestamp = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

        # Define current ETL User ID
        etl_user_id = spark.sql('SELECT current_user() AS user').collect()[0]['user']

        # Adding additional meta data columns and default values to the source data frame 
        source_data_df = source_data_df.withColumn("ETL_CREATED_BY", lit(etl_user_id))\
                                        .withColumn("ETL_CREATED_DATE", lit(current_timestamp))\
                                        .withColumn("ETL_AUDIT_ID", lit(pipeline_run_id).cast("string"))\
                                        .withColumn("ETL_IS_ACTIVE",lit("1"))
        
        return source_data_df
    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"An error occurred while creating a DataFrame from input files with metadata columns.", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception(f"An unexpected error occurred:", e)

# COMMAND ----------

# DBTITLE 1,calling metadatafunction

try :
    df = add_meta_data_into_source_df_mart(df,pipeline_run_id)
    logger(
    logger_level_info,
    f"adding metadata columns has been successfully completed",
    execution_log_list,
    filename,
    )
except Exception as e:
    # Call the logger function with a log level and message
    logger(logger_level_error, f"An error occurred while adding metadata columns in the source dataframe.", execution_log_list, filename)
    print(*execution_log_list, sep='\n')
    raise Exception(f"An unexpected error occurred:", e)


# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("append").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.finacle.ibl_transactions")

    logger(
            logger_level_info,
            f"ibl_transactions writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table ibl_transactions : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table ibl_transactions : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, 'NULL','NULL', execution_log_list)