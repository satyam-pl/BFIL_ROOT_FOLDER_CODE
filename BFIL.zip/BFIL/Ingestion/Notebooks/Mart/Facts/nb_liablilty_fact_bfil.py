# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_liabilities_fact_bfil.dbc"

# COMMAND ----------

from datetime import datetime, date
from pytz import timezone

# Set the timezone
india_tz = timezone("Asia/Kolkata")

# Get the current timestamp and convert it to the specified timezone
current_timestamp = datetime.now(india_tz)

# Calculate the start of the month
MTDStartDate = current_timestamp.replace(day=1).date()

# Get the current date
MTDEndDate = date.today()

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FACTS/LIABLILTY_FACT_BFIL"
    desti_path = "BFIL-MART/FACTS/LIABLILTY_FACT_BFIL"
    

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    
    query = """
    WITH CTE_RD_CLIENTLOANSUBSCRIPTION As       
    (
      Select Distinct CURRENT_DATE() As ReportGenDate,'MFI' As SBU,          
      CM.TargetID,          
      CM.ClientID,                  
      CM.ClientName,          
      Cast(CM.DateOfBirth As Date) As DateOfBirth,          
      CM.MaritalStatus,          
      k1.kYCNUMBER aS AadharNumber,
      Cast(CM.JoinDate As Date) As JoinDate,          
      (Case When CM.DropOutDate IS NULL Then Null          
      Else Cast(CM.DropOutDate As Date) End) As DropOutDate,          
      (Case When COALESCE(CM.DropOutDate,'1900-01-01') ='1900-01-01' Then 'Active'          
      Else 'DropOut' End) As ClientStatus,          
      CNM.CenterID,          
      CNM.CenterMeetingDay,          
      CNM.StaffId As CenterHandled_StaffID,          
      UM.UserName As CenterHandled_StaffName,          
      Null As CenterStatus,          
      Cls.LoanProposalID,          
      Clp.ProposalDate,          
      Cls.ClientLoanID As RDLoanID,          
      Cls.ClientProductSequenceNo As SequenceID,          
      Cls.RDAccountNumber,          
      Cast(Cls.DisbursementDate As Date) As RD_OpenDate,          
      Cls.LoanAmountDisbursed As RD_Amount,       
        Cast(Clp.InterestRate As Decimal(10,2)) As InterestRate,  
    Cls.Tenure,          
      Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate,          
      (Case When Cls.LoanClosedDate is null Then Null          
      Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,          
      (Case When Cls.LoanClosedDate is null Then 'Active'          
        When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'          
        When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus,          
      Cls.Comments,        
    cast(NULL as varchar(50)) AS BussinessType,
    cast(NULL as varchar(50)) AS CAFlag,      
    cast(NULL as varchar(50)) AS AccountNumber,      
    cast(NULL as varchar(50)) AS BatchID,      
    cast(NULL as varchar(50)) As RDOpenStaffID,    
    cast(NULL as varchar(50)) As RDOpenStaffName,      
    cast(NULL as varchar(50)) AS ProductID,    
    cast(NULL as varchar(50)) AS PurposeID
    From {source_catalog}.{source_schema}.`pragati-clientloansubscription` Cls          
    Join {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` Clp On Clp.LoanProposalID = Cls.LoanProposalID   and Clp.ETL_IS_ACTIVE=1       
    Join {source_catalog}.{source_schema}.`pragati-clientmaster`  CM On CM.ClientID = Cls.ClientID    and  CM.ETL_IS_ACTIVE=1      
    Join {source_catalog}.{source_schema}.`pragati-groupmaster` GM On GM.GroupID = CM.GroupID         and GM.ETL_IS_ACTIVE=1 
    Join {source_catalog}.{source_schema}.`pragati-centermaster` CNM On CNM.CenterID = GM.CenterID    and CNM.ETL_IS_ACTIVE=1      
    Left Join {source_catalog}.{source_schema}.`pragatimain-usermaster`  UM ON UM.UserID = CNM.StaffID          and UM.ETL_IS_ACTIVE=1
    LEFT Join {source_catalog}.{source_schema}.`pragati-kycmaster`  K1 On K1.TargetID = CM.TargetID and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M','Y')   and K1.ETL_IS_ACTIVE=1       
    Where Cls.ProductType Is Not Null          
    and (Cls.LoanClosedDate is null Or Cls.LoanClosedDate >= '{MTDStartDate}')
    and Cls.ETL_IS_ACTIVE=1
	
	
	
	
	
      UNION 
	  
	  
	  
	  
      Select Distinct CURRENT_DATE() As ReportGenDate,'BMS',          
      CM.TargetID,          
      CM.ClientID,                  
      CM.ClientName,          
      Cast(CM.DateOfBirth As Date) As DateOfBirth,          
      CM.MaritalStatus,          
      k1.kYCNUMBER aS AadharNumber,
      Cast(CM.JoinDate As Date) As JoinDate,          
      (Case When CM.DropOutDate IS NULL Then Null          
      Else Cast(CM.DropOutDate As Date) End) As DropOutDate,          
      (Case When COALESCE(CM.DropOutDate,'1900-01-01') ='1900-01-01' Then 'Active'          
      Else 'DropOut' End) As ClientStatus,          
      CNM.CenterID,          
      CNM.CenterMeetingDay,          
      CNM.StaffId As CenterHandled_StaffID,          
      UM.UserName As CenterHandled_StaffName,          
      Null As CenterStatus,          
      Cls.LoanProposalID,          
      Clp.ProposalDate,          
      Cls.ClientLoanID As RDLoanID,          
      Cls.ClientProductSequenceNo As SequenceID,          
      Cls.RDAccountNumber,          
      Cast(Cls.DisbursementDate As Date) As RD_OpenDate,          
      Cls.LoanAmountDisbursed As RD_Amount,       
        Cast(Clp.InterestRate As Decimal(10,2)) As InterestRate,  
    Cls.Tenure,          
      Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate,          
      (Case When Cls.LoanClosedDate is null Then Null          
      Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,          
      (Case When Cls.LoanClosedDate is null Then 'Active'          
        When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'          
        When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus,          
      Cls.Comments,          
    cast(NULL as varchar(50)) AS BussinessType,
    cast(NULL as varchar(50)) AS CAFlag,      
    cast(NULL as varchar(50)) AS AccountNumber,      
    cast(NULL as varchar(50)) AS BatchID,      
    cast(NULL as varchar(50)) As RDOpenStaffID,    
    cast(NULL as varchar(50)) As RDOpenStaffName,      
    cast(NULL as varchar(50)) AS ProductID,    
    cast(NULL as varchar(50)) AS PurposeID    
    From {source_catalog}.{source_schema}.`pragati-clientloansubscription` Cls -- `ptsmart-clientloansubscription`          
    Join {source_catalog}.{source_schema}.`ptsmart-clientloanproposal` Clp On Clp.LoanProposalID = Cls.LoanProposalID       
    Join {source_catalog}.{source_schema}.`ptsmart-clientmaster`  CM On CM.ClientID = Cls.ClientID         
    Join {source_catalog}.{source_schema}.`ptsmart-groupmaster` GM On GM.GroupID = CM.GroupID          
    Join {source_catalog}.{source_schema}.`ptsmart-centermaster` CNM On CNM.CenterID = GM.CenterID            
    Left Join {source_catalog}.{source_schema}.`ptsmart-usermaster`  UM ON UM.UserID = CNM.StaffID          
    LEFT Join {source_catalog}.{source_schema}.`ptsmart-kycmaster`  K1 On K1.TargetID = CM.TargetID and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M','Y')         
    Where Cls.ProductType Is Not Null          
    and (Cls.LoanClosedDate is null Or Cls.LoanClosedDate >= '{MTDStartDate}')
	
	
	
    UNION
	
	
	
    select 
    Distinct current_date() As ReportGenDate, 'BSS',      
    CM.BaselineCustomerID,      
    CM.CustomerID,      
    CM.CustomerName,      
    Cast(Clp1.ClientDOBAtDisbursement As Date) As DateOfBirth,
    Clp1.MaritalStatus, 
    k1.kYCNUMBER aS AadharNumber,
    Cast(CM.JoinDate As Date) As JoinDate,
    (Case When CM.DropOutDate is null Then Null      
      Else Cast(CM.DropOutDate As Date) End) As DropOutDate, 
    (Case When  CM.DropOutDate is null Then 'Active'      
      Else 'DropOut' End) As CustomerStatus,
      NULL as CenterID,
      CM.DisbursementDay As CenterMeetingDay,
      BM.UserID As Handled_StaffID,      
      UM.UserName As Handled_StaffName,  
      NULL as CenterStatus,
    Cls.LoanApplicationID,      
    Clp.LoanApplicationDate,      
    Cls.CustomerLoanID As RDLoanID,      
    Cls.CustomerProductSequenceNo As SequenceID,     
    Cls.RDAccountNumber,      
    Cast(Cls.DisbursementDate As Date) As RDOpenDate,
    Cls.LoanAmountDisbursed As RDAmount,      
    Cast(Clp.InterestRate As Decimal(10,2)) As ROI,  
    Cls.Tenure,    
    Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate, 
    (Case When Cls.LoanClosedDate is null Then Null      
    Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,  
    (Case When Cls.LoanClosedDate is null Then 'Active'      
          When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'      
          When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus, 
    Cls.Comments,
    CS.NatureOfBusiness As BussinessType,      
    BCM.CAFlag,      
    BRD.SBAccountNumber As AccountNumber,      
    CM.BatchID,      
    Cls.CreatedBy As RDOpenStaffID,    
    UM1.UserName As RDOpenStaffName,      
    Cls.ProductID,    
    Clp.PurposeID
    from {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` Cls
    join {source_catalog}.{source_schema}.`rlmsbizxtend-customerloanapplication`  CLP on Clp.LoanApplicationID = Cls.LoanApplicationID 
    join {source_catalog}.{source_schema}.`rlmsbizxtend-additionalloanapplicationdetails` Clp1 on Clp1.LoanApplicationID = Cls.LoanApplicationID
    join {source_catalog}.{source_schema}.`rlmsbizxtend-customermaster` CM on CM.CustomerID = Cls.CustomerID
    Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-baselinecustomermaster_h_view` BCM on BCM.CustomerID = CM.BaseLineCustomerID and BCM.ETL_IS_ACTIVE=1
    Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-batchmaster` BM on BM.BatchID = CM.BatchID
    Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-usermaster` UM on UM.UserID = BM.UserID 
    left join {source_catalog}.{source_schema}.`rlmsbizxtend-usermaster` UM1 on UM1.UserID = Cls.CreatedBy
    left join {source_catalog}.{source_schema}.`rlmsbizxtend-customershopdetails` CS on CS.CustomerID = CM.BaseLineCustomerID
    left join {source_catalog}.{source_schema}.`rlmsbizxtend-bankrelationdetails_h_view` BRD on BRD.CustomerID = CM.CustomerID and BRD.ETL_IS_ACTIVE=1
    left join {source_catalog}.{source_schema}.`rlmsbizxtend-kycmaster` K1 On K1.CustomerId = CM.BaselineCustomerId and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M')
    Where Cls.ProductType Is Not Null and ((Cls.LoanClosedDate is null) or Cls.LoanClosedDate >= '{MTDStartDate}' )
    ),


  CTE_CollectionExceptionLog_MAXDATE as
    (
      
  
    -- broadcast (CTE_RD_CLIENTLOANSUBSCRIPTION)
    Select A.ClientID,          
    Max(Cast(B.TransactionDate As Date)) As Max_TranDate          
    From CTE_RD_CLIENTLOANSUBSCRIPTION A          
    Join {source_catalog}.{source_schema}.`pragati-collectionexceptionlog` B On B.ClientID = A.ClientID          
    Group By A.ClientID          
    UNION
    Select A.ClientID,          
    Max(Cast(B.TransactionDate As Date)) As Max_TranDate          
    From CTE_RD_CLIENTLOANSUBSCRIPTION A          
    Join {source_catalog}.{source_schema}.`ptsmart-collectionexceptionlog` B On B.ClientID = A.ClientID          
    Group By A.ClientID          
    ),
--select * from CTE_CollectionExceptionLog_MAXDATE;

CTE_LoanCount AS (
      Select A.ClientID,          
      Count(Distinct B.ClientLoanID) As NoOfLoans          
    From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
    Join {source_catalog}.{source_schema}.`pragati-clientloansubscription` B On B.ClientID = A.ClientID          
    Where B.LoanClosedDate is null and B.ProductType Is Null   and B.ETL_IS_ACTIVE=1       
    Group By A.ClientID 
    union
    Select A.ClientID,          
      Count(Distinct B.ClientLoanID) As NoOfLoans          
    From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
    Join {source_catalog}.{source_schema}.`pragati-clientloansubscription` B On B.ClientID = A.ClientID  -- `ptsmart-clientloansubscription`      
    Where B.LoanClosedDate is null and B.ProductType Is Null          
    Group By A.ClientID 
    union 
    Select A.ClientID,          
      Count(Distinct B.customerloanid) As NoOfLoans          
    From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
    Join {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` B On B.customerid = A.ClientID          
    Where B.LoanClosedDate is null and B.ProductType Is Null          
    Group By A.ClientID 
    ),

     CTE_RD_DISBURSEMENTBASE AS 
    (
    SELECT A.*,C.Remarks,
    (Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
    D.NoOfLoans  
    FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
    LEFT JOIN CTE_CollectionExceptionLog_MAXDATE b ON b.CLIENTID=a.ClientID 
    LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-collectionexceptionlog` C On B.ClientID = C.ClientID  AND Cast(c.TransactionDate As Date) = B.Max_TranDate
    LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
    union
    SELECT A.*,C.Remarks,
    (Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
    D.NoOfLoans  
    FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
    LEFT JOIN CTE_CollectionExceptionLog_MAXDATE b ON b.CLIENTID=a.ClientID 
    LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-collectionexceptionlog` C On B.ClientID = C.ClientID  AND Cast(c.TransactionDate As Date) = B.Max_TranDate
    LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
    union
    SELECT A.*,b.Remarks,
    (Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
    D.NoOfLoans  
    FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
    LEFT JOIN {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` b ON b.Customerloanid=a.RDLoanID 
    LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
    ),
     /* Liabilites Disbursemetn facts BFIL */ 

    

/*Liabilities COllection fact BFIL*/

    CTE_RD_LEDGER
    AS
    (
    
    Select 
     /*+ BROADCAST(CTE_RD_DISBURSEMENTBASE)*/ 
    
    A.SBU,
    A.RDAccountNumber,    
      A.RDLoanID,  
      B.CreatedBy,     
      B.TransactionDate,  
      B.ValueDate,    
      B.DebitOrCredit,
      B.InstallmentNumber,      
      B.PrincipalAmount,    
      B.InterestAmount,    
      B.Amount    
    From CTE_RD_DISBURSEMENTBASE A  
    Join {source_catalog}.{source_schema}.`pragati-at_loanschedules` B On B.ClientID = A.ClientID and B.ClientLoanID = A.RDLoanID    
    Where Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then  Cast(current_date As Date)  Else A.RDClosedDate End)    
    Union
    /*MFI Coll*/
     
      Select
      /*+ BROADCAST(CTE_RD_DISBURSEMENTBASE)*/ 
       
     A.SBU,
      A.RDAccountNumber,          
      A.RDLoanID,      
      B.CreatedBy,   
      B.TransactionDate,      
      B.ValueDate,          
      B.DebitOrCredit, 
      B.InstallmentNumber,         
      B.PrincipalAmount,          
      B.InterestAmount,          
      B.Amount 
    From CTE_RD_DISBURSEMENTBASE A          
    Join {source_catalog}.{source_schema}.`pragati-at_loantransactions` B On  B.ClientID = A.ClientID
    and B.ClientLoanID = A.RDLoanID          
    Where
    Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then Cast(current_date As Date) Else A.RDClosedDate End)  
      UNION
      
      Select 
        /*+ BROADCAST(CTE_RD_DISBURSEMENTBASE)*/ 
         
       A.SBU,
     
      A.RDAccountNumber,          
      A.RDLoanID,  
      B.CreatedBy,      
      B.TransactionDate,      
      B.ValueDate,          
      B.DebitOrCredit,   
      B.InstallmentNumber,       
      B.PrincipalAmount,          
      B.InterestAmount,          
      B.Amount          
    From CTE_RD_DISBURSEMENTBASE A          
    Join {source_catalog}.{source_schema}.`ptsmart-accounttransactions` B On  B.ClientID = A.ClientID
    and B.ClientLoanID = A.RDLoanID          
    Where
    Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then Cast(current_date As Date) Else A.RDClosedDate End)  
    UNION
    
    select
     /*+ BROADCAST(CTE_RD_DISBURSEMENTBASE)*/ 
    
      A.SBU,
    A.RDAccountNumber,  
    A.RDLoanID,        
    B.CreatedBy,      
    B.TransactionDate,  
    B.ValueDate,        
    B.DebitOrCredit,    
    B.InstallmentNumber,
    B.PrincipalAmount,  
    B.InterestAmount,   
    B.Amount          
    from CTE_RD_DISBURSEMENTBASE A
    join {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` B on 
    B.CustomerID = A.CLIENTID and B.CustomerLoanID = A.RDLoanID
    Where Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then Cast(current_date()-1 As Date) Else A.RDClosedDate End)    
    ),
       /* BMS RD LEDGER SUMMARY*/
    CTE_RD_Ledger_Summary AS (
    Select        
      RDAccountNumber,          
      RDLoanID,          
      /* AsOn */          
      Sum(Case When DebitOrCredit ='D' Then 1 Else 0 End) As AsOnNoOfDues,          
      Sum(Case When DebitOrCredit ='C' and Amount > 0 Then 1 Else 0 End) As AsOnNoOfColls,          
      Sum(Case When DebitOrCredit ='D' Then Amount Else 0 End) As AsonDueAmount,          
      Sum(Case When DebitOrCredit ='C' and Amount > 0 Then Amount Else 0 End) As AsOnCollAmount,                    
      /* MTD */          
      Sum(Case When DebitOrCredit ='D' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') Then 1 Else 0 End) As MTDNoOfDues,          
      Sum(Case When DebitOrCredit ='C' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') and Amount > 0 Then 1 Else 0 End) As MTDNoOfColls,          
      Sum(Case When DebitOrCredit ='D' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') Then Amount Else 0 End) As MTDDueAmount,          
      Sum(Case When DebitOrCredit ='C' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') and Amount > 0 Then Amount Else 0 End) As MTDCollAmount,                 
      /* FTD */          
      Sum(Case When DebitOrCredit ='D' and (Cast(ValueDate As Date) = '{MTDEndDate}') Then Amount Else 0 End) As FTDDueAmount,          
      Sum(Case When DebitOrCredit ='C' and (Cast(ValueDate As Date) = '{MTDEndDate}') Then Amount Else 0 End) As FTDCollAmount,          
      /* RD Start/Last Repayment Date */          
      Min(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As RDStartDate,          
      Max(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As LastRepaymentDate,          
      /* Non-Starter RD Status */            
        Null As ActualLastEWI_CollDate,
        Null As AsOnSICollAmount,
        Null As AsOnCashCollAmount,
        Null As MTDSICollAmount,
        Null As MTDcashCollAmount,
        Null As FTDSICollAmount,
        Null As FTDCashCollAmount
    From CTE_RD_LEDGER where SBU in ('MFI','BMS')
    Group By RDAccountNumber,RDLoanID  
    union
    select
    RDAccountNumber,          
    RDLoanID,          
    /* AsOn */          
    Sum(Case When DebitOrCredit ='D' Then 1 Else 0 End) As AsOnNoOfDues,          
    Sum(Case When DebitOrCredit ='C' and Amount > 0 Then 1 Else 0 End) As AsOnNoOfColls,          
    Sum(Case When DebitOrCredit ='D' Then Amount Else 0 End) As AsonDueAmount,    
    sum(Case When DebitOrCredit ='C' then Amount else 0 End) As AsOnCollAmount,                  
    /* MTD */          
    Sum(Case When DebitOrCredit ='D' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') Then 1 Else 0 End) As MTDNoOfDues,          
    Sum(Case When DebitOrCredit ='C' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') and Amount > 0 Then 1 Else 0 End) As MTDNoOfColls,          
    Sum(Case When DebitOrCredit ='D' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') Then Amount Else 0 End) As MTDDueAmount,
    Sum(Case When DebitOrCredit ='C' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') and Amount > 0  Then Amount Else 0 End) As MTDCollAmount,          
    /* FTD */          
    Sum(Case When DebitOrCredit ='D' and (Cast(ValueDate As Date) = '{MTDEndDate}') Then Amount Else 0 End) As FTDDueAmount,          
    Sum(Case When DebitOrCredit ='C' and (Cast(ValueDate As Date) = '{MTDEndDate}') and Amount > 0 Then Amount Else 0 End) As FTDCollAmount,      
    /* RD Start/Last Repayment Date */          
    Min(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As RDStartDate,      
    Max(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As LastRepaymentDate,          
    /*For BSS additional columns*/
    Max(Case When DebitOrCredit ='C' Then ValueDate Else Null End) As ActualLastEWI_CollDate,    
    Sum(Case When CreatedBy = 'SI' and DebitOrCredit ='C' and Amount > 0 Then Amount Else 0 End) As AsOnSICollAmount,          
    Sum(Case When coalesce(CreatedBy,'NA') <> 'SI' and DebitOrCredit ='C' and Amount > 0 Then Amount Else 0 End) As AsOnCashCollAmount,          
    /*MTD SI and Cash*/
    Sum(Case When CreatedBy = 'SI' and DebitOrCredit ='C' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') and Amount > 0 Then Amount Else 0 End) As MTDSICollAmount,      
    Sum(Case When Coalesce(CreatedBy,'NA') <> 'SI' and DebitOrCredit ='C' and (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}') and Amount > 0 Then Amount Else 0 End) As MTDCashCollAmount,      
    /*FTD SI and Cash*/
    Sum(Case When CreatedBy = 'SI' and DebitOrCredit ='C' and (Cast(ValueDate As Date) = '{MTDEndDate}') and Amount > 0 Then Amount Else 0 End) As FTDSICollAmount,      
    Sum(Case When Coalesce(CreatedBy,'NA') <> 'SI' and DebitOrCredit ='C' and (Cast(ValueDate As Date) = '{MTDEndDate}') and Amount > 0 Then Amount Else 0 End) As FTDCashCollAmount
    from CTE_RD_LEDGER where SBU in ('BSS') 
    Group By RDAccountNumber,RDLoanID
    ),
    CTE_RD_MissedInstal
    as (
    Select RDAccountNumber,  
      RDLoanID,  
      Min(ValueDate) As FirstSIMissedRDInstlColl  
    From CTE_RD_LEDGER  
    Where DebitOrCredit ='C' and Amount = '0'   
    Group By RDAccountNumber,RDLoanID  
    ),
    CTE_RD_Ledger_MTDWeekSummary
    AS
    (Select RDAccountNumber,          
      RDLoanID,          
      ROUND(DATEDIFF(Cast(ValueDate As Date), DATE_TRUNC('MONTH', ValueDate))/7 + 1, 0) As WeekNo,          
      Sum(Amount) As WeekCollection          
    From CTE_RD_LEDGER          
    Where (Cast(ValueDate As Date) Between '{MTDStartDate}' and '{MTDEndDate}')          
    and DebitOrCredit ='C' and Amount > 0          
    Group by RDAccountNumber,RDLoanID,ROUND(DATEDIFF(Cast(ValueDate As Date), DATE_TRUNC('MONTH', ValueDate))/7 + 1, 0)
    ),
    /* Due,Coll,Arrear Updated Begins */ 
    CTE_BMS_RD_Ledger_Summary1
    (
    SELECT
     /*+ BROADCAST(CTE_RD_Ledger_MTDWeekSummary)*/ 
      A.*,         
      A.AsonDueAmount - AsOnCollAmount AS AsOnArrearAmount,          
        A.MTDDueAmount - A.MTDCollAmount AS MTDArrearAmount,          
        A.AsOnNoOfDues - A.AsOnNoOfColls AS AsOnArrearWeeks,          
        A.MTDNoOfDues - A.MTDNoOfColls AS MTDArrearWeeks,          
        (Case When Sign(A.AsOnCollAmount) = 0 Then 'Yes'          
                When Sign(A.AsOnCollAmount) = 1 Then 'No'          
                When Sign(A.AsOnCollAmount) = -1 Then Null End) as IsNon_StarterRD,     
        if(B1.WeekNo = 1 ,B1.WeekCollection,0) AS MTDWeek1_Coll,
        if(B1.WeekNo = 2 ,B1.WeekCollection,0) AS MTDWeek2_Coll,
        if(B1.WeekNo = 3 ,B1.WeekCollection,0) AS MTDWeek3_Coll,
        if(B1.WeekNo = 4 ,B1.WeekCollection,0) AS MTDWeek4_Coll,
        if(B1.WeekNo = 5 ,B1.WeekCollection,0) AS MTDWeek5_Coll,

        /*COALESCE(B1.WeekCollection,0) AS MTDWeek1_Coll,          
        COALESCE(B2.WeekCollection,0) AS MTDWeek2_Coll,          
        COALESCE(B3.WeekCollection,0) AS MTDWeek3_Coll,          
        COALESCE(B4.WeekCollection,0) AS MTDWeek4_Coll,          
        COALESCE(B5.WeekCollection,0) AS MTDWeek5_Coll ,*/
        D.FirstSIMissedRDInstlColl         
    From CTE_RD_Ledger_Summary A          
    Left Join CTE_RD_Ledger_MTDWeekSummary B1 On B1.RDAccountNumber = A.RDAccountNumber and B1.RDLoanID = A.RDLoanID /*and B1.WeekNo = 1          
    Left Join CTE_RD_Ledger_MTDWeekSummary B2 On B2.RDAccountNumber = A.RDAccountNumber and B2.RDLoanID = A.RDLoanID and B2.WeekNo = 2          
    Left Join CTE_RD_Ledger_MTDWeekSummary B3 On B3.RDAccountNumber = A.RDAccountNumber and B3.RDLoanID = A.RDLoanID and B3.WeekNo = 3          
    Left Join CTE_RD_Ledger_MTDWeekSummary B4 On B4.RDAccountNumber = A.RDAccountNumber and B4.RDLoanID = A.RDLoanID and B4.WeekNo = 4          
    Left Join CTE_RD_Ledger_MTDWeekSummary B5 On B5.RDAccountNumber = A.RDAccountNumber and B5.RDLoanID = A.RDLoanID and B5.WeekNo = 5  */
    LEFT JOIN CTE_RD_MissedInstal  D ON D.RDLoanID=a.RDLoanID
    )
    select * from CTE_BMS_RD_Ledger_Summary1""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
        MTDStartDate=MTDStartDate,
        MTDEndDate=MTDEndDate
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

try:
    df = spark.sql(query)
    logger(
        logger_level_info,
        f"liablilty_fact_bfil Query has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on liablilty_fact_bfil: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on liablilty_fact_bfil : ", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.liablilty_fact_bfil")

    logger(
        logger_level_info,
        f"liablilty_fact_bfil writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table liablilty_fact_bfil : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table liablilty_fact_bfil : ", str(e)
    )

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)