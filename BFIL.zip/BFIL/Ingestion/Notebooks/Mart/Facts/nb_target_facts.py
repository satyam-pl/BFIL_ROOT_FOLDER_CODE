# Databricks notebook source
# MAGIC %sql
# MAGIC  SET mart_catalog = '${dbutils.widgets.get("mart_catalog")}';
# MAGIC  SET mart_schema = '${dbutils.widgets.get("mart_schema")}';
# MAGIC  SET source_catalog = '${dbutils.widgets.get("source_catalog")}';
# MAGIC  SET source_schema = '${dbutils.widgets.get("source_schema")}';
# MAGIC  
# MAGIC
# MAGIC  SET StartDate = '2022-01-01';
# MAGIC  SET EndDate = DATE_SUB(CURRENT_DATE(), 1);
# MAGIC
# MAGIC CREATE OR REPLACE TABLE ${mart_catalog}.${mart_schema}.targetfacts
# MAGIC WITH T_SJ_Enrolment_BSP2 AS
# MAGIC (SELECT 
# MAGIC     A.HierarchyId, 
# MAGIC     A.TargetId, 
# MAGIC     A.TargetCode, 
# MAGIC     A.TargetDate, 
# MAGIC     B.ClientOrSpouse, 
# MAGIC     B.KYCType, 
# MAGIC     B.IseKYCStatus,
# MAGIC     B.BCMStatus,
# MAGIC     CASE
# MAGIC         WHEN B.ClientOrSpouse = 'M' AND B.IseKYCStatus = '1' AND B.KYCType = 'IDP6' THEN 'A'
# MAGIC         WHEN B.ClientOrSpouse = 'M' AND B.IseKYCStatus = '0' AND B.KYCType = 'IDP6' AND B.BCMStatus = 'A' THEN 'D'
# MAGIC         ELSE NULL
# MAGIC     END AS BCM_Status,
# MAGIC     A.IsBCMApproved, 
# MAGIC     A.ApprovalStatus, 
# MAGIC     A.Caste, 
# MAGIC     A.NumberOfFamilyMembers, 
# MAGIC     A.MemberEducationId, 
# MAGIC     A.MemberOccupationId, 
# MAGIC     A.HOUSECONSTRUCTIONQUALITY, 
# MAGIC     A.MotherMaidenName, 
# MAGIC     A.Religion, 
# MAGIC     A.HouseType, 
# MAGIC     A.MemberPhotoPath, 
# MAGIC     A.MaritalStatus, 
# MAGIC     A.CBUpdateID
# MAGIC FROM 
# MAGIC     -- ${source_catalog}.${source_schema}.`ptsmart-targetmaster` AS A
# MAGIC     (SELECT * FROM ${source_catalog}.${source_schema}.`pragati-targetmaster` WHERE ETL_IS_ACTIVE = '1')  AS A
# MAGIC LEFT JOIN 
# MAGIC     -- ${source_catalog}.${source_schema}.`ptsmart-kycmaster`  AS B
# MAGIC     (SELECT * FROM ${source_catalog}.${source_schema}.`pragati-kycmaster` WHERE ETL_IS_ACTIVE = '1')  AS B
# MAGIC ON 
# MAGIC     A.TargetID = B.TargetID
# MAGIC WHERE 
# MAGIC     cast(A.TargetDate as date) BETWEEN '2023-05-01' AND date_sub(current_date(), 1)),
# MAGIC 	
# MAGIC 	T_SJ_Enrolment_BSP as (
# MAGIC
# MAGIC SELECT DISTINCT
# MAGIC     HierarchyId, 
# MAGIC     TargetId, 
# MAGIC     TargetCode, 
# MAGIC     TargetDate, 
# MAGIC     ClientOrSpouse, 
# MAGIC     KYCType, 
# MAGIC     IseKYCStatus,
# MAGIC     BCMStatus,
# MAGIC     CASE
# MAGIC         WHEN ClientOrSpouse = 'M' AND BCM_Status IS NULL AND BCMStatus = 'A' AND KYCType <> 'IDP6' THEN 'A'
# MAGIC         WHEN ClientOrSpouse = 'M' AND BCM_Status IS NULL AND BCMStatus = 'N' AND KYCType <> 'IDP6' THEN 'N'
# MAGIC         ELSE BCM_Status
# MAGIC     END AS BCM_Status,
# MAGIC     IsBCMApproved, 
# MAGIC     ApprovalStatus, 
# MAGIC     Caste, 
# MAGIC     NumberOfFamilyMembers, 
# MAGIC     MemberEducationId, 
# MAGIC     MemberOccupationId, 
# MAGIC     HOUSECONSTRUCTIONQUALITY, 
# MAGIC     MotherMaidenName, 
# MAGIC     Religion, 
# MAGIC     HouseType, 
# MAGIC     MemberPhotoPath, 
# MAGIC     MaritalStatus, 
# MAGIC     CBUpdateID
# MAGIC from T_SJ_Enrolment_BSP2),
# MAGIC
# MAGIC -- select * from T_SJ_Enrolment_BSP
# MAGIC
# MAGIC -- SELECT count(*) from `T_SJ_Enrolment_BSP`;
# MAGIC  TargetSummary AS (
# MAGIC     SELECT
# MAGIC         TargetID,
# MAGIC         COUNT(TargetID) AS NoOfTargets,
# MAGIC         SUM(CASE WHEN BCM_Status = 'A' THEN 1 ELSE 0 END) AS NoOfBCMApproved
# MAGIC     FROM `T_SJ_Enrolment_BSP`
# MAGIC     WHERE ClientOrSpouse = 'M'
# MAGIC     GROUP BY TargetID
# MAGIC --${mart_catalog}.${mart_schema}.`bfil-datamart-disbursementfacts` ),
# MAGIC ),
# MAGIC
# MAGIC T_SJ_Enrolment_BSP_Distinct AS
# MAGIC (Select Distinct HierarchyID,
# MAGIC 		TargetID,
# MAGIC 		TargetCode,
# MAGIC 		date_format(TargetDate,'dd-MMM-yyyy') As TargetDate,
# MAGIC 		CBUpdateID,
# MAGIC 		Cast(Null As STRING) As CBStatus,
# MAGIC 		Cast(Null As STRING) As Final_BCMStatus,
# MAGIC 		IsBCMApproved,
# MAGIC 		ApprovalStatus,
# MAGIC 		Cast(Null As TINYINT) As IsBCMImport,
# MAGIC 		Cast(Null As STRING) As BSPImport_Status,
# MAGIC 		Cast(Null As STRING) As BSPEnrol_Status,
# MAGIC 		Cast(Null As STRING) As TargetCurrentStatus,
# MAGIC 		Cast(Null As STRING) As Remarks,
# MAGIC 		Cast(Null As STRING) As BranchID,
# MAGIC 		Cast(Null As STRING) As BranchName,
# MAGIC 		Cast(Null As STRING) As Region,
# MAGIC 		Cast(Null As STRING) As Area,
# MAGIC 		Cast(Null As STRING) As ZoneName
# MAGIC 	From `T_SJ_Enrolment_BSP`),
# MAGIC
# MAGIC T_SJ_Enrolment_BSP1 AS 
# MAGIC (SELECT DISTINCT
# MAGIC     A.HierarchyID,
# MAGIC     A.TargetID,
# MAGIC     A.TargetCode,
# MAGIC     A.TargetDate,
# MAGIC     A.CBUpdateID,
# MAGIC     Cast(Null As STRING) As CBStatus,
# MAGIC     A.IsBCMApproved,
# MAGIC     A.ApprovalStatus,
# MAGIC     CAST(NULL AS TINYINT) AS IsBCMImport,
# MAGIC     Cast(Null As STRING) As BSPImport_Status,
# MAGIC 	Cast(Null As STRING) As BSPEnrol_Status,
# MAGIC     CAST(NULL As STRING) AS TargetCurrentStatus,
# MAGIC     CAST(NULL As STRING) AS Remarks,
# MAGIC     B.BranchID AS BranchID,
# MAGIC     B.BranchName AS BranchName,
# MAGIC     B.Region,
# MAGIC     B.Area AS Area,
# MAGIC     B.Zone AS ZoneName,
# MAGIC     CASE
# MAGIC         WHEN C.NoOfTargets = C.NoOfBCMApproved THEN 'A'
# MAGIC         ELSE 'N'
# MAGIC     END AS Final_BCMStatus
# MAGIC FROM T_SJ_Enrolment_BSP_Distinct A
# MAGIC LEFT JOIN ${mart_catalog}.${mart_schema}.`bfil-p_hierarchy_sop` B ON B.HierarchyID = A.HierarchyID
# MAGIC LEFT JOIN TargetSummary C ON C.TargetID = A.TargetID)
# MAGIC
# MAGIC SELECT DISTINCT
# MAGIC     A.HierarchyID,
# MAGIC     A.TargetID,
# MAGIC     A.TargetCode,
# MAGIC     A.TargetDate,
# MAGIC     A.CBUpdateID,
# MAGIC     E.CBStatus AS CBStatus,
# MAGIC     A.IsBCMApproved,
# MAGIC     A.ApprovalStatus,
# MAGIC     CASE
# MAGIC         WHEN COALESCE(F.ApprovalStatus, '') <> 'R' AND COALESCE(F.BCMStatus,'N') = 'N' AND (COALESCE(CAST(F.IseKYCStatus AS STRING),'') = '' OR F.IseKYCStatus = 0) AND A.CBStatus = 'A' AND COALESCE(Caste, '') != '' AND COALESCE(NumberOfFamilyMembers, 0) != '' AND COALESCE(MemberEducationId, '') != '' AND COALESCE(MemberOccupationId, '') != '' and COALESCE(HOUSECONSTRUCTIONQUALITY, '') != ''
# MAGIC 		and COALESCE(MotherMaidenName, '') != '' and COALESCE(Religion, '') != ''
# MAGIC 		and COALESCE(HouseType, '') != '' and COALESCE(MemberPhotoPath, '') != ''
# MAGIC 		and COALESCE(MaritalStatus,'') !='' and COALESCE(F.ApprovalStatus,'') != 'R' THEN 1 ELSE 0
# MAGIC     END AS IsBCMImport,
# MAGIC     CASE 
# MAGIC         WHEN Cast(B.CreatedDateTime As Date) <= date_sub(current_date(), 1) THEN 'Enrol_Imported' 
# MAGIC         WHEN Cast(B.CreatedDateTime As Date) > date_sub(current_date(), 1) THEN 'Enrol_NotImported'
# MAGIC     END AS BSPImport_Status,
# MAGIC     CASE
# MAGIC         WHEN Cast(C.CreatedDateTime As Date) <= date_sub(current_date(), 1) THEN 'Enrol_Auto'
# MAGIC         WHEN Cast(C.CreatedDateTime As Date) > date_sub(current_date(), 1) AND Cast(D.CreatedDateTime As Date) <= date_sub(current_date(), 1)
# MAGIC         THEN 'Enrol_Manual'
# MAGIC         WHEN Cast(C.CreatedDateTime As Date) > date_sub(current_date(), 1) AND Cast(D.CreatedDateTime As Date) > date_sub(current_date(), 1)
# MAGIC         THEN 'Awaiting to Import'
# MAGIC         ELSE NULL
# MAGIC     END AS BSPEnrol_Status,
# MAGIC     CASE
# MAGIC         WHEN A.Final_BCMStatus = 'A' AND A.BSPImport_Status = 'Enrol_Imported' AND A.BSPEnrol_Status IN ('Enrol_Auto') THEN 'Auth Auto Done But GRT Not Done'
# MAGIC         WHEN A.Final_BCMStatus='A' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Manual') THEN 'Auth Manual Done But GRT Not Done'
# MAGIC         WHEN A.Final_BCMStatus='N' and A.BSPImport_Status ='Enrol_NotImported' and A.BSPEnrol_Status In ('Awaiting to Import')
# MAGIC 		and A.CBStatus = 'A' THEN 'CB Success But BCM Pending'
# MAGIC         WHEN A.Final_BCMStatus='A' and A.BSPImport_Status ='Enrol_NotImported' and A.BSPEnrol_Status In ('Awaiting to Import') THEN 'BCM Success But BSP Import Pending'
# MAGIC         WHEN A.Final_BCMStatus='N' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Auto') THEN 'BCM Failed But Auth Auto Done'
# MAGIC         WHEN A.Final_BCMStatus='N' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Manual') THEN 'BCM Failed But Auth Manual Done'
# MAGIC         WHEN A.Remarks IS NULL THEN A.TargetCurrentStatus
# MAGIC         WHEN (A.IsBCMApproved IS NULL  Or A.IsBCMApproved <> 1) and A.Final_BCMStatus='A' and A.BSPImport_Status ='Enrol_Imported' AND A.BSPEnrol_Status In ('Enrol_Auto') THEN 'Auth Auto Done Pragati Not Imported'
# MAGIC         WHEN (A.IsBCMApproved IS NULL Or A.IsBCMApproved <> 1) and A.Final_BCMStatus='A' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Manual') THEN 'Auth Manual Done Pragati Not Imported'
# MAGIC         WHEN A.ApprovalStatus ='R' AND A.TargetCurrentStatus IS NULL THEN 'TD Rejected'
# MAGIC         WHEN COALESCE(A.CBUpdateID,'') ='' AND A.TargetCurrentStatus IS NULL THEN 'CB Pending'
# MAGIC         WHEN (COALESCE(A.CBStatus,'') = '' OR A.CBStatus <>'A') AND A.TargetCurrentStatus IS NULL THEN 'CB Rejected'
# MAGIC         WHEN A.TargetCurrentStatus = 'CB Success' AND A.IsBCMImport = 0 THEN 'Partial TD'
# MAGIC         ELSE A.Remarks
# MAGIC     END AS Remarks,
# MAGIC     CASE 
# MAGIC         WHEN A.ApprovalStatus ='R' AND A.TargetCurrentStatus IS NULL THEN 'TD Rejected'
# MAGIC         WHEN COALESCE(A.CBUpdateID,'') ='' AND A.TargetCurrentStatus IS NULL THEN 'CB Pending'
# MAGIC         WHEN (COALESCE(A.CBStatus,'') = '' OR A.CBStatus <>'A') AND A.TargetCurrentStatus IS NULL THEN 'CB Rejected'
# MAGIC         WHEN A.TargetCurrentStatus IS NULL THEN (
# MAGIC             CASE WHEN A.Remarks = 'Auth Auto Done But GRT Not Done' Then 'Authorization Done_Auto'
# MAGIC                 WHEN A.Remarks = 'Auth Manual Done But GRT Not Done' Then 'Authorization Done_Manual'
# MAGIC                 WHEN A.Remarks = 'Auth Auto Done Pragati Not Imported' Then 'Authorization Done_Auto Pragati Not Imported'
# MAGIC                 WHEN A.Remarks = 'Auth Manual Done Pragati Not Imported' Then 'Authorization Done_Manual Pragati Not Imported'
# MAGIC                 WHEN A.Remarks = 'CB Success But BCM Pending'  Then 'CB Success'
# MAGIC                 WHEN A.Remarks = 'BCM Success But BSP Import Pending' Then 'BCM Approved'
# MAGIC                 WHEN A.Remarks = 'BCM Failed But Auth Auto Done'  Then 'BCM Failed - Auth Done_Auto'
# MAGIC                 WHEN A.Remarks = 'BCM Failed But Auth Manual Done'  Then 'BCM Failed - Auth Done_Manual' END
# MAGIC         )
# MAGIC         WHEN A.TargetCurrentStatus = 'CB Success' AND A.IsBCMImport = 0 THEN 'Partial TD'
# MAGIC         ELSE A.TargetCurrentStatus 
# MAGIC     END AS TargetCurrentStatus,
# MAGIC     A.BranchID,
# MAGIC     A.BranchName,
# MAGIC     A.Region,
# MAGIC     A.Area,
# MAGIC     A.ZoneName,
# MAGIC     A.Final_BCMStatus
# MAGIC FROM T_SJ_Enrolment_BSP1 A
# MAGIC LEFT JOIN ${source_catalog}.${source_schema}.`cashlessdisburs-cl_importcustomerauthdata` B ON B.TargetID = A.TargetID
# MAGIC LEFT JOIN ${source_catalog}.${source_schema}.`cashlessdisburs-cl_customerenrollmentauto` C ON C.TargetID = A.TargetID
# MAGIC LEFT JOIN ${source_catalog}.${source_schema}.`cashlessdisburs-cl_customerenrollmentmanual` D ON D.TargetID = A.TargetID
# MAGIC LEFT JOIN (SELECT * FROM ${source_catalog}.${source_schema}.`pragati-creditbureauupdate` WHERE ETL_IS_ACTIVE = '1') E ON E.CBUpdateID = A.CBUpdateID
# MAGIC LEFT JOIN `T_SJ_Enrolment_BSP` F ON F.TargetID = A.TargetID;
# MAGIC
# MAGIC
# MAGIC --SELECT count(*) from `T_SJ_Enrolment_BSP1`;