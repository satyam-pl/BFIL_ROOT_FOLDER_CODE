# Databricks notebook source
# MAGIC %sql
# MAGIC SET mart_catalog = '${dbutils.widgets.get("mart_catalog")}';
# MAGIC SET mart_schema = '${dbutils.widgets.get("mart_schema")}';
# MAGIC SET source_catalog = '${dbutils.widgets.get("source_catalog")}';
# MAGIC SET source_schema = '${dbutils.widgets.get("source_schema")}';
# MAGIC
# MAGIC Create or replace table ${mart_catalog}.${mart_schema}.liablilty_fact_bfil
# MAGIC WITH CTE_RD_CLIENTLOANSUBSCRIPTION As       
# MAGIC (
# MAGIC   Select Distinct CURRENT_DATE() As ReportGenDate,'MFI' As SBU,          
# MAGIC   CM.TargetID,          
# MAGIC   CM.ClientID,                  
# MAGIC   CM.ClientName,          
# MAGIC   Cast(CM.DateOfBirth As Date) As DateOfBirth,          
# MAGIC   CM.MaritalStatus,          
# MAGIC   k1.kYCNUMBER aS AadharNumber,
# MAGIC   Cast(CM.JoinDate As Date) As JoinDate,          
# MAGIC   (Case When CM.DropOutDate IS NULL Then Null          
# MAGIC   Else Cast(CM.DropOutDate As Date) End) As DropOutDate,          
# MAGIC   (Case When COALESCE(CM.DropOutDate,'1900-01-01') ='1900-01-01' Then 'Active'          
# MAGIC   Else 'DropOut' End) As ClientStatus,          
# MAGIC   CNM.CenterID,          
# MAGIC   CNM.CenterMeetingDay,          
# MAGIC   CNM.StaffId As CenterHandled_StaffID,          
# MAGIC   UM.UserName As CenterHandled_StaffName,          
# MAGIC   Null As CenterStatus,          
# MAGIC   Cls.LoanProposalID,          
# MAGIC   Clp.ProposalDate,          
# MAGIC   Cls.ClientLoanID As RDLoanID,          
# MAGIC   Cls.ClientProductSequenceNo As SequenceID,          
# MAGIC   Cls.RDAccountNumber,          
# MAGIC   Cast(Cls.DisbursementDate As Date) As RD_OpenDate,          
# MAGIC   Cls.LoanAmountDisbursed As RD_Amount,       
# MAGIC     Cast(Clp.InterestRate As Decimal(10,2)) As InterestRate,  
# MAGIC  Cls.Tenure,          
# MAGIC   Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate,          
# MAGIC   (Case When Cls.LoanClosedDate is null Then Null          
# MAGIC   Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,          
# MAGIC   (Case When Cls.LoanClosedDate is null Then 'Active'          
# MAGIC      When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'          
# MAGIC      When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus,          
# MAGIC   Cls.Comments,        
# MAGIC
# MAGIC cast(NULL as varchar(50)) AS BussinessType,
# MAGIC cast(NULL as varchar(50)) AS CAFlag,      
# MAGIC cast(NULL as varchar(50)) AS AccountNumber,      
# MAGIC cast(NULL as varchar(50)) AS BatchID,      
# MAGIC cast(NULL as varchar(50)) As RDOpenStaffID,    
# MAGIC cast(NULL as varchar(50)) As RDOpenStaffName,      
# MAGIC cast(NULL as varchar(50)) AS ProductID,    
# MAGIC cast(NULL as varchar(50)) AS PurposeID
# MAGIC        
# MAGIC From ${source_catalog}.${source_schema}.`pragati-clientloansubscription` Cls          
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-clientloanproposal_h_view` Clp On Clp.LoanProposalID = Cls.LoanProposalID   and Clp.ETL_IS_ACTIVE=1       
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-clientmaster`  CM On CM.ClientID = Cls.ClientID    and  CM.ETL_IS_ACTIVE=1      
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-groupmaster` GM On GM.GroupID = CM.GroupID         and GM.ETL_IS_ACTIVE=1 
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-centermaster` CNM On CNM.CenterID = GM.CenterID    and CNM.ETL_IS_ACTIVE=1      
# MAGIC Left Join ${source_catalog}.${source_schema}.`pragatimain-usermaster`  UM ON UM.UserID = CNM.StaffID          and UM.ETL_IS_ACTIVE=1
# MAGIC LEFT Join ${source_catalog}.${source_schema}.`pragati-kycmaster`  K1 On K1.TargetID = CM.TargetID and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M','Y')   and K1.ETL_IS_ACTIVE=1       
# MAGIC Where Cls.ProductType Is Not Null          
# MAGIC and (Cls.LoanClosedDate IS NULL OR Cls.LoanClosedDate >= CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE))
# MAGIC
# MAGIC and Cls.ETL_IS_ACTIVE=1
# MAGIC
# MAGIC   UNION 
# MAGIC   Select Distinct CURRENT_DATE() As ReportGenDate,'BMS',          
# MAGIC   CM.TargetID,          
# MAGIC   CM.ClientID,                  
# MAGIC   CM.ClientName,          
# MAGIC   Cast(CM.DateOfBirth As Date) As DateOfBirth,          
# MAGIC   CM.MaritalStatus,          
# MAGIC   k1.kYCNUMBER aS AadharNumber,
# MAGIC   Cast(CM.JoinDate As Date) As JoinDate,          
# MAGIC   (Case When CM.DropOutDate IS NULL Then Null          
# MAGIC   Else Cast(CM.DropOutDate As Date) End) As DropOutDate,          
# MAGIC   (Case When COALESCE(CM.DropOutDate,'1900-01-01') ='1900-01-01' Then 'Active'          
# MAGIC   Else 'DropOut' End) As ClientStatus,          
# MAGIC   CNM.CenterID,          
# MAGIC   CNM.CenterMeetingDay,          
# MAGIC   CNM.StaffId As CenterHandled_StaffID,          
# MAGIC   UM.UserName As CenterHandled_StaffName,          
# MAGIC   Null As CenterStatus,          
# MAGIC   Cls.LoanProposalID,          
# MAGIC   Clp.ProposalDate,          
# MAGIC   Cls.ClientLoanID As RDLoanID,          
# MAGIC   Cls.ClientProductSequenceNo As SequenceID,          
# MAGIC   Cls.RDAccountNumber,          
# MAGIC   Cast(Cls.DisbursementDate As Date) As RD_OpenDate,          
# MAGIC   Cls.LoanAmountDisbursed As RD_Amount,       
# MAGIC     Cast(Clp.InterestRate As Decimal(10,2)) As InterestRate,  
# MAGIC  Cls.Tenure,          
# MAGIC   Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate,          
# MAGIC   (Case When Cls.LoanClosedDate is null Then Null          
# MAGIC   Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,          
# MAGIC   (Case When Cls.LoanClosedDate is null Then 'Active'          
# MAGIC      When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'          
# MAGIC      When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus,          
# MAGIC   Cls.Comments,          
# MAGIC cast(NULL as varchar(50)) AS BussinessType,
# MAGIC cast(NULL as varchar(50)) AS CAFlag,      
# MAGIC cast(NULL as varchar(50)) AS AccountNumber,      
# MAGIC cast(NULL as varchar(50)) AS BatchID,      
# MAGIC cast(NULL as varchar(50)) As RDOpenStaffID,    
# MAGIC cast(NULL as varchar(50)) As RDOpenStaffName,      
# MAGIC cast(NULL as varchar(50)) AS ProductID,    
# MAGIC cast(NULL as varchar(50)) AS PurposeID    
# MAGIC
# MAGIC From ${source_catalog}.${source_schema}.`ptsmart-clientloansubscription` Cls          
# MAGIC Join ${source_catalog}.${source_schema}.`ptsmart-clientloanproposal` Clp On Clp.LoanProposalID = Cls.LoanProposalID       
# MAGIC Join ${source_catalog}.${source_schema}.`ptsmart-clientmaster`  CM On CM.ClientID = Cls.ClientID         
# MAGIC Join ${source_catalog}.${source_schema}.`ptsmart-groupmaster` GM On GM.GroupID = CM.GroupID          
# MAGIC Join ${source_catalog}.${source_schema}.`ptsmart-centermaster` CNM On CNM.CenterID = GM.CenterID            
# MAGIC Left Join ${source_catalog}.${source_schema}.`ptsmart-usermaster`  UM ON UM.UserID = CNM.StaffID          
# MAGIC LEFT Join ${source_catalog}.${source_schema}.`ptsmart-kycmaster`  K1 On K1.TargetID = CM.TargetID and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M','Y')         
# MAGIC Where Cls.ProductType Is Not Null          
# MAGIC and (Cls.LoanClosedDate IS NULL OR Cls.LoanClosedDate >= CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE))
# MAGIC
# MAGIC
# MAGIC
# MAGIC UNION
# MAGIC select 
# MAGIC Distinct current_date() As ReportGenDate, 'BSS',      
# MAGIC CM.BaselineCustomerID,      
# MAGIC CM.CustomerID,      
# MAGIC CM.CustomerName,      
# MAGIC Cast(Clp1.ClientDOBAtDisbursement As Date) As DateOfBirth,
# MAGIC Clp1.MaritalStatus, 
# MAGIC  k1.kYCNUMBER aS AadharNumber,
# MAGIC Cast(CM.JoinDate As Date) As JoinDate,
# MAGIC (Case When CM.DropOutDate is null Then Null      
# MAGIC    Else Cast(CM.DropOutDate As Date) End) As DropOutDate, 
# MAGIC (Case When  CM.DropOutDate is null Then 'Active'      
# MAGIC    Else 'DropOut' End) As CustomerStatus,
# MAGIC    NULL as CenterID,
# MAGIC    CM.DisbursementDay As CenterMeetingDay,
# MAGIC    BM.UserID As Handled_StaffID,      
# MAGIC    UM.UserName As Handled_StaffName,  
# MAGIC    NULL as CenterStatus,
# MAGIC Cls.LoanApplicationID,      
# MAGIC Clp.LoanApplicationDate,      
# MAGIC Cls.CustomerLoanID As RDLoanID,      
# MAGIC Cls.CustomerProductSequenceNo As SequenceID,     
# MAGIC Cls.RDAccountNumber,      
# MAGIC Cast(Cls.DisbursementDate As Date) As RDOpenDate,
# MAGIC Cls.LoanAmountDisbursed As RDAmount,      
# MAGIC Cast(Clp.InterestRate As Decimal(10,2)) As ROI,  
# MAGIC Cls.Tenure,    
# MAGIC Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate, 
# MAGIC (Case When Cls.LoanClosedDate is null Then Null      
# MAGIC Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,  
# MAGIC (Case When Cls.LoanClosedDate is null Then 'Active'      
# MAGIC       When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'      
# MAGIC       When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus, 
# MAGIC Cls.Comments,
# MAGIC CS.NatureOfBusiness As BussinessType,      
# MAGIC BCM.CAFlag,      
# MAGIC BRD.SBAccountNumber As AccountNumber,      
# MAGIC CM.BatchID,      
# MAGIC Cls.CreatedBy As RDOpenStaffID,    
# MAGIC UM1.UserName As RDOpenStaffName,      
# MAGIC Cls.ProductID,    
# MAGIC Clp.PurposeID
# MAGIC
# MAGIC from ${source_catalog}.${source_schema}.`rlmsbizxtend-customerloandisbursement` Cls
# MAGIC join ${source_catalog}.${source_schema}.`rlmsbizxtend-customerloanapplication`  CLP on Clp.LoanApplicationID = Cls.LoanApplicationID 
# MAGIC join ${source_catalog}.${source_schema}.`rlmsbizxtend-additionalloanapplicationdetails` Clp1 on Clp1.LoanApplicationID = Cls.LoanApplicationID
# MAGIC join ${source_catalog}.${source_schema}.`rlmsbizxtend-customermaster` CM on CM.CustomerID = Cls.CustomerID
# MAGIC Left Join ${source_catalog}.${source_schema}.`rlmsbizxtend-baselinecustomermaster_h_view` BCM on BCM.CustomerID = CM.BaseLineCustomerID and BCM.ETL_IS_ACTIVE=1
# MAGIC Left Join ${source_catalog}.${source_schema}.`rlmsbizxtend-batchmaster` BM on BM.BatchID = CM.BatchID
# MAGIC Left Join ${source_catalog}.${source_schema}.`rlmsbizxtend-usermaster` UM on UM.UserID = BM.UserID 
# MAGIC left join ${source_catalog}.${source_schema}.`rlmsbizxtend-usermaster` UM1 on UM1.UserID = Cls.CreatedBy
# MAGIC left join ${source_catalog}.${source_schema}.`rlmsbizxtend-customershopdetails` CS on CS.CustomerID = CM.BaseLineCustomerID
# MAGIC left join ${source_catalog}.${source_schema}.`rlmsbizxtend-bankrelationdetails_h_view` BRD on BRD.CustomerID = CM.CustomerID and BRD.ETL_IS_ACTIVE=1
# MAGIC left join ${source_catalog}.${source_schema}.`rlmsbizxtend-kycmaster` K1 On K1.CustomerId = CM.BaselineCustomerId and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M')
# MAGIC Where(Cls.LoanClosedDate IS NULL OR Cls.LoanClosedDate >= CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE))
# MAGIC ),
# MAGIC
# MAGIC
# MAGIC
# MAGIC /* BMS RD MAX TRANDATE  FOR EXCEPTION LOG REMARKS*/
# MAGIC CTE_CollectionExceptionLog_MAXDATE aS
# MAGIC (
# MAGIC Select A.ClientID,          
# MAGIC Max(Cast(B.TransactionDate As Date)) As Max_TranDate          
# MAGIC From CTE_RD_CLIENTLOANSUBSCRIPTION A          
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-collectionexceptionlog` B On B.ClientID = A.ClientID          
# MAGIC Group By A.ClientID          
# MAGIC
# MAGIC  UNION
# MAGIC
# MAGIC Select A.ClientID,          
# MAGIC Max(Cast(B.TransactionDate As Date)) As Max_TranDate          
# MAGIC From CTE_RD_CLIENTLOANSUBSCRIPTION A          
# MAGIC Join ${source_catalog}.${source_schema}.`ptsmart-collectionexceptionlog` B On B.ClientID = A.ClientID          
# MAGIC Group By A.ClientID          
# MAGIC ),
# MAGIC
# MAGIC /* FOR NO OF LOANS */
# MAGIC
# MAGIC CTE_LoanCount AS (
# MAGIC
# MAGIC   Select A.ClientID,          
# MAGIC   Count(Distinct B.ClientLoanID) As NoOfLoans          
# MAGIC From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-clientloansubscription` B On B.ClientID = A.ClientID          
# MAGIC Where B.LoanClosedDate is null and B.ProductType Is Null   and B.ETL_IS_ACTIVE=1       
# MAGIC Group By A.ClientID 
# MAGIC union
# MAGIC Select A.ClientID,          
# MAGIC   Count(Distinct B.ClientLoanID) As NoOfLoans          
# MAGIC From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
# MAGIC Join ${source_catalog}.${source_schema}.`ptsmart-clientloansubscription` B On B.ClientID = A.ClientID          
# MAGIC Where B.LoanClosedDate is null and B.ProductType Is Null          
# MAGIC Group By A.ClientID 
# MAGIC union 
# MAGIC Select A.ClientID,          
# MAGIC   Count(Distinct B.customerloanid) As NoOfLoans          
# MAGIC From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
# MAGIC Join ${source_catalog}.${source_schema}.`rlmsbizxtend-customerloandisbursement` B On B.customerid = A.ClientID          
# MAGIC Where B.LoanClosedDate is null and B.ProductType Is Null          
# MAGIC Group By A.ClientID 
# MAGIC
# MAGIC ),
# MAGIC
# MAGIC CTE_RD_DISBURSEMENTBASE AS 
# MAGIC (
# MAGIC SELECT A.*,C.Remarks,
# MAGIC (Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
# MAGIC D.NoOfLoans  
# MAGIC  FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
# MAGIC LEFT JOIN CTE_CollectionExceptionLog_MAXDATE b ON b.CLIENTID=a.ClientID 
# MAGIC LEFT JOIN ${source_catalog}.${source_schema}.`ptsmart-collectionexceptionlog` C On B.ClientID = C.ClientID  AND Cast(c.TransactionDate As Date) = B.Max_TranDate
# MAGIC LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
# MAGIC union
# MAGIC SELECT A.*,C.Remarks,
# MAGIC (Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
# MAGIC D.NoOfLoans  
# MAGIC  FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
# MAGIC LEFT JOIN CTE_CollectionExceptionLog_MAXDATE b ON b.CLIENTID=a.ClientID 
# MAGIC LEFT JOIN ${source_catalog}.${source_schema}.`ptsmart-collectionexceptionlog` C On B.ClientID = C.ClientID  AND Cast(c.TransactionDate As Date) = B.Max_TranDate
# MAGIC LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
# MAGIC union
# MAGIC SELECT A.*,b.Remarks,
# MAGIC (Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
# MAGIC D.NoOfLoans  
# MAGIC  FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
# MAGIC LEFT JOIN ${source_catalog}.${source_schema}.`rlmsbizxtend-customerloandisbursement` b ON b.Customerloanid=a.RDLoanID 
# MAGIC LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
# MAGIC ),
# MAGIC
# MAGIC --select * from CTE_RD_DISBURSEMENTBASE;
# MAGIC
# MAGIC /* BMS RD LEDGER*/
# MAGIC
# MAGIC CTE_RD_LEDGER
# MAGIC AS
# MAGIC (
# MAGIC /*MFI Dues*/
# MAGIC Select A.SBU,
# MAGIC A.RDAccountNumber,    
# MAGIC   A.RDLoanID,  
# MAGIC   B.CreatedBy,     
# MAGIC   B.TransactionDate,  
# MAGIC   B.ValueDate,    
# MAGIC   B.DebitOrCredit,
# MAGIC   B.InstallmentNumber,      
# MAGIC   B.PrincipalAmount,    
# MAGIC   B.InterestAmount,    
# MAGIC   B.Amount    
# MAGIC From CTE_RD_DISBURSEMENTBASE A  
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-at_loanschedules` B On B.ClientID = A.ClientID and B.ClientLoanID = A.RDLoanID    
# MAGIC Where Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then  Cast(current_date As Date)  Else A.RDClosedDate End)    
# MAGIC
# MAGIC Union
# MAGIC /*MFI Coll*/
# MAGIC   Select A.SBU,
# MAGIC   A.RDAccountNumber,          
# MAGIC   A.RDLoanID,      
# MAGIC   B.CreatedBy,   
# MAGIC   B.TransactionDate,      
# MAGIC   B.ValueDate,          
# MAGIC   B.DebitOrCredit, 
# MAGIC   B.InstallmentNumber,         
# MAGIC   B.PrincipalAmount,          
# MAGIC   B.InterestAmount,          
# MAGIC   B.Amount 
# MAGIC From CTE_RD_DISBURSEMENTBASE A          
# MAGIC Join ${source_catalog}.${source_schema}.`pragati-at_loantransactions` B On  B.ClientID = A.ClientID
# MAGIC and B.ClientLoanID = A.RDLoanID          
# MAGIC Where
# MAGIC Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then Cast(current_date As Date) Else A.RDClosedDate End)  
# MAGIC
# MAGIC   UNION
# MAGIC
# MAGIC   Select A.SBU,
# MAGIC   A.RDAccountNumber,          
# MAGIC   A.RDLoanID,  
# MAGIC   B.CreatedBy,      
# MAGIC   B.TransactionDate,      
# MAGIC   B.ValueDate,          
# MAGIC   B.DebitOrCredit,   
# MAGIC   B.InstallmentNumber,       
# MAGIC   B.PrincipalAmount,          
# MAGIC   B.InterestAmount,          
# MAGIC   B.Amount          
# MAGIC From CTE_RD_DISBURSEMENTBASE A          
# MAGIC Join ${source_catalog}.${source_schema}.`ptsmart-accounttransactions` B On  B.ClientID = A.ClientID
# MAGIC and B.ClientLoanID = A.RDLoanID          
# MAGIC Where
# MAGIC Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then Cast(current_date As Date) Else A.RDClosedDate End)  
# MAGIC
# MAGIC UNION
# MAGIC select 
# MAGIC   A.SBU,
# MAGIC A.RDAccountNumber,  
# MAGIC A.RDLoanID,        
# MAGIC B.CreatedBy,      
# MAGIC B.TransactionDate,  
# MAGIC B.ValueDate,        
# MAGIC B.DebitOrCredit,    
# MAGIC B.InstallmentNumber,
# MAGIC B.PrincipalAmount,  
# MAGIC B.InterestAmount,   
# MAGIC B.Amount          
# MAGIC from CTE_RD_DISBURSEMENTBASE A
# MAGIC join ${source_catalog}.${source_schema}.`rlmsbizxtend-loantransactions` B on 
# MAGIC B.CustomerID = A.CLIENTID and B.CustomerLoanID = A.RDLoanID
# MAGIC Where Cast(ValueDate As Date) <= (Case When A.RDClosedDate Is Null Then Cast(current_date()-1 As Date) Else A.RDClosedDate End)    
# MAGIC ),
# MAGIC
# MAGIC
# MAGIC /* BMS RD LEDGER SUMMARY*/
# MAGIC
# MAGIC CTE_RD_Ledger_Summary AS (
# MAGIC Select        
# MAGIC   RDAccountNumber,          
# MAGIC   RDLoanID,          
# MAGIC   /* AsOn */          
# MAGIC   Sum(Case When DebitOrCredit ='D' Then 1 Else 0 End) As AsOnNoOfDues,          
# MAGIC   Sum(Case When DebitOrCredit ='C' and Amount > 0 Then 1 Else 0 End) As AsOnNoOfColls,          
# MAGIC   Sum(Case When DebitOrCredit ='D' Then Amount Else 0 End) As AsonDueAmount,          
# MAGIC   Sum(Case When DebitOrCredit ='C' and Amount > 0 Then Amount Else 0 End) As AsOnCollAmount,          
# MAGIC  -- Cast(Null As Int) As AsOnArrearWeeks,          
# MAGIC  -- Cast(Null As Float) As AsOnArrearAmount,          
# MAGIC   /* MTD */          
# MAGIC  SUM(
# MAGIC     CASE 
# MAGIC         WHEN DebitOrCredit = 'D' 
# MAGIC              AND CAST(ValueDate AS DATE) BETWEEN CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE) 
# MAGIC              AND CURRENT_DATE
# MAGIC         THEN 1 
# MAGIC         ELSE 0 
# MAGIC     END
# MAGIC ) AS MTDNoOfDues,          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'C' 
# MAGIC                  AND CAST(ValueDate AS DATE) BETWEEN CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE) 
# MAGIC                  AND CURRENT_DATE
# MAGIC                  AND Amount > 0
# MAGIC             THEN 1 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDNoOfColls,          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'D' 
# MAGIC                  AND CAST(ValueDate AS DATE) BETWEEN CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE) 
# MAGIC                  AND CURRENT_DATE
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDDueAmount,          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'C'
# MAGIC                  AND CAST(ValueDate AS DATE) BETWEEN CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE)
# MAGIC                  AND CURRENT_DATE
# MAGIC                  AND Amount > 0
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDCollAmount,          
# MAGIC   --Cast(Null As Int) As MTDArrearWeeks,          
# MAGIC   --Cast(Null As Float) As MTDArrearAmount,          
# MAGIC   /* FTD */          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'D' 
# MAGIC                  AND CAST(ValueDate AS DATE) = CURRENT_DATE
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS FTDDueAmount,
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'C' 
# MAGIC                  AND CAST(ValueDate AS DATE) = CURRENT_DATE
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS FTDCollAmount,          
# MAGIC          
# MAGIC   /* RD Start/Last Repayment Date */          
# MAGIC   Min(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As RDStartDate,          
# MAGIC   Max(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As LastRepaymentDate,          
# MAGIC   /* Non-Starter RD Status */          
# MAGIC --  Cast(Null As Varchar(5)) As IsNon_StarterRD,          
# MAGIC --  Cast(Null As Date) As [1st RD Missed Instl Coll]      
# MAGIC      Null As ActualLastEWI_CollDate,
# MAGIC      Null As AsOnSICollAmount,
# MAGIC      Null As AsOnCashCollAmount,
# MAGIC      Null As MTDSICollAmount,
# MAGIC      Null As MTDcashCollAmount,
# MAGIC      Null As FTDSICollAmount,
# MAGIC      Null As FTDCashCollAmount
# MAGIC
# MAGIC From CTE_RD_LEDGER         where SBU in ('MFI','BMS')
# MAGIC Group By RDAccountNumber,RDLoanID  
# MAGIC union
# MAGIC
# MAGIC select
# MAGIC RDAccountNumber,          
# MAGIC RDLoanID,          
# MAGIC /* AsOn */          
# MAGIC Sum(Case When DebitOrCredit ='D' Then 1 Else 0 End) As AsOnNoOfDues,          
# MAGIC Sum(Case When DebitOrCredit ='C' and Amount > 0 Then 1 Else 0 End) As AsOnNoOfColls,          
# MAGIC Sum(Case When DebitOrCredit ='D' Then Amount Else 0 End) As AsonDueAmount,    
# MAGIC sum(Case When DebitOrCredit ='C' then Amount else 0 End) As AsOnCollAmount,          
# MAGIC --Cast(Null As Int) As AsOnArrearWeeks,          
# MAGIC --Cast(Null As Float) As AsOnArrearAmount,          
# MAGIC /* MTD */          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'D' 
# MAGIC                  AND (CAST(ValueDate AS DATE) BETWEEN DATE_TRUNC('MONTH', FROM_UTC_TIMESTAMP(current_timestamp(), 'Asia/Kolkata')) AND CURRENT_DATE())
# MAGIC             THEN 1 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDNoOfDues,          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'C' 
# MAGIC                  AND (CAST(ValueDate AS DATE) BETWEEN DATE_TRUNC('MONTH', FROM_UTC_TIMESTAMP(current_timestamp(), 'Asia/Kolkata')) AND CURRENT_DATE()) 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN 1 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDNoOfColls,          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'D' 
# MAGIC                  AND (CAST(ValueDate AS DATE) BETWEEN DATE_TRUNC('MONTH', FROM_UTC_TIMESTAMP(current_timestamp(), 'Asia/Kolkata')) AND CURRENT_DATE()) 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDDueAmount,
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'C' 
# MAGIC                  AND (CAST(ValueDate AS DATE) BETWEEN DATE_TRUNC('MONTH', FROM_UTC_TIMESTAMP(current_timestamp(), 'Asia/Kolkata')) AND CURRENT_DATE()) 
# MAGIC                  AND Amount > 0  
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDCollAmount,      
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'D' 
# MAGIC                  AND CAST(ValueDate AS DATE) = CURRENT_DATE() 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS FTDDueAmount,          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN DebitOrCredit = 'C' 
# MAGIC                  AND CAST(ValueDate AS DATE) = CURRENT_DATE() 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS FTDCollAmount,   
# MAGIC /* RD Start/Last Repayment Date */          
# MAGIC Min(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As RDStartDate,      
# MAGIC Max(Case When DebitOrCredit ='C' and Amount > 0 Then Cast(ValueDate As Date) End) As LastRepaymentDate,          
# MAGIC
# MAGIC
# MAGIC /*For BSS additional columns*/
# MAGIC Max(Case When DebitOrCredit ='C' Then ValueDate Else Null End) As ActualLastEWI_CollDate,    
# MAGIC
# MAGIC SUM(
# MAGIC         CASE 
# MAGIC             WHEN CreatedBy = 'SI' 
# MAGIC                  AND DebitOrCredit = 'C' 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS AsOnSICollAmount,          
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN COALESCE(CreatedBy, 'NA') <> 'SI' 
# MAGIC                  AND DebitOrCredit = 'C' 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS AsOnCashCollAmount,          
# MAGIC
# MAGIC     -- MTD SI and Cash Collection Amount
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN CreatedBy = 'SI' 
# MAGIC                  AND DebitOrCredit = 'C' 
# MAGIC                  AND CAST(ValueDate AS DATE) BETWEEN DATE_TRUNC('MONTH', FROM_UTC_TIMESTAMP(current_timestamp(), 'Asia/Kolkata')) AND CURRENT_DATE() 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDSICollAmount,      
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN COALESCE(CreatedBy, 'NA') <> 'SI' 
# MAGIC                  AND DebitOrCredit = 'C' 
# MAGIC                  AND CAST(ValueDate AS DATE) BETWEEN DATE_TRUNC('MONTH', FROM_UTC_TIMESTAMP(current_timestamp(), 'Asia/Kolkata')) AND CURRENT_DATE() 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS MTDCashCollAmount,      
# MAGIC
# MAGIC     -- FTD SI and Cash Collection Amount
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN CreatedBy = 'SI' 
# MAGIC                  AND DebitOrCredit = 'C' 
# MAGIC                  AND CAST(ValueDate AS DATE) = CURRENT_DATE() 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS FTDSICollAmount,      
# MAGIC     SUM(
# MAGIC         CASE 
# MAGIC             WHEN COALESCE(CreatedBy, 'NA') <> 'SI' 
# MAGIC                  AND DebitOrCredit = 'C' 
# MAGIC                  AND CAST(ValueDate AS DATE) = CURRENT_DATE() 
# MAGIC                  AND Amount > 0 
# MAGIC             THEN Amount 
# MAGIC             ELSE 0 
# MAGIC         END
# MAGIC     ) AS FTDCashCollAmount
# MAGIC
# MAGIC from CTE_RD_LEDGER         where SBU in ('BSS') 
# MAGIC Group By RDAccountNumber,RDLoanID
# MAGIC ) ,
# MAGIC
# MAGIC CTE_RD_MissedInstal
# MAGIC aS (
# MAGIC Select RDAccountNumber,  
# MAGIC    RDLoanID,  
# MAGIC    Min(ValueDate) As FirstSIMissedRDInstlColl  
# MAGIC From CTE_RD_LEDGER  
# MAGIC Where DebitOrCredit ='C' and Amount = '0'  
# MAGIC -- and TransactionDate = ValueDate   
# MAGIC Group By RDAccountNumber,RDLoanID  
# MAGIC ),
# MAGIC
# MAGIC CTE_RD_Ledger_MTDWeekSummary
# MAGIC AS
# MAGIC (Select RDAccountNumber,          
# MAGIC   RDLoanID,          
# MAGIC   ROUND(DATEDIFF(Cast(ValueDate As Date), DATE_TRUNC('MONTH', ValueDate))/7 + 1, 0) As WeekNo,          
# MAGIC   Sum(Amount) As WeekCollection          
# MAGIC From CTE_RD_LEDGER          
# MAGIC Where WHERE CAST(ValueDate AS DATE) BETWEEN DATE_TRUNC('MONTH', FROM_UTC_TIMESTAMP(CURRENT_TIMESTAMP(), 'Asia/Kolkata')) AND CURRENT_DATE()         
# MAGIC and DebitOrCredit ='C' and Amount > 0          
# MAGIC Group by RDAccountNumber,RDLoanID,ROUND(DATEDIFF(Cast(ValueDate As Date), DATE_TRUNC('MONTH', ValueDate))/7 + 1, 0)
# MAGIC ),
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC /* Due,Coll,Arrear Updated Begins */ 
# MAGIC CTE_BMS_RD_Ledger_Summary1
# MAGIC (
# MAGIC SELECT A.*,         
# MAGIC   A.AsonDueAmount - AsOnCollAmount AS AsOnArrearAmount,          
# MAGIC      A.MTDDueAmount - A.MTDCollAmount AS MTDArrearAmount,          
# MAGIC     A.AsOnNoOfDues - A.AsOnNoOfColls AS AsOnArrearWeeks,          
# MAGIC      A.MTDNoOfDues - A.MTDNoOfColls AS MTDArrearWeeks,          
# MAGIC      (Case When Sign(A.AsOnCollAmount) = 0 Then 'Yes'          
# MAGIC             When Sign(A.AsOnCollAmount) = 1 Then 'No'          
# MAGIC             When Sign(A.AsOnCollAmount) = -1 Then Null End) as IsNon_StarterRD,          
# MAGIC     COALESCE(B1.WeekCollection,0) AS MTDWeek1_Coll,          
# MAGIC     COALESCE(B2.WeekCollection,0) AS MTDWeek2_Coll,          
# MAGIC     COALESCE(B3.WeekCollection,0) AS MTDWeek3_Coll,          
# MAGIC     COALESCE(B4.WeekCollection,0) AS MTDWeek4_Coll,          
# MAGIC     COALESCE(B5.WeekCollection,0) AS MTDWeek5_Coll ,
# MAGIC      D.FirstSIMissedRDInstlColl         
# MAGIC From CTE_RD_Ledger_Summary A          
# MAGIC Left Join CTE_RD_Ledger_MTDWeekSummary B1 On B1.RDAccountNumber = A.RDAccountNumber and B1.RDLoanID = A.RDLoanID and B1.WeekNo = 1          
# MAGIC Left Join CTE_RD_Ledger_MTDWeekSummary B2 On B2.RDAccountNumber = A.RDAccountNumber and B2.RDLoanID = A.RDLoanID and B2.WeekNo = 2          
# MAGIC Left Join CTE_RD_Ledger_MTDWeekSummary B3 On B3.RDAccountNumber = A.RDAccountNumber and B3.RDLoanID = A.RDLoanID and B3.WeekNo = 3          
# MAGIC Left Join CTE_RD_Ledger_MTDWeekSummary B4 On B4.RDAccountNumber = A.RDAccountNumber and B4.RDLoanID = A.RDLoanID and B4.WeekNo = 4          
# MAGIC Left Join CTE_RD_Ledger_MTDWeekSummary B5 On B5.RDAccountNumber = A.RDAccountNumber and B5.RDLoanID = A.RDLoanID and B5.WeekNo = 5  
# MAGIC LEFT JOIN CTE_RD_MissedInstal  D ON D.RDLoanID=a.RDLoanID
# MAGIC )select * from CTE_BMS_RD_Ledger_Summary1
# MAGIC