# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_firewallaccounts_facts.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FACTS/FIREWALLACCOUNTS_FACTS"
    desti_path = "BFIL-MART/FACTS/FIREWALLACCOUNTS_FACTS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH InitialData AS (
    SELECT DISTINCT
        Created_By AS OperatorID,
        CIFID,
        Ext_CustID AS ExternalCustomerID,
        AccountType,
        AccountID AS AccountNumber,
        CAST(CreatedDateTime AS TIMESTAMP) AS AccountOpenDate,
        AccountStatus,
        CASE 
            WHEN Mobile_No IS NULL OR Mobile_No = '' THEN NULL
            ELSE Mobile_No
        END AS MobileNumber,
        CASE 
            WHEN Agent_ID IS NULL OR Agent_ID = '' THEN NULL
            ELSE Agent_ID
        END AS AgentID
    FROM
        {source_catalog}.{source_schema}.`firewall_prod-accountidmapping` 
    WHERE
        CIFID NOT IN ('36418050', '36631912')
        AND CAST(CreatedDateTime AS DATE) BETWEEN 
            CASE 
                WHEN DAY(CURRENT_DATE()) <= 3 THEN LAST_DAY(ADD_MONTHS(CURRENT_DATE(), -2)) + 1
                ELSE LAST_DAY(ADD_MONTHS(CURRENT_DATE(), -1)) + 1
            END
            AND 
            DATE_SUB(CURRENT_DATE(), 1) and etl_is_active = 1
),
CIFAccounts AS (
    SELECT
        B.*
    FROM (
        SELECT
            CIFID,
            AccountType,
            AccountNumber,
            MIN(AccountOpenDate) AS Min_OpenDate
        FROM InitialData
        GROUP BY CIFID, AccountType, AccountNumber
        HAVING COUNT(*) > 1
    ) A
    JOIN InitialData B ON B.CIFID = A.CIFID
                       AND B.AccountNumber = A.AccountNumber
                       AND B.AccountType = A.AccountType
                       AND B.AccountOpenDate <> A.Min_OpenDate
),
--SELECT * FROM InitialData;

InitialData_CU_1 AS (
    SELECT DISTINCT
        COALESCE(A.OperatorID, C.CreatedBy) AS OperatorID,
        C.`BC_Partner_Branch_Code` AS BranchCode,
        COALESCE(ExternalCustomerID, C.`External_CustomerID`) AS `External_CustomerID`,
        C.`Customer_Name` AS CustomerName,
        CAST(C.`Customer_DOB` AS DATE) AS CustomerDOB,
        Gender,
        C.`Identification_no_or_KYC_ID` AS KYCNumber,
        C.`Name_of_Spouse` AS SpouseName,
        CAST(C.`DATE_OF_BIRTH_SPOUSE` AS DATE) AS SpouseDOB,
        A.CIFID,
        A.AccountType,
        A.AccountNumber,
        A.AccountOpenDate,
        A.AccountStatus,
        COALESCE(A.MobileNumber, C.`Mobile_NO`) AS MobileNumber,
        COALESCE(A.AgentID, C.`Agent_ID`) AS AgentID,
        CAST(NULL AS STRING) AS Tenure,
        CAST(NULL AS FLOAT) AS Booking_Amt,
        CAST(NULL AS STRING) AS Scheme_Code,
        CAST(NULL AS STRING) AS C5Code,
        CASE WHEN C.`KYC2_Type` = '15' THEN 'Yes' ELSE 'No' END AS Form60,
        CASE WHEN C.`KYC2_Type` = '16' THEN `KYC2_ID` ELSE NULL END AS PAN,
        C.NameScreeningScore,
        C.NameScreeningFlag,
        CAST(NULL AS STRING) AS BFIL_OperatorID,
        CAST(NULL AS STRING) AS BFIL_HierarchyID,
        CAST(NULL AS STRING) AS BFIL_ClientID,
        CAST(NULL AS STRING) AS IFSCCode
    FROM (
        SELECT DISTINCT
            CASE 
                WHEN TRY_CAST(Created_By AS INT) IS NOT NULL THEN NULL -- Set OperatorID to NULL if it's numeric
                ELSE Created_By
            END AS OperatorID,
            CIFID,
            Ext_CustID AS ExternalCustomerID,
            AccountType,
            AccountID AS AccountNumber,
            CAST(CreatedDateTime AS TIMESTAMP) AS AccountOpenDate,
            AccountStatus,
            CASE 
                WHEN Mobile_No IS NULL OR Mobile_No = '' THEN NULL
                ELSE Mobile_No
            END AS MobileNumber,
            CASE 
                WHEN Agent_ID IS NULL OR Agent_ID = '' THEN NULL
                ELSE Agent_ID
            END AS AgentID
        FROM
            {source_catalog}.{source_schema}.`firewall_prod-accountidmapping`
        WHERE
            CIFID NOT IN ('36418050', '36631912') and etl_is_active = 1
            AND CAST(CreatedDateTime AS DATE) BETWEEN 
                CASE 
                    WHEN DAY(CURRENT_DATE()) <= 3 THEN LAST_DAY(ADD_MONTHS(CURRENT_DATE(), -2)) + 1
                    ELSE LAST_DAY(ADD_MONTHS(CURRENT_DATE(), -1)) + 1
                END
                AND 
                DATE_SUB(CURRENT_DATE(), 1) 
    ) A
    JOIN {source_catalog}.{source_schema}.`firewall_prod-idmapping_h_view` B ON B.CIFID = A.CIFID AND B.CustomerCode = A.ExternalCustomerID
    JOIN {source_catalog}.{source_schema}.`Firewall_Prod-CU` C ON C.`External_CustomerID` = B.CustomerCode
    JOIN (
        SELECT `External_CustomerID` AS CustID, MAX(CreatedDate) AS Max_CUDate, MAX(ID) AS MaxID
        FROM {source_catalog}.{source_schema}.`Firewall_Prod-CU`
        WHERE IsValid = 1 and ETL_IS_ACTIVE = 1
        GROUP BY `External_CustomerID`
    ) CU ON CU.CustID = C.`External_CustomerID` AND CU.Max_CUDate = C.CreatedDate AND CU.MaxID = C.ID
    WHERE C.IsValid = 1 
    OR (A.AccountNumber = '201005862024' AND A.AccountType = 'SB')
    OR (A.AccountType = 'SB' AND A.AccountNumber LIKE '2%') and b.ETL_IS_ACTIVE = 1 and c.ETL_IS_ACTIVE = 1
),

--select * from InitialData_CU_1;

InitialData_CU_Missed AS (
    SELECT DISTINCT
        COALESCE(A.OperatorID, C.CreatedBy) AS OperatorID,
        C.BC_Partner_Branch_Code AS BranchCode,
        COALESCE(C.External_CustomerID, ExternalCustomerID) AS External_CustomerID,
        C.Customer_Name AS CustomerName,
        CAST(C.Customer_DOB AS Date) AS CustomerDOB,
        C.Gender,
        C.Identification_no_or_KYC_ID AS KYCNumber,
        C.Name_of_Spouse AS SpouseName,
        C.`DATE_OF_BIRTH_SPOUSE` AS SpouseDOB,
        A.CIFID,
        A.AccountType,
        A.AccountNumber,
        A.AccountOpenDate,
        A.AccountStatus,
        COALESCE(A.MobileNumber, C.Mobile_NO) AS MobileNumber,
        COALESCE(A.AgentID, C.Agent_ID) AS AgentID,
        CAST(NULL AS VARCHAR(30)) AS Tenure,
        CAST(NULL AS FLOAT) AS Booking_Amt,
        CAST(NULL AS VARCHAR(10)) AS Scheme_Code,
        CAST(NULL AS VARCHAR(5)) AS C5Code,
        (CASE WHEN KYC2_Type = '15' THEN 'Yes' ELSE 'No' END) AS Form60,
        (CASE WHEN KYC2_Type = '16' THEN KYC2_ID ELSE NULL END) AS PAN,
        C.NameScreeningScore,
        C.NameScreeningFlag,
        CAST(NULL AS VARCHAR(5)) AS BFIL_OperatorID,
        CAST(NULL AS VARCHAR(10)) AS BFIL_HierarchyID,
        CAST(NULL AS VARCHAR(30)) AS BFIL_ClientID,
        CAST(NULL AS VARCHAR(40)) AS IFSCCode
    FROM
        InitialData A
    JOIN
        {source_catalog}.{source_schema}.`firewall_prod-idmapping_h_view` B ON B.CIFID = A.CIFID
    JOIN
        {source_catalog}.{source_schema}.`Firewall_Prod-CU` C ON C.External_CustomerID = B.CustomerCode
    JOIN
        (SELECT External_CustomerID AS CustID,
                MAX(CreatedDate) AS Max_CUDate,
                MAX(ID) AS MaxID
         FROM {source_catalog}.{source_schema}.`Firewall_Prod-CU`
         WHERE IsValid = 1 and ETL_IS_ACTIVE = 1
         GROUP BY External_CustomerID) CU ON CU.CustID = C.External_CustomerID AND CU.Max_CUDate = C.CreatedDate AND CU.MaxID = C.ID
    LEFT JOIN
        InitialData_CU_1 A1 ON A1.External_CustomerID = A.ExternalCustomerID AND A1.CIFID = A.CIFID AND A1.AccountNumber = A.AccountNumber
    WHERE
        C.IsValid = 1 
        AND A.ExternalCustomerID IS NOT NULL 
        AND A1.BranchCode IS NULL 
        AND A.AccountNumber NOT IN (SELECT DISTINCT AccountNumber FROM InitialData_CU_1)
        and b.ETL_IS_ACTIVE = 1 and c.etl_is_active = 1
),

--select * from InitialData_CU_Missed;
InitialData_CU AS (
    SELECT *
    FROM InitialData_CU_1
    UNION ALL
    SELECT *
    FROM InitialData_CU_Missed
),

--SELECT * FROM InitialData_CU;

InitialData_CU_NoExtCustID_1 AS (
    SELECT DISTINCT
        COALESCE(A.OperatorID, C.CreatedBy) AS OperatorID,
        C.BC_Partner_Branch_Code AS BranchCode,
        C.External_CustomerID AS External_CustomerID, -- Removed parentheses
        C.Customer_Name AS CustomerName,
        CAST(C.Customer_DOB AS Date) AS CustomerDOB,
        C.Gender,
        C.Identification_no_or_KYC_ID AS KYCNumber,
        C.Name_of_Spouse AS SpouseName,
        C.DATE_OF_BIRTH_SPOUSE AS SpouseDOB,
        A.CIFID,
        A.AccountType,
        A.AccountNumber,
        A.AccountOpenDate,
        A.AccountStatus,
        COALESCE(A.MobileNumber, C.Mobile_NO) AS MobileNumber,
        COALESCE(A.AgentID, C.Agent_ID) AS AgentID,
        C.CreatedDate AS CUDate,
        CAST(NULL AS VARCHAR(30)) AS Tenure,
        CAST(NULL AS FLOAT) AS Booking_Amt,
        CAST(NULL AS VARCHAR(10)) AS Scheme_Code,
        CAST(NULL AS VARCHAR(5)) AS C5Code,
        (CASE WHEN KYC2_Type = '15' THEN 'Yes' ELSE 'No' END) AS Form60,
        (CASE WHEN KYC2_Type = '16' THEN KYC2_ID ELSE NULL END) AS PAN,
        C.NameScreeningScore,
        C.NameScreeningFlag,
        CAST(NULL AS VARCHAR(5)) AS BFIL_OperatorID,
        CAST(NULL AS VARCHAR(10)) AS BFIL_HierarchyID,
        CAST(NULL AS VARCHAR(30)) AS BFIL_ClientID,
        CAST(NULL AS VARCHAR(40)) AS IFSCCode
    FROM
        InitialData A
    JOIN
        {source_catalog}.{source_schema}.`firewall_prod-idmapping_h_view` B ON B.CIFID = A.CIFID
    JOIN
        {source_catalog}.{source_schema}.`Firewall_Prod-CU` C ON C.External_CustomerID = B.CustomerCode
    WHERE
        A.ExternalCustomerID IS NULL
        AND C.IsValid = 1
        AND (CAST(A.AccountOpenDate AS Date) = CAST(C.CreatedDate AS Date) OR CAST(A.AccountOpenDate AS Date) = CAST(C.NameFlagUpdatedDateTime AS Date))
        AND A.AccountNumber NOT IN (SELECT DISTINCT AccountNumber FROM InitialData_CU)
        and b.etl_is_active = 1
        and c.ETL_IS_ACTIVE = 1
		
),

--select * from InitialData_CU_NoExtCustID_1;

-- CTE to identify duplicate records based on OperatorID, CIFID, AccountType, and AccountNumber
OperatorCIFAccounts AS (
    SELECT 
        OperatorID,
        CIFID,
        AccountType,
        AccountNumber,
        MAX(CUDate) AS Max_CUDate,
        COUNT(*) AS NoOfAccounts
    FROM 
        InitialData_CU_NoExtCustID_1
    GROUP BY 
        OperatorID, CIFID, AccountType, AccountNumber
    HAVING 
        COUNT(*) > 1
),
-- CTE to identify records with different operators but the same CIFID, AccountType, and AccountNumber
DiffOper_CIFIDAccounts AS (
    SELECT 
        CIFID,
        AccountType,
        AccountNumber,
        COUNT(*) AS NoOfAccounts
    FROM 
        InitialData_CU_NoExtCustID_1
    GROUP BY 
        CIFID, AccountType, AccountNumber
    HAVING 
        COUNT(*) > 1
),

RecordsToDelete AS (
SELECT A.*
FROM InitialData_CU_NoExtCustID_1 A
JOIN OperatorCIFAccounts B
ON B.OperatorID = A.OperatorID
AND B.CIFID = A.CIFID
AND B.AccountType = A.AccountType
AND B.AccountNumber = A.AccountNumber
WHERE B.Max_CUDate <> A.CUDate),

--select * from RecordsToDelete;
CR_DuplicateAccountsToDelete AS(
SELECT A.*
FROM InitialData_CU_NoExtCustID_1 A
JOIN DiffOper_CIFIDAccounts B
ON B.CIFID = A.CIFID
AND B.AccountNumber = A.AccountNumber
AND A.AccountType = B.AccountType
WHERE A.OperatorID = 'SPT'
AND B.AccountType = 'CR'),

--select * from CR_DuplicateAccountsToDelete;

-- Create a temporary view to select the rows to be deleted for SB accounts from "BMS" operator
SB_DuplicateAccountsToDelete AS(
SELECT 
    A.*
FROM 
    InitialData_CU_NoExtCustID_1 A
JOIN 
    DiffOper_CIFIDAccounts B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND A.AccountType = B.AccountType
WHERE 
    A.OperatorID = 'RDSP-M' AND B.AccountType = 'SB'),

    --select * from SB_DuplicateAccountsToDelete;


-- Use the temporary views to delete the corresponding rows
InitialData_CU_NoExtCustID as( select * from InitialData_CU_NoExtCustID_1
WHERE (CIFID, AccountNumber, AccountType) IN (SELECT CIFID, AccountNumber, AccountType FROM CR_DuplicateAccountsToDelete)
and (CIFID, AccountNumber, AccountType) IN (SELECT CIFID, AccountNumber, AccountType FROM SB_DuplicateAccountsToDelete)),

-- select * from InitialData_CU_NoExtCustID;
RDAccountsCTE AS (
    SELECT 
        A.CIFID,
        A.AccountNumber,
        A.AccountType,
        A.OperatorID
    FROM 
        (
            SELECT 
                A.CIFID,
                A.AccountNumber,
                A.AccountType,
                A.OperatorID
            FROM 
                InitialData_CU_NoExtCustID A
            JOIN 
                DiffOper_CIFIDAccounts B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND A.AccountType = B.AccountType
            JOIN 
                {source_catalog}.{source_schema}.`pragati-clientloansubscription` C ON C.RDAccountNumber = A.AccountNumber
            JOIN
                {mart_catalog}.{mart_schema}.`p_hierarchy_sop` D ON D.HierarchyID = C.HierarchyID
            WHERE 
                B.AccountType = 'RD' AND REPLACE(REPLACE(A.OperatorID, 'SPT', 'SMPT'), 'RDSP-M', 'RDSP') = D.Branch_Type AND D.Branch_Type <> 'RLMS' and c.ETL_IS_ACTIVE = 1 
            
            UNION
            
            SELECT 
                A.CIFID,
                A.AccountNumber,
                A.AccountType,
                A.OperatorID
            FROM 
                InitialData_CU_NoExtCustID A
            JOIN 
                DiffOper_CIFIDAccounts B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND A.AccountType = B.AccountType
            JOIN 
                {source_catalog}.{source_schema}.`pragati-clientloansubscription` C ON C.RDAccountNumber = A.AccountNumber
            JOIN 
                {mart_catalog}.{mart_schema}.`p_hierarchy_sop`  D ON D.HierarchyID = C.HierarchyID
            WHERE 
               B.AccountType = 'RD' AND REPLACE(REPLACE(A.OperatorID, 'SPT', 'SMPT'), 'RDSP-M', 'RDSP') = D.Branch_Type AND D.Branch_Type <> 'RLMS' and c.ETL_IS_ACTIVE = 1 
        ) AS A
        
        ),

        --select * from RDAccountsCTE;
DAccounts as (
SELECT 
    *
FROM 
    RDAccountsCTE),

--select * from RDAccounts;
CTE AS (
    SELECT 
        A.CIFID,
        A.AccountNumber,
        A.AccountType,
        A.OperatorID
    FROM 
        InitialData_CU_NoExtCustID A
    JOIN 
        DiffOper_CIFIDAccounts B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND B.AccountType = A.AccountType
    WHERE 
        B.AccountType = 'RD' AND A.AccountNumber NOT IN ('398000913120')
    EXCEPT
    SELECT 
        *
    FROM 
        RDAccountsCTE
),
--select * from CTE;

DeleteViewcte AS(
SELECT *
FROM CTE a Join  InitialData_CU_NoExtCustID B on B.CIFID = A.CIFID and B.AccountNumber = A.AccountNumber and B.AccountType = A.AccountType         
and B.OperatorID = A.OperatorID),

--select * from DeleteViewcte;

InitialData_CU_NoExtCustID1 AS(
    SELECT DISTINCT
        COALESCE(A.OperatorID, C.CreatedBy) AS OperatorID,
        C.BC_Partner_Branch_Code AS BranchCode,
        COALESCE(ExternalCustomerID, C.External_CustomerID) AS External_CustomerID,
        C.Customer_Name AS CustomerName,
        CAST(C.Customer_DOB AS DATE) AS CustomerDOB,
        C.Gender,
        C.Identification_no_or_KYC_ID AS KYCNumber,
        C.Name_of_Spouse AS SpouseName,
        C.DATE_OF_BIRTH_SPOUSE AS SpouseDOB,
        A.CIFID,
        A.AccountType,
        A.AccountNumber,
        A.AccountOpenDate,
        A.AccountStatus,
        COALESCE(A.MobileNumber, C.Mobile_NO) AS MobileNumber,
        COALESCE(A.AgentID, C.Agent_ID) AS AgentID,
        CAST(NULL AS VARCHAR(30)) AS Tenure,
        CAST(NULL AS FLOAT) AS Booking_Amt,
        CAST(NULL AS VARCHAR(10)) AS Scheme_Code,
        CAST(NULL AS VARCHAR(5)) AS C5Code,
        (CASE WHEN KYC2_Type = '15' THEN 'Yes' ELSE 'No' END) AS Form60,
        (CASE WHEN KYC2_Type = '16' THEN KYC2_ID ELSE NULL END) AS PAN,
        C.NameScreeningScore,
        C.NameScreeningFlag,
        CAST(NULL AS VARCHAR(5)) AS BFIL_OperatorID,
        CAST(NULL AS VARCHAR(10)) AS BFIL_HierarchyID,
        CAST(NULL AS VARCHAR(30)) AS BFIL_ClientID,
        CAST(NULL AS VARCHAR(40)) AS IFSCCode
    FROM 
        InitialData A
    JOIN 
        {source_catalog}.{source_schema}.`firewall_prod-idmapping_h_view`  B ON B.CIFID = A.CIFID
    JOIN 
        {source_catalog}.{source_schema}.`Firewall_Prod-CU` C ON C.External_CustomerID = B.CustomerCode
    JOIN 
        (SELECT External_CustomerID AS CustID, 
                MAX(CreatedDate) AS Max_CUDate, 
                MAX(ID) AS MaxID        
         FROM {source_catalog}.{source_schema}.`Firewall_Prod-CU`       
         WHERE IsValid = 1        
        GROUP BY `External_CustomerID`
    ) CU ON CU.CustID = C.`External_CustomerID` AND CU.Max_CUDate = C.CreatedDate AND CU.MaxID = C.ID
    WHERE C.IsValid = 1   and 
        A.ExternalCustomerID IS NULL    
        AND A.AccountNumber NOT IN (SELECT DISTINCT AccountNumber FROM InitialData_CU)
),
--elect * from InitialData_CU_NoExtCustID1;
RDAccountsDuplicate AS (
    SELECT CIFID, AccountType, AccountNumber, COUNT(*) AS NoOfAccounts
    FROM InitialData_CU_NoExtCustID1
    GROUP BY CIFID, AccountType, AccountNumber
    HAVING COUNT(*) > 1
),
--select * from RDAccountsDuplicate;

 RecordsToDelete1 AS (
    SELECT A.*
    FROM InitialData_CU_NoExtCustID1 A
    JOIN RDAccountsDuplicate B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND A.AccountType = B.AccountType
    WHERE (A.OperatorID = 'SPT' AND B.AccountType = 'CR')
        OR (A.OperatorID = 'RDSP-M' AND B.AccountType = 'SB')
        OR (A.OperatorID IN ('RLMS-TATKAL', 'RLMS') AND B.AccountType = 'SB')
),

--select * from RDAccountsDuplicate;
--select * from RecordsToDelete1;

CTE_RDAccounts AS (
    SELECT A.CIFID, A.AccountNumber, A.AccountType, A.OperatorID
    FROM (
        SELECT A.CIFID, A.AccountNumber, A.AccountType, A.OperatorID
        FROM InitialData_CU_NoExtCustID1 A
        JOIN RDAccountsDuplicate B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND B.AccountType = A.AccountType
        JOIN {source_catalog}.{source_schema}.`pragati-clientloansubscription` C  ON C.RDAccountNumber = A.AccountNumber
        JOIN {mart_catalog}.{mart_schema}.`p_hierarchy_sop` D  ON D.HierarchyID = C.HierarchyID
        WHERE B.AccountType = 'RD' AND REPLACE(REPLACE(A.OperatorID, 'SPT', 'SMPT'), 'RDSP-M', 'RDSP') = D.Branch_Type
        UNION
        SELECT A.CIFID, A.AccountNumber, A.AccountType, A.OperatorID
        FROM InitialData_CU_NoExtCustID1 A
        JOIN RDAccountsDuplicate B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND B.AccountType = A.AccountType
        JOIN {source_catalog}.{source_schema}.`pragati-clientloansubscription` C  ON C.RDAccountNumber = A.AccountNumber
        JOIN {mart_catalog}.{mart_schema}.`p_hierarchy_sop` D  ON D.HierarchyID = C.HierarchyID
        WHERE B.AccountType = 'RD' AND REPLACE(REPLACE(A.OperatorID, 'SPT', 'SMPT'), 'RDSP-M', 'RDSP') = D.Branch_Type
    ) AS A
),

--select * from CTE_RDAccounts;
RDAccounts1 as (
SELECT CIFID, AccountNumber, AccountType, OperatorID
FROM CTE_RDAccounts),

--select * from CTE_RDAccounts1;

Temp_Delete_View AS
(
-- Dropout clients in SPT /AOF deleted (for SB accounts)
SELECT *
FROM RDAccountsDuplicate A
JOIN InitialData_CU_NoExtCustID1 B ON B.CIFID = A.CIFID AND B.AccountNumber = A.AccountNumber AND B.AccountType = A.AccountType
JOIN {source_catalog}.{source_schema}.`pragati-clientmaster` C ON C.ClientID = B.External_CustomerID AND COALESCE(C.DropOutDate, '1900-01-01') <> '1900-01-01'
WHERE B.OperatorID IN ('SPT', 'AOF') AND A.AccountType = 'SB'
),
--select * from Temp_Delete_View;

InitialData_CU_2 as(    
Select Distinct A.OperatorID,        
   A.BranchCode,        
   A.External_CustomerID,        
   A.CustomerName,        
   A.CustomerDOB,        
   A.Gender,        
   A.KYCNumber,        
   A.SpouseName,        
   A.SpouseDOB,        
   A.CIFID,        
   A.AccountType,        
   A.AccountNumber,        
   A.AccountOpenDate,        
   A.AccountStatus,        
   A.MobileNumber,        
   A.AgentID,        
   A.Tenure,        
   A.Booking_Amt,        
   A.Scheme_Code,        
   A.C5Code,
   --A.Form60,               
   A.PAN,        
   A.NameScreeningScore,        
   A.NameScreeningFlag,        
   A.BFIL_OperatorID ,        
   A.BFIL_HierarchyID,        
   A.BFIL_ClientID ,  
   A.IFSCCode       
From InitialData_CU_NoExtCustID1  A        
Where A.AccountNumber Not in ('398001509302','398002040333','398001739463','398001509184','398001464718',        
'398001870854','398001508488','398001455333','398001681190','398000647933','398001687781','398001758130','398000988965')        
and AccountType <> 'LM'     
 ),

--select * from InitialData_CU_2;
-- Create the temporary view
Temp_Alter_View AS(

-- Selecting the columns from InitialData_CU_2 with specified alterations
SELECT 
    External_CustomerID AS External_CustomerID,
    COALESCE(AgentID, '') AS AgentID,
    COALESCE(Gender, '') AS Gender,
    COALESCE(SpouseName, '') AS SpouseName,
    SpouseDOB,
    --COALESCE(Form60, '') AS Form60,
    COALESCE(PAN, '') AS PAN,
    COALESCE(BranchCode, '') AS BranchCode,
    COALESCE(CustomerName, '') AS CustomerName,
    COALESCE(KYCNumber, '') AS KYCNumber
FROM InitialData_CU_2),

--select * from Temp_Alter_View;

InitialData_CU_3 as(         
       Select Distinct A.*        
From InitialData  A        
left Join InitialData_CU_2  B On B.CIFID = A.CIFID and B.AccountNumber = A.AccountNumber        
Where B.CIFID Is Null ),

--select * from InitialData_CU_3;

 InitialData_CU_4 AS(
    -- Calculate new tenure & booking amount for RD and FD Accounts
    (SELECT
a.*,
        CASE
            WHEN B.RDACCOUNTNumber IS NOT NULL THEN B.RD_Tenure
            WHEN C.RDACCOUNTNumber IS NOT NULL THEN C.FD_Tenure
        END AS NewTenure,
        CASE
            WHEN B.RDACCOUNTNumber IS NOT NULL THEN B.RDAMOUNT
            WHEN C.RDACCOUNTNumber IS NOT NULL THEN C.AMOUNT
        END AS NewBookingAmt
    FROM InitialData_cu A
    LEFT JOIN {source_catalog}.{source_schema}.`firewall_prod-rdaccounts` B ON B.RDACCOUNTNumber = A.AccountNumber
    LEFT JOIN {source_catalog}.{source_schema}.`firewall_prod-fdaccounts` C ON C.RDACCOUNTNumber = A.AccountNumber
    )
    union all
SELECT
a.*,
    CASE
        WHEN B.APITYPE IS NOT NULL THEN B.Code
        WHEN D.APITYPE IS NOT NULL THEN D.Code
    END AS Scheme_Code,
    CASE
        WHEN E.APITYPE IS NOT NULL THEN E.Code
        WHEN F.APITYPE IS NOT NULL THEN F.Code
    END AS C5Code
FROM InitialData_CU_1 A
LEFT JOIN {source_catalog}.{source_schema}.`firewall_prod-mastercodevalues` B ON B.APITYPE = A.OperatorID AND B.Desp LIKE '%SchmCode%' AND A.AccountNumber LIKE '1%'
LEFT JOIN {source_catalog}.{source_schema}.`firewall_prod-currentaccountmastercodevalues` D ON D.APITYPE = A.OperatorID AND D.Desp LIKE '%SchmCode%' AND A.AccountNumber LIKE '2%' 
LEFT JOIN {source_catalog}.{source_schema}.`firewall_prod-mastercodevalues` E ON E.APITYPE = A.OperatorID AND E.Desp LIKE '%FREE_CODE_10%' AND A.AccountNumber LIKE '1%'
LEFT JOIN {source_catalog}.{source_schema}.`firewall_prod-currentaccountmastercodevalues` F ON F.APITYPE = A.OperatorID AND F.Desp LIKE '%FREE_CODE_10%' AND A.AccountNumber LIKE '2%'
where (b.etl_is_active = 1 and b.etl_is_active is Null) and (d.etl_is_active = 1 and d.etl_is_active is Null) and  (e.etl_is_active = 1 and e.etl_is_active is Null) and  (f.etl_is_active = 1 and f.etl_is_active is Null) ),

--SELECT * FROM InitialData_CU_4;

NewDataView AS(
SELECT
    GETDATE() AS InsertDate,
    *,  -- Include all columns from InitialData_CU
    CAST(NULL AS TINYINT) AS Is_StandaloneFD,
    current_date()  AS DBT_LatestReqDate,
    CAST(NULL AS VARCHAR(30)) AS MerchantID
FROM
    InitialData_CU_4),

    --select * from NewDataView;

    P_FirewallAccountsMaster as (
SELECT * FROM NewDataView),

--select * from NewDataView


UpdatedData_1 AS (
    SELECT 
        A.*,
        A.IFSCCode = CASE 
                        WHEN A.IFSCCode IS NULL THEN 'INDB000' + '' + A.BranchCode
                        ELSE A.IFSCCode
                    END,
        A.BFIL_OperatorID = CASE 
                                WHEN A.BFIL_OperatorID IS NULL AND (B.CustomerID IS NOT NULL OR CM.ClientID IS NOT NULL) THEN 
                                    CASE 
                                        WHEN B.CustomerID IS NOT NULL THEN 'BSS'
                                        ELSE 'BMS'
                                    END
                                ELSE A.BFIL_OperatorID
                            END,
        A.BFIL_HierarchyID = CASE 
                                WHEN A.BFIL_HierarchyID IS NULL AND (B.HierarchyID IS NOT NULL OR CM.HierarchyID IS NOT NULL) THEN 
                                    CASE 
                                        WHEN B.HierarchyID IS NOT NULL THEN B.HierarchyID
                                        ELSE CM.HierarchyID
                                    END
                                ELSE A.BFIL_HierarchyID
                            END,
        A.BFIL_ClientID = CASE 
                            WHEN A.BFIL_ClientID IS NULL AND (CM.ClientID IS NOT NULL OR CM.ClientID IS NOT NULL) THEN 
                                CASE 
                                    WHEN CM.ClientID IS NOT NULL THEN MM.ClientID
                                    ELSE CM.ClientID
                                END
                            ELSE A.BFIL_ClientID
                        END
    FROM 
        P_FirewallAccountsMaster A
    LEFT JOIN 
        {source_catalog}.{source_schema}.`firewall_prod-branchmaster` BA ON A.BranchCode  = BA.BranchCode

    LEFT JOIN 
        {source_catalog}.{source_schema}.`rlmsbizxtend-customermaster` B ON B.CustomerID = A.External_CustomerID
    LEFT JOIN 
        {source_catalog}.{source_schema}.`rlmsbizxtend-bankrelationdetails_h_view` BRD ON BRD.SBAccountNumber = A.AccountNumber
    LEFT JOIN 
        {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` CLD ON CLD.RDAccountNumber = A.AccountNumber
    LEFT JOIN 
        {source_catalog}.{source_schema}.`rdsp-merchant_master` MM ON MM.MerchantAccNo = A.AccountNumber AND MM.merchant_uidai_no = A.External_CustomerID
    LEFT JOIN 
       {source_catalog}.{source_schema}.`ptsmart-kycmaster` KM ON KM.KYCNumber = MM.merchant_uidai_no AND KM.ClientOrSpouse IN ('M','Y')
    LEFT JOIN 
        {source_catalog}.{source_schema}.`ptsmart-clientmaster` CM ON CM.TargetID = KM.TargetID AND COALESCE(CM.DropOutDate, '1900-01-01') = '1900-01-01'
    LEFT JOIN 
        {source_catalog}.{source_schema}.`pragati-clientloansubscription` CLS ON CLS.RDAccountNumber = A.AccountNumber
    WHERE 
        (A.BFIL_OperatorID IS NULL AND (B.CustomerID IS NOT NULL OR CM.ClientID IS NOT NULL)) OR
        (A.BFIL_HierarchyID IS NULL AND (B.HierarchyID IS NOT NULL OR CM.HierarchyID IS NOT NULL)) OR
        (A.BFIL_ClientID IS NULL AND ( CM.ClientID IS NOT NULL))
        and (ba.etl_is_active = 1 and ba.etl_is_active is Null)
        and (b.etl_is_active = 1 and ba.etl_is_active is Null)
        and (brd.etl_is_active = 1 and ba.etl_is_active is Null)
        and (mm.etl_is_active = 1 and ba.etl_is_active is Null)
        and (cld.etl_is_active = 1 and ba.etl_is_active is Null)
        and (km.etl_is_active = 1 and ba.etl_is_active is Null)
        and (cm.etl_is_active = 1 and ba.etl_is_active is Null)
        and (cls.etl_is_active = 1 and ba.etl_is_active is Null)
),




DuplicateAccounts AS (
    SELECT DISTINCT OperatorID, CIFID, AccountNumber
    FROM P_FirewallAccountsMaster
    WHERE AccountNumber IN (
            SELECT DISTINCT AccountNumber
            FROM P_FirewallAccountsMaster 
            WHERE BFIL_OperatorID IS NOT NULL
        ) AND BFIL_OperatorID IS NULL
),

--select * from P_FirewallAccountsMaster;

LatestDBTReqDate AS (
    SELECT CIFFID AS CIFID, MAX(Logged) AS RequestDate
    FROM {source_catalog}.{source_schema}.`firewall_prod-aadhaarapilog`
    WHERE Response LIKE '%success%' and etl_is_active = 1
    GROUP BY CIFFID
),
 UpdatedData_CTE AS (
    SELECT
        A.*,
        COALESCE(B.HierarchyID, TM.HierarchyID) AS NewHierarchyID,
        COALESCE(B.ClientID, CM.ClientID) AS NewClientID
    FROM P_FirewallAccountsMaster A
    JOIN LatestDBTReqDate B ON B.CIFID = A.CIFID
    LEFT JOIN {source_catalog}.{source_schema}.`rdsp-merchant_master` C ON C.Merchant_UIDAI_No = A.KYCNumber
    LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-clientmaster` B ON B.ClientID = A.External_CustomerID AND A.BFIL_ClientID IS NULL
    LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-targetmaster` TM ON TM.TargetID = A.External_CustomerID AND A.BFIL_ClientID IS NULL
    LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-clientmaster` CM ON CM.TargetID = TM.TargetID AND A.BFIL_ClientID IS NULL
    WHERE A.AccountType IN ('SB', 'CR') and (c.etl_is_active = 1 and c.etl_is_active is Null) and (b.etl_is_active = 1 and  B.etl_is_active is Null) and (tm.etl_is_active = 1 and tm.etl_is_active is Null) and (cm.etl_is_active = 1 and cm.etl_is_active is Null)
),

AccountClientsNull as(
Select	Distinct KYCNumber
From P_FirewallAccountsMaster 
Where BFIL_ClientID Is Null),


T_Rav_KYCTargets as(
Select	A.KYCNumber,
		km.targetid
From AccountClientsNull A
Join {source_catalog}.{source_schema}.`ptsmart-kycmaster` KM  On KM.KYCNumber = A.KYCNumber and KM.ClientOrSpouse In ('M','Y')),


UpdatedData_CTE3 AS (
    SELECT
A.InsertDate,
A.OperatorID,
A.BranchCode,
A.External_CustomerID,
A.CustomerName,
A.CustomerDOB,
A.Gender,
A.KYCNumber,
A.SpouseName,
A.SpouseDOB,
A.CIFID,
A.AccountType,
A.AccountNumber,
A.AccountOpenDate,
A.AccountStatus,
A.MobileNumber,
A.AgentID,
A.Tenure,
A.Booking_Amt,
A.Scheme_Code,
A.C5Code,
A.Form60,
A.PAN,
A.NameScreeningScore,
A.NameScreeningFlag,
A.IFSCCode,
A.NewTenure,
A.NewBookingAmt,
A.Is_StandaloneFD,
A.DBT_LatestReqDate,
A.MerchantID,
        COALESCE(CM.HierarchyID, B.HierarchyID,  B.HierarchyID, B.HierarchyID, SUBSTRING(A.External_CustomerID, 2, 6)) AS BFIL_HierarchyID,
        COALESCE(CM.ClientID, B.ClientID, B.ClientID, B.ClientID, 'BMS') AS BFIL_ClientID,
        CASE 
            WHEN A.BFIL_ClientID IS NULL AND COALESCE(CM.DropOutDate, '1900-01-01') = '1900-01-01' THEN 'BMS'
            WHEN A.BFIL_ClientID IS NULL AND COALESCE(CM.DropOutDate, '1900-01-01') <> '1900-01-01' THEN NULL
            ELSE A.BFIL_OperatorID
        END AS BFIL_OperatorID
    FROM P_FirewallAccountsMaster A
    LEFT JOIN T_Rav_KYCTargets KM ON  KM.KYCNumber = A.KYCNumber
    LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-clientmaster` CM ON CM.TargetID = KM.targetid AND A.BFIL_ClientID IS NULL
    LEFT JOIN {source_catalog}.{source_schema}.`pragati-clientbankdetails` B ON B.BankAccountNumber = A.AccountNumber AND A.BFIL_ClientID IS NULL
    LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-clientmaster` BA ON BA.ClientID = A.BFIL_ClientID 
    LEFT JOIN {mart_catalog}.{mart_schema}.`p_hierarchy_sop` H ON H.HierarchyID = A.BFIL_HierarchyID 
   -- where 
    --cm.etl_is_active = 1 and 
    --b.etl_is_active = 1 
    --and ba.etl_is_active = 1 
    --WHERE A.AccountType IN ('SB', 'CR')
)


  select * from  UpdatedData_CTE3;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"firewallaccounts_facts table Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on firewallaccounts_facts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on firewallaccounts_facts : ", str(e))

# COMMAND ----------

try:

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.firewallaccounts_facts")

    logger(
        logger_level_info,
        f"firewallaccounts_facts writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table firewallaccounts_facts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table firewallaccounts_facts : ", str(e)
    )

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)