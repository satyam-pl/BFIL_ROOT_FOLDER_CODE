# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_dailyloanfacts.dbc"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Facts/nb_dailyloanfacts_step1"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Facts/nb_dailyloanfacts_rlms"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Facts/nb_dailyloanfacts_rdsp"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    # Calculate the date for yesterday
    yesterday_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
    # Construct the table name
    backup_table_folder_path = f"BFIL-MART/FACTS/DAILYLOANFACTS_BKP_{yesterday_date}"
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FACTS/DAILYLOANFACTS"
    backup_path = mart_layer_abfss_url + backup_table_folder_path
    desti_path = "BFIL-MART/FACTS/DAILYLOANFACTS"
    

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """With DAILY_LOANFACTS_SUB as (
	SELECT * FROM
(SELECT * FROM
(SELECT * FROM (SELECT *, row_number() over (partition by ClientLoanid order by ClientLoanid) as rank FROM {mart_catalog}.{mart_schema}.dailyloanfacts_Step1) A where A.rank = 1)
UNION ALL
(SELECT * FROM
(SELECT *,
	NULL as HouseHoldIncomeAmount,
	NULL as ActualEWI,
	NULL as SpouseName,
	NULL as CenterMeetingTime,
	NULL as INterestaccured,
	NULL as CumPriDue_PM,
	NULL as CumINtDue_PM,
	NULL as Cum_PrINcipalColl_PM,
	NULL as Cum_INterestColl_PM,
	NULL as NoofInstallmentCompleted,
	NULL as Monthend_POS,
	NULL as Monthend_Ageing,
	NULL as Month_End_Status,
	NULL as Client_type,
	NULL as ClientNPAstatus,
	NULL as LoanType,
	NULL as Remarks_writeoff,
	NULL as Freezed_OP,
	NULL as LoanClosedDate1,
	row_number() over (partition by ClientLoanid order by ClientLoanid) as rank
FROM {mart_catalog}.{mart_schema}.dailyloanfacts_RDSP) A where A.rank = 1) 
UNION ALL
(SELECT * FROM
(SELECT *,
	NULL as HouseHoldIncomeAmount,
	NULL as ActualEWI,
	NULL as SpouseName,
	NULL as CenterMeetingTime,
	NULL as INterestaccured,
	NULL as CumPriDue_PM,
	NULL as CumINtDue_PM,
	NULL as Cum_PrINcipalColl_PM,
	NULL as Cum_INterestColl_PM,
	NULL as NoofInstallmentCompleted,
	NULL as Monthend_POS,
	NULL as Monthend_Ageing,
	NULL as Month_End_Status,
	NULL as Client_type,
	NULL as ClientNPAstatus,
	NULL as LoanType,
	NULL as Remarks_writeoff,
	NULL as Freezed_OP,
	NULL as LoanClosedDate1,
	row_number() over (partition by ClientLoanid order by ClientLoanid) as rank
FROM {mart_catalog}.{mart_schema}.dailyloanfacts_RLMS) A where A.rank = 1))
),

Min_DPDDate_DAILY_LOANFACTS_SUB AS (
		SELECT MIN(DPDStartdate) Min_DPDStartdate,ClientId FROM DAILY_LOANFACTS_SUB
		GROUP BY ClientId
),

DAILY_COD
AS
(
SELECT p.HierarchyId AS HierarchyId,MAX(p.CODDATE) AS Max_CODDATE
FROM {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` p
join {mart_catalog}.{mart_schema}.`p_hierarchy_sop` t on t.hierarchyid=p.hierarchyid
GROUP BY p.HierarchyId
),
NPA_CLOSED_LOANS
AS
(
SELECT NPA2.*, CLSD.MaxCODDate AS MaxCODDate FROM
(SELECT CLS.ClientLoanid , MAX(NPA.CODDATE) AS MaxCODDate,MIN(NPA.LastUnpaidDate) as LastUnpaidDate
FROM  {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription`  CLS
JOIN    {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` NPA ON CLS.ClientLoanID = NPA.ClientLoanID
and CLS.hierarchyid = NPA.hierarchyid
where CLS.LoanClosedDate IS NOT NULL
GROUP BY CLS.ClientLoanid) CLSD
JOIN {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` NPA2
ON CLSD.ClientLoanID = NPA2.ClientLoanID AND CLSD.MaxCODDate = NPA2.CODDate
where NPA2.LoanClosedDate IS not NULL
),
month_end_status
AS
(
SELECT 
 monthlf.Ageing_client_CM as Ageing_client_PM
,monthlf.client_Ason_status as Month_end_status
,monthlf.HierarchyId as HierarchyId
,monthlf.Clientid as Clientid
,monthlf.Ageing as Monthend_Ageing
,monthlf.Client_DPD as Client_DPD_PM
,monthlf.NPA_date as NPA_date
,sum(monthlf.POS) as Month_END_POS
,monthlf.client_Type as client_Type
,monthlf.client_Ason_status as clientNPAstatus_PM
from  {source_catalog}.{source_schema}.`azuresource-p_loanfacts_client` monthlf 
group by hierarchyId,Ageing_client_CM,Ageing,
Clientid,Client_DPD,NPA_date ,client_Ason_status,client_Type
),
DAILY_DPD_DATE
AS
--- need to be reviewed
(
select CLS.clientid,CLS.HierarchyId,  Min(NPA.LastUnpaidDate) as NPA_LastUnpaidDate, Min(NPA_CL.LastUnpaidDate) as NPA_CL_LastUnpaidDate
FROM {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` CLS
LEFT JOIN DAILY_COD A ON CLS.HierarchyId = A.HierarchyId
LEFT JOIN {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` NPA ON CLS.ClientLoanID = NPA.ClientLoanID AND A.Max_CODDATE = NPA.CODDate
LEFT JOIN NPA_CLOSED_LOANS NPA_CL ON NPA_CL.ClientLoanID = CLS.ClientLoanID AND NPA_CL.MaxCODDate = A.Max_CODDATE
group by CLS.ClientId,CLS.HierarchyId
),
D2K_NPA1 as (
		select sum(PrincipleOutstanding) as PrincipleOutstanding, sum(IntOverdue) as IntOverdue, sum(TotalProvision) as TotalProvision, customerid, NPA_Date,AssetClassName 
		from (
		select distinct  max(CreatedDateTime) as CreatedDateTime,
		NCIF_Id,customerid, AssetClassName, NCIF_NPA_Date as NPA_Date,
		cast( PrincipleOutstanding as  decimal (18,2) ) as PrincipleOutstanding,
		cast( IntOverdue  as decimal(18,2))as IntOverdue, cast(TotalProvision as decimal(18,2)) as TotalProvision
		from {source_catalog}.{source_schema}.`ptsmartnpa-d2k_npadetailsfrommanagedfiles`
		where lower(sourcename)='pt smart' and  NCIF_NPA_Date is not null
		and AssetClassName is not  Null AND (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)
		group by NCIF_Id,customerid, AssetClassName, NCIF_NPA_Date ,PrincipleOutstanding,IntOverdue,TotalProvision
		)
		group by customerid,AssetClassName,NPA_Date
		),
D2K_NPA as (
			select  customerid, NPA_Date,AssetClassName AssetCl_Br,PrincipleOutstanding,IntOverdue from D2K_NPA1
			Union all
			Select	ClientId,NPADate,AssetCl_Br,POS	,0 from {source_catalog}.{source_schema}.`azuresource-p_agri_nonagri_npachange_list01`
		),
CLIENT_DPD
AS
(
Select  ClientId,
		Max(case when upper(Freezed1) = 'Y' and lower(DAILY_LOANFACTS_SUB.Type_New) in ('advances') then noofdaysINarrears1 end) as Max_noofdaysINarrears_EXCL_ARC ,
		Max( case when upper(Freezed_OP) ='Y'  then noofdaysINarrears1 end) as Max_noofdaysINarrears_ALL,
		(case when  Max( case when upper(Freezed_OP) ='Y'  then NoOfDaysInArrears1 end) = 0 THEN 'Current1'
		WHEN COALESCE (Max( case when upper(Freezed_OP) ='Y'  then NoOfDaysInArrears1 end),0) BETWEEN 1 AND 30 THEN '[1 To 30]'
		WHEN COALESCE (Max( case when upper(Freezed_OP) ='Y'  then NoOfDaysInArrears1 end),0) BETWEEN 31 AND 60 THEN '[31 To 60]'
		WHEN COALESCE (Max( case when upper(Freezed_OP) ='Y'  then NoOfDaysInArrears1 end),0) BETWEEN 61 AND 90 THEN '[61 To 90]'
		WHEN COALESCE (Max( case when upper(Freezed_OP) ='Y'  then NoOfDaysInArrears1 end),0) > 90 THEN '[>90]'   END) AS ALL_Client_ageing
		,(case when  Max(case when upper(freezed1) = 'Y' and lower(DAILY_LOANFACTS_SUB.Type_New) in ('advances','On B/s') then NoOfDaysInArrears1 end)=0  THEN 'Current1'
		WHEN COALESCE (Max(case when upper(freezed1) = 'Y' AND lower(DAILY_LOANFACTS_SUB.Type_New) in ('advances','On B/s') then NoOfDaysInArrears1 end),0) BETWEEN 1 AND 30 THEN '[1 To 30]'
		WHEN COALESCE (Max(case when upper(freezed1) = 'Y' AND lower(DAILY_LOANFACTS_SUB.Type_New) in ('advances','On B/s') then NoOfDaysInArrears1 end),0) BETWEEN 31 AND 60 THEN '[31 To 60]'
		WHEN COALESCE (Max(case when upper(freezed1) = 'Y' AND lower(DAILY_LOANFACTS_SUB.Type_New) in ('advances','On B/s') then NoOfDaysInArrears1 end),0) BETWEEN 61 AND 90 THEN '[61 To 90]'
		WHEN COALESCE (Max(case when upper(freezed1) = 'Y' AND lower(DAILY_LOANFACTS_SUB.Type_New) in ('advances','On B/s') then NoOfDaysInArrears1 end),0) > 90 THEN '[>90]' END) AS  Ageing_Client_EXCL_ARC
from DAILY_LOANFACTS_SUB
Group by ClientId
),
ClientNPAstatus_PM as
(
select  distinct clientid,  Monthend_Status ClientNPAstatus
from     {source_catalog}.{source_schema}.`azuresource-p_loanfacts`
  where lower(freezed)='y ' and lower(assetcl_br) in('db1','db2','db3','los','sub')  and upper(branch_type)<>'HIL'
)

SELECT DISTINCT
		DAILY_LOANFACTS_SUB.CODDATE
		,DAILY_LOANFACTS_SUB.Branch_Type
		,DAILY_LOANFACTS_SUB.State
		,DAILY_LOANFACTS_SUB.Region
		,DAILY_LOANFACTS_SUB.District
		,DAILY_LOANFACTS_SUB.Zone
		,DAILY_LOANFACTS_SUB.Area
		,DAILY_LOANFACTS_SUB.BranchName
		,DAILY_LOANFACTS_SUB.BranchID
		,DAILY_LOANFACTS_SUB.HierarchyId
		,DAILY_LOANFACTS_SUB.ClientLoanId
		,DAILY_LOANFACTS_SUB.ClientLoanCode
		,DAILY_LOANFACTS_SUB.LoanProposalId
		,DAILY_LOANFACTS_SUB.LoanProposalCode
		,DAILY_LOANFACTS_SUB.ProductName
		,DAILY_LOANFACTS_SUB.ProductCode
		,DAILY_LOANFACTS_SUB.ProductDescription
		,DAILY_LOANFACTS_SUB.ClientProductSequenceNo
		,DAILY_LOANFACTS_SUB.ClientId
		,DAILY_LOANFACTS_SUB.ClientCode
		,DAILY_LOANFACTS_SUB.ClientName
		,DAILY_LOANFACTS_SUB.CenterCode
		,DAILY_LOANFACTS_SUB.CenterId
		,DAILY_LOANFACTS_SUB.centername
		,DAILY_LOANFACTS_SUB.CenterMeetingDay
		,DAILY_LOANFACTS_SUB.CenterStaffID
		,DAILY_LOANFACTS_SUB.DisbursementDate
		,DAILY_LOANFACTS_SUB.LoanAmountDisbursed
		,DAILY_LOANFACTS_SUB.ExpectedPaidUPDATE
		,DAILY_LOANFACTS_SUB.LoanClosedDate1
		,DAILY_LOANFACTS_SUB.PurposeId
		,DAILY_LOANFACTS_SUB.PurposeName
		,DAILY_LOANFACTS_SUB.HoUSEHoldINcome
		,DAILY_LOANFACTS_SUB.INterestRate
		,DAILY_LOANFACTS_SUB.DifferenceAmountInPreclosing
		,DAILY_LOANFACTS_SUB.Tenure
		,DAILY_LOANFACTS_SUB.FundName
		,DAILY_LOANFACTS_SUB.FundId
		,DAILY_LOANFACTS_SUB.Caste
		,DAILY_LOANFACTS_SUB.Religion
		,DAILY_LOANFACTS_SUB.Rural_Urban
		,DAILY_LOANFACTS_SUB.DeviationCancel
		,DAILY_LOANFACTS_SUB.LoanCancelleddate
		,DAILY_LOANFACTS_SUB.DisbursementMode
		,DAILY_LOANFACTS_SUB.RepaymentFrequency
		,DAILY_LOANFACTS_SUB.Gender
		,DAILY_LOANFACTS_SUB.DateOfBirth
		,DAILY_LOANFACTS_SUB.JoinDate
		,DAILY_LOANFACTS_SUB.ProposalDate
		,DAILY_LOANFACTS_SUB.ApprovedDate
		,DAILY_LOANFACTS_SUB.LoanAmountApproved
		,DAILY_LOANFACTS_SUB.Groupid
		,DAILY_LOANFACTS_SUB.TargetId
		,DAILY_LOANFACTS_SUB.TargetCode
		,DAILY_LOANFACTS_SUB.TargetDate
		,DAILY_LOANFACTS_SUB.IsLoanClosed
		,DAILY_LOANFACTS_SUB.UpfrontInterest_vp
		,DAILY_LOANFACTS_SUB.NPAStatus
		,DAILY_LOANFACTS_SUB.Moratorium_flag
		,DAILY_LOANFACTS_SUB.DeathDate
		,DAILY_LOANFACTS_SUB.Cum_PrincipalColl1
		,DAILY_LOANFACTS_SUB.Cum_InterestColl1
		,DAILY_LOANFACTS_SUB.Cum_Pridue
		,DAILY_LOANFACTS_SUB.Cum_IntDue
		,DAILY_LOANFACTS_SUB.PrincipalWrittenoff
		,DAILY_LOANFACTS_SUB.InterestWrittenoff
		,DAILY_LOANFACTS_SUB.TransactionDate
		,DAILY_LOANFACTS_SUB.Total_PrincipalDue
		,DAILY_LOANFACTS_SUB.Total_InterestDue
		,DAILY_LOANFACTS_SUB.RD_AdjustAmt
		,CASE WHEN DAILY_LOANFACTS_SUB.POS < 0 THEN 0 ELSE DAILY_LOANFACTS_SUB.POS END POS
		,DAILY_LOANFACTS_SUB.IOS
		,DAILY_LOANFACTS_SUB.PrincipalInArears
		,DAILY_LOANFACTS_SUB.InterestInArears
		,DAILY_LOANFACTS_SUB.LastRepaymentDate
		,DAILY_LOANFACTS_SUB.M_Flag
		,DAILY_LOANFACTS_SUB.Last_CMDate
		,DAILY_LOANFACTS_SUB.DPDStartdate
		,DAILY_LOANFACTS_SUB.NoOfDaysInArrears1
		,DAILY_LOANFACTS_SUB.Type_New
		,DAILY_LOANFACTS_SUB.freezed1
		,DAILY_LOANFACTS_SUB.Loan_Status
		,DAILY_LOANFACTS_SUB.Ageing_Loan
		,DAILY_LOANFACTS_SUB.Product_type
		,DAILY_LOANFACTS_SUB.EWI
		,DAILY_LOANFACTS_SUB.ProductCategory
		,DAILY_LOANFACTS_SUB.ClosedloanwithPos
		,DAILY_LOANFACTS_SUB.M_PriDue
		,DAILY_LOANFACTS_SUB.M_IntDue
		,DAILY_LOANFACTS_SUB.M_PriColl
		,DAILY_LOANFACTS_SUB.M_IntColl
		,DAILY_LOANFACTS_SUB.HouseHoldIncomeAmount
		,DAILY_LOANFACTS_SUB.ActualEWI
		,DAILY_LOANFACTS_SUB.SpouseName
		,DAILY_LOANFACTS_SUB.CenterMeetingTime
		,DAILY_LOANFACTS_SUB.INterestaccured
		,DAILY_LOANFACTS_SUB.CumPriDue_PM
		,DAILY_LOANFACTS_SUB.CumINtDue_PM
		,DAILY_LOANFACTS_SUB.Cum_PrINcipalColl_PM
		,DAILY_LOANFACTS_SUB.Cum_INterestColl_PM
		,DAILY_LOANFACTS_SUB.NoofInstallmentCompleted
		,DAILY_LOANFACTS_SUB.Monthend_POS
		,DAILY_LOANFACTS_SUB.Monthend_Ageing
		,DAILY_LOANFACTS_SUB.Month_End_Status
		,DAILY_LOANFACTS_SUB.Client_type
		--,DAILY_LOANFACTS_SUB.ClientNPAstatus
		,DAILY_LOANFACTS_SUB.LoanType
		,DAILY_LOANFACTS_SUB.Remarks_writeoff
		,DAILY_LOANFACTS_SUB.Freezed_OP
		--,DAILY_LOANFACTS_SUB.LoanClosedDate
		,CLIENT_DPD.ALL_Client_ageing
		,CLIENT_DPD.Max_noofdaysINarrears_EXCL_ARC AS ClientDPD_EXCL_ARC
		,CLIENT_DPD.Max_noofdaysINarrears_ALL AS ALL_Client_DPD
		,CASE WHEN CLIENT_DPD.ClientId IS NOT NULL THEN CLIENT_DPD.Ageing_Client_EXCL_ARC ELSE DAILY_LOANFACTS_SUB.Ageing_Client_EXCL_ARC END Ageing_Client_EXCL_ARC
		,(CASE WHEN upper(freezed1)='Y' AND DAILYNPA.CUSTOMERID is not null THEN 'Yes'
		WHEN upper(freezed1)='Y' and (CASE WHEN CLIENT_DPD.ClientId IS NOT NULL THEN CLIENT_DPD.Ageing_Client_EXCL_ARC ELSE DAILY_LOANFACTS_SUB.Ageing_Client_EXCL_ARC END)='[>90]'
		AND remarks_writeoff is null
		THEN 'Yes'
		WHEN ALL_Client_ageing ='[>90]' AND DAILYNPA.CUSTOMERID is not null THEN 'Yes'
		WHEN ((upper(freezed1)='Y') or (lower(DAILY_LOANFACTS_SUB.Type_New) in ('writeoff_mar22', 'writeoff_mar23','writeoff_jun23','writeoff_jun21','writeoff_sep23','writeoff_jun22','writeoff_sep22','writeoff_dec22' ,'closed deals mar22'))) AND (CASE WHEN CLIENT_DPD.ClientId IS NOT NULL THEN CLIENT_DPD.Ageing_Client_EXCL_ARC ELSE DAILY_LOANFACTS_SUB.Ageing_Client_EXCL_ARC END)!='[>90]' and LoanClosedDate1 is null THEN 'No'
		WHEN lower(DAILY_LOANFACTS_SUB.Type_New) in ('arc_mar21','arc_dec21','arc_feb23','arc_mar23') and DAILY_LOANFACTS_SUB.LoanClosedDate1 is null THEN 'No'
		WHEN DAILY_LOANFACTS_SUB.Type_New like '%Writeoff%' THEN 'No'
		ELSE 'No'
		END
		) AS As_on_NPA
    ,(CASE WHEN upper(freezed1)='Y' AND DAILYNPA.CUSTOMERID is not null THEN DAILYNPA.Assetcl_br
	  WHEN upper(freezed1)='Y' and
	 (CASE WHEN CLIENT_DPD.ClientId IS NOT NULL THEN CLIENT_DPD.Ageing_Client_EXCL_ARC 
	 ELSE DAILY_LOANFACTS_SUB.Ageing_Client_EXCL_ARC END)='[>90]'
		AND remarks_writeoff is null
		AND DAILYNPA.CUSTOMERID is null THEN 'SUB'
		WHEN upper(freezed1)='Y'
		and remarks_writeoff is null
		and CLIENT_DPD.ClientId IS NOT NULL 
		AND CLIENT_DPD.Ageing_Client_EXCL_ARC in('[31 To 60]','[61 To 90]','[1 To 30]','Current1') 
		AND DAILYNPA.CUSTOMERID is null THEN 'Standard'
		WHEN lower(DAILY_LOANFACTS_SUB.Type_New) like ('%arc%') AND DAILYNPA.CUSTOMERID is null THEN 'ARC'
		ELSE DAILY_LOANFACTS_SUB.AssetCl_BR
		END
		) AS AssetClBR
	  ,(CASE WHEN CLIENT_DPD.Max_noofdaysINarrears_EXCL_ARC BETWEEN 1 AND 91 and lower(DAILY_LOANFACTS_SUB.freezed1)='y' THEN 91-CAST(CLIENT_DPD.Max_noofdaysINarrears_EXCL_ARC as INT)
		WHEN upper(DAILY_LOANFACTS_SUB.freezed1)='Y' and lower(as_on_NPA)='yes' THEN NULL
		END
		) AS days_to_r91
		,(
		CASE WHEN CLIENT_DPD.Max_noofdaysINarrears_EXCL_ARC BETWEEN 1 AND 91 and lower(DAILY_LOANFACTS_SUB.freezed1)='y' THEN DATE_ADD(DAILY_LOANFACTS_SUB.CODDATE,CAST(days_to_r91 AS INT))
		WHEN upper(DAILY_LOANFACTS_SUB.freezed1)='Y' and lower(as_on_NPA)='yes' THEN NULL
		END
		) AS Expected_NPA_date
		,(
		CASE WHEN upper(freezed1)='Y' AND DAILYNPA.CUSTOMERID is not null THEN DAILYNPA.NPA_date
		WHEN upper(freezed1)='Y' and (CASE WHEN CLIENT_DPD.ClientId IS NOT NULL THEN CLIENT_DPD.Ageing_Client_EXCL_ARC ELSE DAILY_LOANFACTS_SUB.Ageing_Client_EXCL_ARC END)='[>90]'
		-- AND remarks_writeoff is null
		THEN date_format(to_timestamp(current_date()-1, "yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd")
		WHEN upper(freezed_op)='Y' and upper(freezed1)='Y' and AssetClBR is null and (CASE WHEN CLIENT_DPD.ClientId IS NOT NULL THEN CLIENT_DPD.Ageing_Client_EXCL_ARC ELSE DAILY_LOANFACTS_SUB.Ageing_Client_EXCL_ARC END)='[>90]'
		-- and remarks_writeoff is null
		AND CLIENT_DPD.clientid is not NULL then to_timestamp(date_add(Min_DPDDate_DAILY_LOANFACTS_SUB.Min_DPDStartdate,90), "yyyy-MM-dd")
		END
		) AS NPA_date
		,(CASE WHEN upper(freezed1)='Y' AND DAILYNPA.CUSTOMERID is not null and lower(As_on_NPA)='yes' and ClientNPAstatus_PM.ClientNPAstatus is not null THEN ClientNPAstatus_PM.ClientNPAstatus 
    WHEN upper(freezed1)='Y' AND DAILYNPA.CUSTOMERID is not null and lower(As_on_NPA)='yes' THEN  'NPA In CurrentMonth' 
    WHEN lower(As_on_NPA)='no' and Expected_NPA_date is not null and NoOfDaysInArrears1 between 1 and 90 THEN concat('Expected NPA in ' , date_format(cast(Expected_NPA_date as date), 'MMM'))
    WHEN upper(freezed_op)='Y' and lower(As_on_NPA) ='no' and upper(DAILY_LOANFACTS_SUB.type_new) IN ('ARC_DEC21','ARC_MAR23','ARC_FEB23') THEN DAILY_LOANFACTS_SUB.type_new 
    WHEN upper(freezed_op)='Y' and lower(As_on_NPA) ='no' and lower(DAILY_LOANFACTS_SUB.type_new) like '%writeoff_%' THEN month_end_status.ClientNPAstatus_PM 
    WHEN month_end_status.CLIENTID IS NOT NULL and lower(As_on_NPA) ='no' and month_end_status.ClientNPAstatus_PM like '%Closeddeals%' THEN month_end_status.ClientNPAstatus_PM else CLIENT_DPD.ALL_Client_ageing  END ) ClientNPAstatus
    FROM DAILY_LOANFACTS_SUB 
    LEFT JOIN Min_DPDDate_DAILY_LOANFACTS_SUB ON Min_DPDDate_DAILY_LOANFACTS_SUB.ClientId = DAILY_LOANFACTS_SUB.ClientId 
    LEFT JOIN CLIENT_DPD ON CLIENT_DPD.ClientId = DAILY_LOANFACTS_SUB.ClientId 
    LEFT JOIN D2K_NPA DAILYNPA ON DAILYNPA.CustomerId = DAILY_LOANFACTS_SUB.clientid 
    LEFT JOIN DAILY_DPD_DATE ON DAILY_DPD_DATE.clientid = DAILY_LOANFACTS_SUB.Clientid 
    LEFT JOIN month_end_status ON month_end_status.clientid = DAILY_LOANFACTS_SUB.Clientid 
    LEFT JOIN ClientNPAstatus_PM ON ClientNPAstatus_PM.clientid = DAILY_LOANFACTS_SUB.Clientid""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

try:
    sql_query = f"SELECT * FROM {mart_catalog}.{mart_schema}.dailyloanfacts"
    df = spark.sql(sql_query)
    logger(
        logger_level_info,
        f"dailyloanfacts Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on dailyloanfacts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on dailyloanfacts : ", str(e))

# COMMAND ----------



try :
    # Calculate the date for yesterday
    yesterday_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
    # Construct the table name
    table_name = f"dailyloanfacts_bkp_{yesterday_date}"
    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",backup_path).saveAsTable(f"{mart_catalog}.{mart_schema}.{table_name}")

    logger(
            logger_level_info,
            f"{table_name} writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table {table_name} : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table dailyloanfacts_bkp : ", str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"dailyloanfacts Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on dailyloanfacts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on dailyloanfacts : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.dailyloanfacts")

    logger(
            logger_level_info,
            f"dailyloanfacts writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table dailyloanfacts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table dailyloanfacts : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)