# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_rd_disbursementbase_fact.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FACTS/RD_DISBURSEMENTBASE_FACT"
    desti_path = "BFIL-MART/FACTS/RD_DISBURSEMENTBASE_FACT"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH CTE_RD_CLIENTLOANSUBSCRIPTION As       
(
  Select Distinct CURRENT_DATE() As ReportGenDate,'MFI' As SBU,          
  CM.TargetID,          
  CM.ClientID,                  
  CM.ClientName,          
  Cast(CM.DateOfBirth As Date) As DateOfBirth,          
  CM.MaritalStatus,          
  k1.kYCNUMBER aS AadharNumber,
  Cast(CM.JoinDate As Date) As JoinDate,          
  (Case When CM.DropOutDate IS NULL Then Null          
  Else Cast(CM.DropOutDate As Date) End) As DropOutDate,          
  (Case When COALESCE(CM.DropOutDate,'1900-01-01') ='1900-01-01' Then 'Active'          
  Else 'DropOut' End) As ClientStatus,          
  CNM.CenterID,          
  CNM.CenterMeetingDay,          
  CNM.StaffId As CenterHandled_StaffID,          
  UM.UserName As CenterHandled_StaffName,          
  0 As CenterStatus,          
  Cls.LoanProposalID,          
  Clp.ProposalDate,          
  Cls.ClientLoanID As RDLoanID,          
  Cls.ClientProductSequenceNo As SequenceID,          
  Cls.RDAccountNumber,          
  Cast(Cls.DisbursementDate As Date) As RD_OpenDate,          
  Cls.LoanAmountDisbursed As RD_Amount,       
    Cast(Clp.InterestRate As Decimal(10,2)) As InterestRate,  
 Cls.Tenure,          
  Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate,          
  (Case When Cls.LoanClosedDate is null Then Null          
  Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,          
  (Case When Cls.LoanClosedDate is null Then 'Active'          
     When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'          
     When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus,          
  Cls.Comments,        

cast(NULL as varchar(50)) AS BussinessType,
cast(NULL as varchar(50)) AS CAFlag,      
cast(NULL as varchar(50)) AS AccountNumber,      
cast(NULL as varchar(50)) AS BatchID,      
cast(NULL as varchar(50)) As RDOpenStaffID,    
cast(NULL as varchar(50)) As RDOpenStaffName,      
cast(NULL as varchar(50)) AS ProductID,    
cast(NULL as varchar(50)) AS PurposeID
       
From {source_catalog}.{source_schema}.`pragati-clientloansubscription` Cls          
Join {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` Clp On Clp.LoanProposalID = Cls.LoanProposalID   and Clp.ETL_IS_ACTIVE=1       
Join {source_catalog}.{source_schema}.`pragati-clientmaster`  CM On CM.ClientID = Cls.ClientID    and  CM.ETL_IS_ACTIVE=1      
Join {source_catalog}.{source_schema}.`pragati-groupmaster` GM On GM.GroupID = CM.GroupID         and GM.ETL_IS_ACTIVE=1 
Join {source_catalog}.{source_schema}.`pragati-centermaster` CNM On CNM.CenterID = GM.CenterID    and CNM.ETL_IS_ACTIVE=1      
Left Join {source_catalog}.{source_schema}.`pragatimain-usermaster`  UM ON UM.UserID = CNM.StaffID          and UM.ETL_IS_ACTIVE=1
LEFT Join {source_catalog}.{source_schema}.`pragati-kycmaster`  K1 On K1.TargetID = CM.TargetID and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M','Y')   and K1.ETL_IS_ACTIVE=1       
Where Cls.ProductType Is Not Null          
and (Cls.LoanClosedDate IS NULL OR Cls.LoanClosedDate >= CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE))

and Cls.ETL_IS_ACTIVE=1

  UNION 
  Select Distinct CURRENT_DATE() As ReportGenDate,'BMS',          
  CM.TargetID,          
  CM.ClientID,                  
  CM.ClientName,          
  Cast(CM.DateOfBirth As Date) As DateOfBirth,          
  CM.MaritalStatus,          
  k1.kYCNUMBER aS AadharNumber,
  Cast(CM.JoinDate As Date) As JoinDate,          
  (Case When CM.DropOutDate IS NULL Then Null          
  Else Cast(CM.DropOutDate As Date) End) As DropOutDate,          
  (Case When COALESCE(CM.DropOutDate,'1900-01-01') ='1900-01-01' Then 'Active'          
  Else 'DropOut' End) As ClientStatus,          
  CNM.CenterID,          
  CNM.CenterMeetingDay,          
  CNM.StaffId As CenterHandled_StaffID,          
  UM.UserName As CenterHandled_StaffName,          
  Null As CenterStatus,          
  Cls.LoanProposalID,          
  Clp.ProposalDate,          
  Cls.ClientLoanID As RDLoanID,          
  Cls.ClientProductSequenceNo As SequenceID,          
  Cls.RDAccountNumber,          
  Cast(Cls.DisbursementDate As Date) As RD_OpenDate,          
  Cls.LoanAmountDisbursed As RD_Amount,       
    Cast(Clp.InterestRate As Decimal(10,2)) As InterestRate,  
 Cls.Tenure,          
  Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate,          
  (Case When Cls.LoanClosedDate is null Then Null          
  Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,          
  (Case When Cls.LoanClosedDate is null Then 'Active'          
     When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'          
     When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus,          
  Cls.Comments,          
cast(NULL as varchar(50)) AS BussinessType,
cast(NULL as varchar(50)) AS CAFlag,      
cast(NULL as varchar(50)) AS AccountNumber,      
cast(NULL as varchar(50)) AS BatchID,      
cast(NULL as varchar(50)) As RDOpenStaffID,    
cast(NULL as varchar(50)) As RDOpenStaffName,      
cast(NULL as varchar(50)) AS ProductID,    
cast(NULL as varchar(50)) AS PurposeID    

From {source_catalog}.{source_schema}.`ptsmart-clientloansubscription` Cls          
Join {source_catalog}.{source_schema}.`ptsmart-clientloanproposal` Clp On Clp.LoanProposalID = Cls.LoanProposalID       
Join {source_catalog}.{source_schema}.`ptsmart-clientmaster`  CM On CM.ClientID = Cls.ClientID         
Join {source_catalog}.{source_schema}.`ptsmart-groupmaster` GM On GM.GroupID = CM.GroupID          
Join {source_catalog}.{source_schema}.`ptsmart-centermaster` CNM On CNM.CenterID = GM.CenterID            
Left Join {source_catalog}.{source_schema}.`ptsmart-usermaster`  UM ON UM.UserID = CNM.StaffID          
LEFT Join {source_catalog}.{source_schema}.`ptsmart-kycmaster`  K1 On K1.TargetID = CM.TargetID and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M','Y')         
Where Cls.ProductType Is Not Null          
and (Cls.LoanClosedDate IS NULL OR Cls.LoanClosedDate >= CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE))



UNION
select 
Distinct current_date() As ReportGenDate, 'BSS',      
CM.BaselineCustomerID,      
CM.CustomerID,      
CM.CustomerName,      
Cast(Clp1.ClientDOBAtDisbursement As Date) As DateOfBirth,
Clp1.MaritalStatus, 
 k1.kYCNUMBER aS AadharNumber,
Cast(CM.JoinDate As Date) As JoinDate,
(Case When CM.DropOutDate is null Then Null      
   Else Cast(CM.DropOutDate As Date) End) As DropOutDate, 
(Case When  CM.DropOutDate is null Then 'Active'      
   Else 'DropOut' End) As CustomerStatus,
   NULL as CenterID,
   CM.DisbursementDay As CenterMeetingDay,
   BM.UserID As Handled_StaffID,      
   UM.UserName As Handled_StaffName,  
   NULL as CenterStatus,
Cls.LoanApplicationID,      
Clp.LoanApplicationDate,      
Cls.CustomerLoanID As RDLoanID,      
Cls.CustomerProductSequenceNo As SequenceID,     
Cls.RDAccountNumber,      
Cast(Cls.DisbursementDate As Date) As RDOpenDate,
Cls.LoanAmountDisbursed As RDAmount,      
Cast(Clp.InterestRate As Decimal(10,2)) As ROI,  
Cls.Tenure,    
Cast(Cls.ExpectedPaidUpDate As Date) As RDExpectPaidUpDate, 
(Case When Cls.LoanClosedDate is null Then Null      
Else Cast(Cls.LoanClosedDate As Date) End) As RDClosedDate,  
(Case When Cls.LoanClosedDate is null Then 'Active'      
      When Cast(Cls.LoanClosedDate As Date) < Cast(Cls.ExpectedPaidUpDate As Date) Then 'PreClosed'      
      When Cast(Cls.LoanClosedDate As Date) >= Cast(Cls.ExpectedPaidUpDate As Date) Then 'Closed' End) As RDStatus, 
Cls.Comments,
CS.NatureOfBusiness As BussinessType,      
BCM.CAFlag,      
BRD.SBAccountNumber As AccountNumber,      
CM.BatchID,      
Cls.CreatedBy As RDOpenStaffID,    
UM1.UserName As RDOpenStaffName,      
Cls.ProductID,    
Clp.PurposeID

from {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` Cls
join {source_catalog}.{source_schema}.`rlmsbizxtend-customerloanapplication`  CLP on Clp.LoanApplicationID = Cls.LoanApplicationID 
join {source_catalog}.{source_schema}.`rlmsbizxtend-additionalloanapplicationdetails` Clp1 on Clp1.LoanApplicationID = Cls.LoanApplicationID
join {source_catalog}.{source_schema}.`rlmsbizxtend-customermaster` CM on CM.CustomerID = Cls.CustomerID
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-baselinecustomermaster_h_view` BCM on BCM.CustomerID = CM.BaseLineCustomerID and BCM.ETL_IS_ACTIVE=1
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-batchmaster` BM on BM.BatchID = CM.BatchID
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-usermaster` UM on UM.UserID = BM.UserID 
left join {source_catalog}.{source_schema}.`rlmsbizxtend-usermaster` UM1 on UM1.UserID = Cls.CreatedBy
left join {source_catalog}.{source_schema}.`rlmsbizxtend-customershopdetails` CS on CS.CustomerID = CM.BaseLineCustomerID
left join {source_catalog}.{source_schema}.`rlmsbizxtend-bankrelationdetails_h_view` BRD on BRD.CustomerID = CM.CustomerID and BRD.ETL_IS_ACTIVE=1
left join {source_catalog}.{source_schema}.`rlmsbizxtend-kycmaster` K1 On K1.CustomerId = CM.BaselineCustomerId and K1.KYCType ='IDP6' and K1.ClientOrSpouse in ('M')
Where(Cls.LoanClosedDate IS NULL OR Cls.LoanClosedDate >= CAST(date_trunc('MONTH', from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')) AS DATE))
),



/* BMS RD MAX TRANDATE  FOR EXCEPTION LOG REMARKS*/
CTE_CollectionExceptionLog_MAXDATE aS
(
Select A.ClientID,          
Max(Cast(B.TransactionDate As Date)) As Max_TranDate          
From CTE_RD_CLIENTLOANSUBSCRIPTION A          
Join {source_catalog}.{source_schema}.`pragati-collectionexceptionlog` B On B.ClientID = A.ClientID          
Group By A.ClientID          

 UNION

Select A.ClientID,          
Max(Cast(B.TransactionDate As Date)) As Max_TranDate          
From CTE_RD_CLIENTLOANSUBSCRIPTION A          
Join {source_catalog}.{source_schema}.`ptsmart-collectionexceptionlog` B On B.ClientID = A.ClientID          
Group By A.ClientID          
),

/* FOR NO OF LOANS */

CTE_LoanCount AS (

  Select A.ClientID,          
  Count(Distinct B.ClientLoanID) As NoOfLoans          
From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
Join {source_catalog}.{source_schema}.`pragati-clientloansubscription` B On B.ClientID = A.ClientID          
Where B.LoanClosedDate is null and B.ProductType Is Null   and B.ETL_IS_ACTIVE=1       
Group By A.ClientID 
union
Select A.ClientID,          
  Count(Distinct B.ClientLoanID) As NoOfLoans          
From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
Join {source_catalog}.{source_schema}.`ptsmart-clientloansubscription` B On B.ClientID = A.ClientID          
Where B.LoanClosedDate is null and B.ProductType Is Null          
Group By A.ClientID 
union 
Select A.ClientID,          
  Count(Distinct B.customerloanid) As NoOfLoans          
From  CTE_RD_CLIENTLOANSUBSCRIPTION A          
Join {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` B On B.customerid = A.ClientID          
Where B.LoanClosedDate is null and B.ProductType Is Null          
Group By A.ClientID 

),

CTE_RD_DISBURSEMENTBASE AS 

(
SELECT A.*,C.Remarks,
(Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
D.NoOfLoans  
 FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
LEFT JOIN CTE_CollectionExceptionLog_MAXDATE b ON b.CLIENTID=a.ClientID 
LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-collectionexceptionlog` C On B.ClientID = C.ClientID  AND Cast(c.TransactionDate As Date) = B.Max_TranDate
LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
union
SELECT A.*,C.Remarks,
(Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
D.NoOfLoans  
 FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
LEFT JOIN CTE_CollectionExceptionLog_MAXDATE b ON b.CLIENTID=a.ClientID 
LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-collectionexceptionlog` C On B.ClientID = C.ClientID  AND Cast(c.TransactionDate As Date) = B.Max_TranDate
LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
union
SELECT A.*,b.Remarks,
(Case When D.ClientID Is Not Null Then 'Yes' Else 'No' End)AS IsLoanClient,          
D.NoOfLoans  
 FROM CTE_RD_CLIENTLOANSUBSCRIPTION A
LEFT JOIN {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` b ON b.Customerloanid=a.RDLoanID 
LEFT JOIN CTE_LoanCount D ON D.CLIENTID=A.CLIENTID
)

select * from CTE_RD_DISBURSEMENTBASE;
""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"rd_disbursementbase_fact Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on rd_disbursementbase_fact: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on rd_disbursementbase_fact : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.rd_disbursementbase_fact")

    logger(
            logger_level_info,
            f"rd_disbursementbase_fact writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table rd_disbursementbase_fact : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table rd_disbursementbase_fact : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)