# Databricks notebook source
# MAGIC %sql
# MAGIC  SET mart_catalog = '${dbutils.widgets.get("mart_catalog")}';
# MAGIC  SET mart_schema = '${dbutils.widgets.get("mart_schema")}';
# MAGIC  SET source_catalog = '${dbutils.widgets.get("source_catalog")}';
# MAGIC  SET source_schema = '${dbutils.widgets.get("source_schema")}';
# MAGIC  
# MAGIC CREATE OR REPLACE TABLE ${mart_catalog}.${mart_schema}.client_facts
# MAGIC WITH CTE_CLIENTMASTER(
# MAGIC SELECT  CM.Operator,CM.CreatedBy,CM.CreatedDateTime,CM.Hierarchyid,CM.clientid,CM.clientcode,CM.clientname,
# MAGIC        CM.spousename,CM.SpouseAge,CM.Gender,CM.Targetid,CM.Groupid,CM.MaritalStatus,CM.DateOfBirth,CM.joindate,
# MAGIC        CM.DropOutDate,CM.ReplacementStatus,C.CENTERID,C.CENTERCODE,C.CENTERNAME,C.CenterMeetingDay,C.StaffId, 
# MAGIC        T.TARGETDATE,CB.CBStatus,UC.UCICID,UC.PDATE,BK.BankName,BK.BankBranch,BK.Bankaccountnumber,BK.IFSCCODE,
# MAGIC        BK.ClientNameASPerBank,AA.KYCNUMBER Aadhar,VO.KYCNUMBER AS VOTER
# MAGIC        ,coalesce(T.EKYCCaptureDate,EKYC.capturedate) EKYC_CaptureDate
# MAGIC        
# MAGIC FROM 
# MAGIC (select 'MFI' as Operator,CreatedBy,CreatedDateTime,Hierarchyid,clientid,clientcode,clientname,
# MAGIC        spousename,SpouseAge,Gender,Targetid,Groupid,MaritalStatus,DateOfBirth,joindate,
# MAGIC        DropOutDate,ReplacementStatus
# MAGIC        from ${source_catalog}.${source_schema}.`pragati-clientmaster` 
# MAGIC where ETL_IS_ACTIVE=1 and (dropoutdate is null or dropoutdate>='2023-04-01') AND Hierarchyid='116183') CM
# MAGIC      JOIN   (SELECT GROUPID,ETL_IS_ACTIVE,CENTERID FROM  ${source_catalog}.${source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE=1)  GM  on CM.Groupid=GM.GROUPID 
# MAGIC      JOIN   (SELECT CENTERID,CENTERCODE,CENTERNAME,CENTERMEETINGDAY,STAFFID,ETL_IS_ACTIVE FROM ${source_catalog}.${source_schema}.`pragati-centermaster`
# MAGIC              WHERE ETL_IS_ACTIVE=1 )            C   ON GM.CENTERID=C.CENTERID
# MAGIC      JOIN   (SELECT TARGETID,TARGETDATE,CBUpdateId,ETL_IS_ACTIVE,EKYCCaptureDate  FROM ${source_catalog}.${source_schema}.`pragati-targetmaster` WHERE ETL_IS_ACTIVE=1 )  T   ON CM.TARGETID=T.TARGETID
# MAGIC LEFT JOIN   (SELECT TARGETID,CBUpdateId,CBSTATUS,ETL_IS_ACTIVE FROM   ${source_catalog}.${source_schema}.`pragati-creditbureauupdate` WHERE ETL_IS_ACTIVE=1) CB  ON CB.TARGETID=CM.TARGETID AND CB.CBUpdateId=T.CBUpdateId
# MAGIC LEFT JOIN   (SELECT CLIENTID,UCICID,PDATE,ETL_IS_ACTIVE FROM ${source_catalog}.${source_schema}.`azuresource-p_ucic`
# MAGIC              WHERE ETL_IS_ACTIVE=1 ) UC  ON UC.Clientid=CM.CLIENTID
# MAGIC LEFT JOIN   (SELECT CLIENTID,DEATHDATE,DeathofMemberorSpouse,ETL_IS_ACTIVE FROM ${source_catalog}.${source_schema}.`pragati-clientdeathintimation_h_view`
# MAGIC            WHERE DeathofMemberorSpouse='M' AND ETL_IS_ACTIVE=1 ) DM ON CM.CLIENTID=DM.CLIENTID
# MAGIC LEFT JOIN (select Clientid,BankName,BankBranch,Bankaccountnumber,IFSCCode,ClientNameASPerBank,ETL_IS_ACTIVE,                                                            
# MAGIC ROW_NUMBER()over(partition by clientid order by cast(CreatedDateTime as date) ) drnk                                
# MAGIC from ${source_catalog}.${source_schema}.`pragati-clientbankdetails` WHERE ETL_IS_ACTIVE=1 )  BK  ON CM.CLIENTID=BK.CLIENTID AND BK.drnk=1 
# MAGIC LEFT JOIN  (SELECT KYCNUMBER,KYCTYPE,CLIENTORSPOUSE,TARGETID FROM ${source_catalog}.${source_schema}.`pragati-kycmaster`
# MAGIC             WHERE ETL_IS_ACTIVE=1 AND KycType='IDP6' and (KycNumber)<>''                                                            
# MAGIC and ClientOrSpouse in('M','Y') ) AA ON AA.TARGETID=CM.Targetid    
# MAGIC LEFT JOIN  (SELECT KYCNUMBER,KYCTYPE,CLIENTORSPOUSE,TARGETID FROM ${source_catalog}.${source_schema}.`pragati-kycmaster`
# MAGIC             WHERE ETL_IS_ACTIVE=1 AND KycType='IDP8' and (KycNumber)<>''                                                            
# MAGIC and ClientOrSpouse in('M','Y') ) VO ON VO.TARGETID=CM.Targetid  
# MAGIC LEFT JOIN  (SELECT UNIQUEID,MAX(capturedate)capturedate  FROM ${source_catalog}.${source_schema}.`pragati-kycmaster`
# MAGIC             GROUP BY UNIQUEID ) EKYC ON EKYC.UNIQUEID=CM.Targetid)
# MAGIC SELECT   DISTINCT CT_CM.*,COALESCE(HHI_C.CreatedDateTime,HHI_T.CreatedDateTime) HHI_DATE,CKYC.CKYCID,ckyc.remarks CKYCIDRemarks,
# MAGIC           SOP.BRANCHID,SOP.BRANCHNAME,SOP.UM_BASE_LOCATION_BRANCH_NAME  UNITNAME,SOP.ZONE,SOP.REGION,SOP.AREA,SOP.STATE,SOP.DISTRICT,SOP.SBHSTATE,
# MAGIC           (CASE WHEN DROPOUTDATE IS NULL AND DATEDIFF(WEEK,CT_CM.JoinDate,CAST(CURRENT_DATE()-1 AS DATE))>8 AND CLS.MINDATE IS NULL THEN 'Dormant Without Loan' 
# MAGIC                 WHEN MAX_LOANCLOSE IS NOT NULL AND DATEDIFF(WEEK,MAX_LOANCLOSE,CAST(CURRENT_DATE()-1 AS DATE))>8  THEN 'Dormant With Loan'
# MAGIC           END) DormantWithLoanWithoutLoan 
# MAGIC  FROM  CTE_CLIENTMASTER  CT_CM
# MAGIC LEFT JOIN (
# MAGIC SELECT CLIENTID,CreatedDateTime,ETL_IS_ACTIVE FROM ${source_catalog}.${source_schema}.`rdsp_trans-mfi_household_details`
# MAGIC WHERE ETL_IS_ACTIVE=1) HHI_C  ON  HHI_C.CLIENTID=CT_CM.CLIENTID   
# MAGIC LEFT JOIN (
# MAGIC            SELECT CLIENTID,CreatedDateTime,ETL_IS_ACTIVE FROM ${source_catalog}.${source_schema}.`rdsp_trans-mfi_household_details`
# MAGIC WHERE ETL_IS_ACTIVE=1) HHI_T  ON  HHI_T.CLIENTID=CT_CM.TARGETID   
# MAGIC LEFT JOIN ${source_catalog}.${source_schema}.`azuresource-tbl_bfilckycmis_clientwise` CKYC ON CKYC.CLIENTID=CT_CM.CLIENTID
# MAGIC LEFT JOIN ${mart_catalog}.${mart_schema}.`bfil-p_hierarchy_sop` SOP ON SOP.HIERARCHYID=CT_CM.HIERARCHYID
# MAGIC LEFT JOIN (SELECT CLIENTID,MIN(DISBURSEMENTDATE)MINDATE,MAX(LOANCLOSEDDATE) MAX_LOANCLOSE 
# MAGIC           FROM ${source_catalog}.${source_schema}.`pragati-clientloansubscription` WHERE  ETL_IS_ACTIVE=1 AND PRODUCTTYPE IS NULL
# MAGIC           GROUP BY CLIENTID) CLS ON CLS.CLIENTID=CT_CM.CLIENTID
# MAGIC
# MAGIC