# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_dailyloanfacts_summary.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/DAILYLOANFACTS_SUMMARY"
    desti_path = "BFIL-MART/REPORTING/DAILYLOANFACTS_SUMMARY"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
Select pd.Branch_Type,case when coalesce(pd.LoanClosedDate1,'1900-01-01')='1900-01-01' then 'Active' Else 'Closed' End LoanStatus,pd.ClientNPAstatus,CODDATE,Expected_NPA_date,PD.Freezed1,
       case when pd.ProductCategory = 'FUL' then 'CDF' else pd.ProductCategory end as ProductCategory,
       pd.HierarchyId,PD.Ageing_Loan,As_on_NPA,
       Case
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = 'Current1' then '[1. Current]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[1 To 30]' then '[2. 01 To 30]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[31 To 60]' then '[3. 31 To 60]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[61 To 90]' then '[4. 61 To 90]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[>90]' then '[5. NPA]' 
       when PD.Freezed1 is null  then '[6. Written off / ARC]'
       when pd.LoanClosedDate1 is not null then '[7. Loans Closed]' 
       Else PD.Ageing_Loan End Category,
       case when last_day(pd.disbursementdate) = last_day(current_date()-2) then 'Current Month' else 'Previous Months' end DisbMonthCat,
       case when last_day(pd.disbursementdate) = last_day(current_date()-2) then '[8. New Disbursements]' end Category_ME,
       count(1)NOL,sum(PD.POS)POS  
       ,Sum(ME.POS) POS_ME
       from {mart_catalog}.{mart_schema}.dailyloanfacts pd
       left join {source_catalog}.{source_schema}.`azuresource-p_loanfacts` Me on pd.clientloanid = Me.clientloanid
       group by pd.Branch_Type,case when coalesce(pd.LoanClosedDate1,'1900-01-01')='1900-01-01' then 'Active' Else 'Closed' End
      ,pd.ClientNPAstatus,pd.CODDATE,pd.Expected_NPA_date,PD.Freezed1,pd.ProductCategory,pd.HierarchyId,PD.Ageing_Loan,pd.As_on_NPA,
      Case
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = 'Current1' then '[1. Current]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[1 To 30]' then '[2. 01 To 30]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[31 To 60]' then '[3. 31 To 60]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[61 To 90]' then '[4. 61 To 90]' 
       when PD.Freezed1 = 'Y' and PD.Ageing_Loan = '[>90]' then '[5. NPA]'  
       when PD.Freezed1 is null  then '[6. Written off / ARC]'
       when pd.LoanClosedDate1 is not null then '[7. Loans Closed]' 
       Else PD.Ageing_Loan End
       ,case when last_day(pd.disbursementdate) = last_day(current_date()-2) then 'Current Month' else 'Previous Months' end 
       ,case when last_day(pd.disbursementdate) = last_day(current_date()-2) then '[8. New Disbursements]' end
""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"dailyloanfacts_summary Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on dailyloanfacts_summary: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on dailyloanfacts_summary : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.dailyloanfacts_summary")

    logger(
            logger_level_info,
            f"dailyloanfacts_summary writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table dailyloanfacts_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table dailyloanfacts_summary : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "dailyloanfacts_summary").mode("overwrite").save()
    logger(
            logger_level_info,
            f"dailyloanfacts_summary writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table dailyloanfacts_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table dailyloanfacts_summary : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)