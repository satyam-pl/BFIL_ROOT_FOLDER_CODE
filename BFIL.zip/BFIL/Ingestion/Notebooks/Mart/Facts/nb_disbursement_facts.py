# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_disbursement_facts.dbc"

# COMMAND ----------

try:

    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )    

    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/BFIL-MART/FACTS/DISBURSEMENT_FACTS"
    desti_path = "BFIL-MART/REPORTING/BFIL-MART/FACTS/DISBURSEMENT_FACTS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    # Define the SQL query as a string
    sql_query = """With CTE_ClientLoanProposal As(
/* MFI Proposals - Disbursements */ 
Select 'MFI' As SBU,
         Clp.HierarchyID,
        /* Client Loan Proposal Details */
        Clp.ClientID,                            
        Clp.LoanProposalID,
        Clp.CreatedDateTime As ProposalEntryDate,
        Clp.FieldStaffId As StaffID,
        Cast(Clp.ProposalDate As Date) As ProposalDate,
        Clp.LoanAmountRequested As RequestedAmount,
        Clp.LoanAmountApproved As ApprovedAmount,
        Cast(Clp.ApprovedDate As Date) As ApprovedDate,
        Clp.ApprovalRemarks,
        Cast(Clp.TEMPDISBURSEMENTDATE As Date) As TempDisbursementDate,
        Clp.PurposeID,
        LP.PurposeName,
        PM.ProductCode,          
        PM.ProductName, 
        (Case When Upper(SPAP.CreatedBy) IN ('UNNATI','UNNATIT') and PM.ProductCode='800' Then 'Unnati'
              When Upper(SPAP.CreatedBy) IN ('UNNATIPLS','UNNATI PLUS') and PM.ProductCode='800' Then 'UnnatiPls'
              When SPAP.SLPlus=1 and SPAP.SLCancelDate Is Null and Upper(Clp.DisbursementMode) = 'DM1' and PM.ProductCode='800' Then 'SurakshaPls'
              When Upper(DIM_PM.PRODUCT_CATEGORY1) = 'RDSP' and DIM_PM.PRODUCT_ID = '1042' Then 'RDSP'
        Else DIM_PM.PRODUCT_CATEGORY1 End) As ProductCategory,
        Clp.DisbursementMode,
        (Case When Upper(DIM_PM.PRODUCT_CATEGORY1) In ('FUL','TWO WHEELERS') and Upper(Clp.CreatedBy) Like '%HO%' Then 'Preapproved'   
              When Upper(DIM_PM.PRODUCT_CATEGORY1) In ('FUL','TWO WHEELERS') Then 'Instant'  
              When Upper(DIM_PM.PRODUCT_CATEGORY1) Like '%UNNATI%' Then 'Preapproved'
              When Upper(DIM_PM.PRODUCT_CATEGORY1) = 'MFI' and Upper(PAP.CreatedBy) Like '%HO%' Then 'Preapproved'   
          Else 'Instant' End) As DisbursementType, 
        Cast(Clp.LoanDisbursementDate As Date) As LoanDisbursementDate,
        Cast(Clp.ActualDisbursementDate As Date) As ActualDisbursementDate,
        Clp.ActualDisbursedAmount,
        Clp.ClientProductSequenceNo As Proposal_SeqNo,
        Cast(Clp.InterestRate As Decimal(10,2)) As ROI,  
        Clp.Tenure,        
        IFF(Clp.Tenure In(12,25,52,50),'DL','TL') As LoanType,   
        Clp.RepaymentFrequency,  
        Clp.CBUpdateID,
        Clp.IsBCMTrackerFlag,    
        Clp.IsBCMApproved,    
        Clp.EKYCStatus,
        Cast(Clp.EKYCSucessDate As Date) As EKYCSucessDate,
        Cast(Coalesce(Clp.MainOTPSucessDate,Clp.AlternateOTPSucessDate) As Date) As OTPDate,
        (Case When Upper(DIM_PM.PRODUCT_CATEGORY1) In ('TWO WHEELERS') Then   
        (Case When Cast(Clp.EKYCSucessDate As Date) Is Not Null  
        and (Cast(Clp.SpouseEKYCCaptureDate As Date) Is Not Null Or Cast(Clp.CoApplicantEKYCSucessDate As Date) Is Not Null ) Then 'with Bio-auth' End)  
        Else   
        ( Case  When Cast(Clp.ProposalDate As Date)=Cast(Clp.EKYCSucessDate As Date) then 'with Bio-auth'     
                When Cast(Clp.ProposalDate As Date)=Cast(Clp.MainOTPSucessDate As Date) then 'with OTP'     
                When Cast(Clp.ProposalDate As Date)=Cast(Clp.AlternateOTPSucessDate As Date) then 'with OTP'    
                When Cast(Clp.TEMPDISBURSEMENTDATE As Date)=Cast(Clp.EKYCSucessDate As Date) then 'with Bio-auth'    
                When Cast(Clp.TEMPDISBURSEMENTDATE As Date)=Cast(Clp.MainOTPSucessDate As Date) then 'with OTP'     
                When Cast(Clp.TEMPDISBURSEMENTDATE As Date)=Cast(Clp.AlternateOTPSucessDate As Date) then 'with OTP'    
          Else 'Without Bio-auth & OTP' End) End) As BioAuthStatus,
        IFF(Cast(Cls.DisbursementDate As Date)>= '2023-08-07',Clp.BioAuthDisbConsentFlag,Null) As BioAuthDisbConsentFlag ,
        Clp.ESignRRNO,
        Clp.WorkFlowStatus,
        Clp.ProposalStatus,
        Cast(Clp.CancelDate As Date) As Proposal_CancelDate,    
        Cast(Clp.LOANCANCELLEDDATE As Date) As Proposal_LoanCancelDate,    
        Cast(CLp.BCMLoanCancelledDate As Date)  As Proposal_BCMCancelDate,    
        Cast(Clp.DeviationCancelledDate As Date)  As Proposal_DeviationCancelDate,   
        Clp.CancelRemarks,
        (Case When Clp.IsProposalAfterCenterConfirm=0 Then 'With CM'      
              When Clp.IsProposalAfterCenterConfirm=1 Then 'OutSide CM' Else 'Error' End) As Proposal_CenterConfirm,
         Cast(Clp.ClientDOBAtDisbursement As Date) As ClientDOBAtDisbursement,
         Cast(Clp.SpouseDOBAtDisbursement As Date) As SpouseDOBAtDisbursement,

        /* Client Loan SubScription Details */
        Cls.CreatedBy As Disbursement_StaffID,          
        Cls.ClientLoanID,        
        Cls.ClientProductSequenceNo As Loan_SeqNo,  
        Cast(Cls.DisbursementDate As Date) As DisbursementDate,          
        Cls.LoanAmountDisbursed,                   
        Cls.IsLoanCancelled,            
        Cast(Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) As Date) As LoanCancel_DeviationDate,            
        Coalesce(Cls.LoanCancellationType,Cls.Remarks) As Cancel_ClosedRemarks,            
        Cast(Cls.LoanClosedDate As Date) As LoanClosedDate,         
        Cast(Cls.ExpectedPaidUpDate As Date) As ExpectedPaidUpDate,        
        (Case When Cls.ClientLoanID Is Not Null Then 
              (Case When Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,
                    Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) Is Not Null Then 'Cancel'            
                    When Cls.LoanClosedDate Is Null Then 'Open'             
                    When Cls.LoanClosedDate < Cls.ExpectedPaidUpdate Then 'Pre-Closure'            
                    Else 'Closed' End)
        Else Null End) As LoanStatus,
        InitCap(DLP.DLPStatus) As DLPStatus,
        IFF(Upper(DLP.DLPStatus) ='YES',1,0) As DLPSMSSent 
From {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` As Clp
Left Join {source_catalog}.{source_schema}.`pragati-clientloansubscription` As Cls On Cls.LoanProposalID = Clp.LoanProposalID and Cls.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` As DPM On DPM.DerivedProductID = Clp.ProductID and DPM.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`pragati-productmaster` As PM On PM.ProductID = DPM.ProductID  and PM.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`pragati-loanpurposes` As LP On LP.PurposeID = Clp.PurposeID and LP.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`azuresource-dim_productmaster` As DIM_PM On DIM_PM.PRODUCT_ID = PM.ProductCode and DIM_PM.SBU ='MFI' and DIM_PM.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`pragati-preapprovedproposal` As PAP On PAP.LoanProposalID = Clp.LoanProposalID and PAP.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`pragati-surakshapreapprovedproposal` As SPAP On SPAP.LoanProposalID = Clp.LoanProposalID and SPAP.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`azuresource-alldlpdata_view` As DLP On DLP.LoanProposalID = Clp.LoanProposalID and DLP.ETL_IS_ACTIVE = 1

Where Clp.ProductType Is Null and Clp.ETL_IS_ACTIVE = 1
-- and Clp.LoanProposalID ='5114157005022325'
and (((Cast(Clp.ProposalDate As Date) Between '2023-04-01' and DATEADD(DAY, -1, CURRENT_DATE())) Or (Cast(Cls.DisbursementDate As Date) Between '2023-04-01' and DATEADD(DAY, -1, CURRENT_DATE())))
Or ((Cast(Clp.UpdatedDateTime As Date)>= (Select (SELECT Cast(From_UTC_TimeStamp(Current_Date(),'Asia/Kolkata') As Date))-2)) Or (Cast(Cls.UpdatedDateTime As Date)>= (Select (SELECT Cast(From_UTC_TimeStamp(Current_Date(),'Asia/Kolkata') As Date))-2))))

Union

/* BSS Proposals - Disbursements */ 
Select  'BSS' As SBU,
        Clp.HierarchyID, 
        /* Client Loan Application Details */
        Clp.CustomerID As ClientID,
        Clp.LoanApplicationID As LoanProposalID,
        Clp.Createddatetime As ProposalEntryDate,
        BM.UserID As StaffID,
        Cast(Clp.LoanApplicationDate As Date) As ProposalDate,
        Clp.LoanAmountRequested As RequestedAmount,
        Clp.LoanAmountApproved As ApprovedAmount,
        Cast(Clp.Approveddate As Date) As ApprovedDate,
        Clp.ApprovalRemarks,
        Cast(Alp.TEMPDISBURSEMENTDATE As Date) As TempDisbursementDate,
        Clp.PurposeID,
        LP.PurposeName,
        PM.ProductCode,
        PM.ProductName,
        DIM_PM.PRODUCT_CATEGORY1 As ProductCategory,
        Clp.DisbursementMode,
        (Case When DT.LoanApplicationID Is Not Null and PM.ProductCode In ('P398','M604') and Cls.CustomerProductSequenceNo = 2 Then 'Regular'
              When DT.LoanApplicationID Is Not Null Then 'Instant' 
        Else 'Regular' End) As DisbursementType,
        Cast(Clp.LoanDisbursementDate As Date) As LoanDisbursementDate,
        Null As ActualDisbursementDate,
        Null As ActualDisbursedAmount,
        Alp.CustomerProductSequenceNo As Proposal_SeqNo,
        cast(clp.InterestRate As Decimal(10,2)) As ROI,
        Clp.Tenure,
        IFF(Clp.Tenure In(12,25,52,50),'DL','TL') As LoanType,   
        Clp.RepaymentFrequency,
        Alp.CBUpdateID,
        Alp.IsBCMTrackerFlag,
        Alp.IsBCMApproved, 
        Alp.EKYCStatus,
        Cast(Alp.EKYCSucessDate As Date) As EKYCSucessDate,
        Cast((Case When Upper(Alp.LoanApplicationType) ='SMS' Then Alp.CustomerRRNoDateTime Else Null End) As Date) As OTPDate,
        (Case When Upper(Alp.LoanApplicationType) ='SMS' Then 'With OTP'     
              When Upper(Alp.LoanApplicationType) = Upper('Regular') Then 'With Bio-Auth' End) As BioAuthStatus,
        Cast(IFF(CC.CustomerID Is Not Null,'True','False') As Boolean) As BioAuthDisbConsentFlag,
        Alp.ESignRRNO,
        Alp.WorkFlowStatus,
        Clp.LoanApplicationStatus As ProposalStatus,
        Cast(Coalesce(Alp.CancelDate,Clp.RejectedDate) As Date) As Proposal_CancelDate,
        Cast(Alp.LOANCANCELLEDDATE As Date) As Proposal_LoanCancelDate,
        Cast(Alp.BCMLoanCancelledDate As Date) As Proposal_BCMCancelDate,
        Cast(Alp.DeviationCancelledDate As Date) As Proposal_DeviationCancelDate,
        Clp.Remarks As CancelRemarks,
        Null As Proposal_CenterConfirm,
        Cast(Alp.ClientDOBAtDisbursement As Date) As ClientDOBAtDisbursement,
        Cast(Alp.SpouseDOBAtDisbursement As Date) As SpouseDOBAtDisbursement,

        /* Client Loan SubScription Details */
        Cls.CreatedBy As Disbursement_StaffID,
        Cls.CustomerLoanId AS ClientLoanID,
        Cls.CustomerProductSequenceNo As Loan_SeqNo,
        Cast(Cls.DisbursementDate As Date) As DisbursementDate,
        Cls.LoanAmountDisbursed,
        Cls.IsLoanCancelled,
        cast(Coalesce(coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) As Date) As LoanCancel_DeviationDate,
        Coalesce(cls.LoanCancellationType,Cls.Remarks) As Cancel_ClosedRemarks,
        cast(Cls.LoanClosedDate as date) As LoanClosedDate,
        cast(Cls.ExpectedPaidupDate as date) As ExpectedPaidUpDate,
        (Case When Cls.CustomerLoanID Is Not Null Then 
              (Case When Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,
                    Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) Is Not Null Then 'Cancel'            
                    When Cls.LoanClosedDate Is Null Then 'Open'             
                    When Cls.LoanClosedDate < Cls.ExpectedPaidUpdate Then 'Pre-Closure'            
                    Else 'Closed' End)
        Else Null End) As LoanStatus,
        IFF(Tiny.ClientLoanID Is Not Null,'Yes',Null) As DLPStatus,
        IFF(IFNull(Msg.MsgPath,Msg1.MsgPath) Is Not Null,1,0) As DLPSMSSent

From  {source_catalog}.{source_schema}.`rlmsbizxtend-customerloanapplication` AS Clp
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-additionalloanapplicationdetails` Alp on Clp.LoanApplicationID=Alp.LoanApplicationID and Alp.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` AS Cls on Clp.LoanApplicationID=Cls.LoanApplicationID and Cls.ETL_IS_ACTIVE = 1 
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-productmaster` AS PM on Cls.ProductID=PM.ProductID and PM.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-loanpurposemaster` as LP on Clp.PurposeID=LP.PurposeID and LP.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`azuresource-dim_productmaster` As DIM_PM On DIM_PM.PRODUCT_ID = PM.ProductCode and DIM_PM.SBU ='BSS' and DIM_PM.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`rlmsbizxtend-batchmaster` As BM On BM.BatchID = Clp.BatchID and BM.ETL_IS_ACTIVE = 1
/* Disbursement Type */
Left Join ( Select A.LoanApplicationID           
            From {source_catalog}.{source_schema}.`rlmsbizxtend-additionalloanapplicationdetails` A
            Join {source_catalog}.{source_schema}.`rlmsbizxtend-bfil_cbresponse_h` B On B.ReportID = A.CBUpdateID and B.ETL_IS_ACTIVE = 1
            Where (History12Months=1 Or History6Months=1) and B.ETL_Is_Active = 1
            Union
            Select A.LoanApplicationID
            From {source_catalog}.{source_schema}.`rlmsbizxtend-customerloanapplication` A
            Join {source_catalog}.{source_schema}.`rlmsbizxtend-bfil_bankstatements_sent` B On B.CustomerID = A.CustomerID and B.ETL_IS_ACTIVE = 1
            Where TicketSize >0 and InstantFlag=1  and A.ETL_IS_ACTIVE = 1) As DT On DT.LoanApplicationID = Clp.LoanApplicationID
/* Bio Auth Authorization */
Left Join ( Select CC.CustomerID,row_number() OVER (PARTITION BY CC.CustomerID Order By CC.CreatedDateTime Desc) As RowNumber
            From {source_catalog}.{source_schema}.`rlmsbizxtend-bfil_consentsconfirmed` As CC  
            Join {source_catalog}.{source_schema}.`rlmsbizxtend-bfil_consents` As CS On CS.ID = CC.Consents and CS.ETL_IS_ACTIVE = 1
            Where CC.Consents In ('60','61') and CC.ETL_IS_ACTIVE = 1) As CC On CC.CustomerID = Clp.CustomerID and RowNumber = 1
/* DLP Status */
Left Join ( Select  Left(Replace(A.c4,'https://dlp.bfil.it/BSSLoanApplication',''),16) As ClientLoanID,B.c3 As MsgFilePath
            From (  Select json_tuple(Req,'Mobile','AccountNumber','ClientID','BfilRefNum','DocPath','sourceSystem','Purpose'),CreateDate
                    From {source_catalog}.{source_schema}.`rlmsbizxtend-bfil_tiny`
                    Where ETL_IS_ACTIVE = 1) As A
            Left Join (Select json_tuple(Res,'responseCode','responseMsg','BfilRefNum','msgFilePath'),CreateDate
                        From {source_catalog}.{source_schema}.`rlmsbizxtend-bfil_tiny`
                        Where ETL_IS_ACTIVE = 1) As B On B.C2 = A.C3 and B.CreateDate= A.CreateDate
            Where Upper(A.c6) ='LD') As Tiny On Tiny.ClientLoanID = Cls.CustomerLoanID and Tiny.MsgFilePath Is Not Null
/* DLP SMS Sent */
Left Join ( Select Replace(Left(SMSText,CHARINDEX('to view',SMStext)-2),'Greetings! Click here ','') As MsgPath
            From {source_catalog}.{source_schema}.`rlmsbizxtend-BFIL_SMSData` 
            Where Upper(Purpose) = Upper('Customer Loan Application') and ETL_IS_ACTIVE = 1) As Msg On Msg.MsgPath = Tiny.MsgFilePath
Left Join ( Select Replace(Left(SMSText,CHARINDEX('to view',SMStext)-2),'Greetings! Click here https://rlms.bfil.it/','') As MsgPath
            From {source_catalog}.{source_schema}.`rlmsbizxtend-BFIL_SMSData` 
            Where Upper(Purpose) = Upper('Customer Loan Application') and ETL_IS_ACTIVE = 1) As Msg1 On Msg1.MsgPath = Tiny.MsgFilePath

Where Clp.ProductType Is Null
and (((Cast(Clp.LoanApplicationDate As Date) Between '2023-04-01' and DATEADD(DAY, -1, CURRENT_DATE()) ) Or (Cast(Cls.DisbursementDate As Date) Between '2023-04-01' and DATEADD(DAY, -1, CURRENT_DATE()) ))
Or ((Cast(Clp.UpdatedDateTime As Date)>= (Select (SELECT Cast(From_UTC_TimeStamp(Current_Date(),'Asia/Kolkata') As Date))-2)) Or (Cast(Cls.UpdatedDateTime As Date)>= (Select (SELECT Cast(From_UTC_TimeStamp(Current_Date(),'Asia/Kolkata') As Date))-2))))

Union

/* BMS Proposals - Disbursements */ 
Select 'BMS' as SBU,
        CLP.HierarchyID,
        /* Client Loan Application Details */
        Clp.ClientID,
        Clp.LoanProposalID,
        Clp.CreatedDateTime As ProposalEntryDate,
        Clp.FieldStaffId As StaffID,
        Cast(Clp.ProposalDate As Date) As ProposalDate,
        Clp.LoanAmountRequested As RequestedAmount,
        Clp.LoanAmountApproved As ApprovedAmount,
        Cast(Clp.ApprovedDate As Date) As ApprovedDate,
        Clp.ApprovalRemarks,
        Cast(Clp.TEMPDISBURSEMENTDATE As Date) As TempDisbursementDate,
        Clp.PurposeID,
        LP.PurposeName,
        PM.ProductCode,
        PM.ProductName,
        DIM_PM.PRODUCT_CATEGORY1 As ProductCategory,
        Clp.DisbursementMode,
        (Case When (Upper(Clp.DisbursementType) = 'I' and Upper(CLp.SameDayOrNextWeek) = 'SAME DAY') Then 'Instant'        
              When Upper(Clp.Createdby) ='HO' Then 'Preapproved'         
              When Upper(Clp.CBUpdateID) Like '%:P%' Then 'Preapproved'        
        Else 'Normal' End) As DisbursementType,  
        Cast(Clp.LoanDisbursementDate As Date) As LoanDisbursementDate,
        Null As ActualDisbursementDate,
        Clp.ActualDisbursedAmount,
        Clp.ClientProductSequenceNo As Proposal_SeqNo,
        Cast(Clp.InterestRate As Decimal(10,2)) As ROI,  
        Clp.Tenure,        
        IFF(Clp.Tenure In (12,25,52,50),'DL','TL') As LoanType,
        Clp.RepaymentFrequency,  
        Clp.CBUpdateID,
        Clp.IsBCMTrackerFlag,    
        Clp.IsBCMApproved,    
        Clp.EKYCStatus,
        Cast(Clp.EKYCSucessDate As Date) As EKYCSucessDate,
        Cast(Coalesce(Clp.MainOTPSucessDate,Clp.AlternateOTPSucessDate) As Date) As OTPDate,
        'with Bio-auth' As BioAuthStatus,
        Cast(Null As Boolean) As BioAuthDisbConsentFlag,
        LD.RRN As ESignRRNO,
        Clp.WorkFlowStatus,
        Clp.ProposalStatus,
        Cast(Clp.CancelDate As Date) As Proposal_CancelDate,    
        Cast(Clp.LOANCANCELLEDDATE As Date) As Proposal_LoanCancelDate,    
        Cast(CLp.BCMLoanCancelledDate As Date) As Proposal_BCMCancelDate,    
        Cast(Clp.DeviationCancelledDate As Date) As Proposal_DeviationCancelDate,
        Clp.CancelRemarks,
        (Case When Clp.IsProposalAfterCenterConfirm=0 Then 'With CM'      
              When Clp.IsProposalAfterCenterConfirm=1 Then 'OutSide CM' 
        Else 'Error' End) As Proposal_CenterConfirm,
        Cast(Clp.ClientDOBAtDisbursement As Date) As ClientDOBAtDisbursement,
        Cast(Clp.SpouseDOBAtDisbursement As Date) As SpouseDOBAtDisbursement,

        /* Client Loan SubScription Details */
        Cls.CreatedBy As Disbursement_StaffID,        
        Cls.ClientLoanID, 
        Cls.ClientProductSequenceNo As Loan_SeqNo,  
        Cast(Cls.DisbursementDate As Date) As DisbursementDate,          
        Cls.LoanAmountDisbursed,                  
        Cls.IsLoanCancelled,            
        Cast(Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) As Date) As LoanCancel_DeviationDate,     
        Coalesce(Cls.LoanCancellationType,Cls.Remarks) As Cancel_ClosedRemarks,            
        Cast(Cls.LoanClosedDate As Date) As LoanClosedDate,        
        Cast(Cls.ExpectedPaidUpDate As Date) As ExpectedPaidUpDate,        
        (Case When Cls.ClientLoanID Is Not Null Then 
              (Case When Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,
                    Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) Is Not Null Then 'Cancel'            
                    When Cls.LoanClosedDate Is Null Then 'Open'             
                    When Cls.LoanClosedDate < Cls.ExpectedPaidUpdate Then 'Pre-Closure'            
                    Else 'Closed' End)
        Else Null End) As LoanStatus,
        IFF(LD.LoanDocFlag ='1','Yes','No') As DLPStatus,
        IFF(LD.LoanDocFlag ='1',1,0) As DLPSMSSent

From {source_catalog}.{source_schema}.`ptsmart-clientloanproposal` AS Clp 
Left Join {source_catalog}.{source_schema}.`ptsmart-clientloansubscription` As Cls On Cls.LoanProposalID = Clp.LoanProposalID and Cls.ETL_IS_ACTIVE = 1
Left join {source_catalog}.{source_schema}.`ptsmart-derivedproductmaster`  As DPM On DPM.DerivedProductID = Clp.ProductID and DPM.ETL_IS_ACTIVE = 1
Left join {source_catalog}.{source_schema}.`ptsmart-productmaster`  As PM On PM.ProductID = DPM.ProductID and PM.ETL_IS_ACTIVE = 1
left join {source_catalog}.{source_schema}.`ptsmart-loanpurposes` As LP On LP.PurposeID = Clp.PurposeID and LP.ETL_IS_ACTIVE = 1
left join {source_catalog}.{source_schema}.`azuresource-dim_productmaster`As DIM_PM On DIM_PM.PRODUCT_ID = PM.ProductCode and DIM_PM.SBU ='BMS' and DIM_PM.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`rdsp-tbl_bms_loandocumentdetails` As LD On LD.ProposalID = Clp.LoanProposalID and LD.ETL_IS_ACTIVE = 1
where Clp.ProductType Is Null
-- and Clp.LoanProposalId='5114451000186803'
and (((Cast(Clp.ProposalDate As Date) Between '2023-04-01' and DATEADD(DAY, -1, CURRENT_DATE()) ) Or (Cast(Cls.DisbursementDate As Date) Between '2023-04-01' and DATEADD(DAY, -1, CURRENT_DATE()) ))
Or ((Cast(Clp.UpdatedDateTime As Date)>= (Select (SELECT Cast(From_UTC_TimeStamp(Current_Date(),'Asia/Kolkata') As Date))-2)) Or (Cast(Cls.UpdatedDateTime As Date)>= (Select (SELECT Cast(From_UTC_TimeStamp(Current_Date(),'Asia/Kolkata') As Date))-2))))),

/* Loan Ledger Like LPF,CSIP,etc. */
CTE_AccountTransactions As (
/* MFI Loan Transactions */
Select A.LoanProposalID,
        Coalesce(Sum(Case When Upper(TransactionType) = 'F' Then Amount Else 0 End),0) As LPF,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'I' Then Amount Else 0 End),0) As CSIP_Member,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'H' Then Amount Else 0 End),0) As CSIP_Spouse,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'L' Then Amount Else 0 End),0) As CSIP_CoApplicant,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'O' Then Amount Else 0 End),0) As Document_Charges,    
        Coalesce(Sum(Case When Upper(TransactionType) = 'D' Then Amount Else 0 End),0) As DownPayment_Charges  
From CTE_ClientLoanProposal As A
Join {source_catalog}.{source_schema}.`pragati-at_loantransactions` As B On B.HierarchyID = A.HierarchyID and B.ClientID = A.ClientID and B.ClientLoanProposalID = A.LoanProposalID
Where Upper(B.DebitOrCredit) ='C' and Upper(A.SBU) ='MFI' and B.ETL_IS_ACTIVE = 1
Group By A.LoanProposalID

Union All

/* BSS Loan Transactions */
Select  A.LoanproposalID,
        Coalesce(Sum(Case When Upper(TransactionType) = 'F' Then Amount Else 0 End),0) As LPF,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'I' Then Amount Else 0 End),0) As CSIP_Member,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'H' Then Amount Else 0 End),0) As CSIP_spouse,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'L' Then Amount Else 0 End),0) As CSIP_CoApplicant,
        Coalesce(Sum(Case When Upper(TransactionType) = 'D' Then Amount Else 0 End),0) As Document_Charges,
        0 As DownPayment_Charges       
From CTE_ClientLoanProposal A
JOIN {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` B On B.HierarchyID = A.HierarchyID and B.CustomerID = A.ClientID and B.LoanApplicationID = A.LoanProposalID
Where Upper(B.DebitOrCredit) ='C' and Upper(A.SBU) ='BSS' and B.ETL_IS_ACTIVE = 1
Group By A.LoanProposalID

Union All

/* BMS Loan Transactions */
Select A.LoanProposalID,
        Coalesce(Sum(Case When Upper(TransactionType) = 'F' Then Amount Else 0 End),0) As LPF,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'I' Then Amount Else 0 End),0) As CSIP_Member,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'H' Then Amount Else 0 End),0) As CSIP_Spouse,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'L' Then Amount Else 0 End),0) As CSIP_CoApplicant,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'O' Then Amount Else 0 End),0) As Document_Charges,    
        Coalesce(Sum(Case When Upper(TransactionType) = 'D' Then Amount Else 0 End),0) As DownPayment_Charges  
From CTE_ClientLoanProposal As A
Join {source_catalog}.{source_schema}.`ptsmart-accounttransactions` As B On B.HierarchyID = A.HierarchyID and B.ClientID = A.ClientID and B.ClientLoanProposalID = A.LoanProposalID
Where Upper(B.DebitOrCredit) = 'C' and Upper(A.SBU) ='BMS' and B.ETL_IS_ACTIVE = 1
Group By A.LoanProposalID),

/* Final Table */
CTE_Proposal_Disbursements_BSP As(
Select  A.*,
        B.LPF,
        B.CSIP_Member,
        B.CSIP_Spouse,
        B.CSIP_CoApplicant,
        B.Document_Charges,
        B.DownPayment_Charges,
        IFF(Upper(A.DisbursementMode) In ('DM1','DM4'),A.LoanAmountDisbursed,
        A.LoanAmountDisbursed - (coalesce(B.LPF,0)+coalesce(B.CSIP_Member,0)+coalesce(B.CSIP_Spouse,0)+coalesce(B.CSIP_CoApplicant,0)+coalesce(B.Document_Charges,0)+coalesce(B.DownPayment_Charges,0))) As SMPT_NetAmount,
        BSP.LoanAmountDisbursed As BSP_NetAmount,
        BSP.ACC_Download,
        BSP.ACC_DownloadDate,
        BSP.UTR_NO,
        BSP.UTR_PaymentDate,
        BSP.BankType,
        BSP.BankAccountNumber,
        BSP.BankIFSCCode,
        BSP.BankName,
        BSP.BankBranch,
        BSP.ClientNameASPerBank,
        BSP.IBLRefNo,
        IFF(Coalesce(C.LoanProposalID,D.LoanProposalID) Is Not Null,'Yes',Null) As IsDedupe
From CTE_ClientLoanProposal A
Left Join CTE_AccountTransactions As B On B.LoanProposalID = A.LoanProposalID
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-Azure_BSP_CashlessDisburs_Data` As BSP On BSP.LoanProposalID = A.LoanProposalID and BSP.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-cl_dedupe_loanandclientdetails` As C On C.LoanProposalID = A.LoanProposalID and C.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-cl_mfi_household` As D On D.LoanProposalID = A.LoanProposalID and D.IsCancel = 2 and D.ETL_IS_ACTIVE = 1),

/* Proposal Against Final Remarks */
CTE_Proposal_FinalRemarks As 
(Select A.LoanProposalID,
        IFF(A.ACC_DownloadDate Is Null and A.LoanCancel_DeviationDate Is Not Null and A.IsDedupe Is Null,'Yes',Null) As Direct_PTCancellation, 
        IFF(IFF(A.ACC_DownloadDate Is Null and A.LoanCancel_DeviationDate Is Not Null and A.IsDedupe Is Null,'Yes',Null)='Yes',SMPT_NetAmount,0) As Direct_PTCancellationAmount,
        (Case When Upper(A.UTR_No) Not Like Upper('%Reject%') and A.UTR_No Is Not Null Then 'Payment Done'
              When Upper(A.UTR_No) Like Upper('%Reject%') Then 'Payment Rejected'
              When A.UTR_No Is Null and A.LoanCancel_DeviationDate Is Not Null Then 'Loan Cancel'
              When A.Acc_Download = 1 and coalesce(A.UTR_No,0) = 0 Then 'Processed But UTR Pending'
              When A.Acc_Download = 0 And A.LoanCancel_DeviationDate Is Null and A.ClientLoanID Is Not Null Then 'Payment Pending'
              When A.ClientLoanID Is Not Null and Upper(A.DisbursementMode) In ('DM1','DM4') Then 'Cash Payment'
              When A.Proposal_CancelDate Is Not Null Or A.Proposal_LoanCancelDate Is Not Null Or A.Proposal_DeviationCancelDate Is Not Null Then 'Proposal Cancel'
              When A.Proposal_BCMCancelDate Is Not Null Then 'BCM Cancel'
              When Upper(A.CancelRemarks) = Upper('System Cancelled due to disbursed not done on same day') Then 'System Cancelled due to disbursed not done on same day'
              When Upper(A.CancelRemarks) = Upper('System Cancelled while tab sync process, due to disbursed not done on same day') Then 'System Cancelled while tab sync process, due to disbursed not done on same day'
              When Upper(A.CancelRemarks) Like Upper('%Previous day disbursement confirmation Pending%') Then 'Previous day disbursement confirmation Pending'
              When Upper(A.CancelRemarks) Like Upper('%Instant CB validity expired%') Then 'Instant CB validity expired'
              When B.LoanProposalID Is Not Null Then 'BSP - WD Blocked'
              When C.LoanProposalID Is Not Null Then 'BSP - Bank A/C Restrict'
              When D.LoanProposalID Is Not Null Then 'BSP - Diversion Disbursement Amount'
              When E.LoanProposalID Is Not Null Then 'BSP - Diversion Disbursement Amount'
              When F.LoanProposalID Is Not Null Then 'BSP - Dedupe'
              When G.LoanProposalID Is Not Null Then 'BSP - HouseHold Reject'
              -- When Upper(A.ProductCategory) = 'FUL' and A.TempDisbursementDate Is Not Null Then 'Disbursement Pending'
              When Upper(A.DisbursementMode) In ('DM1','DM4') and A.TempDisbursementDate Is Not Null Then 'Disbursement Pending'
              When Upper(A.WorkFlowStatus) = 'A' Then 'BCM Pending'
              When Upper(A.WorkFlowStatus) = 'R' and Upper(A.ApprovalRemarks) = Upper('Instantly Rejected') Then 'Instantly Rejected'
              When Upper(A.WorkFlowStatus) = 'N' Or Coalesce(A.WorkFlowStatus,'') ='' Then 'Proposal Cancel'
        Else A.CancelRemarks End) As FinalRemarks
FROM CTE_Proposal_Disbursements_BSP As A
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-wd_blocked_proposals` As B On B.LoanProposalID = A.LoanProposalID and B.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-cl_restrict_bankaccount` As C On C.LoanProposalID = A.LoanProposalID and C.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-cl_diversiondisbursedamount_H` As D On D.LoanProposalID = A.LoanProposalID and D.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-cl_diversiondisbursedamount_csip_H` As E On E.LoanProposalID = A.LoanProposalID and E.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-cl_dedupe_loanandclientdetails` As F On F.LoanProposalID = A.LoanProposalID and F.ETL_IS_ACTIVE = 1
Left Join {source_catalog}.{source_schema}.`cashlessdisburs-cl_mfi_household` As G On G.LoanProposalID = A.LoanProposalID and G.IsCancel= 0 and G.ETL_IS_ACTIVE = 1),

/* Final Query with Payment Status */
CTE_Proposal_DisbursementFacts As(
Select  A.*,
        B.FinalRemarks,
        (Case   When Upper(B.FinalRemarks) Like 'BSP%' Then 'BSP Validation Failed'
                When B.FinalRemarks Not In ('Payment Done','Payment Rejected','Loan Cancel','Processed But UTR Pending','Payment Pending','Cash Payment',
                'Proposal Cancel','BCM Cancel','Instant CB validity expired','BCM Pending','Disbursement Pending','Instantly Rejected') Then 'Proposal Cancel'
        Else B.FinalRemarks End) As PaymentStatus
From CTE_Proposal_Disbursements_BSP A
Left Join CTE_Proposal_FinalRemarks As B On B.LoanProposalID = A.LoanProposalID )

/* Final Table */
Select * From CTE_Proposal_DisbursementFacts""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

try:
    df = spark.sql(sql_query).repartition(50).cache()
    logger(
        logger_level_info,
        f"disbursement_facts table Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on disbursement_facts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on disbursement_facts : ", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.disbursement_facts")

    logger(
        logger_level_info,
        f"disbursement_facts writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table disbursement_facts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table disbursement_facts : ",
        str(e),
    )

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)