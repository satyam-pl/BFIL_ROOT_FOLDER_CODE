# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_clientfacts.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        "Required notebook imports have been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FACTS/CLIENTFACTS"
    desti_path = "BFIL-MART/FACTS/CLIENTFACTS"

    logger(
        logger_level_info,
        "Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH CTE_CLIENTMASTER AS (
SELECT  CM.Operator, CM.CreatedBy, CM.CreatedDateTime, CM.Hierarchyid, CM.clientid, CM.clientcode, CM.clientname,
       CM.spousename, CM.SpouseAge, CM.Gender, CM.Targetid, CM.Groupid, CM.MaritalStatus, CM.DateOfBirth, CM.joindate,
       CM.DropOutDate, CM.ReplacementStatus, C.CENTERID, C.CENTERCODE, C.CENTERNAME, C.CenterMeetingDay, C.StaffId, 
       T.TARGETDATE, CB.CBStatus, UC.UCICID, UC.PDATE, BK.BankName, BK.BankBranch, BK.Bankaccountnumber, BK.IFSCCODE,
       BK.ClientNameASPerBank, AA.KYCNUMBER AS Aadhar, VO.KYCNUMBER AS VOTER,
       COALESCE(T.EKYCCaptureDate, EKYC.capturedate) AS EKYC_CaptureDate
FROM 
(select 'MFI' as Operator, CreatedBy, CreatedDateTime, Hierarchyid, clientid, clientcode, clientname,
       spousename, SpouseAge, Gender, Targetid, Groupid, MaritalStatus, DateOfBirth, joindate,
       DropOutDate, ReplacementStatus
       from {source_catalog}.{source_schema}.`pragati-clientmaster` 
where ETL_IS_ACTIVE=1 and (dropoutdate is null or dropoutdate>='2023-04-01') AND Hierarchyid='116183') CM
     JOIN   (SELECT GROUPID, ETL_IS_ACTIVE, CENTERID FROM  {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE=1)  GM  ON CM.Groupid=GM.GROUPID 
     JOIN   (SELECT CENTERID, CENTERCODE, CENTERNAME, CENTERMEETINGDAY, STAFFID, ETL_IS_ACTIVE FROM {source_catalog}.{source_schema}.`pragati-centermaster`
             WHERE ETL_IS_ACTIVE=1 )            C   ON GM.CENTERID=C.CENTERID
     JOIN   (SELECT TARGETID, TARGETDATE, CBUpdateId, ETL_IS_ACTIVE, EKYCCaptureDate  FROM {source_catalog}.{source_schema}.`pragati-targetmaster` WHERE ETL_IS_ACTIVE=1 )  T   ON CM.TARGETID=T.TARGETID
LEFT JOIN   (SELECT TARGETID, CBUpdateId, CBSTATUS, ETL_IS_ACTIVE FROM   {source_catalog}.{source_schema}.`pragati-creditbureauupdate` WHERE ETL_IS_ACTIVE=1) CB  ON CB.TARGETID=CM.TARGETID AND CB.CBUpdateId=T.CBUpdateId
LEFT JOIN   (SELECT CLIENTID, UCICID, PDATE, ETL_IS_ACTIVE FROM {source_catalog}.{source_schema}.`ptsmartserver-p_ucic`
             WHERE ETL_IS_ACTIVE=1 ) UC  ON UC.Clientid=CM.CLIENTID
LEFT JOIN   (SELECT CLIENTID, DEATHDATE, DeathofMemberorSpouse, ETL_IS_ACTIVE FROM {source_catalog}.{source_schema}.`pragati-clientdeathintimation_h_view`
           WHERE DeathofMemberorSpouse='M' AND ETL_IS_ACTIVE=1 ) DM ON CM.CLIENTID=DM.CLIENTID
LEFT JOIN (select Clientid, BankName, BankBranch, Bankaccountnumber, IFSCCode, ClientNameASPerBank, ETL_IS_ACTIVE,                                                            
ROW_NUMBER() OVER(PARTITION BY clientid ORDER BY CAST(CreatedDateTime AS DATE)) AS drnk                                
from {source_catalog}.{source_schema}.`pragati-clientbankdetails` WHERE ETL_IS_ACTIVE=1 )  BK  ON CM.CLIENTID=BK.CLIENTID AND BK.drnk=1 
LEFT JOIN  (SELECT KYCNUMBER, KYCTYPE, CLIENTORSPOUSE, TARGETID FROM {source_catalog}.{source_schema}.`pragati-kycmaster`
            WHERE ETL_IS_ACTIVE=1 AND KycType='IDP6' and (KycNumber)<>''                                                            
and ClientOrSpouse IN('M','Y') ) AA ON AA.TARGETID=CM.Targetid    
LEFT JOIN  (SELECT KYCNUMBER, KYCTYPE, CLIENTORSPOUSE, TARGETID FROM {source_catalog}.{source_schema}.`pragati-kycmaster`
            WHERE ETL_IS_ACTIVE=1 AND KycType='IDP8' and (KycNumber)<>''                                                            
and ClientOrSpouse IN('M','Y') ) VO ON VO.TARGETID=CM.Targetid  
LEFT JOIN  (SELECT UNIQUEID, MAX(capturedate) AS capturedate  FROM {source_catalog}.{source_schema}.`pragati-ekyclog`
            GROUP BY UNIQUEID ) EKYC ON EKYC.UNIQUEID=CM.Targetid)

SELECT DISTINCT CT_CM.*, COALESCE(HHI_C.CreatedDateTime, HHI_T.CreatedDateTime) AS HHI_DATE, CKYC.CKYCID, CKYC.remarks AS CKYCIDRemarks,
          SOP.BRANCHID, SOP.BRANCHNAME, SOP.UMBaseLocationBranchName AS UNITNAME, SOP.ZONE, SOP.REGION, SOP.AREA, SOP.STATE, SOP.DISTRICT, SOP.SBHSTATE,
          (CASE WHEN DROPOUTDATE IS NULL AND DATEDIFF(WEEK, CT_CM.JoinDate, CAST(CURRENT_DATE()-1 AS DATE))>8 AND CLS.MINDATE IS NULL THEN 'Dormant Without Loan' 
                WHEN MAX_LOANCLOSE IS NOT NULL AND DATEDIFF(WEEK, MAX_LOANCLOSE, CAST(CURRENT_DATE()-1 AS DATE))>8  THEN 'Dormant With Loan'
          END) AS DormantWithLoanWithoutLoan, CLS.MINDATE AS Min_Disbdate
 FROM  CTE_CLIENTMASTER  CT_CM
LEFT JOIN (
SELECT CLIENTID, CreatedDateTime, ETL_IS_ACTIVE FROM {source_catalog}.{source_schema}.`rdsp_trans-mfi_household_details`
WHERE ETL_IS_ACTIVE=1) HHI_C  ON  HHI_C.CLIENTID=CT_CM.CLIENTID   
LEFT JOIN (
           SELECT CLIENTID, CreatedDateTime, ETL_IS_ACTIVE FROM {source_catalog}.{source_schema}.`rdsp_trans-mfi_household_details`
WHERE ETL_IS_ACTIVE=1) HHI_T  ON  HHI_T.CLIENTID=CT_CM.TARGETID   
LEFT JOIN {source_catalog}.{source_schema}.`azuresource-tbl_bfilckycmis_clientwise` CKYC ON CKYC.CLIENTID=CT_CM.CLIENTID
LEFT JOIN {mart_catalog}.{mart_schema}.`p_hierarchy_sop` SOP ON SOP.HIERARCHYID=CT_CM.HIERARCHYID
LEFT JOIN (SELECT CLIENTID, MIN(DISBURSEMENTDATE) AS MINDATE, MAX(LOANCLOSEDDATE) AS MAX_LOANCLOSE 
          FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` WHERE  ETL_IS_ACTIVE=1 AND PRODUCTTYPE IS NULL
          GROUP BY CLIENTID) CLS ON CLS.CLIENTID=CT_CM.CLIENTID
""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"Error while initializing the parameters and query: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("Error while initializing the parameters and query:", str(e))


# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"clientfacts Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on clientfacts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on clientfacts : ", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.clientfacts")

    logger(
        logger_level_info,
        f"clientfacts writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table clientfacts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table clientfacts : ", str(e)
    )

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)