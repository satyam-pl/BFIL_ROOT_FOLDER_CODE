# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_liablilty_fact_finacle.dbc"

# COMMAND ----------

try:
    # Log the start of the notebook
    logger(
        logger_level_info,
        "Required notebook imports have been successfully completed.",
        execution_log_list,
        filename,
    )
    
    # Fetching parameters from ADF widgets
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FACTS/LIABLILTY_FACT_FINACLE"
    desti_path = "BFIL-MART/FACTS/LIABLILTY_FACT_FINACLE"

    logger(
        logger_level_info,
        "Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    # Get the current date in the 'Asia/Kolkata' timezone
    current_date_kolkata = spark.sql("SELECT CAST(FROM_UTC_TIMESTAMP(CURRENT_TIMESTAMP(), 'Asia/Kolkata') AS DATE) AS CURRENTDATE").collect()[0]['CURRENTDATE']

    # Calculate LASTTHREEDATE as CURRENTDATE - 3 days
    last_three_date = spark.sql(f"SELECT DATE_SUB(DATE('{current_date_kolkata}'), 3) AS LASTTHREEDATE").collect()[0]['LASTTHREEDATE']

    # Calculate LASTYEARENDDATE based on the current date
    current_month = int(spark.sql(f"SELECT MONTH(DATE('{current_date_kolkata}')) AS MONTH").collect()[0]['MONTH'])
    current_year = int(spark.sql(f"SELECT YEAR(DATE('{current_date_kolkata}')) AS YEAR").collect()[0]['YEAR'])
    
    if current_month <= 3:
        last_year_end_date = f"{current_year - 1}-03-31"
    else:
        last_year_end_date = f"{current_year}-03-31"

    query = f"""
    WITH FactBaldly AS (
        SELECT ACID,
               MAX(CAST(REPORT_DATE AS DATE)) AS MaxReportDate
        FROM edp_datawarehouse_prod.edw.factbaldly
        WHERE CAST(REPORT_DATE AS DATE) >= '{last_three_date}'
        GROUP BY ACID
    ),
    
    FactLiab AS (
        SELECT B.ACID,
               B.Account_No,
               B.AVG_BAL_ORG
        FROM FactBaldly AS A
        JOIN edp_datawarehouse_prod.edw.factbaldly AS B 
        ON B.ACID = A.ACID AND CAST(B.REPORT_DATE AS DATE) = A.MaxReportDate
    ),
    
    MerchantMaster AS (
        SELECT *
        FROM edp_curated_prod.bfil.`rdsp-merchant_master`
        WHERE (Merchant_ID LIKE 'I00%' OR Merchant_ID LIKE 'I0U%')
        AND LENGTH(TRIM(Merchant_ID)) = 8
        AND ETL_IS_ACTIVE = '1'
    ),
    
    MerchantDetails_ExclDeactive AS (
        SELECT MerchantAccNo, Merchant_ID
        FROM MerchantMaster
        WHERE UPPER(TRIM(Merchant_Status)) <> 'DEACTIVE'
    ),
    
    MerchantDeatils_Deactive AS (
        SELECT A.MerchantAccNo, A.Merchant_ID
        FROM MerchantMaster AS A
        JOIN (
            SELECT MerchantAccNo, MAX(Createdatetime) AS MaxCreatedDateTime
            FROM MerchantMaster
            WHERE MerchantAccNo NOT IN (SELECT MerchantAccNo FROM MerchantDetails_ExclDeactive)
            AND UPPER(TRIM(Merchant_Status)) = 'DEACTIVE'
            GROUP BY MerchantAccNo
        ) AS B ON B.MerchantAccNo = A.MerchantAccNo AND B.MaxCreatedDateTime = A.Createdatetime
    ),
    
    Merchant_Details AS (
        SELECT MerchantAccNo, Merchant_ID
        FROM MerchantDetails_ExclDeactive
        UNION 
        SELECT MerchantAccNo, Merchant_ID
        FROM MerchantDeatils_Deactive
    ),
    
    LienData_OverAll AS (
        SELECT DISTINCT ACID,
               'Yes' AS IsOverAllLien
        FROM edp_bfil_prod.finacle.alt_vw 
        WHERE CAST(LIEN_EXPIRY_DATE AS DATE) = '2099-12-31'
    ),
    
    LienData_BFIL AS (
        SELECT DISTINCT ACID,
               'Yes' AS IsBFIL_Lien
        FROM edp_bfil_prod.finacle.alt_vw 
        WHERE CAST(LIEN_EXPIRY_DATE AS DATE) = '2099-12-31' AND LIEN_REASON_CODE = '072'
    ),
    
    BaseData AS (
        SELECT DISTINCT Base.ACID,
               Base.SBU,
               Base.SOL_ID AS IBLBaseCode,
               Base.CIFID,
               Base.SCHM_CODE,
               Base.SCHM_TYPE,
               Base.C5Code,
               Base.FORACID AS AccountNumber,
               Base.ACCT_NAME AS CustomerName,
               Base.AccountType,
               CAST(A.ACCT_OPN_DATE AS DATE) AS AccountOpenDate,
               F.DEPOSIT_PERIOD_MTHS AS Tenure_Months,
               F.DEPOSIT_PERIOD_DAYS AS Tenure_Days,
               F.DEPOSIT_AMOUNT AS DepositAmount,
               CAST(F.MATURITY_DATE AS DATE) AS MaturityDate,
               IFNULL(E.IsOverAllLien, 'No') AS IsOverallLien,
               IFNULL(E1.IsBFIL_Lien, 'No') AS IsBFIL_Lien,
               A.FREZ_CODE AS FreezeCode,
               A.FREZ_REASON_CODE AS FreezeReasonCode,
               A.LAST_FREZ_DATE AS Last_FreezedDate,
               A.LAST_UNFREZ_DATE AS Last_UnFreezedDate,
               CAST(A.BAL_ON_FREZ_DATE AS DECIMAL(20,2)) AS BalanceOn_FreezedDate,        
               CAST(A.CUM_DR_AMT AS DECIMAL(20,2)) AS Cumulative_DebitAmount,
               CAST(A.CUM_CR_AMT AS DECIMAL(20,2)) AS Cumulative_CreditAmount,
               CAST(A.CLR_BAL_AMT AS DECIMAL(20,2)) AS Balance,
               CAST(A.LAST_TRAN_DATE_DR AS DATE) AS Last_DebitTranDate,
               CAST(A.LAST_TRAN_DATE_CR AS DATE) AS Last_CreditTranDate,
               CAST(A.LAST_TRAN_DATE AS DATE) AS Last_TranDate,
               CAST(A.LAST_ANY_TRAN_DATE AS DATE) AS Last_AnyTranDate,
               CAST(F.CUMULATIVE_INSTL_PAID AS DECIMAL(20,2)) AS PrincipleAmount,
               CAST(F.CUMULATIVE_INT_CREDITED AS DECIMAL(20,2)) AS InterestAmount,
               CAST(IFNULL(G.REPAYMENT_AMT, F.MATURITY_AMOUNT) AS DECIMAL(20,2)) AS MaturedAmount,
               CAST((F.CUMULATIVE_INSTL_PAID / F.DEPOSIT_AMOUNT) AS FLOAT) AS NoOfInstallmentsPaid,
               H.ForacID AS RepaymentAccount,
               CAST(F.LAST_REPAYMENT_DATE AS DATE) AS Last_RepaymentDate,
               IF(UPPER(TRIM(C.ACCT_STATUS)) = 'I', CAST(C.NEXT_INACT_CHRG_CALC_DATE AS DATE), NULL) AS InActiveDate,
               IF(UPPER(TRIM(C.ACCT_STATUS)) = 'D', CAST(C.NEXT_DORM_CHRG_CALC_DATE AS DATE), NULL) AS DormatDate,
               A.ACCT_CLS_FLG AS AccountClosedFlag,
               CAST(COALESCE(G.PART_CLOSE_DATE, F.CLS_VALUE_DATE, A.ACCT_CLS_DATE) AS DATE) AS AccountClosedDate,
               CASE 
                   WHEN G.PART_CLOSE_DATE IS NOT NULL THEN 'Pre-Closure'
                   WHEN A.ACCT_CLS_DATE IS NOT NULL THEN 'Closed'
                   WHEN UPPER(TRIM(C.ACCT_STATUS)) = 'I' THEN 'In-Active'
                   WHEN UPPER(TRIM(C.ACCT_STATUS)) = 'D' THEN 'Dormat'
                   WHEN UPPER(E1.IsBFIL_Lien) = 'YES' THEN 'Lien'
                   WHEN IFNULL(A.FREZ_CODE, ' ') <> ' ' THEN 'Freezed'
                   WHEN (A.CLR_BAL_AMT <> 0 OR UPPER(A.ACTIVE_STATUS) = 'A' OR A.ACCT_CLS_FLG = 'N') THEN 'Active'
               ELSE NULL 
               END AS Status,
               CASE 
                   WHEN CAST(F.MATURITY_DATE AS DATE) < CAST(CURRENT_DATE() AS DATE)
                   AND CAST(COALESCE(G.PART_CLOSE_DATE, F.CLS_VALUE_DATE, A.ACCT_CLS_DATE) AS DATE) IS NULL THEN 1 
               ELSE 0 
               END AS IsOverDue,
               Mapping.Agent_ID,
               MM.Merchant_ID,
               IFF(CAST(A.ACCT_OPN_DATE AS DATE) <= '{last_year_end_date}', 'ETB', 'NTB') AS AccountAquistion,
               IFNULL(Fact.AVG_BAL_ORG, 0) AS ANR        
        FROM edp_bfil_prod.finacle.dim_bfil_ACID_vw AS Base
        JOIN edp_bfil_prod.finacle.gam_vw AS A ON A.ACID = Base.ACID
        LEFT JOIN edp_bfil_prod.finacle.smt_vw AS C ON C.ACID = Base.ACID
        LEFT JOIN LienData_OverAll AS E ON E.ACID = Base.ACID
        LEFT JOIN LienData_BFIL AS E1 ON E1.ACID = Base.ACID
        LEFT JOIN edp_bfil_prod.finacle.tam_vw AS F ON F.ACID = Base.ACID
        LEFT JOIN edp_bfil_prod.finacle.tph_vw AS G ON G.ACID = Base.ACID AND CLOSURE_TYPE = 'P'
        LEFT JOIN edp_bfil_prod.finacle.gam_vw AS H ON H.ACID = F.REPAYMENT_ACID
        LEFT JOIN FactLiab AS Fact ON Fact.ACID = Base.ACID
        LEFT JOIN edp_curated_prod.bfil.`firewall_prod-accountidmapping` AS Mapping ON Mapping.AccountID = Base.ForacID AND Mapping.ETL_IS_ACTIVE = '1'
        LEFT JOIN Merchant_Details AS MM ON MM.MerchantAccNo = Base.ForacID
        WHERE UPPER(Base.SCHM_CODE) NOT IN ('IBFIL')
        AND Base.ForacID NOT IN (SELECT ForacID FROM edp_bfil_prod.finacle.dim_bfil_poolaccounts WHERE Status = 1)
    ),
    
    Base_ETBData AS (
        SELECT A.ACID,
               B.ENR_BAL_ORG AS Base_ENR,
               B.AVG_BAL_ORG AS Base_ANR
        FROM BaseData AS A
        JOIN edp_datawarehouse_prod.edw.factbaldly AS B ON B.ACID = A.ACID AND CAST(B.REPORT_DATE AS DATE) = '{last_year_end_date}'
        WHERE UPPER(A.AccountAquistion) = 'ETB'
    ),
    
    Final_FinacleData AS (
        SELECT A.*, 
               B.Base_ENR,
               B.Base_ANR
        FROM BaseData AS A
        LEFT JOIN Base_ETBData AS B ON B.ACID = A.ACID
    )
    
    SELECT * FROM Final_FinacleData
    """

except Exception as e:
    logger(
        logger_level_error,
        f"Error while initializing the parameters and query: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("Error while initializing the parameters and query: ", str(e))


# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"liablilty_fact_finacle Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on liablilty_fact_finacle: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on liablilty_fact_finacle : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.liablilty_fact_finacle")

    logger(
            logger_level_info,
            f"liablilty_fact_finacle writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table liablilty_fact_finacle : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table liablilty_fact_finacle : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)