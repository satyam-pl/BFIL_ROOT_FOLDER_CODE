# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_dailyloanfacts_RDSP.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/DAILYLOANFACTS_RDSP"
    desti_path = "BFIL-MART/FACTS/DAILYLOANFACTS_RDSP"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )
    query = """SELECT DISTINCT
  CODDATE,
  Branch_Type,
  State,
  Region,
  District,
  Zone,
  Area,
  BranchName,
  BranchID,
  HierarchyId,
  ClientLoanId,
  ClientLoanCode,
  LoanProposalId,
  LoanProposalCode,
  ProductName,
  ProductCode,
  ProductDescription,
  ClientProductSequenceNo,
  ClientId,
  ClientCode,
  ClientName,
  CenterCode,
  CenterId,
  centername,
  CAST(CenterMeetingDay as STRING),
  CenterStaffID,
  DisbursementDate,
  CAST(LoanAmountDisbursed as decimal(19,4)),
  ExpectedPaidUPDATE,
  LoanClosedDate1,
  PurposeId,
  PurposeName,
  HoUSEHoldINcome,
  INterestRate,
  DifferenceAmountInPreclosing,
  Tenure,
  FundName,
  FundId,
  Caste,
  Religion,
  Rural_Urban,
  DeviationCancel,
  LoanCancelleddate,
  DisbursementMode,
  RepaymentFrequency,
  Gender,
  DateOfBirth,
  JoinDate,
  ProposalDate,
  ApprovedDate,
  CAST(LoanAmountApproved as decimal(19,4)),
  Groupid,
  TargetId,
  TargetCode,
  TargetDate,
  IsLoanClosed,
  CAST(UpfrontInterest_vp as decimal(18,4)),
  CAST(NPAStatus_vp as INT),
  CAST(NULL as STRING) Moratorium_flag,
  DeathDate,
  CAST(Cum_PrincipalColl1 as decimal(29,4)),
  CAST(Cum_InterestColl1 as decimal(29,4)),
  CAST(Cum_Pridue as decimal(29,4)),
  CAST(Cum_IntDue as decimal(29,4)),
  CAST(PrincipalWrittenoff as decimal(18,4)),
  CAST(InterestWrittenoff as decimal(18,4)),
  TransactionDate,
  CAST(Total_PrincipalDue as decimal(29,4)),
  CAST(Total_InterestDue as decimal(29,4)),
  CAST(NULL as decimal(18,4)) RD_AdjustAmt,
  CAST(POS as decimal(34,6)),
  CAST(IOS as decimal(30,4)),
  CAST(PrincipalInArears as decimal(30,4)),
  CAST(InterestInArears as decimal(30,4)),
  LastRepaymentDate,
  M_Flag,
  Last_CMDate,
  DPDStartdate,
  CAST(NoOfDaysInArrears1 as decimal(22,2)),
  Type_New1 Type_New,
  Freezed1,
  CAST(NULL as STRING) AssetCl_BR,
  Loan_Status,
  Ageing_Loan,
  CAST(NULL as decimal(22,2)) ClientDPD_EXCL_ARC,
  CAST(NULL as STRING) Ageing_Client_EXCL_ARC,
  Product_Type,
  EWI,
  ProductCategory,
  CAST(ClosedloanwithPos as decimal(34,6)),
  CAST(M_PriDue as decimal(29,4)),
  CAST(M_IntDue as decimal(29,4)),
  CAST(M_PriColl as decimal(29,4)),
  CAST(M_IntColl as decimal(29,4))
  from (
 
 
  With T_branch_Daily as (
  SELECT     H.BranchID, H.BranchName, H.HierarchyId, H.State,H.Branch_Type,H.Region,H.Zone,H.Area,
  H.District,
  MAX(PL.TransactionDate) AS CODDate
  FROM  (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-BranchCODProcessLog` WHERE ETL_IS_ACTIVE = '1') PL
  join {mart_catalog}.{mart_schema}.p_hierarchy_sop h on PL.HierarchyId = H.HierarchyId
  WHERE   h.HierarchyId in ('114451','114910')
  GROUP BY H.BranchID, H.BranchName, H.HierarchyId,H.State,H.Branch_Type,H.Region,H.District,H.Zone,H.Area
  ),
 
 EWI_Completed_Coll as (
 
    select
    CLS.HierarchyId ,CLS.ClientId ,CLS.ClientLoanId,
    (CASE WHEN CLS.ClientLoanId IS NULL THEN 0 ELSE MAX(AT.MeetingInstallmentNumber) END) AS Max_Meeting ,
    (CASE WHEN CLS.ClientLoanId IS NULL THEN 0 ELSE MAX(AT.InstallmentNumber) END) AS MaxInstallmentNUmber,
    max(AT.ValueDate) as Max_ValueDate,
    (CASE WHEN CLS.ClientLoanId IS NULL THEN 0 ELSE SUM(PrincipalAmount) END) AS Cum_PrincipalColl,
    (CASE WHEN CLS.ClientLoanId IS NULL THEN 0 ELSE SUM(InterestAmount) END) AS Cum_InterestColl
    FROM  (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-ClientLoanSubscription` WHERE ETL_IS_ACTIVE = '1'
  and (LoanClosedDate IS NULL OR LoanClosedDate = '1900-01-01' or LoanClosedDate >= CAST(date_format(now(), 'yyyy-MM-01') as date))
  AND ProductType IS NULL)  CLS
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') AT
  ON AT.HierarchyId = CLS.HierarchyId and AT.ClientId =CLS.ClientId and CLS.ClientLoanId = AT.ClientLoanId
    WHERE AT.TransactionType = 'C' and AT.DebitOrCredit = 'C' and  CLS.HierarchyId in ('114451','114910')
    GROUP BY CLS.HierarchyId ,CLS.ClientId ,CLS.ClientLoanId
  ),
 
 EWI_Completed_due as (
  select HierarchyId ,ClientId ,ClientLoanId,max(MaxInstallmentNUmber2) as MaxInsNumberForDue    
  from
  (
  SELECT      CLS.HierarchyId ,CLS.ClientId ,CLS.ClientLoanId,   Max(AT.InstallmentNumber)MaxInstallmentNUmber2
    FROM EWI_Completed_Coll CLS    
  JOIN  {source_catalog}.{source_schema}.`ptsmart-AccountTransactions`   AT  ON AT.HierarchyId = CLS.HierarchyId and AT.ClientId =CLS.ClientId and CLS.ClientLoanId = AT.ClientLoanId
    WHERE      upper(AT.TransactionType) = 'C' AND  upper(AT.DebitorCredit) = 'D'
 
  and CLS.HierarchyId in ('114451','114910') and AT.ETL_IS_ACTIVE = '1'
  and AT.TransactionDate<= CLS.Max_ValueDate
	GROUP BY  CLS.HierarchyId ,CLS.ClientId ,CLS.ClientLoanId
union all
   select     HierarchyId ,ClientId ,ClientLoanId, Max_Meeting from EWI_Completed_Coll
union all
   select     HierarchyId ,ClientId ,ClientLoanId,MaxInstallmentNUmber from EWI_Completed_Coll
   ) CLS
   group by CLS.HierarchyId ,CLS.ClientId ,CLS.ClientLoanId
 ),
--select * from EWI_Completed_due;
TotalDue_Daily as (
    SELECT  t.HierarchyId ,t.ClientId ,t.ClientLoanId,
  SUM(A .PrINcipalAmount) AS PRI_DUE,
  SUM(A.INterestAmount ) AS INT_Due
  FROM  EWI_Completed_due T
  INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') A  ON A.ClientLoanId = T.ClientLoanId
  AND  A.HierarchyId = T.HierarchyId
  WHERE A.InstallmentNumber <= T.MaxInsNumberForDue
   AND  upper(A.TransactionType) = 'C' AND  upper(A.DebitorCredit) = 'D'
  and   A.HierarchyId in ('114451','114910')
  GROUP BY  t.HierarchyId ,t.ClientId ,t.ClientLoanId
  )

  ,
  RDSP_DLF_SUB as (
  SELECT  A.CODDate
  ,A.Branch_Type
  ,A.State as State
  ,A.Region
  ,A.District as District
  ,A.Zone as Zone
  ,A.Area
  ,A.BranchName
  ,A.BranchID
  , A.HierarchyId
  ,CLS.ClientLoanId
  , CLS.ClientLoanCode
  ,CLS.LoanProposalId
  ,CLP.LoanProposalCode
  ,CM.ClientId
  ,CM.ClientCode
  ,C.CenterCode
  ,C.CenterId
  ,C.centername
  ,GM.Groupid
  ,TM.TargetId
  ,TM.TargetCode
  ,CM.ClientName
  ,CM.SpouseName
  ,PM.ProductName
  ,PM.ProductCode
  ,PM.ProductDescription
  --,PD.Product_Type
  --,PD.ProductCategory
  ,CLS.ClientProductSequenceNo
  , C.CenterMeetingDay
  ,C.StaffId AS CenterStaffID
  ,C.CenterMeetingTime
  ,CLS.DisbursementDate
  , CLS.LoanAmountDisbursed
  ,(case when lwrd.ClientLoanID is not null then lwrd.ExpectedClosedDate else CLS.ExpectedPaidUPDATE end) as ExpectedPaidUPDATE
  ,(CASE WHEN CLS.LoanClosedDate <=A.CODDate THEN  CLS.LoanClosedDate ELSE NULL END) AS LoanClosedDate1
  ,CLP.PurposeId
  , LoanPurposes.PurposeName
  , CLP.HoUSEHoldINcome
  ,CLS.INterestRate
  ,(CASE WHEN (LoanClosedDate IS NULL OR LoanClosedDate > A.CODDate) THEN 0 ELSE  coalesce(CLS.differenceAmountinPreclosing,0) END ) AS DifferenceAmountInPreclosing
  ,CLS.Tenure
  ,FundMaster.FundName
  ,CLP.FundId
  ,TM.Caste
  , CV.Value AS Religion
  , CodeValue_1.Value AS Rural_Urban
  ,CLS.IsDeviationCancelled AS DeviationCancel
  ,CLS.LoanCancelleddate
  ,CLS.DisbursementMode
  ,CLS.RepaymentFrequency
  ,CM.Gender
  ,CM.DateOfBirth
  ,CM.JoinDate
  ,CLP.ProposalDate
  ,CLP.ApprovedDate
  ,CLP.LoanAmountApproved
  ,TM.TargetDate
  ,CLS.IsLoanClosed
  ,CLp.HouseHoldIncomeAmount
  ,(case when PM.ProductCode = '854' and CLS.MIInterestAmount <> 0 then MIInterestAmount end) as UpfrontInterest_vp
  -- else coalesce(MI.UpfrontInterest_vp,0) end) as UpfrontInterest_vp
  ,'' as NPAStatus_vp
  ,'' as Moratorium_flag
  --,MI.NPAStatus_vp as NPAStatus_vp
  --,MI.Moratorium_flag as Moratorium_flag
  ,(case when CDI.DeathDate is not null and CDI.DeathDate >= CLS.DisbursementDate AND CDI.DeathDate <= A.CODDate and (LoanClosedDate1 is null or LoanClosedDate1 > CDI.DeathDate) then CDI.DeathDate end) as DeathDate
  ,coalesce(EWI_Completed_Coll.Cum_PrincipalColl,0) as Cum_PrincipalColl1
  ,coalesce(EWI_Completed_Coll.Cum_InterestColl,0) as Cum_InterestColl1
  ,coalesce(TotalDue_Daily.PRI_DUE,0) as Cum_Pridue
  ,coalesce(TotalDue_Daily.INT_Due,0) as Cum_IntDue
  ,(case when W.TransactionDate <= A.CODDate and w.HierarchyId in ('114451','114910') then coalesce(W.WriteOffAmount,0) end) as PrincipalWrittenoff
  ,(case when W.TransactionDate <= A.CODDate and w.HierarchyId in ('114451','114910') then coalesce(W.WriteOffIntreast,0) end) as InterestWrittenoff
  ,(case when W.TransactionDate <= A.CODDate and w.HierarchyId in ('114451','114910') then W.TransactionDate end) as TransactionDate
  ,coalesce(TotalDue_Daily.PRI_DUE,0) as Total_PrincipalDue
  ,coalesce(TotalDue_Daily.INT_Due,0)  as Total_InterestDue
  ,case when LoanClosedDate1 is null then (CLS.LoanAmountDisbursed+coalesce(UpfrontInterest_vp,0))-(Cum_PrINcipalColl1+coalesce(PrINcipalWrittenoff,0))
  ELSE 0.0000 END as POS
  ,case when LoanClosedDate1 is null then (Total_InterestDue-Cum_InterestColl1-InterestWrittenoff)
  ELSE 0.0000 END as IOS
  ,case when LoanClosedDate1 is null and (Cum_PriDue - Cum_PrincipalColl1) >= 1 then (Cum_PriDue - Cum_PrincipalColl1)
  when ((coalesce(Cum_Pridue,0)+coalesce(Cum_IntDue,0))-(coalesce(Cum_PrincipalColl1,0)+coalesce(Cum_InterestColl1,0))) < 1 then 0.0000
  ELSE 0.0000
  END as PrincipalInArears
  ,case when LoanClosedDate1 is null and (Cum_IntDue - Cum_InterestColl1) >= 1 then (Cum_IntDue - Cum_InterestColl1)
  when ((coalesce(Cum_Pridue,0)+coalesce(Cum_IntDue,0))-(coalesce(Cum_PrincipalColl1,0)+coalesce(Cum_InterestColl1,0))) < 1 then 0.0000
  ELSE 0.0000 END as InterestInArears
  ,(case when (DeathDAte IS NOT NULL OR LoanClosedDate1 IS NOT NULL OR DeviationCancel = '1' OR CLS.LoanCancelledDate IS NOT NULL OR ExpectedPaidUpDate <= '2021-05-31') then 0.00 end) as INterestaccured
  ,(case when CLS.ClientLoanId IS NULL then CLS.DisbursementDate else EWI_Completed_Coll.Max_ValueDate end) as Last_CMDate
  ,(CASE when (DATEDIFF(DAY,Disbursementdate,last_CMDate))<7 AND (Cum_PrINcipalColl1+Cum_INterestColl1) =0 AND (Cum_PriDue+Cum_INtDue)>0 AND LoanClosedDate1 IS NULL THEN 'Y' ELSE 'N' END) as M_Flag
  ,EWI_Completed_Coll.Max_Meeting as NoofInstallmentCompleted
 
  FROM  (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-ClientLoanSubscription` WHERE ETL_IS_ACTIVE = '1'and HierarchyId in ('114451','114910') and (LoanClosedDate IS NULL OR LoanClosedDate = '1900-01-01' or CAST(LoanClosedDate as date) >= CAST(date_format(now(), 'yyyy-MM-01') as date)) AND ProductType IS NULL)  CLS
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-ClientLoanProposal` WHERE ETL_IS_ACTIVE = '1') CLP  ON CLS.LoanProposalId = CLP.LoanProposalId
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-DerivedProductMASter` WHERE ETL_IS_ACTIVE = '1') DM ON DM.DerivedProductId = CLS.ProductId
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-ProductMASter` WHERE ETL_IS_ACTIVE = '1') PM ON PM.ProductId = DM.ProductId
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-ClientMASter` WHERE ETL_IS_ACTIVE = '1') CM ON CLS.ClientId = CM.ClientId
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-TargetMASter` WHERE ETL_IS_ACTIVE = '1') TM ON CM.TargetId = TM.TargetId
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-codevalue` WHERE ETL_IS_ACTIVE = '1') CV ON TM.Religion = CV.Code
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-Groupmaster` WHERE ETL_IS_ACTIVE = '1') GM on GM.groupid = CM.groupid
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-centermaster` WHERE ETL_IS_ACTIVE = '1') C on C.centerid = GM.centerid
  LEFT JOIN T_branch_Daily AS A  ON A.HierarchyId = CLS.HierarchyId
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-fundmaster` WHERE ETL_IS_ACTIVE = '1') FundMASter ON CLP.FundId = FundMASter.FundId
  LEFT OUTER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-codevalue` WHERE ETL_IS_ACTIVE = '1') AS CodeValue_1  ON C.AuthORityORDepartment = CodeValue_1.Code
  LEFT OUTER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-LoanPurposes` WHERE ETL_IS_ACTIVE = '1') LoanPurposes  ON CLP.PurposeId = LoanPurposes.PurposeId
  ---product type???
  left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-dim_productmaster` WHERE ETL_IS_ACTIVE = '1') PD ON PM.ProductCode = PD.PRODUCT_ID
  and PD.SBU = 'BMS'
  left join (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-loanwiserescheduledetails` WHERE ETL_IS_ACTIVE = '1') lwrd on lwrd.ClientLoanID = CLS.ClientLoanid
  ---script for this table???
  --left JOIN ITDB..P_MIAmountAndMoratoriumFlagFromNov20 MI ON CLS.ClientLoanId = MI.Clientloanid
  ---collate SQL_Latin1_General_CP1_CI_AS
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-ClientDeathINtimation` WHERE ETL_IS_ACTIVE = '1')  CDI ON CLS.ClientId = CDI.ClientId
 
  LEFT JOIN EWI_Completed_Coll ON EWI_Completed_Coll.Clientloanid =  CLS.ClientLoanId
  LEFT JOIN TotalDue_Daily on TotalDue_Daily.Clientloanid =  CLS.ClientLoanId
 
  LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-ClientLoanWriteOff` WHERE ETL_IS_ACTIVE = '1') W ON CLS.ClientLoanId = W.ClientLoanId
  -- LEFT join LastPaidDateInfo D on CLS.ClientLoanId = D.clientloanid
  -- WHERE  (CLS.LoanClosedDate IS NULL OR CLS.LoanClosedDate = '1900-01-01' or
  -- CLS.LoanClosedDate >= CAST(date_format(now(), 'yyyy-MM-01') as date) )
  -- AND     (CLS.DisbursementDate <=A.CODDate)
  -- AND     CLS.ProductType IS NULL
  -- ---why only 2 hierarchyids???
  -- and   A.HierarchyId in ('114451','114910')
	)

  ,
  LastPaidDateInfo as (
    Select A.HierarchyId,A.ClientID,A.ClientLoanId, Max(B.ValueDAte) AS LastRepaymentDate from (
    SELECT  HIerarchyID,ClientID,ClientLoanid, COUNT(INstallmentNumber) AS MaxInstNumber
    FROM (
    SELECT T.HierarchyId,T.ClientId,T.ClientLoanId ,InstallmentNumber,MAX(Valuedate) AS MaxValueDate
    FROM RDSP_DLF_SUB T
    INNER JOIN   (SELECT * FROM  {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') A ON
    A.HierarchyId = T.HierarchyId
    and A.ClientId  = T.ClientId
    and A.ClientLoanId = T.ClientLoanId
    WHERE  A.ValueDate <= Coddate
    AND           A.TransactionType = 'C'
    AND           A.DebitorCredit = 'C'
    and   A.HierarchyId in ('114451','114910')
    GROUP BY      T.HierarchyId,T.ClientId,T.ClientLoanId,InstallmentNumber
    HAVING SUM(Amount) > 0
    )A
    GROUP BY HIerarchyID,ClientID,ClientLoanid) A
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions`
    WHERE ETL_IS_ACTIVE = '1') B ON A.HIerarchyID = B.HIerarchyiD AND A.ClientID = B.ClientID AND  A.ClientLoanid = B.ClientLoanid
    AND A.MaxInstNumber = B.InstallmentNumber
    WHERE B.DebitorCredit = 'C' AND B.Transactiontype = 'C'
    AND B.Amount > 0     and   B.HierarchyId in ('114451','114910')
    GROUP BY A.HierarchyId,A.ClientID,A.ClientLoanId
  )
  -- select * FROM LastPaidDateInfo
  ,
  DPD_start_date as (
    SELECT A.HierarchyId,A.ClientId , A.ClientLoanId, MAX(ATV.ValueDate) AS MaxValueDate,CODDate
    from (select ClientId ,ClientLoanId ,HierarchyId ,Tenure ,CODDate from RDSP_DLF_SUB where CAST((PrincipalInArears+InterestInArears) as decimal (18,4))>0   and LoanClosedDate1 is null) as A
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') ATV ON  A.HierarchyID = ATV.HierarchyID
    and a.ClientId =atv.ClientId
    and A.ClientLoanId = ATV.ClientLoanId
    WHERE (ATV.DebitORCredit = 'C' AND ATV.TransactionTYpe = 'C') AND ATV.ValueDate <= CODDate
    and   ATV.HierarchyId in ('114451','114910')
    GROUP BY A.HierarchyId, A.ClientId ,A.ClientLoanId,CODDate
 
  )
  -- select * from DPD_start_date
  ,
  DPD_start_date_2 as (
    SELECT A.HierarchyId,a.Clientid, A.ClientLoanId, A.MaxValueDate,MAX(ATV.TransactionDate) AS MaxTranDateAgMaxValueDate,
    MIN(CASE WHEN ATV.Amount < 0 THEN ATV.TransactionDate END) AS MinTranDateAgMaxValueDate
    FROM DPD_start_date A
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') ATV
    ON A.HierarchyID = ATV.HierarchyID
    and a.ClientId =atv.ClientId
    and A.ClientLoanId = ATV.ClientLoanId
    WHERE (ATV.DebitOrCredit = 'C' AND ATV.TransactionType = 'C')
    AND           A.MaxValueDate = ATV.ValueDate
    and   ATV.HierarchyId in ('114451','114910')
    GROUP BY A.HierarchyId, A.ClientLoanId, A.MaxValueDate,a.clientid
  )
  ,
  DPD_start_date_3 as (
    SELECT A.HierarchyId, A.ClientId ,A.ClientLoanId, SUM(ATV.Amount) AS AmountColl
    FROM DPD_start_date_2 A
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') ATV
    ON  A.HierarchyID = ATV.HierarchyID
    and a.ClientId =atv.ClientId
    and A.ClientLoanId = ATV.ClientLoanId
    WHERE (ATV.DebitOrCredit = 'C' AND ATV.TransactionType = 'C')
    AND A.MaxTranDateAgMaxValueDate = ATV.TransactionDate
    and   ATV.HierarchyId in ('114451','114910')
    GROUP BY A.HierarchyId, A.ClientId ,A.ClientLoanId
  )
  ,
  DPD_start_date_4 as (
    SELECT A.HierarchyId,a.ClientId , A.ClientLoanId, MIN(ATV.TransactionDate) AS NextDueDate
    FROM DPD_start_date_2 A
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') ATV
    ON  A.HierarchyID = ATV.HierarchyID
    and a.ClientId =atv.ClientId
    and A.ClientLoanId = ATV.ClientLoanId
    WHERE (ATV.DebitOrCredit = 'D' AND ATV.TransactionType = 'C')
    AND  ATV.TransactionDate > A.MaxTranDateAgMaxValueDate
    and   ATV.HierarchyId in ('114451','114910')
    GROUP BY A.HierarchyId,a.ClientId , A.ClientLoanId
  )
  ,
  DPD_start_date_5 as (
    SELECT A.HierarchyId,a.ClientId , A.ClientLoanId, SUM(ATV.Amount) AS DueAmount_ForMaxTranDate
    FROM DPD_start_date_2 A
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` WHERE ETL_IS_ACTIVE = '1') ATV ON
    A.HierarchyID = ATV.HierarchyID
    and a.ClientId =atv.ClientId
    and A.ClientLoanId = ATV.ClientLoanId
    WHERE (ATV.DebitOrCredit = 'D' AND ATV.TransactionType = 'C')
    AND A.MaxTranDateAgMaxValueDate = ATV.TransactionDate
    and   ATV.HierarchyId in ('114451','114910')
    GROUP BY A.HierarchyId,a.ClientId , A.ClientLoanId
  )
  ,
  DPD_start_date_6 as (
    SELECT Base.HierarchyId,Base.ClientLoanID, coddate,
    A.MaxValueDate, A.MaxTranDateAgMaxValueDate,A.MinTranDateAgMaxValueDate, B.AmountColl,C.NextDueDate,
    coalesce(D.DueAmount_ForMaxTranDate,0) AS DueAmount_ForMaxTranDate,
    (CASE WHEN A.MinTranDateAgMaxValueDate IS  NULL and (DueAmount_ForMaxTranDate-AmountColl)=0 then NextDueDate
    WHEN A.MinTranDateAgMaxValueDate IS  NULL and (DueAmount_ForMaxTranDate-AmountColl)!=0 then A.MaxTranDateAgMaxValueDate
    WHEN A.MinTranDateAgMaxValueDate IS NOT NULL and (DueAmount_ForMaxTranDate-AmountColl)=0 then NextDueDate
    WHEN A.MinTranDateAgMaxValueDate IS NOT NULL and (DueAmount_ForMaxTranDate-AmountColl)!=0 then A.MinTranDateAgMaxValueDate
    else A.MaxTranDateAgMaxValueDate
    end) as LastUnpaidEWIDate2,
    (case when LastUnpaidEWIDate2 > CODDate then A.MaxValueDate else LastUnpaidEWIDate2 end) as LastUnpaidEWIDate
    FROM DPD_start_date Base
    LEFT JOIN DPD_start_date_2 A ON A.ClientLoanId = Base.ClientLoanId
    LEFT JOIN DPD_start_date_3 B ON B.ClientLoanId = Base.ClientLoanId
    LEFT JOIN DPD_start_date_4 C ON C.ClientLoanId = Base.ClientLoanId
    LEFT JOIN DPD_start_date_5 D ON D.ClientLoanId = Base.ClientLoanId
  )
  -- select * from DPD_start_date_6
  ,
  RDSP_DLF_SUB2 as (
  select P.*
    ,L.LastRepaymentDate
    ,D.LastUnpaidEWIDate as DPDStartdate
    ,(case when (P.LoanClosedDate1 IS NOT NULL or DPDStartdate is null) then 0
    when P.LoanClosedDate1 IS NULL AND DPDStartdate < '2020-03-01' then (DATEDIFF(DAY,DPDStartdate,P.CODDate)+1)-184
    when Moratorium_flag = 'Y' AND P.LoanClosedDate1 IS NULL AND (DPDStartdate BETWEEN '2020-03-01' AND '2020-08-31') then DATEDIFF(DAY,'2020-09-01',P.CODDate)+1
    when Moratorium_flag = 'Y' AND P.LoanClosedDate1 IS NULL                       AND (DPDStartdate >= '2020-09-01') then DATEDIFF(DAY,DPDStartdate,P.CODDate)+1
    when Moratorium_flag = 'Y'  AND NPAStatus_vp = '1' AND P.LoanClosedDate1 IS NULL AND DPDStartdate IS NOT NULL then DATEDIFF(DAY,DPDStartdate,P.CODDate)+1
    when (Moratorium_flag <> 'Y' OR Moratorium_flag IS NULL) AND P.LoanClosedDate1 IS NULL and DPDStartdate is not null then DATEDIFF(DAY,DPDStartdate,P.CODDate)+1
    when M_Flag = 'Y' AND (Cum_PrINcipalColl1+Cum_INterestColl1) = 0 then 0
  end) as NoOfDaysInArrears1
    ,(CASE WHEN clst.SPT_ID is not null THEN clst.Type_New  
      ELSE 'Advances' END) as Type_New1
  ,(CASE WHEN Type_New1 IN ('Advances') AND P.LoanClosedDate1 IS NULL THEN 'Y' ELSE NULL END) as Freezed1
  ,(CASE WHEN clst.assettag = 'ARC' and clst.SPT_ID is not null THEN 'ARC'
    WHEN Freezed1 = 'Y' and clst.SPT_ID is null then 'Standard' END) as AssetCl_BR
  ,(CASE WHEN CDI.DeathCertificateReceivedDate =P.LoanClosedDate1 AND CDI.DeathCertificateReceivedDate <= P.CODDate AND DisbursementDate <= CDI.DeathDate AND CDI.ClientId is Not null THEN 'DeathCASE'
    WHEN P.LoanClosedDate1 IS NOT NULL AND  (Cum_PrINcipalColl1-Cum_PriDue) > 10 AND CDI.DeathDate IS NULL AND DATEDIFF(DAY,P.LoanClosedDate1,ExpectedPaidUpDate) >5 THEN 'Prepayment'
    WHEN NoOfDaysInArrears1>0 and P.LoanClosedDate1 IS NULL THEN 'Arrear'
    WHEN NoOfDaysInArrears1=0 THEN 'Normal'
      END) as Loan_Status
      ,(CASE WHEN Loan_Status  <> 'Arrear' AND NoOfDaysInArrears1 = 0 THEN 'Current1'
      WHEN Loan_Status = 'Arrear' AND (NoOfDaysInArrears1 BETWEEN 1 AND 30) THEN '[1 To 30]'
      WHEN (NoOfDaysInArrears1 BETWEEN 31 AND 60) THEN '[31 To 60]'
      WHEN (NoOfDaysInArrears1 BETWEEN 61 AND 90) THEN '[61 To 90]'
      WHEN (NoOfDaysInArrears1 > 90) THEN '[>90]'
      END) as Ageing_Loan
  from RDSP_DLF_SUB P
  left join DPD_start_date_6 D on P.ClientLoanId = D.ClientLoanId
  left join {source_catalog}.{source_schema}.`ptsmart-ClientDeathIntimation` CDI on CDI.ClientId = P.ClientId
  LEFT join LastPaidDateInfo L on P.ClientLoanId = L.clientloanid
  LEFT JOIN {source_catalog}.{source_schema}.`azuresource-p_clstagging` clst ON P.ClientLoanId = CLST.SPT_ID
  )
  -- select * from RDSP_DLF_SUB2
  ,
  Clientlevel_DPD as (
  Select  ClientId, Max(NoOfDaysInArrears1)Max_NoOfDaysInArrears1
  from RDSP_DLF_SUB2
  where Freezed1 = 'Y' and AssetCl_BR not in ('ARC')
  Group by ClientId
  )
  -- select * from Clientlevel_DPD
  ,
  collection as (
  SELECT
  T.HierarchyId ,t.ClientId ,T.ClientLoanId,
  SUM(PrincipalAmount)   AS M_PriColl,
  SUM(InterestAmount)   AS M_IntColl
  FROM  RDSP_DLF_SUB2 T
  inner JOIN {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` LT  ON
  LT.HierarchyId = T.HierarchyId
  and LT.ClientId =t.ClientId
  and LT.ClientLoanId = T.ClientLoanId
  WHERE LT.TransactionType = 'C'
  AND LT.DebitORCredit = 'C'
  AND LT.ValueDate BETWEEN DATEADD(MONTH,0,GETDATE()) AND CODDate
  and T.HierarchyId in ('114451','114910')
  GROUP BY T.HierarchyId ,t.ClientId ,T.ClientLoanId
  )
  ,
  Due as (
  SELECT  t.HierarchyId ,t.ClientId ,t.ClientLoanId,
  SUM(LT.PrINcipalAmount) AS M_PriDue,
  SUM(LT.INterestAmount ) AS M_IntDue
  FROM  RDSP_DLF_SUB2 T
  INNER JOIN {source_catalog}.{source_schema}.`ptsmart-AccountTransactions` LT  ON LT.HierarchyId = T.HierarchyId
  AND LT.ClientId = T.ClientId
  AND LT.ClientLoanId = T.ClientLoanId
  WHERE LT.ValueDate BETWEEN DATEADD(MONTH,0,GETDATE()) AND CODDate
  AND  LT.TransactionType = 'C' AND  LT.DebitorCredit = 'D'
  and T.HierarchyId in ('114451','114910')
  GROUP BY  t.HierarchyId ,t.ClientId ,t.ClientLoanId
  )
  select
    p.*
    ,DPD.Max_NoOfDaysInArrears1 as ClientDPD_EXCL_ARC
    ,(CASE WHEN InterestRate <> 0 then round (LoanAmountDisbursed / ((1-POWER(1/(1+ (((InterestRate /cast( 100 as decimal(10,4)) / 365) * 7))), Tenure))/ (((InterestRate / cast( 100 as decimal(10,4)) / 365) * 7))),0) END) as EWI
    ,EWI as ActualEWI
    ,(case when p.loancloseddate1 is not null then ((LoanAmountDisbursed+coalesce(UpfrontInterest_vp,0))-coalesce(Cum_PrINcipalColl1,0)-            coalesce(dIFferenceAmountINPreclosINg,0)-coalesce(PrINcipalWrittenoff,0)) end) as ClosedloanwithPos
    ,(case when BranchID = '46:44' then 'RDSP_Borrower'
        when BranchID = '46:45' then 'RDSP_NonBorrower' end) as ProductCategory
    ,ProductCategory as Product_type
    ,(case when p.ClientLoanId is NULL then 0 else collection.M_PriColl end) as M_PriColl
    ,(case when p.ClientLoanId is NULL then 0 else collection.M_IntColl end) as M_IntColl
    ,(case when p.ClientLoanId is NULL then 0 else Due.M_PriDue end) as M_PriDue
    ,(case when p.ClientLoanId is NULL then 0 else Due.M_IntDue end) as M_IntDue
    from RDSP_DLF_SUB2 p
    left join Clientlevel_DPD DPD ON DPD.clientid = p.Clientid
    left join collection on collection.ClientLoanID = p.ClientLoanid
    left join Due on Due.ClientLoanID = p.ClientLoanid);""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"dailyloanfacts_RDSP Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on dailyloanfacts_RDSP: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on dailyloanfacts_RDSP : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.dailyloanfacts_RDSP")

    logger(
            logger_level_info,
            f"dailyloanfacts_RDSP writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table dailyloanfacts_RDSP : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table dailyloanfacts_RDSP : ", str(e))
