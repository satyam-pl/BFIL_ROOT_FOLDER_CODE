# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_dailyloanfacts_step1.dbc"

# COMMAND ----------


try:
	logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
	)
	mart_catalog = dbutils.widgets.get("mart_catalog")
	mart_schema = dbutils.widgets.get("mart_schema")
	source_catalog = dbutils.widgets.get("source_catalog")
	source_schema = dbutils.widgets.get("source_schema")
	mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
	path = mart_layer_abfss_url + "BFIL-MART/REPORTING/DAILYLOANFACTS_STEP1"
    
	logger(
		logger_level_info,
		f"Fetching required parameters from ADF has been successfully completed.",
		execution_log_list,
		filename,
	)
	query = """SELECT DISTINCT
			CAST(CODDATE as timestamp),
			CAST(Branch_Type as string),
			CAST(State as string),
			CAST(Region as string),
			CAST(District as string),
			CAST(Zone as string),
			CAST(Area as string),
			CAST(BranchName as string),
			CAST(BranchID as string),
			CAST(HierarchyId as string),
			CAST(ClientLoanId as string),
			CAST(ClientLoanCode as string),
			CAST(LoanProposalId as string),
			CAST(LoanProposalCode as string),
			CAST(ProductName as string),
			CAST(ProductCode as string),
			CAST(ProductDescription as string),
			CAST(ClientProductSequenceNo as integer),
			CAST(ClientId as string),
			CAST(ClientCode as string),
			CAST(ClientName as string),
			CAST(CenterCode as string),
			CAST(CenterId as string),
			CAST(centername as string),
			CAST(CenterMeetingDay as string),
			CAST(CenterStaffID as string),
			CAST(DisbursementDate as timestamp),
			CAST(LoanAmountDisbursed as decimal(19,4)),
			CAST(ExpectedPaidUPDATE as timestamp),
			CAST(LoanClosedDate1 as timestamp),
			CAST(PurposeId as string),
			CAST(PurposeName as string),
			CAST(HoUSEHoldINcome as decimal(16,6)),
			CAST(INterestRate as decimal(25,20)),
			CAST(DifferenceAmountInPreclosing as decimal(16,6)),
			CAST(Tenure as integer),
			CAST(FundName as string),
			CAST(FundId as string),
			CAST(Caste as string),
			CAST(Religion as string),
			CAST(Rural_Urban as string),
			CAST(DeviationCancel as boolean),
			CAST(LoanCancelleddate as timestamp),
			CAST(DisbursementMode as string),
			CAST(RepaymentFrequency as string),
			CAST(Gender as string),
			CAST(DateOfBirth as timestamp),
			CAST(JoinDate as timestamp),
			CAST(ProposalDate as timestamp),
			CAST(ApprovedDate as timestamp),
			CAST(LoanAmountApproved as decimal(19,4)),
			CAST(Groupid as string),
			CAST(TargetId as string),
			CAST(TargetCode as string),
			CAST(TargetDate as timestamp),
			CAST(IsLoanClosed as boolean),
			CAST(UpfrontInterest_vp as decimal(18,4)),
			CAST(NPAStatus as string),
			CAST(Moratorium_flag as string),
			CAST(DeathDate as timestamp),
			CAST(Cum_PrincipalColl1 as decimal(29,4)),
			CAST(Cum_InterestColl1 as decimal(29,4)),
			CAST(Cum_Pridue as decimal(29,4)),
			CAST(Cum_IntDue as decimal(29,4)),
			CAST(PrincipalWrittenoff as decimal(18,4)),
			CAST(InterestWrittenoff as decimal(18,4)),
			CAST(TransactionDate as timestamp),
			CAST(Total_PrincipalDue as decimal(29,4)),
			CAST(Total_InterestDue as decimal(29,4)),
			CAST(RD_AdjustAmt as decimal(18,4)),
			CAST(POS as decimal(34,6)),
			CAST(IOS as decimal(30,4)),
			CAST(PrincipalInArears as decimal(30,4)),
			CAST(InterestInArears as decimal(30,4)),
			CAST(LastRepaymentDate as timestamp),
			CAST(M_Flag as string),
			CAST(Last_CMDate as timestamp),
			CAST(DPDStartdate as timestamp),
			CAST(NoOfDaysInArrears1 as decimal(22,2)),
			CAST(Type_New1 as string) Type_New,
			CAST(freezed1 as string),
			CAST(NULL as string) AssetCl_Br,
			CAST(Loan_Status as string),
			CAST(Ageing_Loan as string),
			CAST(NULL as decimal(22,2)) ClientDPD_EXCL_ARC,
			CAST(NULL as string) Ageing_Client_EXCL_ARC,
			CAST(Product_type as string),
			CAST(EWI as double),
			CAST(ProductCategory as string),
			CAST(ClosedloanwithPos as decimal(34,6)),
			CAST(M_PriDue as decimal(29,4)),
			CAST(M_IntDue as decimal(29,4)),
			CAST(M_PriColl as decimal(29,4)),
			CAST(M_IntColl as decimal(29,4)),
			HouseHoldIncomeAmount,
			ActualEWI,
			SpouseName,
			CenterMeetingTime,
			INterestaccured,
			CumPriDue_PM,
			CumINtDue_PM,
			Cum_PrINcipalColl_PM,
			Cum_INterestColl_PM,
			NoofInstallmentCompleted,
			Monthend_POS,
			Monthend_Ageing,
			Month_End_Status,
			Client_type,
			ClientNPAstatus,
			LoanType,
			Remarks_writeoff1 Remarks_writeoff,
			Freezed_OP,
			LoanClosedDate
		FROM		
		(WITH DAILY_COD 
		AS
		(
		SELECT p.HierarchyId AS HierarchyId,MAX(p.CODDATE) AS Max_CODDATE
		FROM (SELECT * FROM {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) p                               
		join {mart_catalog}.{mart_schema}.`p_hierarchy_sop` t on t.hierarchyid=p.hierarchyid                                                             
		GROUP BY p.HierarchyId 
		),                                                       
		NPA_CLOSED_LOANS 
		AS 
		(
		SELECT NPA2.*, CLSD.MaxCODDate AS MaxCODDate FROM 
		(SELECT `pragati-ClientLoanSubscription`.ClientLoanid , MAX(NPA.CODDATE) AS MaxCODDate,MIN(NPA.LastUnpaidDate) as LastUnpaidDate
		FROM  (SELECT * FROM {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-ClientLoanSubscription` JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) NPA ON `pragati-ClientLoanSubscription`.ClientLoanID = NPA.ClientLoanID               
		and `pragati-ClientLoanSubscription`.hierarchyid = NPA.hierarchyid                                                  
		where `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL                                                
		GROUP BY `pragati-ClientLoanSubscription`.ClientLoanid) CLSD  
		JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) NPA2         
		ON CLSD.ClientLoanID = NPA2.ClientLoanID AND CLSD.MaxCODDate = NPA2.CODDate                                                
		where NPA2.LoanClosedDate IS not NULL    
		),   
		LAST_CM_DATES
		AS
		(
		Select CenterId,Max(CenterMeetingDate) Last_CMDate1,                                            
		Max(ConductedMeetingDate) Last_CMDate                                           
		from {source_catalog}.{source_schema}.`pragati-CenterMeetingConductedDates`
		WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL              
		Group by CenterId 
		),  
		TOTAL_INTEREST_DUE
		AS
		(
		SELECT HierarchyId,ClientLoanId,                                                      
		SUM(InterestAmount)   AS Total_InterestDue                                             
		FROM {source_catalog}.{source_schema}.`pragati-AT_Loanschedules`   
		WHERE TransactionType = 'C'
		-- AND DebitORCredit = 'D'
		AND (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)                                                      
		GROUP BY  HierarchyId  ,ClientLoanId   
		),
		DAILY_DPD_DATE
		AS
		--- need to be reviewed
		(
		select `pragati-ClientLoanSubscription`.clientid,`pragati-ClientLoanSubscription`.HierarchyId,  Min(NPA.LastUnpaidDate) as NPA_LastUnpaidDate, Min(NPA_CL.LastUnpaidDate) as NPA_CL_LastUnpaidDate
		FROM (SELECT * FROM {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-ClientLoanSubscription`
		LEFT JOIN DAILY_COD A ON `pragati-ClientLoanSubscription`.HierarchyId = A.HierarchyId  
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) NPA ON `pragati-ClientLoanSubscription`.ClientLoanID = NPA.ClientLoanID AND A.Max_CODDATE = NPA.CODDate
		LEFT JOIN NPA_CLOSED_LOANS NPA_CL ON NPA_CL.ClientLoanID = `pragati-ClientLoanSubscription`.ClientLoanID AND NPA_CL.MaxCODDate = A.Max_CODDATE
		group by `pragati-ClientLoanSubscription`.ClientId,`pragati-ClientLoanSubscription`.HierarchyId
		),
		D2K_NPA1 as (
		select sum(PrincipleOutstanding) as PrincipleOutstanding, sum(IntOverdue) as IntOverdue, sum(TotalProvision) as TotalProvision, customerid, NPA_Date,AssetClassName 
		from (
		select distinct  max(CreatedDateTime) as CreatedDateTime,
		NCIF_Id,customerid, AssetClassName, NCIF_NPA_Date as NPA_Date,
		cast( PrincipleOutstanding as  decimal (18,2) ) as PrincipleOutstanding,
		cast( IntOverdue  as decimal(18,2))as IntOverdue, cast(TotalProvision as decimal(18,2)) as TotalProvision
		from {source_catalog}.{source_schema}.`ptsmartnpa-d2k_npadetailsfrommanagedfiles`
		where lower(sourcename)='pt smart' and  NCIF_NPA_Date is not null
		and AssetClassName is not  Null AND (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)
		group by NCIF_Id,customerid, AssetClassName, NCIF_NPA_Date ,PrincipleOutstanding,IntOverdue,TotalProvision
		)
		group by customerid,AssetClassName,NPA_Date
		),
		D2K_NPA as (
			select  customerid, NPA_Date,AssetClassName AssetCl_Br,PrincipleOutstanding,IntOverdue from D2K_NPA1
			Union all
			Select	ClientId,NPADate,AssetCl_Br,POS	,0 from {source_catalog}.{source_schema}.`azuresource-p_agri_nonagri_npachange_list01`
		)
  		SELECT DISTINCT  DAILY_COD.Max_CODDATE as CODDATE
				,`p_hierarchy_sop`.Branch_Type
				,`p_hierarchy_sop`.State
				,`p_hierarchy_sop`.Region 
				,`p_hierarchy_sop`.District
				,`p_hierarchy_sop`.Zone
				,`p_hierarchy_sop`.Area
				,`p_hierarchy_sop`.BranchName 
				,`p_hierarchy_sop`.BranchID
				,`p_hierarchy_sop`.HierarchyId
				,`pragati-ClientLoanSubscription`.ClientLoanId
				,`pragati-ClientLoanSubscription`.ClientLoanCode
				,`pragati-ClientLoanSubscription`.LoanProposalId
				,`pragati-clientloanproposal_h_view`.LoanProposalCode                                                        
				,`pragati-ClientMASter`.ClientId
				,`pragati-ClientMASter`.ClientCode
				,`pragati-centermaster`.CenterCode 
				,`pragati-centermaster`.CenterId
				,`pragati-centermaster`.centername 
				,`pragati-Groupmaster`.Groupid
				,`pragati-TargetMASter`.TargetId
				,`pragati-TargetMASter`.TargetCode
				,`pragati-ClientMASter`.ClientName
				,`pragati-ClientMASter`.SpouseName
				,`pragati-ProductMASter`.ProductName
				,`pragati-ProductMASter`.ProductCode
				,`pragati-ProductMASter`.ProductDescription
				-- ,PD.Product_Type
				--,PD.ProductCategory
				,`pragati-ClientLoanSubscription`.ClientProductSequenceNo
				,`pragati-centermaster`.CenterMeetingDay
				,`pragati-centermaster`.StaffId AS CenterStaffID
				,`pragati-centermaster`.CenterMeetingTime
				,`pragati-ClientLoanSubscription`.DisbursementDate
				,`pragati-ClientLoanSubscription`.LoanAmountDisbursed
				,(CASE WHEN loanwiserescheduledetails.ExpectedClosedDate is NULL THEN `pragati-ClientLoanSubscription`.ExpectedPaidUPDATE ELSE loanwiserescheduledetails.ExpectedClosedDate END) AS ExpectedPaidUPDATE
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate <=DAILY_COD.Max_CODDATE THEN  `pragati-ClientLoanSubscription`.LoanClosedDate ELSE NULL END) AS LoanClosedDate1
				,`pragati-clientloanproposal_h_view`.PurposeId
				,`pragati-LoanPurposes`.PurposeName
				,`pragati-clientloanproposal_h_view`.HoUSEHoldINcome
				,`pragati-ClientLoanSubscription`.INterestRate
				,(CASE WHEN (`pragati-ClientLoanSubscription`.LoanClosedDate IS NULL OR `pragati-ClientLoanSubscription`.LoanClosedDate > DAILY_COD.Max_CODDATE) THEN 0 
				ELSE  COALESCE(`pragati-ClientLoanSubscription`.differenceAmountinPreclosing,0) END ) AS DifferenceAmountInPreclosing
				,`pragati-ClientLoanSubscription`.Tenure
				,(CASE WHEN `pragati-fundmaster`.FundName is NULL THEN 'IndusInd(06:01)' ELSE `pragati-fundmaster`.FundName END) AS FundName
				,`pragati-clientloanproposal_h_view`.FundId 
				,`pragati-TargetMASter`.Caste
				,`pragati-CodeValue`.Value AS Religion
				,`pragati-CodeValue`.Value AS Rural_Urban
				,`pragati-ClientLoanSubscription`.IsDeviationCancelled AS DeviationCancel
				,`pragati-ClientLoanSubscription`.LoanCancelleddate 
				,`pragati-ClientLoanSubscription`.DisbursementMode
				,`pragati-ClientLoanSubscription`.RepaymentFrequency
				,`pragati-ClientMASter`.Gender
				,`pragati-ClientMASter`.DateOfBirth
				,`pragati-ClientMASter`.JoinDate
				,`pragati-clientloanproposal_h_view`.ProposalDate
				,`pragati-clientloanproposal_h_view`.ApprovedDate
				,`pragati-clientloanproposal_h_view`.LoanAmountApproved
				,`pragati-TargetMASter`.TargetDate
				,`pragati-ClientLoanSubscription`.IsLoanClosed
				,`pragati-clientloanproposal_h_view`.HouseHoldIncomeAmount
				,(CASE WHEN `pragati-ProductMASter`.ProductCode = '854' THEN `pragati-ClientLoanSubscription`.MIInterestAmount 
				WHEN `pragati-rescheduleloans`.UpfrontInterest IS NOT NULL and (`pragati-rescheduleloans`.NPAStatus=0 OR `pragati-rescheduleloans`.ResRemarks IS  not NULL) THEN `pragati-rescheduleloans`.UpfrontInterest 
				ELSE 0 END) AS UpfrontInterest_vp                                                          
				,`pragati-rescheduleloans`.NPAStatus                                                     
				,(CASE WHEN `pragati-ClientLoanSubscription`.DisbursementDate  >=  '2020-11-01' then 'N' 
	 			WHEN `pragati-rescheduleloans`.UpfrontInterest IS NOT NULL AND (NPAStatus=0 OR ResRemarks IS  not NULL) THEN 'Y'
	 			WHEN `pragati-ProductMASter`.ProductCode = '854' and `pragati-rescheduleloans`.UpfrontInterest <> 0 THEN 'Y' END) as Moratorium_flag
				,`pragati-clientdeathintimation_h_view`.DeathDate      
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN `pragati-BranchDailyNPALoanStatus`.PrincipalAmount WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN NPA_CLOSED_LOANS.PrincipalAmount END) AS Cum_PrincipalColl1                                                          
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN `pragati-BranchDailyNPALoanStatus`.InterestAmount WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN NPA_CLOSED_LOANS.InterestAmount END) AS Cum_InterestColl1                                                          
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN `pragati-BranchDailyNPALoanStatus`.DuePrincipalAmount WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN NPA_CLOSED_LOANS.DuePrincipalAmount END) AS Cum_Pridue                                       
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN `pragati-BranchDailyNPALoanStatus`.DueInterestAmount WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN NPA_CLOSED_LOANS.DueInterestAmount END) AS Cum_IntDue                                                     
					,(CASE WHEN `pragati-ClientLoanWriteOff`.TransactionDate <= DAILY_COD.Max_CODDATE THEN coalesce(`pragati-ClientLoanWriteOff`.WriteOffAmount,0) ELSE 0 END) AS PrincipalWrittenoff                                                          
				,(CASE WHEN `pragati-ClientLoanWriteOff`.TransactionDate <= DAILY_COD.Max_CODDATE THEN coalesce(`pragati-ClientLoanWriteOff`.WriteOffIntreast,0) ELSE 0 END) AS InterestWrittenoff                                                     
				,(CASE WHEN `pragati-ClientLoanWriteOff`.TransactionDate <= DAILY_COD.Max_CODDATE THEN `pragati-ClientLoanWriteOff`.TransactionDate END) AS TransactionDate 
				,(coalesce(`pragati-ClientLoanSubscription`.LoanAmountDisbursed,0)+coalesce(UpfrontInterest_vp,0)) AS Total_PrincipalDue                                                          
				,TOTAL_INTEREST_DUE.Total_InterestDue                                                          
				,(CASE 
					WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL and Moratorium_flag ='Y' and coalesce(`pragati-BranchDailyNPALoanStatus`.UpfrontInterestvp,0)=0 THEN (`pragati-BranchDailyNPALoanStatus`.POS + coalesce(`pragati-rescheduleloans`.UpfrontInterest,0))
    				WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.POS,0) 
        			WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.POS,0)
				END) AS POS
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN (coalesce(Total_InterestDue,0)-coalesce(Cum_InterestColl1,0)-coalesce(InterestWrittenoff,0)) END) AS IOS 		
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.PrINcipalINArears,0) WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.PrINcipalINArears,0) END) AS PrincipalInArears                                                           
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.INterestINArears,0) WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.INterestINArears,0) END) AS InterestInArears                                                           
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.IntAccuredTotal,0) WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.IntAccuredTotal,0) END) AS INterestaccured                                                 
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN `pragati-BranchDailyNPALoanStatus`.LastRepaymentDate WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN NPA_CLOSED_LOANS.LastRepaymentDate END) AS LastRepaymentDate                                             
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.MFLAG,0) WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.MFLAG,0) END) AS M_Flag                                                           
				,(CASE WHEN LAST_CM_DATES.last_CMDate is null and `pragati-centermaster`.FormationDate>=cast(current_date()-10 as Date) THEN `pragati-centermaster`.FormationDate WHEN LAST_CM_DATES.last_CMDate is NOT null THEN LAST_CM_DATES.last_CMDate END) AS Last_CMDate  
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN `pragati-BranchDailyNPALoanStatus`.LastUnpaidDate WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN NPA_CLOSED_LOANS.LastUnpaidDate END) AS DPDStartdate                                                           
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.NoofdaysINarrears,0) WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.NoofdaysINarrears,0) END) AS NoOfDaysInArrears1                                                                                ,(CASE WHEN `azuresource-p_clstagging`.SPT_ID is not null and `azuresource-p_clstagging`.Type_New NOT IN ('On_BalanceSheet') THEN `azuresource-p_clstagging`.Type_New  
      ELSE 'Advances' END) as Type_New1,
    			(CASE WHEN Type_New1 IN ('Advances') AND `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN 'Y' ELSE NULL END) AS freezed1 
				--ok till here 
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate is not null THEN ((`pragati-ClientLoanSubscription`.LoanAmountDisbursed+coalesce(UpfrontInterest_vp,0))-coalesce(Cum_PrINcipalColl1,0)-coalesce(`pragati-ClientLoanSubscription`.dIFferenceAmountINPreclosINg,0)-coalesce(PrINcipalWrittenoff,0)) END) AS ClosedloanwithPos   
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.LOANSTATUS,0) WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.LOANSTATUS,0) END) AS Loan_Status                                                           
				,(CASE WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NULL THEN coalesce(`pragati-BranchDailyNPALoanStatus`.Ageing,0) WHEN `pragati-ClientLoanSubscription`.LoanClosedDate IS NOT NULL THEN coalesce(NPA_CLOSED_LOANS.Ageing,0) END) AS Ageing_Loan,(CASE WHEN `pragati-ClientLoanSubscription`.InterestRate <> 0 THEN round (`pragati-ClientLoanSubscription`.LoanAmountDisbursed / ((1-POWER(1/(1+ (((`pragati-ClientLoanSubscription`.InterestRate /cast( 100 as decimal(10,4)) / 365) * 7))), `pragati-ClientLoanSubscription`.Tenure))/(((`pragati-ClientLoanSubscription`.InterestRate / cast( 100 as decimal(10,4)) / 365) * 7))),0) END) AS EWI
				,EWI as ActualEWI                                                           
				,CASE WHEN `pragati-ProductMASter`.ProductCode='800' THEN ''
				WHEN coalesce(`pragati-surakshapreapprovedproposal`.SLPlus,false) = true AND `pragati-surakshapreapprovedproposal`.SLCancelDate IS NULL AND upper(`pragati-ClientLoanSubscription`.DisbursementMode) = 'DM1' and `pragati-ProductMASter`.ProductCode='800' THEN 'SurakshaPls'
				WHEN `pragati-surakshapreapprovedproposal`.createdby in ('Unnati','UnnatiT')  and `pragati-ProductMASter`.ProductCode='800' THEN 'Unnati'
				WHEN `pragati-surakshapreapprovedproposal`.createdby in ('UnnatiPls')  and `pragati-ProductMASter`.ProductCode='800' THEN 'UnnatiPls'
				WHEN `pragati-ProductMASter`.ProductCode='800' and `pragati-surakshapreapprovedproposal`.createdby not in ('Unnati','UnnatiPls','UnnatiT') and NOT (coalesce(`pragati-surakshapreapprovedproposal`.SLPlus,false) = true AND `pragati-surakshapreapprovedproposal`.SLCancelDate IS NULL AND `pragati-ClientLoanSubscription`.DisbursementMode = 'DM1') THEN 'Suraksha'
				WHEN `pragati-ProductMASter`.ProductCode='800' and (coalesce(`pragati-surakshapreapprovedproposal`.SLPlus,false) = true AND `pragati-surakshapreapprovedproposal`.SLCancelDate IS NULL AND `pragati-ClientLoanSubscription`.DisbursementMode = 'DM1') and   `pragati-ClientLoanSubscription`.DisbursementDate >'2021-03-31' THEN 'Unnati'
				WHEN `pragati-ProductMASter`.ProductCode = '851' THEN 'Sahayata Plus'
				WHEN `p_hierarchy_sop`.BranchID = '46:44' THEN 'RDSP_Borrower'
				WHEN `p_hierarchy_sop`.BranchID = '46:45'  THEN 'RDSP_NonBorrower'
				END as ProductCategory
				,CASE WHEN `p_hierarchy_sop`.BranchID = '46:44' THEN 'RDSP_Borrower'
				WHEN `p_hierarchy_sop`.BranchID = '46:45'  THEN 'RDSP_NonBorrower' END as Product_type 
				,(CASE WHEN p_loanfacts.clientloanid is not NULL then p_loanfacts.CumPriDue END) AS CumPriDue_PM
				,(CASE WHEN p_loanfacts.clientloanid is not NULL then p_loanfacts.CumINtDue END) AS CumINtDue_PM
				,(CASE WHEN p_loanfacts.clientloanid is not NULL then p_loanfacts.Cum_PrincipalColl END) AS Cum_PrINcipalColl_PM
				,(CASE WHEN p_loanfacts.clientloanid is not NULL then p_loanfacts.Cum_InterestColl END) AS Cum_INterestColl_PM
				,(CASE WHEN `pragati-ClientLoanSubscription`.DisbursementDate <  Cast(date_add(last_day(add_months(current_date(), -1)), 1) as Date) THEN (CASE WHEN (Cum_Pridue - CumPriDue_PM) < 0 THEN 0 ELSE (Cum_Pridue - CumPriDue_PM) END) ELSE (CASE WHEN Cum_Pridue<0 THEN 0 ELSE Cum_Pridue END)END) AS M_PriDue          
				,(CASE WHEN `pragati-ClientLoanSubscription`.DisbursementDate <  Cast(date_add(last_day(add_months(current_date(), -1)), 1) as Date) THEN (CASE WHEN (Cum_IntDue - CumINtDue_PM) < 0 THEN 0 ELSE (Cum_IntDue - CumINtDue_PM) END) ELSE (CASE WHEN Cum_IntDue<0 THEN 0 ELSE Cum_IntDue END) END) AS M_IntDue
				,(CASE WHEN `pragati-ClientLoanSubscription`.DisbursementDate <  Cast(date_add(last_day(add_months(current_date(), -1)), 1) as Date) THEN (CASE WHEN (Cum_PrINcipalColl1- Cum_PrINcipalColl_PM) < 0 THEN 0 ELSE (Cum_PrINcipalColl1- Cum_PrINcipalColl_PM) END) ELSE (CASE WHEN Cum_PrINcipalColl1<0 THEN 0 ELSE Cum_PrINcipalColl1 END) END) AS M_PriColl
				,(CASE WHEN `pragati-ClientLoanSubscription`.DisbursementDate <  Cast(date_add(last_day(add_months(current_date(), -1)), 1) as Date) THEN (CASE WHEN (Cum_INterestColl1- Cum_INterestColl_PM) < 0 THEN 0 ELSE (Cum_INterestColl1- Cum_INterestColl_PM) END) ELSE (CASE WHEN Cum_INterestColl1<0 THEN 0 ELSE Cum_INterestColl1 END) END) AS M_IntColl
				,coalesce(Round( Nullif(COALESCE(Cum_PrincipalColl1,0)+COALESCE(Cum_InterestColl1 ,0),0)/nullif(COALESCE(EWI,0) ,0) ,0),0) AS NoofInstallmentCompleted                                                           
				,RD_AdjustAmt---delete                                
				,(CASE WHEN p_loanfacts.clientloanid is not NULL then p_loanfacts.POS END) AS Monthend_POS
				,(CASE WHEN p_loanfacts.clientloanid is not NULL then p_loanfacts.Client_Ageing END) AS Monthend_Ageing
				,(CASE WHEN p_loanfacts.clientloanid is not NULL then p_loanfacts.Monthend_Status END) AS Month_End_Status                            
				,(CASE WHEN upper(`azuresource-p_clstagging`.Type_New) in ('ARC_DEC21','ARC_FEB23','ARC_MAR23') and `pragati-ClientLoanSubscription`.loancloseddate is null THEN `azuresource-p_clstagging`.Type_New WHEN freezed1='y' and upper(`azuresource-p_clstagging`.Type_New) not in ('ARC_DEC21','ARC_FEB23','ARC_MAR23') THEN 'Regular' END) AS Client_type,(
				CASE WHEN upper(`azuresource-p_clstagging`.Type_new) in ('ARC_DEC21','ARC_DEC21','ARC_FEB23','ARC_FEB23','ARC_MAR23') and `pragati-ClientLoanSubscription`.loancloseddate is null THEN `azuresource-p_clstagging`.Type_New END
				) AS ClientNPAstatus
				,(CASE WHEN `pragati-ClientLoanSubscription`.tenure>50 THEN 'TL' WHEN `pragati-ClientLoanSubscription`.Tenure<52 THEN 'DL' END) AS LoanType                                                                   
				,(CASE WHEN  (lower(`azuresource-p_clstagging`.Type_New) like '%writeoff_%') or (lower(`azuresource-p_clstagging`.Type_New) like '%closed deals mar22%') THEN 'Y' END) AS Remarks_writeoff1
                ,(CASE WHEN (upper(freezed1) = 'Y' or
				lower(`azuresource-p_clstagging`.Type_New) in ('arc_dec21','arc_feb23','arc_mar23') or upper(Remarks_writeoff1)='Y') and `pragati-ClientLoanSubscription`.loancloseddate is null THEN 'Y' END) AS Freezed_OP
				,`pragati-ClientLoanSubscription`.LoanClosedDate
		FROM  (SELECT * FROM {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` WHERE ETL_IS_ACTIVE = '1') `pragati-ClientLoanSubscription`
		LEFT JOIN (select * from {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` where etl_is_active = '1') `pragati-clientloanproposal_h_view`  ON `pragati-ClientLoanSubscription`.LoanProposalId = `pragati-clientloanproposal_h_view`.LoanProposalId
		LEFT JOIN DAILY_COD ON DAILY_COD.HierarchyId = `pragati-ClientLoanSubscription`.HierarchyId                                                                                               LEFT JOIN  {mart_catalog}.{mart_schema}.`p_hierarchy_sop` ON DAILY_COD.HierarchyId = `p_hierarchy_sop`.HierarchyId                                                           
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-DerivedProductMASter` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragatimain-DerivedProductMASter` ON `pragatimain-DerivedProductMASter`.DerivedProductId = `pragati-ClientLoanSubscription`.ProductId                                                         
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-ProductMASter` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-ProductMASter` ON `pragati-ProductMASter`.ProductId = `pragatimain-DerivedProductMASter`.ProductId
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-surakshapreapprovedproposal` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-surakshapreapprovedproposal` ON `pragati-surakshapreapprovedproposal`.LoanProposalId = `pragati-ClientLoanSubscription`.LoanProposalId                                                         
		LEFT JOIN (select * from {source_catalog}.{source_schema}.`pragati-ClientMASter` where etl_is_active = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-ClientMASter` ON `pragati-ClientLoanSubscription`.ClientId = `pragati-ClientMASter`.ClientId  
		LEFT JOIN D2K_NPA ON D2K_NPA.CustomerId = `pragati-ClientLoanSubscription`.clientid                                                       
		LEFT JOIN (select * from {source_catalog}.{source_schema}.`pragati-TargetMASter` where etl_is_active = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-TargetMASter` ON `pragati-ClientMASter`.TargetId = `pragati-TargetMASter`.TargetId 
		--need to be separated to getb distinct code values                                                        
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-CodeValue` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-CodeValue` ON `pragati-TargetMASter`.Religion = `pragati-CodeValue`.Code                                                         
		LEFT JOIN (select * from {source_catalog}.{source_schema}.`pragati-Groupmaster` where etl_is_active = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-Groupmaster` on `pragati-Groupmaster`.groupid = `pragati-ClientMASter`.groupid                                                        
		LEFT JOIN (select * from {source_catalog}.{source_schema}.`pragati-centermaster` where etl_is_active = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-centermaster` on `pragati-centermaster`.centerid = `pragati-Groupmaster`.centerid                                                        
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-fundmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-fundmaster` ON `pragati-clientloanproposal_h_view`.FundId = `pragati-fundmaster`.FundId                                                        
		LEFT OUTER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-LoanPurposes` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-LoanPurposes`  ON `pragati-clientloanproposal_h_view`.PurposeId = `pragati-LoanPurposes`.PurposeId                                                        
		left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-dim_productmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `azuresource-dim_productmaster` ON `pragati-ProductMASter`.ProductCode = `azuresource-dim_productmaster`.PRODUCT_ID
		and `azuresource-dim_productmaster`.SBU='MFI'
		LEFT JOIN {source_catalog}.{source_schema}.`azuresource-loanwiserescheduledetails` loanwiserescheduledetails ON `pragati-ClientLoanSubscription`.ClientLoanID = loanwiserescheduledetails.ClientLoanid    
		LEFT JOIN (select * from {source_catalog}.{source_schema}.`pragati-rescheduleloans` where (NPAStatus=0 OR ResRemarks IS  not NULL) AND (ETL_IS_ACTIVE = '1')) `pragati-rescheduleloans` ON `pragati-ClientLoanSubscription`.ClientLoanId = `pragati-rescheduleloans`.Clientloanid    
		LEFT JOIN (select * from (select *, row_number() over (partition by ClientId order by DeathDate desc) as rank  from {source_catalog}.{source_schema}.`pragati-clientdeathintimation_h_view` where etl_is_active = '1') A where A.rank = 1) `pragati-clientdeathintimation_h_view` ON `pragati-ClientLoanSubscription`.ClientId = `pragati-clientdeathintimation_h_view`.ClientId AND `pragati-clientdeathintimation_h_view`.DeathDate >= `pragati-ClientLoanSubscription`.DisbursementDate AND `pragati-clientdeathintimation_h_view`.DeathDate <= CAST(GETDATE() as date) AND (`pragati-ClientLoanSubscription`.LoanClosedDate IS NULL OR `pragati-ClientLoanSubscription`.LoanClosedDate > `pragati-clientdeathintimation_h_view`.DeathDate)
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-BranchDailyNPALoanStatus` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-BranchDailyNPALoanStatus` ON `pragati-ClientLoanSubscription`.ClientLoanID = `pragati-BranchDailyNPALoanStatus`.ClientLoanID AND DAILY_COD.Max_CODDATE = `pragati-BranchDailyNPALoanStatus`.CODDate
		LEFT JOIN NPA_CLOSED_LOANS ON NPA_CLOSED_LOANS.ClientLoanID = `pragati-ClientLoanSubscription`.ClientLoanID AND NPA_CLOSED_LOANS.MaxCODDate = DAILY_COD.Max_CODDATE 
		--- check this join
		LEFT JOIN LAST_CM_DATES on LAST_CM_DATES.CenterId = `pragati-centermaster`.CenterId          
		LEFT JOIN TOTAL_INTEREST_DUE on TOTAL_INTEREST_DUE.HierarchyId = `p_hierarchy_sop`.HierarchyId  AND  TOTAL_INTEREST_DUE.ClientLoanId = `pragati-ClientLoanSubscription`.ClientLoanId 
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-ClientLoanWriteOff` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `pragati-ClientLoanWriteOff` ON `pragati-ClientLoanSubscription`.ClientLoanId = `pragati-ClientLoanWriteOff`.ClientLoanId   
		LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-p_clstagging` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) `azuresource-p_clstagging` ON `pragati-ClientLoanSubscription`.ClientLoanId = `azuresource-p_clstagging`.SPT_ID
		LEFT JOIN {source_catalog}.{source_schema}.`azuresource-p_loanfacts` p_loanfacts ON `pragati-ClientLoanSubscription`.clientloanid=p_loanfacts.clientloanid
		LEFT JOIN DAILY_DPD_DATE ON DAILY_DPD_DATE.clientid = `pragati-ClientLoanSubscription`.Clientid                                      
		WHERE  (`pragati-ClientLoanSubscription`.LoanClosedDate IS NULL OR `pragati-ClientLoanSubscription`.LoanClosedDate = '1900-01-01' or `pragati-ClientLoanSubscription`.LoanClosedDate >= date_add(last_day(add_months(current_date(), -1)), 1))
		AND (`pragati-ClientLoanSubscription`.DisbursementDate <=DAILY_COD.Max_CODDATE)
		AND `pragati-ClientLoanSubscription`.ProductType IS NULL)""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"dailyloanfacts_step1 Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on dailyloanfacts_step1: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on dailyloanfacts_step1 : ", str(e))

# COMMAND ----------

try :
    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.dailyloanfacts_step1")
    

    logger(
            logger_level_info,
            f"dailyloanfacts_step1 writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table dailyloanfacts_step1 : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table dailyloanfacts_step1 : ", str(e))
