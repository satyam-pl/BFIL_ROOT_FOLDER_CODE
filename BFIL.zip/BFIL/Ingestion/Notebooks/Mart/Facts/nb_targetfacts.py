# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_targetfacts.dbc"

# COMMAND ----------

try:
    from pyspark.sql.functions import current_date, date_sub
    from datetime import datetime, timedelta

    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/FACTS/TARGETFACTS"
    desti_path = "BFIL-MART/FACTS/TARGETFACTS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH MFI_TargetMaster AS (
SELECT  A.HierarchyID, 
        A.TargetID, 
        A.TargetCode, 
        Cast(A.TargetDate As Date) As TargetDate, 
        A.IsBCMApproved, 
        A.ApprovalStatus, 
        A.Caste, 
        A.NumberOfFamilyMembers, 
        A.MemberEducationId, 
        A.MemberOccupationId, 
        A.HOUSECONSTRUCTIONQUALITY, 
        A.MotherMaidenName, 
        A.Religion, 
        A.HouseType, 
        A.MemberPhotoPath, 
        A.MaritalStatus, 
        A.ExternalFinalStatus,
        A.ExternalApprovalRemarks,
        GRT.GRTID,  
        GRT.Result As GRT_Result,  
        Cast(GRT.GRTDate As Date) As GRTDate,
        GM.CenterID,
        GM.GroupID,  
        CM.ClientID,  
        Cast(CM.JoinDate As Date) As JoinDate,  
        Cast(CM.DropOutDate As Date) As DropOutDate,  
        CM.ReplacementStatus As ClientReplacementStatus,  
        (CASE WHEN CAST(CM.JoinDate As Date) BETWEEN A.TargetDate AND DATEADD(A.TargetDate,45) THEN 'Yes'
        WHEN CAST(CM.JoinDate As Date) Not BETWEEN A.TargetDate AND DATEADD(A.TargetDate,45) THEN 'No'  
        WHEN CM.JoinDate Is Null THEN Null End) As Client_Joined_45Days,
        A.CBUpdateID,
        C.CBStatus
FROM {source_catalog}.{source_schema}.`pragati-targetmaster` As A
LEFT JOIN {source_catalog}.{source_schema}.`pragati-clientmaster` As CM On CM.TargetID = A.TargetID AND CM.ETL_IS_ACTIVE = 1
LEFT JOIN {source_catalog}.{source_schema}.`pragati-GroupMaster` As GM On GM.GroupID = CM.GroupID AND GM.ETL_IS_ACTIVE = 1
LEFT JOIN {source_catalog}.{source_schema}.`pragati-GRTMaster` As GRT On GRT.GRTID = GM.GRTID AND GRT.ETL_IS_ACTIVE = 1
LEFT JOIN ( SELECT  TargetID,
		            Max(CreatedDateTime) As MaxCBDate
            FROM {source_catalog}.{source_schema}.`pragati-creditbureauupdate` 
            WHERE LoanProposalID Is Null AND ETL_IS_ACTIVE = 1
            Group By TargetID) As B On B.TargetID = A.TargetID
LEFT JOIN {source_catalog}.{source_schema}.`pragati-creditbureauupdate` As C On C.TargetID = B.TargetID AND C.CreatedDateTime = B.MaxCBDate AND C.LoanProposalID Is Null AND C.ETL_IS_ACTIVE = 1
WHERE A.ETL_IS_ACTIVE = '1' 
AND (CAST(A.TargetDate AS DATE) BETWEEN '2023-05-01' AND date_sub(current_date(), 1))),

/* Targets GRT Empty */
MFI_TragetGRTEmpty As(
SELECT  A.HierarchyID, 
        A.TargetID, 
        A.TargetCode, 
        A.TargetDate, 
        A.IsBCMApproved, 
        A.ApprovalStatus, 
        A.Caste, 
        A.NumberOfFamilyMembers, 
        A.MemberEducationId, 
        A.MemberOccupationId, 
        A.HOUSECONSTRUCTIONQUALITY, 
        A.MotherMaidenName, 
        A.Religion, 
        A.HouseType, 
        A.MemberPhotoPath, 
        A.MaritalStatus, 
        A.ExternalFinalStatus,
        A.ExternalApprovalRemarks,
        GRT.GRTID,  
        GRT.Result As GRT_Result,  
        Cast(GRT.GRTDate As Date) As GRTDate,
        GM.CenterID,
        GM.GroupID,  
        CM.ClientID,  
        CM.JoinDate,  
        CM.DropOutDate,  
        CM.ReplacementStatus As ClientReplacementStatus,  
        (CASE WHEN CAST(CM.JoinDate As Date) BETWEEN A.TargetDate AND DATEADD(A.TargetDate,45) THEN 'Yes'
        WHEN CAST(CM.JoinDate As Date) Not BETWEEN A.TargetDate AND DATEADD(A.TargetDate,45) THEN 'No'  
        WHEN CM.JoinDate Is Null THEN Null End) As Client_Joined_45Days,
        A.CBUpdateID,
        A.CBStatus
FROM MFI_TargetMaster As A
JOIN {source_catalog}.{source_schema}.`pragati-GRTDetails` As GRTD On GRTD.TargetID = A.TargetID AND GRTD.ETL_IS_ACTIVE = 1
LEFT JOIN {source_catalog}.{source_schema}.`pragati-GRTMaster` As GRT On GRT.GRTID = GRTD.GRTID AND GRT.ETL_IS_ACTIVE = 1
LEFT JOIN {source_catalog}.{source_schema}.`pragati-GroupMaster` As GM On GM.GRTID = GRT.GRTID AND GM.ETL_IS_ACTIVE = 1
LEFT JOIN {source_catalog}.{source_schema}.`pragati-clientmaster` As CM On CM.GroupID = GM.GroupID AND CM.TargetID = A.TargetID AND CM.ETL_IS_ACTIVE = 1
Where A.GRT_Result Is Null),

/* Merging All the above */
MFI_TargetsMasterBase As(
Select * From MFI_TargetMaster
Where TargetID Not In (Select TargetID From MFI_TragetGRTEmpty Where GRT_Result Is Not Null)
Union
Select * From MFI_TragetGRTEmpty
Where GRT_Result Is Not Null ),

/* Targets Base - KYC Details */
MFI_TargetKYCMaster As(
SELECT  A.TargetID,
        B.ClientOrSpouse,
        IFF(Upper(B.ClientOrSpouse) = 'M' AND B.IseKYCStatus = 1 AND Upper(B.KYCType)='IDP6',1,0) As IsEKYCStatus,        

        /* BCM Status */
        (CASE WHEN Upper(B.ClientOrSpouse) = 'M' AND B.IseKYCStatus = 1 AND Upper(B.KYCType)='IDP6' THEN 'A'
              WHEN Upper(B.ClientOrSpouse) = 'M' AND B.IseKYCStatus = 0 AND Upper(B.KYCType)='IDP6' AND B.BCMStatus = 'A' THEN 'D'
              WHEN Upper(B.ClientOrSpouse) = 'M' AND Upper(B.KYCType) <> 'IDP6' AND B.BCMStatus = 'A' THEN 'A'
              WHEN Upper(B.ClientOrSpouse) = 'M' AND Upper(B.KYCType) <> 'IDP6' AND B.BCMStatus = 'N' THEN 'N' End) As BCM_Status,

        /* Is Ported to BCM Portal */
        (CASE WHEN IFNULL(A.ApprovalStatus,'')<>'R' AND IFNULL(B.BCMStatus,'N')='N'
        AND (B.IseKYCStatus=0) AND A.CBStatus='A' 
        AND IFNULL(A.Caste, '') != '' AND 
        IFNULL(A.NumberOfFamilyMembers, 0) != '0' 
        AND IFNULL(A.MemberEducationId, '') != ''
        AND IFNULL(A.MemberOccupationId, '') != '' AND IFNULL(A.HOUSECONSTRUCTIONQUALITY, '') != ''
        AND IFNULL(A.MotherMaidenName, '') != '' AND IFNULL(A.Religion, '') != '' 
        AND IFNULL(A.HouseType, '') != '' AND IFNULL(A.MemberPhotoPath, '') != ''
        AND IFNULL(A.MaritalStatus,'') !='' AND IFNULL(A.ApprovalStatus,'') != 'R' THEN 1 ELSE 0 End) As IsBCMImport

FROM MFI_TargetsMasterBase As A
JOIN {source_catalog}.{source_schema}.`pragati-kycmaster` As B On B.TargetID = A.TargetID AND B.ETL_IS_ACTIVE = '1'),
 
/* Summary For checking Approved BCM Status (Every KYC should be approved Inc.EKYC) */  
MFI_TargetKYCBCMStatus As (
SELECT 	TargetID,  
        Sum(Case When ClientOrSpouse ='M' Then IsEKYCStatus Else 0 End) As IsEKYCStatus,
		SUM(Case When ClientOrSpouse ='M' Then 1 Else 0 End) As NoOfTargets,  
		SUM((CASE WHEN BCM_Status = 'A' and ClientOrSpouse ='M' THEN 1 ELSE 0 END)) As NoOfBCMApproved,
        Sum(IsBCMImport) As NoOfBCMImports
From MFI_TargetKYCMaster
Group By TargetID),

/* Target Against Loans */
MFI_TargetLoans As (
SELECT A.TargetID,Min(B.DisbursementDate) As MinDisbDate
FROM MFI_TargetsMasterBase As A
Join {source_catalog}.{source_schema}.`pragati-clientloansubscription` As B On B.ClientID = A.ClientID
WHERE B.ProductType Is Null AND B.ETL_IS_ACTIVE=1
Group By A.TargetID),

/* BSP Validations */
MFI_TargetsFinalBase As(
SELECT  Distinct Base.HierarchyID, 
        Base.TargetID, 
        Base.TargetDate, 
        Base.CBUpdateID,
        Base.CBStatus,
        A.IsEKYCStatus,
        IFF(A.NoOfBCMImports >=1,1,0) As IsBCMImport,
        IFF(A.NoOfTargets = A.NoOfBCMApproved,'A','N') As BCMStatus,
        Base.IsBCMApproved, 
        Base.ApprovalStatus, 
        Base.ExternalApprovalRemarks,
        Base.ExternalFinalStatus,
        Base.GRTID,  
        Base.GRT_Result,  
        Base.GRTDate,
        Base.CenterID,
        Base.GroupID,  
        Base.ClientID,  
        Base.JoinDate,  
        Base.DropOutDate,  
        Base.ClientReplacementStatus,  
        Base.Client_Joined_45Days,

        (CASE WHEN CAST(B.CreatedDateTime As Date) <= date_sub(current_date(), 1) THEN 'Enrol_Imported'
        ELSE 'Enrol_NotImported' END) AS BSPImport_Status,

        (CASE WHEN CAST(C.CreatedDateTime As Date) <= date_sub(current_date(), 1) THEN 'Enrol_Auto'
              WHEN CAST(D.CreatedDateTime As Date) <= date_sub(current_date(), 1) THEN 'Enrol_Manual'
        WHEN (CASE WHEN CAST(B.CreatedDateTime As Date) <= date_sub(current_date(), 1) THEN 'Enrol_Imported'
              ELSE 'Enrol_NotImported' END )='Enrol_NotImported' THEN 'Awaiting to Import'
        ELSE NULL END) AS BSPEnrol_Status,
        /* GRT Status */
        (CASE WHEN Base.GRT_Result In ('2','3') THEN 'Success'  
              WHEN Base.GRT_Result In ('1') THEN 'Failed'  
              WHEN Base.GRT_Result Is Null THEN 'GRT Not Done' END) As GRTStatus,
        /* E-KYC Status */
        (Case When A.IsEKYCStatus = 1 Then 'Success'  
              When A.IsEKYCStatus = 0 Then 'Failed'  
              When A.IsEKYCStatus Is Null Then 'KYC Not Done' End) As KYCStatus
FROM MFI_TargetsMasterBase As Base
LEFT JOIN MFI_TargetKYCBCMStatus As A On A.TargetID = Base.TargetID
LEFT JOIN {source_catalog}.{source_schema}.`cashlessdisburs-cl_importcustomerauthdata` B ON B.TargetID = A.TargetID AND B.ETL_Is_Active=1
LEFT JOIN {source_catalog}.{source_schema}.`cashlessdisburs-cl_customerenrollmentauto` C ON C.TargetID = A.TargetID AND C.ETL_Is_Active=1
LEFT JOIN {source_catalog}.{source_schema}.`cashlessdisburs-cl_customerenrollmentmanual` D ON D.TargetID = A.TargetID AND D.ETL_Is_Active=1),

MFI_TargetsStatus As (
SELECT  A.TargetID,
        (Case When E.MinDisbDate is Not Null Then 'LoanDisbursed'  
              When A.GRT_Result in ('2','3') and A.ClientID Is Null Then 'GRT Done - Client Not Joined'  
              When A.GRT_Result in ('2','3') and A.ClientID Is Not Null and A.DropOutDate >= A.JoinDate Then 'Client Joined - Dropped without a Loan'
              When A.GRT_Result in ('2','3') and A.ClientID Is Not Null Then 'Client Done - Loan Not Disbursed'  
              When A.GRT_Result in ('1') and A.ClientID Is Not Null Then 'GRT Failed - Client Done'  
              When A.GRT_Result in ('1') and A.ClientID Is Null Then 'GRT Failed' 
              
              When A.CBStatus = 'A'  and A.ExternalFinalStatus like '%Rejected%' Then 'CB External Rejected'  
              When A.CBStatus = 'A'  and A.ExternalFinalStatus like '%CB/Eligibility Check Failed%' Then 'CB External Rejected'
              When A.CBStatus = 'A' and A.TargetDate <='2023-04-30' Then 'CB Success_Old' 
              When Coalesce(A.CBStatus,' ')=' '  Then 'CB Not Done'
              When (A.CBStatus = 'R' ) Then 'CB Rejected'
              When IFNull(A.CBStatus,'')='' and A.ExternalApprovalRemarks like '%Dedup%' Then 'Dedupe Rejected'
              When A.ApprovalStatus ='R' Then 'TD Rejected'
              When A.TargetDate < IfNull(A.GRTDate,Cast(Current_Date()-45 As Date)) Then 'TD Rejected'

              When A.BCMStatus='A' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Auto') Then 'Authorization Done_Auto'
              When A.BCMStatus='A' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Manual') Then 'Authorization Done_Manual' 
              When A.BCMStatus='N' and A.BSPImport_Status ='Enrol_NotImported' and A.BSPEnrol_Status In ('Awaiting to Import') and A.CBStatus = 'A' and A.IsBCMImport = 0 Then 'Partial TD'
              When A.CBStatus ='A' and A.Targetdate < Cast(Current_date()-21 As Date) Then 'CB Validity Expired'
              When A.BCMStatus='N' and A.BSPImport_Status ='Enrol_NotImported' and A.BSPEnrol_Status In ('Awaiting to Import') and A.CBStatus = 'A' Then 'CB Success' 
              When A.BCMStatus='A' and A.BSPImport_Status ='Enrol_NotImported' and A.BSPEnrol_Status In ('Awaiting to Import') Then 'BCM Approved'
              When A.BCMStatus='N' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Auto')  Then 'BCM Failed - Auth Done_Auto' 
              When A.BCMStatus='N' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Manual') Then 'BCM Failed - Auth Done_Manual' 
              When A.IsBCMApproved <> '1' and A.BCMStatus='A' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Auto') Then 'Authorization Done_Auto Pragati Not Imported' 
              When A.IsBCMApproved <> '1' and A.BCMStatus='A' and A.BSPImport_Status ='Enrol_Imported' and A.BSPEnrol_Status In ('Enrol_Manual') Then 'Authorization Done_Manual Pragati Not Imported' 
              When A.CBStatus = 'A'  Then 'CB Success'  
        Else Null End) As TargetCurrentStatus
FROM MFI_TargetsFinalBase As A
LEFT JOIN MFI_TargetLoans As E On E.TargetID = A.TargetID),

 
MFI_TargetRemarks As (
SELECT  A.TargetID,
        A.ClientID,
        (CASE WHEN B.TargetCurrentStatus In ('Authorization Done_Manual','Authorization Done_Auto') and A.TargetDate >= '2023-05-01' 
        and A.TargetDate < Cast(Current_Date()-45 As Date) Then 'Validity Expired, GRT Not Done'
        ELSE B.TargetCurrentStatus END) As TargetCurrentStatus,
        -- B.TargetCurrentStatus,
        (Case When B.TargetCurrentStatus ='LoanDisbursed' Then Null  
              When B.TargetCurrentStatus ='Client Done - Loan Not Disbursed' Then 'Client Done but Loan yet to be Disbursed'   
              When B.TargetCurrentStatus ='GRT Done - Client Not Joined' Then 'GRT Done but Client Not yet Joined'  
              When B.TargetCurrentStatus ='GRT Failed - Client Done' Then 'GRT Test Failed but Client Done'  
              When B.TargetCurrentStatus ='GRT Failed' Then 'GRT Test Failed'  
              When B.TargetCurrentStatus ='CB Success' and A.TargetDate < '2023-05-01' and A.TargetDate < Cast(Current_Date()-45 As Date) Then 'Validity Expired, GRT Not Done'
              When B.TargetCurrentStatus ='CB Success' Then 'CB Success but GRT Not Done'
              When B.TargetCurrentStatus in ('CB Not Done','CB Rejected','CB External Rejected') Then A.ExternalFinalStatus 
              When B.TargetCurrentStatus = 'Dedupe Rejected' Then A.ExternalApprovalRemarks
        Else Null End) As TargetStatusRemarks
FROM (Select TargetID,TargetDate,ClientID,ExternalFinalStatus,ExternalApprovalRemarks
from MFI_TargetsFinalBase 
Group By TargetID,TargetDate,ClientID,ExternalFinalStatus,ExternalApprovalRemarks)As A
JOIN (Select TargetID,TargetCurrentStatus from MFI_TargetsStatus 
group by TargetID,TargetCurrentStatus ) B On A.TargetID=b.TargetID),


MFI_TargetFacts As (
SELECT  A.*,
        (CASE WHEN C.TargetCurrentStatus In ('Authorization Done_Auto','Authorization Done_Manual','BCM Failed - Auth Done') and B.SurveyStatus Is Null 
        and A.TargetDate >= '2023-05-01' Then 'Auth Done, Housing Survey Pending'
        ELSE C.TargetCurrentStatus END) As TargetCurrentStatus,
        C.TargetStatusRemarks,
        Cast(B.SurveyDate As Date) As SurveyDate,
        B.SurveyStatus
FROM MFI_TargetsFinalBase As A
LEFT JOIN {source_catalog}.{source_schema}.`pragati-targethousingsurveydetails` As B On B.TargetID = A.TargetID
LEFT JOIN (select TargetID,ClientID,TargetCurrentStatus,TargetStatusRemarks
          From MFI_TargetRemarks
          Group By TargetID,ClientID,TargetCurrentStatus,TargetStatusRemarks ) As C On C.TargetID  = A.TargetID  
          --and C.ClientID = A.ClientID
)
Select * From MFI_TargetFacts; """.format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"targetfacts Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on targetfacts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on targetfacts : ", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option(
        "mergeSchema", "true"
    ).option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.targetfacts")

    logger(
        logger_level_info,
        f"targetfacts writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table targetfacts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table targetfacts : ", str(e)
    )

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)