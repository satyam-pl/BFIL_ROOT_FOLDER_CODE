# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "dailyloanfacts_rlms.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/DAILYLOANFACTS_RLMS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )
    query = """WITH T_branch_RLMS_Daily AS (
        SELECT H.BranchID, BranchMASter.BranchName, BranchMaster.HierarchyId,
            H.STATE StateName, H.Branch_Type, H.Region, H.DISTRICT DistrictName, H.ZONE ZoneName, H.Area,
            MAX(DayProcessLog.TransactionDate) AS CODDate
            FROM (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-dayprocesslog` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) DayProcessLog
            INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-branchmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) BranchMASter ON DayProcessLog.HierarchyId = BranchMASter.HierarchyId
            INNER JOIN {mart_catalog}.{mart_schema}.`p_hierarchy_sop` H on DayProcessLog.HierarchyId = H.HierarchyId
            WHERE   DayProcessLog.CODProcessCompleted=1
            AND (BranchMaster.EndDate IS NULL OR BranchMaster.EndDate = '1900-01-01')
            and upper(h.Branch_Type) = 'BSS'
            GROUP BY H.BranchID, BranchMaster.BranchName, BranchMASter.HierarchyId,StateName,
            H.Branch_Type,H.Region,DistrictName,ZoneName,H.Area),P_DailyLoanfacts_RLMS1 AS (
        SELECT A.CODDate, A.Branch_Type, A.StateName, A.Region , A.DistrictName , A.ZoneName, A.Area,
            A.BranchName , A.BranchID, A.HierarchyId,
            CLS.CustomerLoanId AS ClientLoanId, CLS.CustomerLoanCode AS ClientLoanCode,
            CLS.LoanApplicationId As LoanProposalId, ALD.LoanProposalCode,
            PM.ProductName, PM.ProductCode, PM.ProductDescription,
            CLS.CustomerProductSequenceNo AS ClientProductSequenceNo,
            CM.CustomerId AS ClientId, CM.CustomerCode AS ClientCode, CM.CustomerName AS ClientName,
            '' AS CenterCode , '' AS CenterId , '' as centername, '' AS CenterMeetingDay, '' AS CenterStaffID,
            CLS.DisbursementDate, CLS.LoanAmountDisbursed, CLS.ExpectedPaidUPDATE,
            (CASE WHEN CLS.LoanClosedDate <=A.CODDate THEN  CLS.LoanClosedDate ELSE NULL END) AS LoanClosedDate,
            CLP.PurposeId, LoanPurposes.PurposeName,
            ALD.HoUSEHoldINcome, CLS.INterestRate, 
            (CASE WHEN (CLS.LoanClosedDate IS NULL OR CLS.LoanClosedDate > A.CODDate) THEN 0 ELSE  coalesce(CLS.differenceAmountinPreclosing,0) END ) AS DifferenceAmountInPreclosing,
            CLS.Tenure, CAST('' AS Varchar(50)) AS FundName, ALD.FundId ,
            TM.casteid AS Caste, CV.Value AS Religion, CAST('' AS Varchar(50)) AS `Rural/Urban`,
            CLS.IsDeviationCancelled AS DeviationCancel, CLS.LoanCancelleddate , CLS.DisbursementMode, CLS.RepaymentFrequency,CM.Gender, CM.CustomerDOB AS DateOfBirth, CM.JoinDate,CLP.LoanApplicationDate AS ProposalDate, CLP.ApprovedDate,CLP.LoanAmountApproved,'' AS Groupid, CM.BaselineCustomerId AS TargetId, ABD.TargetCode, ABD.TargetDate, CLS.IsLoanClosed FROM (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)  CLS left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-customerloanapplication` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) CLP ON CLS.LoanApplicationId = CLP.LoanApplicationId
            left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-customermaster` WHERE ETL_IS_ACTIVE = '1') CM ON CLS.CustomerId = CM.CustomerId left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-additionalloanapplicationdetails` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)  ALD ON ALD.LoanApplicationId=CLP.LoanApplicationId left JOIN T_branch_RLMS_Daily A on A.HierarchyId=CLS.hierarchyid left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-baselinecustomermaster_h_view` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) TM ON TM.CUSTOMERID=CM.BaselineCustomerID
            left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-productmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) PM ON CLS.ProductID = PM.ProductID
            left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loanpurposemaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) LoanPurposes ON CLP.PurposeId = LoanPurposes.PurposeId left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-codevalue` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) CV ON TM.ReligionId = CV.Code left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-additionalbaselinedetails` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) ABD ON CM.CustomerID = ABD.CustomerID WHERE  (CLS.LoanClosedDate IS NULL OR CLS.LoanClosedDate = '1900-01-01' or CAST(CLS.LoanClosedDate as date) >= current_date - day(current_date) + 1) AND (CLS.DisbursementDate <=A.CODDate) AND CLS.ProductType IS NULL),
        P_DailyLoanfacts_RLMS2 AS (SELECT A.*,
        -- CASE WHEN MI.Clientloanid IS NOT NULL THEN coalesce(MI.UpfrontInterest_vp,0) ELSE NULL END UpfrontInterest_vp,
        CAST(NULL AS decimal (18,4)) UpfrontInterest_vp,
        -- CASE WHEN MI.Clientloanid IS NOT NULL THEN MI.NPAStatus_vp ELSE NULL END NPAStatus_vp,
        CAST(NULL as INT) NPAStatus_vp,
        -- CASE WHEN MI.Clientloanid IS NOT NULL THEN MI.Moratorium_flag ELSE NULL END Moratorium_flag,
        CASE WHEN CAST(A.DisbursementDate as date) >=  '2020-11-01' THEN 'N' ELSE CAST(NULL AS STRING) END Moratorium_flag,
        CASE WHEN C.CustomerID IS NOT NULL AND C.DeathDate >= A.DisbursementDate AND C.DeathDate <= CODDate AND  (A.LoanClosedDate IS NULL OR A.LoanClosedDate > C.DeathDate) THEN C.DeathDate ELSE CAST(NULL as date) END DeathDate,
        CAST(NULL as decimal (18,4)) Cum_PrincipalColl,
        CAST(NULL as decimal (18,4)) Cum_InterestColl,
        CAST(NULL as decimal (18,4)) Cum_Pridue,
        CAST(NULL as decimal (18,4)) Cum_IntDue,
        CAST(NULL as decimal (18,4)) PrincipalWrittenoff,
        CAST(NULL as decimal (18,4)) InterestWrittenoff,
        CAST(NULL as date) TransactionDate,
        CAST(NULL AS decimal (18,4)) Total_PrincipalDue,
        CAST(NULL AS decimal (18,4)) Total_InterestDue,
        -- CASE WHEN MI.Clientloanid IS NOT NULL THEN MI.RD_AdjustAmt ELSE NULL END RD_AdjustAmt,
        CAST(NULL AS decimal (18,4)) RD_AdjustAmt,
        CAST(NULL AS decimal (18,4)) POS,
        CAST(NULL AS decimal (18,4)) IOS,
        CAST(NULL AS decimal (18,4)) PrincipalInArears,
        CAST(NULL AS decimal (18,4)) InterestInArears,
        CAST(NULL as date) LastRepaymentDate,
        CAST(NULL as  char(2)) M_Flag,
        CAST(NULL as date) Last_CMDate,
        CAST(NULL as date) DPDStartdate,
        CAST(NULL as INT) NoOfDaysInArrears,
        CAST(NULL AS VARCHAR (50)) AssetCl_BR,
        CAST(NULL AS VARCHAR (50)) Type_New,
        CAST(NULL as  char(2)) Freezed,
        CAST(NULL AS VARCHAR (30)) Loan_Status,
        CAST(NULL AS VARCHAR (25)) Ageing_Loan,
        CAST(NULL as INT) ClientDPD_EXCL_ARC,
        CAST(NULL as varchar(25)) Ageing_Client_EXCL_ARC,
        CAST(NULL AS DECIMAL(18,4)) EWI,
        CAST(NULL AS VARCHAR (50)) Product_Type,
        CAST(NULL AS VARCHAR (50)) ProductCategory,
        CAST(NULL as DECIMAL(18,4))ClosedloanwithPos,
        CAST(NULL as DECIMAL(18,4))M_PriDue,
        CAST(NULL as DECIMAL(18,4))M_IntDue,
        CAST(NULL as DECIMAL(18,4))M_PriColl,
        CAST(NULL as DECIMAL(18,4))M_IntColl
    FROM P_DailyLoanfacts_RLMS1 A
    -- LEFT JOIN ITDB..P_MIAmountAndMoratoriumFlagFromNov20 B ON LF.ClientLoanId = MI.Clientloanid collate SQL_Latin1_General_CP1_CI_AS
    LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-customerdeathintimation` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) C
    ON A.ClientId = C.CustomerID),T_TotalEWICompleted_RLMS_Daily1 AS (
    SELECT
            T.HierarchyId , t.ClientId , T.ClientLoanId,
            SUM(PrincipalAmount)   AS Cum_PrincipalColl,
            SUM(InterestAmount)   AS Cum_InterestColl,
            max(LT.ValueDate) as Max_ValueDate,
            MAX(CASE WHEN LT.Amount > 0 THEN LT.ValueDate END) AS LAStRepaymentDate
        FROM P_DailyLoanfacts_RLMS2 T
            JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) LT ON LT.HierarchyId = T.HierarchyId
                and LT.CustomerID =t.ClientId
                and LT.CustomerLoanID = T.ClientLoanId
        WHERE upper(LT.TransactionType) = 'C'
            AND upper(LT.DebitORCredit) = 'C'
            AND upper(LT.ValueDate) <= CODDate
        GROUP BY T.HierarchyId ,t.ClientId ,T.ClientLoanId),T_TotalEWICompleted_RLMS_Daily AS (
    SELECT * FROM 
    (SELECT * FROM T_TotalEWICompleted_RLMS_Daily1)
    UNION ALL
    (SELECT Base.HierarchyId , Base.ClientId , Base.ClientLoanId, 0, 0, DisbursementDate, DisbursementDate
        FROM P_DailyLoanfacts_RLMS2 Base 
        LEFT JOIN T_TotalEWICompleted_RLMS_Daily1 A ON Base.ClientLoanID = A.ClientLoanId
        WHERE A.ClientLoanId IS NULL)),
    T_TotalDue_RLMS_Daily1 AS (
    SELECT t.HierarchyId , t.ClientId , t.ClientLoanId,
            SUM(LT.PrINcipalAmount) AS PRI_DUE,
            SUM(LT.INterestAmount ) AS INT_Due
        FROM P_DailyLoanfacts_RLMS2 T
            INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) LT ON LT.HierarchyId = T.HierarchyId AND LT.CustomerID = T.ClientId AND LT.CustomerLoanID = T.ClientLoanId
        WHERE LT.ValueDate <= T.CODDate AND upper(LT.TransactionType) = 'C' AND upper(LT.DebitorCredit) = 'D'
        GROUP BY  t.HierarchyId ,t.ClientId ,t.ClientLoanId),
        T_TotalDue_RLMS_Daily AS (
    SELECT * FROM 
    (SELECT * FROM T_TotalDue_RLMS_Daily1)
    UNION ALL
    (SELECT P_DailyLoanfacts_RLMS2.HierarchyId , P_DailyLoanfacts_RLMS2.ClientId , P_DailyLoanfacts_RLMS2.ClientLoanId,0, 0
    FROM P_DailyLoanfacts_RLMS2 
        LEFT JOIN T_TotalDue_RLMS_Daily1 ON T_TotalDue_RLMS_Daily1.ClientLoanId = P_DailyLoanfacts_RLMS2.ClientLoanId
    WHERE T_TotalDue_RLMS_Daily1.ClientLoanId IS NULL)),P_DailyLoanfacts_RLMS3 AS (
    SELECT 
        A.CODDate,
        A.Branch_Type,
        A.StateName,
        A.Region,
        A.DistrictName,
        A.ZoneName,
        A.Area,
        A.BranchName,
        A.BranchID,
        A.HierarchyId,
        A.ClientLoanId,
        A.ClientLoanCode,
        A.LoanProposalId,
        A.LoanProposalCode,
        A.ProductName,
        A.ProductCode,
        A.ProductDescription,
        A.ClientProductSequenceNo,
        A.ClientId,
        A.ClientCode,
        A.ClientName,
        A.CenterCode,
        A.CenterId,
        A.centername,
        A.CenterMeetingDay,
        A.CenterStaffID,
        A.DisbursementDate,
        A.LoanAmountDisbursed,
        A.ExpectedPaidUPDATE,
        A.LoanClosedDate,
        A.PurposeId,
        A.PurposeName,
        A.HoUSEHoldINcome,
        A.INterestRate,
        A.DifferenceAmountInPreclosing,
        A.Tenure,
        A.FundName,
        A.FundId,
        A.Caste,
        A.Religion,
        A.`Rural/Urban`,
        A.DeviationCancel,
        A.LoanCancelleddate,
        A.DisbursementMode,
        A.RepaymentFrequency,
        A.Gender,
        A.DateOfBirth,
        A.JoinDate,
        A.ProposalDate,
        A.ApprovedDate,
        A.LoanAmountApproved,
        A.Groupid,
        A.TargetId,
        A.TargetCode,
        A.TargetDate,
        A.IsLoanClosed,
        A.UpfrontInterest_vp,
        A.NPAStatus_vp,
        A.Moratorium_flag,
        A.DeathDate,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN coalesce(B.Cum_PrincipalColl,0) ELSE A.Cum_PrincipalColl END Cum_PrincipalColl,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN coalesce(B.Cum_InterestColl,0) ELSE A.Cum_InterestColl END Cum_InterestColl,
        CASE WHEN C.ClientLoanid IS NOT NULL THEN coalesce(C.PRI_DUE,0) ELSE A.Cum_Pridue END Cum_Pridue,
        CASE WHEN C.ClientLoanid IS NOT NULL THEN coalesce(C.INT_Due,0) ELSE A.Cum_IntDue END Cum_IntDue,
        A.PrincipalWrittenoff,
        A.InterestWrittenoff,
        A.TransactionDate,
        A.Total_PrincipalDue,
        A.Total_InterestDue,
        A.RD_AdjustAmt,
        A.POS,
        A.IOS,
        A.PrincipalInArears,
        A.InterestInArears,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN B.LAStRepaymentDate ELSE A.LAStRepaymentDate END LAStRepaymentDate,
        A.M_Flag,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN B.Max_ValueDate ELSE A.Last_CMDate END Last_CMDate,
        A.DPDStartdate,
        A.NoOfDaysInArrears,
        A.AssetCl_BR,
        A.Type_New,
        A.Freezed,
        A.Loan_Status,
        A.Ageing_Loan,
        A.ClientDPD_EXCL_ARC,
        A.Ageing_Client_EXCL_ARC,
        A.EWI,
        A.Product_Type,
        A.ProductCategory,
        A.ClosedloanwithPos,
        A.M_PriDue,
        A.M_IntDue,
        A.M_PriColl,
        A.M_IntColl 
    FROM P_DailyLoanfacts_RLMS2 A
    LEFT JOIN T_TotalEWICompleted_RLMS_Daily B
    ON A.ClientLoanid = B.ClientLoanid
    LEFT JOIN T_TotalDue_RLMS_Daily C
    ON A.ClientLoanid = C.ClientLoanid),T_TotalIntexp_RLMS_Daily AS (
    SELECT
        T.HierarchyId , T.ClientId , T.ClientLoanId,
        SUM(PrincipalAmount)   AS Total_PrincipalDue,
        SUM(InterestAmount)   AS Total_InterestDue
    FROM P_DailyLoanfacts_RLMS3 T
        JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)  LT ON T.HierarchyId = LT.HIerarchyID
            AND T.ClientId = LT.CustomerID
            AND T.ClientLoanId = LT.CustomerLoanID
    WHERE upper(LT.TransactionType) = 'C' AND upper(LT.DebitORCredit) = 'D'
    GROUP BY  T.HierarchyId ,T.ClientId ,T.ClientLoanId),
    P_DailyLoanfacts_RLMS4 AS (
    SELECT 
        A.CODDate,
        A.Branch_Type,
        A.StateName,
        A.Region,
        A.DistrictName,
        A.ZoneName,
        A.Area,
        A.BranchName,
        A.BranchID,
        A.HierarchyId,
        A.ClientLoanId,
        A.ClientLoanCode,
        A.LoanProposalId,
        A.LoanProposalCode,
        A.ProductName,
        A.ProductCode,
        A.ProductDescription,
        A.ClientProductSequenceNo,
        A.ClientId,
        A.ClientCode,
        A.ClientName,
        A.CenterCode,
        A.CenterId,
        A.centername,
        A.CenterMeetingDay,
        A.CenterStaffID,
        A.DisbursementDate,
        A.LoanAmountDisbursed,
        A.ExpectedPaidUPDATE,
        A.LoanClosedDate,
        A.PurposeId,
        A.PurposeName,
        A.HoUSEHoldINcome,
        A.INterestRate,
        A.DifferenceAmountInPreclosing,
        A.Tenure,
        A.FundName,
        A.FundId,
        A.Caste,
        A.Religion,
        A.`Rural/Urban`,
        A.DeviationCancel,
        A.LoanCancelleddate,
        A.DisbursementMode,
        A.RepaymentFrequency,
        A.Gender,
        A.DateOfBirth,
        A.JoinDate,
        A.ProposalDate,
        A.ApprovedDate,
        A.LoanAmountApproved,
        A.Groupid,
        A.TargetId,
        A.TargetCode,
        A.TargetDate,
        A.IsLoanClosed,
        A.UpfrontInterest_vp,
        A.NPAStatus_vp,
        A.Moratorium_flag,
        A.DeathDate,
        A.Cum_PrincipalColl,
        A.Cum_InterestColl,
        A.Cum_Pridue,
        A.Cum_IntDue,
        A.PrincipalWrittenoff,
        A.InterestWrittenoff,
        A.TransactionDate,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN coalesce(B.Total_PrincipalDue,0) ELSE A.Total_PrincipalDue END Total_PrincipalDue,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN coalesce(B.Total_InterestDue,0) ELSE A.Total_InterestDue END Total_InterestDue1,
        A.RD_AdjustAmt,
        CASE 
            WHEN A.LoanClosedDate IS NULL THEN A.LoanAmountDisbursed + coalesce(A.UpfrontInterest_vp,0)-coalesce(A.Cum_PrINcipalColl,0)- coalesce(A.dIFferenceAmountINPreclosINg,0) - coalesce(A.RD_AdjustAmt,0)  
            ELSE 0.0000
        END POS,
        CASE 
            WHEN A.LoanClosedDate IS NULL THEN (Total_InterestDue1 - A.Cum_InterestColl)
            ELSE 0.0000
        END IOS,
        CASE
            WHEN ((coalesce(A.Cum_Pridue,0)+coalesce(A.Cum_IntDue,0))-(coalesce(A.Cum_PrincipalColl,0)+coalesce(A.Cum_InterestColl,0))) <= 0 THEN 0
            WHEN A.LoanClosedDate IS NULL AND A.PrincipalInArears < 0 THEN 0.0000
            WHEN A.LoanClosedDate IS NOT NULL THEN 0.0000
            WHEN A.LoanClosedDate IS NULL THEN A.Cum_PriDue - A.Cum_PrincipalColl
            ELSE A.PrincipalInArears
        END PrincipalInArears,
        CASE 
            WHEN ((coalesce(A.Cum_Pridue,0)+coalesce(A.Cum_IntDue,0))-(coalesce(A.Cum_PrincipalColl,0)+coalesce(A.Cum_InterestColl,0))) <= 0 THEN 0
            WHEN A.LoanClosedDate IS NULL AND A.InterestInArears < 0 THEN 0.0000
            WHEN A.LoanClosedDate IS NOT NULL THEN 0.0000
            WHEN A.LoanClosedDate IS NULL THEN A.Cum_IntDue - A.Cum_InterestColl
            ELSE A.InterestInArears
        END InterestInArears,
        A.LAStRepaymentDate,
        CASE WHEN (date_diff(DAY,A.Disbursementdate,A.last_CMDate))<7
            AND A.Cum_PrINcipalColl=0 AND A.Cum_PriDue > 0 AND A.LoanClosedDate IS NULL THEN 'Y' 
            ELSE A.M_Flag
        END M_Flag,
        A.Last_CMDate,
        A.DPDStartdate,
        A.NoOfDaysInArrears,
        A.AssetCl_BR,
        A.Type_New,
        A.Freezed,
        A.Loan_Status,
        A.Ageing_Loan,
        A.ClientDPD_EXCL_ARC,
        A.Ageing_Client_EXCL_ARC,
        A.EWI,
        A.Product_Type,
        A.ProductCategory,
        A.ClosedloanwithPos,
        A.M_PriDue,
        A.M_IntDue,
        A.M_PriColl,
        A.M_IntColl 
    FROM P_DailyLoanfacts_RLMS3 A
    LEFT JOIN T_TotalIntexp_RLMS_Daily B
    ON A.ClientLoanid = B.ClientLoanid),
    T_openloansRLMS_Daily AS (
    select HierarchyId , ClientId , ClientLoanId , Tenure , DisbursementDAte, CODDate
        from P_DailyLoanfacts_RLMS4
        where CAST(((Cum_Pridue+Cum_IntDue)-(Cum_PrincipalColl +Cum_InterestColl)) as decimal (18,4))>0
            and LoanClosedDate is null),
    T_openloans_MaxTranDateColl_RLMS_Daily1 AS (
    SELECT A.HierarchyId, ClientId , A.ClientLoanId, MAX(LT.TransactionDate) AS MaxTranDateColl
        FROM T_openloansRLMS_Daily A
        JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` WHERE ETL_IS_ACTIVE = '1') LT ON A.HierarchyId = LT.HierarchyID AND A.ClientID = LT.CustomerID AND A.ClientLoanId = LT.CustomerLoaniD
        WHERE (LT.DebitOrcredit = 'C' AND LT.TransactionType = 'C') AND LT.Amount > 0 AND LT.ValueDate <= CODDate
        GROUP BY A.HierarchyId,ClientId,A.ClientLoanId),
    T_openloans_MaxTranDateColl_RLMS_Daily2 AS (
    SELECT * FROM 
    (SELECT * FROM T_openloans_MaxTranDateColl_RLMS_Daily1)
    UNION ALL
    (SELECT A.HierarchyId, A.ClientID, A.ClientLoanId, A.DisbursementDate
    FROM T_openloansRLMS_Daily A
    LEFT JOIN T_openloans_MaxTranDateColl_RLMS_Daily1 B ON A.ClientLoanid = B.ClientLoanid
    WHERE B.ClientLoanId IS NULL)),
    T_openloans_NextTranDate_RLMS_Daily AS (
    SELECT A.HIerarchyID, A.ClientLoanId, A.MaxTranDateColl, MIN(LT.TransactionDate)  AS NextTranDate
        FROM T_openloans_MaxTranDateColl_RLMS_Daily2 A
            JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) LT ON A.ClientLoanId = LT.CustomerLoaniD AND A.HierarchyID = LT.HierarchyID
        WHERE (upper(LT.DebitOrcredit) = 'D' AND upper(LT.TransactionType) = 'C') AND LT.TransactionDAte > A.MaxTranDateColl
        GROUP BY A.HIerarchyID,A.ClientLoanId,A.MaxTranDateColl),

    T_openloans_DPD_RLMS_Daily AS (
    SELECT A.*, B.MaxTranDateColl, B.NextTranDate AS LastUnpaidEWIDate
        FROM T_openloansRLMS_Daily A
            JOIN T_openloans_NextTranDate_RLMS_Daily B ON A.Clientloanid = B.ClientLoanid),

    P_NPA_CurrentMonth AS (
    select ClientId, ClientLoanId, AssetCl_BR as NPA_Tag
        from edp_bfil_prod.bfil_mart.dailyloanfacts_step1
        where upper(AssetCl_BR) in ('LOS','DB3','DB1','DB2','SUB')),

    P_DailyLoanfacts_RLMS5 AS
    (SELECT 
        A.CODDate,
        A.Branch_Type,
        A.StateName,
        A.Region,
        A.DistrictName,
        A.ZoneName,
        A.Area,
        A.BranchName,
        A.BranchID,
        A.HierarchyId,
        A.ClientLoanId,
        A.ClientLoanCode,
        A.LoanProposalId,
        A.LoanProposalCode,
        A.ProductName,
        A.ProductCode,
        A.ProductDescription,
        A.ClientProductSequenceNo,
        A.ClientId,
        A.ClientCode,
        A.ClientName,
        A.CenterCode,
        A.CenterId,
        A.centername,
        A.CenterMeetingDay,
        A.CenterStaffID,
        A.DisbursementDate,
        A.LoanAmountDisbursed,
        A.ExpectedPaidUPDATE,
        A.LoanClosedDate,
        A.PurposeId,
        A.PurposeName,
        A.HoUSEHoldINcome,
        A.INterestRate,
        A.DifferenceAmountInPreclosing,
        A.Tenure,
        A.FundName,
        A.FundId,
        A.Caste,
        A.Religion,
        A.`Rural/Urban`,
        A.DeviationCancel,
        A.LoanCancelleddate,
        A.DisbursementMode,
        A.RepaymentFrequency,
        A.Gender,
        A.DateOfBirth,
        A.JoinDate,
        A.ProposalDate,
        A.ApprovedDate,
        A.LoanAmountApproved,
        A.Groupid,
        A.TargetId,
        A.TargetCode,
        A.TargetDate,
        A.IsLoanClosed,
        A.UpfrontInterest_vp,
        A.NPAStatus_vp,
        A.Moratorium_flag,
        A.DeathDate,
        A.Cum_PrincipalColl,
        A.Cum_InterestColl,
        CASE WHEN upper(A.M_Flag) = 'Y' AND (A.Cum_PrINcipalColl+A.Cum_INterestColl) = 0 THEN 0.00 ELSE A.Cum_Pridue END Cum_Pridue,
        CASE WHEN upper(A.M_Flag) = 'Y' AND (A.Cum_PrINcipalColl+A.Cum_INterestColl) = 0 THEN 0.00 ELSE A.Cum_IntDue END Cum_IntDue,
        A.PrincipalWrittenoff,
        A.InterestWrittenoff,
        A.TransactionDate,
        A.Total_PrincipalDue,
        A.Total_InterestDue1 Total_InterestDue,
        A.RD_AdjustAmt,
        A.POS,
        A.IOS,
        CASE WHEN upper(A.M_Flag) = 'Y' AND (A.Cum_PrINcipalColl+A.Cum_INterestColl) = 0 THEN 0.00 ELSE A.PrincipalInArears END PrincipalInArears,
        CASE WHEN upper(A.M_Flag) = 'Y' AND (A.Cum_PrINcipalColl+A.Cum_INterestColl) = 0 THEN 0.00 ELSE A.InterestInArears END InterestInArears,
        A.LAStRepaymentDate,
        A.M_Flag,
        A.Last_CMDate,
        CASE
            WHEN upper(A.M_Flag) = 'Y' AND (A.Cum_PrINcipalColl+A.Cum_INterestColl) = 0 THEN NULL
            ELSE B.LastUnpaidEWIDate
        END DPDStartdate1,
        CASE
            WHEN upper(A.M_Flag) = 'Y' AND (A.Cum_PrINcipalColl+A.Cum_INterestColl) = 0 THEN 0.00
            WHEN (upper(A.Moratorium_flag) <> 'Y' OR A.Moratorium_flag IS NULL) AND A.LoanClosedDate IS NULL AND DPDStartdate1 is not NULL THEN date_diff(DAY,DPDStartdate1,A.CODDate) + 1
            WHEN A.Moratorium_flag = 'Y' AND A.ClientLoanid IN ('6113787000004859') AND A.LoanClosedDate IS NULL AND DPDStartdate1 IS NOT NULL THEN date_diff(DAY,DPDStartdate1,A.CODDate) + 1
            WHEN A.Moratorium_flag = 'Y' AND A.LoanClosedDate IS NULL AND (DPDStartdate1 >= '2020-09-01') THEN date_diff(DAY,DPDStartdate1,A.CODDate)+1
            WHEN A.Moratorium_flag = 'Y' AND A.LoanClosedDate IS NULL AND (cast(DPDStartdate1 as date) BETWEEN '2020-03-01' AND '2020-08-31') THEN date_diff(DAY,cast('2020-09-01' as date),A.CODDate) + 1
            WHEN A.Moratorium_flag = 'Y' AND A.LoanClosedDate IS NULL AND cast(DPDStartdate1 as date) < '2020-03-01' THEN (date_diff(DAY,DPDStartdate1,A.CODDate) + 1) - 184 
            WHEN (A.LoanClosedDate IS NOT NULL) AND DPDStartdate1 is null THEN 0
            ELSE A.NoOfDaysInArrears 
        END NoOfDaysInArrears,
        CASE 
            WHEN D.SPT_ID IS NOT NULL AND D.assettag = 'ARC' THEN D.assettag
            WHEN C.ClientLoanId IS NOT NULL THEN C.NPA_Tag 
            ELSE A.AssetCl_BR 
        END AssetCl_BR,
        CASE 
            WHEN D.SPT_ID IS NOT NULL THEN D.Type_New
            WHEN A.Type_New IS NULL THEN 'On B/s'
            ELSE A.Type_New 
        END Type_New,
        A.Freezed,
        A.Loan_Status,
        A.Ageing_Loan,
        A.ClientDPD_EXCL_ARC,
        A.Ageing_Client_EXCL_ARC,
        A.EWI,
        A.Product_Type,
        A.ProductCategory,
        A.ClosedloanwithPos,
        A.M_PriDue,
        A.M_IntDue,
        A.M_PriColl,
        A.M_IntColl 
    FROM P_DailyLoanfacts_RLMS4 A
    LEFT JOIN T_openloans_DPD_RLMS_Daily B
    ON A.ClientLoanid = B.ClientLoanID
    LEFT JOIN P_NPA_CurrentMonth C
    ON A.ClientLoanId = C.ClientLoanId
    LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-p_clstagging` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) D ON A.ClientLoanId = D.SPT_ID
    -- collate SQL_Latin1_General_CP1_CI_AS
    ),P_DailyLoanfacts_RLMS6 AS
    (SELECT 
        A.CODDate,
        A.Branch_Type,
        A.StateName,
        A.Region,
        A.DistrictName,
        A.ZoneName,
        A.Area,
        A.BranchName,
        A.BranchID,
        A.HierarchyId,
        A.ClientLoanId,
        A.ClientLoanCode,
        A.LoanProposalId,
        A.LoanProposalCode,
        A.ProductName,
        A.ProductCode,
        A.ProductDescription,
        A.ClientProductSequenceNo,
        A.ClientId,
        A.ClientCode,
        A.ClientName,
        A.CenterCode,
        A.CenterId,
        A.centername,
        A.CenterMeetingDay,
        A.CenterStaffID,
        A.DisbursementDate,
        A.LoanAmountDisbursed,
        A.ExpectedPaidUPDATE,
        A.LoanClosedDate,
        A.PurposeId,
        A.PurposeName,
        A.HoUSEHoldINcome,
        A.INterestRate,
        A.DifferenceAmountInPreclosing,
        A.Tenure,
        A.FundName,
        A.FundId,
        A.Caste,
        A.Religion,
        A.`Rural/Urban`,
        A.DeviationCancel,
        A.LoanCancelleddate,
        A.DisbursementMode,
        A.RepaymentFrequency,
        A.Gender,
        A.DateOfBirth,
        A.JoinDate,
        A.ProposalDate,
        A.ApprovedDate,
        A.LoanAmountApproved,
        A.Groupid,
        A.TargetId,
        A.TargetCode,
        A.TargetDate,
        A.IsLoanClosed,
        A.UpfrontInterest_vp,
        A.NPAStatus_vp,
        A.Moratorium_flag,
        A.DeathDate,
        A.Cum_PrincipalColl,
        A.Cum_InterestColl,
        A.Cum_Pridue,
        A.Cum_IntDue,
        A.PrincipalWrittenoff,
        A.InterestWrittenoff,
        A.TransactionDate,
        A.Total_PrincipalDue,
        A.Total_InterestDue,
        A.RD_AdjustAmt,
        A.POS,
        A.IOS,
        A.PrincipalInArears,
        A.InterestInArears,
        A.LAStRepaymentDate,
        A.M_Flag,
        A.Last_CMDate,
        A.DPDStartdate1 DPDStartdate,
        A.NoOfDaysInArrears,
        A.Type_New,
        CASE WHEN A.Type_New IN ('On B/s') AND A.LoanClosedDate IS NULL THEN 'Y' ELSE A.Freezed END Freezed1,
        CASE 
            WHEN (A.AssetCl_BR is null or A.AssetCl_BR = '') and Freezed1 = 'Y' THEN 'Standard' 
            ELSE A.AssetCl_BR 
        END AssetCl_BR,
        CASE
            WHEN B.CustomerId IS NOT NULL AND B.DeathCertificateReceivedDate =A.LoanClosedDate AND B.DeathCertificateReceivedDate <= A.CODDate AND A.DisbursementDate <= B.DeathDate THEN 'DeathCASE'
            WHEN A.LoanClosedDate IS NOT NULL AND (A.Cum_PrINcipalColl-A.Cum_PriDue) > 10 AND A.DeathDate IS NULL AND DATE_DIFF(DAY,A.LoanClosedDate,A.ExpectedPaidUpDate) > 5 THEN 'Prepayment'
            WHEN A.LoanClosedDate IS NULL AND A.NoOfDaysInArrears > 0 THEN 'Arrear' 
            WHEN A.NoOfDaysInArrears = 0 THEN 'Normal'
            ELSE A.Loan_Status 
        END Loan_Status1,
        CASE 
            WHEN Loan_Status1  <> 'Arrear' AND A.NoOfDaysInArrears = 0 THEN 'Current1'
            WHEN Loan_Status1 = 'Arrear' AND (A.NoOfDaysInArrears BETWEEN 0 AND 30) THEN '[1 To 30]'
            WHEN (A.NoOfDaysInArrears BETWEEN 31 AND 60) THEN '[31 To 60]'
            WHEN (A.NoOfDaysInArrears BETWEEN 61 AND 90) THEN '[61 To 90]'
            WHEN (A.NoOfDaysInArrears > 90) THEN '[>90]'
            ELSE A.Ageing_Loan
        END Ageing_Loan,
        A.ClientDPD_EXCL_ARC,
        A.Ageing_Client_EXCL_ARC,
        A.EWI,
        A.Product_Type,
        A.ProductCategory,
        A.ClosedloanwithPos,
        A.M_PriDue,
        A.M_IntDue,
        A.M_PriColl,
        A.M_IntColl 
    FROM P_DailyLoanfacts_RLMS5 A
    LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-customerdeathintimation` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) B
    ON A.ClientId = B.CustomerId),
    T_sha_clientlevel_dpd_RLMS_Daily AS (
    Select ClientId, Max(noofdaysINarrears)Max_noofdaysINarrears
    from P_DailyLoanfacts_RLMS6
    where upper(Freezed1) = 'Y' and upper(AssetCl_BR) not in ('ARC')
    Group by ClientId),
    P_DailyLoanfacts_RLMS7 AS
    (SELECT 
        A.CODDate,
        A.Branch_Type,
        A.StateName,
        A.Region,
        A.DistrictName,
        A.ZoneName,
        A.Area,
        A.BranchName,
        A.BranchID,
        A.HierarchyId,
        A.ClientLoanId,
        A.ClientLoanCode,
        A.LoanProposalId,
        A.LoanProposalCode,
        A.ProductName,
        A.ProductCode,
        A.ProductDescription,
        A.ClientProductSequenceNo,
        A.ClientId,
        A.ClientCode,
        A.ClientName,
        A.CenterCode,
        A.CenterId,
        A.centername,
        A.CenterMeetingDay,
        A.CenterStaffID,
        A.DisbursementDate,
        A.LoanAmountDisbursed,
        A.ExpectedPaidUPDATE,
        A.LoanClosedDate,
        A.PurposeId,
        A.PurposeName,
        A.HoUSEHoldINcome,
        A.INterestRate,
        A.DifferenceAmountInPreclosing,
        A.Tenure,
        A.FundName,
        A.FundId,
        A.Caste,
        A.Religion,
        A.`Rural/Urban`,
        A.DeviationCancel,
        A.LoanCancelleddate,
        A.DisbursementMode,
        A.RepaymentFrequency,
        A.Gender,
        A.DateOfBirth,
        A.JoinDate,
        A.ProposalDate,
        A.ApprovedDate,
        A.LoanAmountApproved,
        A.Groupid,
        A.TargetId,
        A.TargetCode,
        A.TargetDate,
        A.IsLoanClosed,
        A.UpfrontInterest_vp,
        A.NPAStatus_vp,
        A.Moratorium_flag,
        A.DeathDate,
        A.Cum_PrincipalColl,
        A.Cum_InterestColl,
        A.Cum_Pridue,
        A.Cum_IntDue,
        A.PrincipalWrittenoff,
        A.InterestWrittenoff,
        A.TransactionDate,
        A.Total_PrincipalDue,
        A.Total_InterestDue,
        A.RD_AdjustAmt,
        A.POS,
        A.IOS,
        A.PrincipalInArears,
        A.InterestInArears,
        A.LAStRepaymentDate,
        A.M_Flag,
        A.Last_CMDate,
        A.DPDStartdate,
        A.NoOfDaysInArrears,
        A.Type_New,
        A.Freezed1 Freezed,
        A.AssetCl_BR,
        A.Loan_Status1 Loan_Status,
        A.Ageing_Loan,
        CASE WHEN upper(A.Freezed1) = 'Y' and upper(A.AssetCl_BR) not in ('ARC') THEN B.Max_noofdaysINarrears ELSE A.ClientDPD_EXCL_ARC END ClientDPD_EXCL_ARC1,
        CASE
            WHEN (coalesce(ClientDPD_EXCL_ARC1,0)  = 0 OR A.Ageing_Client_EXCL_ARC = 'Current1') AND A.Freezed1 IS NULL THEN NULL
            WHEN lower(A.type_new) in ('closed deals','written off loans','arc_mar21','arc_dec21','arc_feb23','arc_mar23','writeoff_dec22','writeoff_dec23','writeoff_jun22','writeoff_jun23','writeoff_mar22','writeoff_mar23','writeoff_sep23','writeoff_sep22') THEN NULL
            WHEN coalesce(ClientDPD_EXCL_ARC1,0)  = 0 THEN 'Current1'
            WHEN coalesce(ClientDPD_EXCL_ARC1,0) BETWEEN 1 AND 30 THEN '[1 To 30]'
            WHEN coalesce(ClientDPD_EXCL_ARC1,0) BETWEEN 31 AND 60 THEN '[31 To 60]'
            WHEN coalesce(ClientDPD_EXCL_ARC1,0) BETWEEN 61 AND 90 THEN '[61 To 90]'
            WHEN coalesce(ClientDPD_EXCL_ARC1,0) > 90 THEN '[>90]'
            ELSE A.Ageing_Client_EXCL_ARC
        END Ageing_Client_EXCL_ARC,
        CASE WHEN C.PRODUCT_ID IS NOT NULL THEN C.PRODUCT_CATEGORY5 ELSE A.Product_Type END Product_Type1,
        CASE
            WHEN A.InterestRate <> 0 AND (CASE WHEN C.PRODUCT_ID IS NOT NULL THEN C.PRODUCT_CATEGORY5 ELSE Product_Type1 END)  LIKE '%Monthly%' THEN round ( A.LoanAmountDisbursed / ((1-POWER(1/(1+ (((A.InterestRate /cast( 100 as decimal(10,4)) / 12)))), A.Tenure)) / (((A.InterestRate / cast( 100 as decimal(10,4)) / 12)  ))),0)
            WHEN A.InterestRate <> 0 AND (CASE WHEN C.PRODUCT_ID IS NOT NULL THEN C.PRODUCT_CATEGORY5 ELSE Product_Type1 END) NOT LIKE '%Monthly%' THEN round( A.LoanAmountDisbursed / ((1-POWER(1/(1+(((A.InterestRate /cast( 100 as decimal(10,4)) / 365) * 7))), A.Tenure)) / (((A.InterestRate / cast( 100 as decimal(10,4)) / 365) * 7))),0) 
            ELSE A.EWI 
        END EWI,
        CASE WHEN C.PRODUCT_ID IS NOT NULL THEN C.PRODUCT_CATEGORY5 ELSE A.ProductCategory END ProductCategory,
        CASE 
            WHEN A.LoanClosedDate IS not NULL THEN LoanAmountDisbursed + coalesce(UpfrontInterest_vp,0)-coalesce(Cum_PrINcipalColl,0)-coalesce(dIFferenceAmountINPreclosINg,0)-coalesce(RD_AdjustAmt,0)
            ELSE A.ClosedloanwithPos
        END ClosedloanwithPos,
        A.M_PriDue,
        A.M_IntDue,
        A.M_PriColl,
        A.M_IntColl 
    FROM P_DailyLoanfacts_RLMS6 A
    LEFT JOIN T_sha_clientlevel_dpd_RLMS_Daily B
    ON A.clientid = B.Clientid
    LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-dim_productmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) C
    ON C.PRODUCT_ID = A.ProductCode),T_MTDCOll_RLMS_Daily1 AS (
    SELECT
            T.HierarchyId , t.ClientId , T.ClientLoanId,
            SUM(PrincipalAmount)   AS M_PriColl,
            SUM(InterestAmount)   AS M_IntColl
        FROM P_DailyLoanfacts_RLMS7 T
            JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` WHERE ETL_IS_ACTIVE = '1 ' OR ETL_IS_ACTIVE IS NULL) LT 
        ON LT.HierarchyId = T.HierarchyId and LT.CustomerID =t.ClientId and LT.CustomerLoanID = T.ClientLoanId
        WHERE LT.TransactionType = 'C' AND LT.DebitORCredit = 'C' AND LT.ValueDate BETWEEN (current_date - day(current_date) + 1) AND T.CODDate
        GROUP BY T.HierarchyId ,t.ClientId ,T.ClientLoanId),

    T_MTDCOll_RLMS_Daily AS (
    SELECT * FROM 
    (SELECT * FROM T_MTDCOll_RLMS_Daily1)
    UNION ALL
    (SELECT Base.HierarchyId , Base.ClientId , Base.ClientLoanId, 0, 0
        FROM P_DailyLoanfacts_RLMS7 Base 
        LEFT JOIN T_MTDCOll_RLMS_Daily1  A ON Base.ClientLoanID = A.ClientLoanId
        WHERE A.ClientLoanId IS NULL)),

    T_MTDDue_RLMS_Daily1 AS (
    SELECT t.HierarchyId , t.ClientId , t.ClientLoanId,
            SUM(LT.PrINcipalAmount) AS M_PriDue,
            SUM(LT.INterestAmount ) AS M_IntDue
    FROM P_DailyLoanfacts_RLMS7 T
    JOIN (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-loantransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) LT 
    ON LT.HierarchyId = T.HierarchyId AND LT.CustomerID = T.ClientId AND LT.CustomerLoanID = T.ClientLoanId
    WHERE LT.ValueDate BETWEEN (current_date - day(current_date) + 1) AND T.CODDate AND LT.TransactionType = 'C' AND LT.DebitorCredit = 'D'
    GROUP BY  t.HierarchyId ,t.ClientId ,t.ClientLoanId),T_MTDDue_RLMS_Daily AS (
    SELECT * FROM 
    (SELECT * FROM T_MTDDue_RLMS_Daily1)
    UNION ALL
    (SELECT A.HierarchyId , A.ClientId , A.ClientLoanId, 0, 0
    FROM P_DailyLoanfacts_RLMS7 A
    LEFT JOIN T_MTDDue_RLMS_Daily1 B ON A.ClientLoanId = B.ClientLoanId
    WHERE B.ClientLoanId IS NULL))
    SELECT DISTINCT
        A.CODDate,
        A.Branch_Type,
        A.StateName,
        A.Region,
        A.DistrictName,
        A.ZoneName,
        A.Area,
        A.BranchName,
        A.BranchID,
        A.HierarchyId,
        A.ClientLoanId,
        A.ClientLoanCode,
        A.LoanProposalId,
        A.LoanProposalCode,
        A.ProductName,
        A.ProductCode,
        A.ProductDescription,
        A.ClientProductSequenceNo,
        A.ClientId,
        A.ClientCode,
        A.ClientName,
        A.CenterCode,
        A.CenterId,
        A.centername,
        A.CenterMeetingDay,
        A.CenterStaffID,
        A.DisbursementDate,
        A.LoanAmountDisbursed,
        A.ExpectedPaidUPDATE,
        A.LoanClosedDate,
        A.PurposeId,
        A.PurposeName,
        A.HoUSEHoldINcome,
        CAST(A.INterestRate as decimal(25,20)),
        A.DifferenceAmountInPreclosing,
        A.Tenure,
        A.FundName,
        A.FundId,
        A.Caste,
        A.Religion,
        A.`Rural/Urban` Rural_Urban,
        A.DeviationCancel,
        A.LoanCancelleddate,
        A.DisbursementMode,
        A.RepaymentFrequency,
        A.Gender,
        A.DateOfBirth,
        A.JoinDate,
        A.ProposalDate,
        A.ApprovedDate,
        A.LoanAmountApproved,
        A.Groupid,
        A.TargetId,
        A.TargetCode,
        A.TargetDate,
        A.IsLoanClosed,
        A.UpfrontInterest_vp,
        CAST(A.NPAStatus_vp as STRING),
        A.Moratorium_flag,
        A.DeathDate,
        A.Cum_PrincipalColl,
        A.Cum_InterestColl,
        A.Cum_Pridue,
        A.Cum_IntDue,
        A.PrincipalWrittenoff,
        A.InterestWrittenoff,
        CAST(A.TransactionDate as timestamp),
        A.Total_PrincipalDue,
        A.Total_InterestDue,
        A.RD_AdjustAmt,
        A.POS,
        A.IOS,
        A.PrincipalInArears,
        A.InterestInArears,
        A.LAStRepaymentDate,
        A.M_Flag,
        A.Last_CMDate,
        CAST(A.DPDStartdate as timestamp),
        A.NoOfDaysInArrears,
        A.Type_New,
        A.Freezed,
        A.AssetCl_BR,
        A.Loan_Status,
        A.Ageing_Loan,
        A.ClientDPD_EXCL_ARC1 ClientDPD_EXCL_ARC,
        A.Ageing_Client_EXCL_ARC,
        A.Product_Type1 Product_Type,
        A.EWI,
        A.ProductCategory,
        A.ClosedloanwithPos,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN coalesce(B.M_PriDue,0) ELSE A.M_PriDue END M_PriDue,
        CASE WHEN B.ClientLoanid IS NOT NULL THEN coalesce(B.M_IntDue,0) ELSE A.M_IntDue END M_IntDue,
        CASE WHEN C.ClientLoanid IS NOT NULL THEN coalesce(C.M_PriColl,0) ELSE A.M_PriColl END M_PriColl,
        CASE WHEN C.ClientLoanid IS NOT NULL THEN coalesce(C.M_IntColl,0) ELSE A.M_IntColl END M_IntColl
    FROM P_DailyLoanfacts_RLMS7 A
    LEFT JOIN T_MTDDue_RLMS_Daily B
    ON A.ClientLoanID = B.ClientLoanid
    LEFT JOIN T_MTDCOll_RLMS_Daily C
    ON A.ClientLoanID = C.ClientLoanid""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))


# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"dailyloanfacts_rlms Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on dailyloanfacts_rlms: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on dailyloanfacts_rlms : ", str(e))

# COMMAND ----------

try :
    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.dailyloanfacts_rlms")

    logger(
            logger_level_info,
            f"dailyloanfacts_rlms writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table dailyloanfacts_rlms : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table dailyloanfacts_rlms : ", str(e))