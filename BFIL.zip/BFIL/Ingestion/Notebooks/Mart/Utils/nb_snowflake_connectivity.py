# Databricks notebook source
# Retrieve Snowflake connection string from Azure Key Vault
connection_string = dbutils.secrets.get(scope="AKV_secret_scope", key="BFIL-SNOWFLAKE-ETL-ADMIN")
snowflake_url = dbutils.secrets.get(scope="AKV_secret_scope", key="SNOWFLAKE-URL")

# Snowflake connection options
options = {
    "sfURL": snowflake_url,
    "sfUser": "ETL_ADMIN_USER",
    "sfPassword": connection_string,
    "sfDatabase": "BFIL",
    "sfSchema": mart_schema,
    "sfWarehouse": "ETL_WH"
}