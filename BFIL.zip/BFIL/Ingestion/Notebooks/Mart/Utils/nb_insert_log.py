# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_query_on_synapse"

# COMMAND ----------

# DBTITLE 1,synapse connections
def synapse_jdbc_connectivity(adb_synapse_connection_string):
    try:
        adb_secret_scope_name = "AKV_secret_scope"
        # For creating connection between databricks to synapse
        synapse_jdbc_url = create_databricks_to_synapse_connection(adb_secret_scope_name, adb_synapse_connection_string)
        
        if synapse_jdbc_url is not None :
            # Configure connection between Databricks to Synapse
            filename = "Insert_log"
            logger(logger_level_info, f"The configuration of the connection between Databricks and Synapse has been successfully completed.", execution_log_list, filename)
            return synapse_jdbc_url
            
    except Exception as e:
        filename = "Insert_log"
        logger(logger_level_error, f"An error occurred in the nb_synapse_connectivity notebook: {str(e)}", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception("An error occurred in the nb_synapse_connectivity notebook:", str(e))

# COMMAND ----------

# DBTITLE 1,Create Dataframe
def Create_data_frame(src_object_id,end_timestamp,duration_seconds,run_id,log_status,error):
    try:
        schema = StructType([
            StructField("exec_batch_id", StringType(), True),  ## no need null
            StructField("src_object_id", StringType(), True),
            StructField("layer_name", StringType(), True),
            StructField("start_datetime", StringType(), True),
            StructField("end_datetime", StringType(), True),
            StructField("task_duration", StringType(), True),
            StructField("status", StringType(), True),
            StructField("load_from_date", StringType(), True),  
            StructField("load_to_date", StringType(), True), 
            StructField("load_from_id", StringType(), True),  ## no need null
            StructField("load_to_id", StringType(), True),  ## no need null
            StructField("pipeline_name", StringType(), True),
            StructField("pipeline_runid", StringType(), True),
            StructField("pipeline_trigger_name", StringType(), True), ## will check
            StructField("triggered_by_pipeline", StringType(), True), ## no need null
            StructField("source_row_count", StringType(), True),
            StructField("destination_row_count", StringType(), True),
            StructField("error_log", StringType(), True), # NO_ERROR
            StructField("cons_tbl_name", StringType(), True) ## no need null
        ])
        
        # Sample data
        data = [
            (None,f"{src_object_id}","MART",f"{start_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')}",f"{end_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')}",f"{duration_seconds}",f"{log_status}","1990-01-01T00:00:00Z",f"{end_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')}",None,None,"wf_realtime_pragati_live",f"{run_id}","Sandbox",None,f"{source_row_count}",f"{destination_row_count}",error,None)
        ]

        # Create DataFrame
        df_logs = spark.createDataFrame(data, schema)
        return df_logs
    
    except Exception as e:
        filename = "Insert_log"
        logger(logger_level_info, f"Error while creating data frame : {str(e)} ", execution_log_list, filename) 
        raise Exception("Error while creating data frame : ", str(e))

# COMMAND ----------

# DBTITLE 1,insert log in log table
def append_df_in_log_table(df_log,adb_synapse_connection_string,synapse_schema):
    try:
        scope_name = "AKV_secret_scope"
        synapse_jdbc_url = dbutils.secrets.get(scope=scope_name, key=adb_synapse_connection_string) 
        table_name = f"{synapse_schema}.pl_exec_log"

        # Write the data to the table using the JDBC connection and append mode
        df_log.write \
            .format("jdbc") \
            .option("url", synapse_jdbc_url) \
            .option("dbtable", table_name) \
            .mode("append") \
            .save()
            
    except Exception as e:
        filename = "Insert_log"
        logger(logger_level_info, f"Error inserting log in log table : {str(e)} ", execution_log_list, filename) 
        raise Exception("Error inserting log in log table : ", str(e))

# COMMAND ----------

def insert_log(run_id,table_name,log_status,synapse_catalog,synapse_schema,adb_synapse_connection_string,error):
    try:
        synapse_jdbc_url = synapse_jdbc_connectivity(adb_synapse_connection_string)
        filter_condition = (
           ( col("target_object_name") == f"{table_name}" )
        )  
        config_column_list = ["src_object_id"]
        table_list = get_query_result_from_synapse(synapse_jdbc_url, synapse_schema, config_table_name, config_column_list, filter_condition)
        src_object_id = table_list.select('src_object_id').collect()[0][0]

        end_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))

        # Calculate the duration by subtracting end_time from start_time
        duration = end_timestamp - start_timestamp
        duration_seconds = int(duration.total_seconds())
        
    except Exception as e:
        filename = "Insert_log"
        logger(logger_level_info, f"Error while fetching src_object_id : {str(e)} ", execution_log_list, filename) 
        raise Exception("Error while fetching src_object_id : ", str(e))

    df_log = Create_data_frame(src_object_id,end_timestamp,duration_seconds,run_id,log_status,error)
    append_df_in_log_table(df_log,adb_synapse_connection_string,synapse_schema)