# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_create_monthly_bkp.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    # Calculate the current month
    month_date = (datetime.now() - timedelta(days=1)).strftime("%b%Y")
    # Construct path for table to be backed up
    backup_table_folder_path_daywise = f"BFIL/AZURESOURCE/P_LOANFACTS_{month_date}"
    backup_path_daywise = mart_layer_abfss_url + backup_table_folder_path_daywise.upper()
    backup_table_folder_path_clientwise = (
        f"BFIL/AZURESOURCE/P_LOANFACTS_CLIENT_{month_date}"
    )
    backup_path_clientwise = mart_layer_abfss_url + backup_table_folder_path_clientwise.upper()

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query_loanfacts_daywise = """select * from {source_catalog}.{source_schema}.`azuresource-p_loanfacts`;""".format(
        source_catalog=source_catalog,
        source_schema=source_schema,
    )

    query_loanfacts_clientwise = """SELECT * FROM {source_catalog}.{source_schema}.`azuresource-p_loanfacts_client`;""".format(
        source_catalog=source_catalog,
        source_schema=source_schema,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df_loanfacts_daywise = spark.sql(query_loanfacts_daywise).repartition(50).cache()
    df_loanfacts_clientwise = spark.sql(query_loanfacts_clientwise).repartition(50).cache()

    logger(
        logger_level_info,
        f"nb_create_monthly_bkp Query has been successfully completed.{backup_path_daywise}",
        execution_log_list,
        filename,
    )

    logger(
        logger_level_info,
        f"nb_create_monthly_bkp Query has been successfully completed.{backup_path_clientwise}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_create_monthly_bkp: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_create_monthly_bkp : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :
    # Construct the table name
    table_name_daywise = f"`azuresource-p_loanfacts_{month_date}`"
    df_loanfacts_daywise.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",backup_path_daywise).saveAsTable(f"{source_catalog}.{source_schema}.{table_name_daywise}")

    # Construct the table name
    table_name_clientwise = f"`azuresource-p_loanfacts_client_{month_date}`"
    df_loanfacts_clientwise.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",backup_path_clientwise).saveAsTable(f"{source_catalog}.{source_schema}.{table_name_clientwise}")

    logger(
            logger_level_info,
            f"nb_create_monthly_bkp writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_create_monthly_bkp : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_create_monthly_bkp : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df_loanfacts_daywise.unpersist()
df_loanfacts_clientwise.unpersist()