# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_tw_disbdata_pos.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/TW_DISBDATA_POS"
    desti_path = "BFIL-MART/REPORTING/TW_DISBDATA_POS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """with 3itpos as (
    SELECT A.ZONE ZoneName ,A.State StateName ,A.Region ,A.`AREA` Area
    ,A.`UMBaseLocationBranchName` UnitOffice ,CLP.FundId
    ,A.BRANCHID ,A.`BranchName` ,a.HierarchyId ,CLP.LoanProposalCode
    , CLS.LoanProposalId  ,CM.ClientId ,CLS.ClientLoanId ,CLS.ClientLoanCode
    ,CM.ClientCode ,CM.ClientName ,CO.Centerid ,CO.CenterCode ,
    b.POS,
b.NoofDaysInArrears1 as NoofDaysInArrear,
b.PrincipalInArears as PrincipleInArrear,
b.InterestInArears as InterestInArrear,
b.EWI,
b.M_FLAG,
b.DeathDate as IsDeath,
b.LastRepaymentDate as Last_Repayment_Date ,
    (CASE 
      WHEN CO.CenterMeetingDay = 1 THEN 'Monday'
      WHEN CO.CenterMeetingDay = 2 THEN 'Tuesday' 
      WHEN CO.CenterMeetingDay = 3 THEN 'Wednesday' 
      WHEN CO.CenterMeetingDay = 4 THEN 'Thursday' 
    ELSE 'Friday' END)  AS CenterMeetingDay
    ,CS.Status CenterStatus ,x.OGL_PRODUCT_CODE ,CLS.ClientProductSequenceNo
    ,CLS.DisbursementDate ,CLS.LoanAmountDisbursed ,CLP.ProposalStatus AS CBSTATUS ,CLP.WorkFlowStatus AS BMAPPROVALSTATUS
    ,CLP.Proposaldate ,CLS.CreatedBy AS StaffID ,D.UserName AS StaffName ,CLS.LoanClosedDate ,cls.ExpectedPaidupDate
  FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` AS CLS
    JOIN {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` AS CLP ON CLS.LoanProposalId = CLP.LoanProposalId
    JOIN {source_catalog}.{source_schema}.`pragati-clientmaster` AS CM ON CM.ClientId=CLS.ClientId
    JOIN {source_catalog}.{source_schema}.`pragati-groupmaster` AS C ON CM.GroupId = C.GroupId
    JOIN {source_catalog}.{source_schema}.`pragati-centermaster` AS CO ON C.CenterId = CO.CenterId
    LEFT JOIN {source_catalog}.{source_schema}.`azuresource-statuscurrentcenters` AS CS ON CO.CenterId = CS.CenterSmartID
    JOIN {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` AS DPM ON CLS.ProductId = DPM.DerivedProductId
    JOIN {source_catalog}.{source_schema}.`ptsmart-productmaster` AS PM ON DPM.ProductId = PM.ProductId
    left JOIN {source_catalog}.{source_schema}.`azuresource-dim_productmaster` AS x ON PM.Productcode = x.Product_Id
    LEFT JOIN {source_catalog}.{source_schema}.`pragatimain-usermaster` AS D ON CLS.CreatedBy=D.UserID
    LEFT JOIN {mart_catalog}.{mart_schema}.`p_hierarchy_sop` AS A ON A.HierarchyId=CLS.HierarchyId
    LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts AS B ON CLS.ClientLoanID=B.ClientLoanID -- Commented this line since script is pending
    LEFT JOIN {source_catalog}.{source_schema}.`consumerloan-tbl_tw_stock` AS T ON CLS.LoanProposalId=T.LoanproposalId -- Commented this line since script is pending
  WHERE x.PRODUCT_CATEGORY1 in ('Two Wheelers','TW loyalty') and (ClS.ETL_IS_ACTIVE = 1 or ClS.ETL_IS_ACTIVE is Null) and (cm.ETL_IS_ACTIVE = 1 or cm.ETL_IS_ACTIVE is Null) and (c.ETL_IS_ACTIVE = 1 or c.ETL_IS_ACTIVE is Null) and (co.ETL_IS_ACTIVE = 1  or co.ETL_IS_ACTIVE is Null )and (cs.ETL_IS_ACTIVE = 1 or cs.ETL_IS_ACTIVE is Null) 
  and (DPM.ETL_IS_ACTIVE = 1 or DPM.ETL_IS_ACTIVE is Null)
   --and X.ETL_IS_ACTIVE = 1 
  and (d.ETL_IS_ACTIVE = 1 or d.ETL_IS_ACTIVE is Null)
 --and a.ETL_IS_ACTIVE = 1 
 --and  b.ETL_IS_ACTIVE = 1 
  and (t.ETL_IS_ACTIVE = 1 or t.ETL_IS_ACTIVE is Null)
  and (CLP.ETL_IS_ACTIVE = 1 or CLP.ETL_IS_ACTIVE is Null)
  and (pm.ETL_IS_ACTIVE = 1 or pm.ETL_IS_ACTIVE is Null)
  and (d.ETL_IS_ACTIVE = 1 or d.ETL_IS_ACTIVE is Null)
)

--select Distinct proposaldate,Count(LoanProposalID) as NOOFProposals from 3itpos group by Proposaldate

select distinct LoanProposalId,ZoneName,
StateName,
Region,
Area,
UnitOffice,
FundId,
BRANCHID,
BranchName,
HierarchyId,
LoanProposalCode,
ClientId,
ClientLoanId,
ClientLoanCode,
ClientCode,
ClientName,
Centerid,
CenterCode,
POS,
NoofDaysInArrear,
PrincipleInArrear,
InterestInArrear,
EWI,
M_FLAG,
IsDeath,
Last_Repayment_Date,
CenterMeetingDay,
CenterStatus,
OGL_PRODUCT_CODE,
ClientProductSequenceNo,
DisbursementDate,
LoanAmountDisbursed,
CBSTATUS,
BMAPPROVALSTATUS,
Proposaldate,
StaffID,
StaffName,
LoanClosedDate,
ExpectedPaidupDate  from 3itpos  ;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"tw_disbdata_pos Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on tw_disbdata_pos: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on tw_disbdata_pos : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.tw_disbdata_pos")

    logger(
            logger_level_info,
            f"tw_disbdata_pos writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table tw_disbdata_pos : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table tw_disbdata_pos : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "tw_disbdata_pos").mode("overwrite").save()
    logger(
            logger_level_info,
            f"tw_disbdata_pos writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table tw_disbdata_pos : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table tw_disbdata_pos : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)