# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_tw_itlogin.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/TW_ITLOGIN"
    desti_path = "BFIL-MART/REPORTING/TW_ITLOGIN"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """with P_Vraju_TW_VendorMaster AS (
  SELECT CAST(b.BranchID as STRING) , c.BranchName , c.Region , c.Area , c.ZoneName , c.StateName
        , CAST(a.VendorID as STRING) , a.Branch_Name VendorName , b.Make AS `Vechicle Brand` , a.UserName , a.Password , A.EmailID
  FROM  {source_catalog}.{source_schema}.`consumerloan-login` a
      INNER JOIN  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_vendorbranchmapping` b ON a.VendorID=b.VendorID
      INNER JOIN  {source_catalog}.{source_schema}.`consumerloan-p_hierarchy`c ON c.BranchID=b.BranchID
  WHERE a.vendorid IS NOT NULL and a.ETL_IS_ACTIVE = 1 or a.ETL_IS_ACTIVE is null  and b.ETL_IS_ACTIVE = 1 or b.ETL_IS_ACTIVE is Null and c.ETL_IS_ACTIVE = 1 or c.ETL_IS_ACTIVE is Null
  ORDER BY BranchID
),

 T_Nar_allclients AS (
    select ClientId,TargetId
  from  {source_catalog}.{source_schema}.`ptsmart-clientmaster` where ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_Aadhar AS (
    select  b.TargetId,CreatedBy as Aadhar_Cby,CreatedDateTime as Aadhar_Cdate,UpdatedBy as Aadhar_Uby,UpdatedDateTime as Aadhar_UDate,KYCType as aadharid,KYCNumber  as AadharCard,DateOfBirth as Dob_aadhar,KYCIssueDate as Aadhar_issuedate 
    from T_Nar_allclients a
    JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b  on a.TargetId=b.TargetId
    where ClientOrSpouse='M' and KYCType='IDP6'  and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_Voter AS (
    select b.TargetId,CreatedBy as Voter_Cby,CreatedDateTime as Voter_Cdate,UpdatedBy as Voter_Uby,UpdatedDateTime as Voter_UDate,KYCType as voterid,KYCNumber as voterCard,DateOfBirth as Dob_Voter,KYCIssueDate as Voter_issuedate
    from T_Nar_allclients A
    JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b on b.TargetId=A.TargetId
    where ClientOrSpouse='M' and KYCType='IDP8'  and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_Ration AS (
    select b.TargetId,CreatedBy as Ration_Cby,CreatedDateTime as Ration_Cdate,UpdatedBy as Ration_Uby,UpdatedDateTime as Ration_UDate,KYCType as RationId,KYCNumber as RationCard,KYCIssueDate as Ration_issuedate
    from  T_Nar_allclients A
    join  {source_catalog}.{source_schema}.`pragati-kycmaster` b  on A.TargetId=b.TargetId
    where  b.TargetId=A.TargetId and ClientOrSpouse='M' and KYCType='APD8' and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_PAN AS (
    select b.TargetId,CreatedBy as Pan_Cby,CreatedDateTime as Pan_Cdate,UpdatedBy as Pan_Uby,UpdatedDateTime as Pan_UDate,KYCType as Panid,
    KYCNumber as PanCard,KYCIssueDate as Pan_issuedate
    from T_Nar_allclients A join  {source_catalog}.{source_schema}.`pragati-kycmaster` b on  b.TargetId=A.TargetId
    where  ClientOrSpouse='M' and KYCType='IDP1'  and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_Driving AS (
    select b.TargetId,CreatedBy as Driving_Cby,CreatedDateTime as Driving_Cdate,UpdatedBy as Driving_Uby,UpdatedDateTime as Driving_UDate,KYCType as Drivingid,KYCNumber as `Driving License`,KYCIssueDate as Driving_issuedate 
    from T_Nar_allclients A
    JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b
    on b.TargetId=A.TargetId
    where ClientOrSpouse='M' and KYCType='IDP2'  and b.ETL_IS_ACTIVE = 1

  ),

  T_Nar_allclients_Passport AS (
    select b.TargetId,CreatedBy as Passport_Cby,CreatedDateTime as Passport_Cdate,UpdatedBy as Passport_Uby,UpdatedDateTime as Passport_UDate,KYCType as Passportid,KYCNumber as Passport,KYCIssueDate as Passport_issuedate
    from T_Nar_allclients A
    JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b
    on  b.TargetId=A.TargetId
    where ClientOrSpouse='M' and KYCType='IDP3'  and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_idcard AS (
    select b.TargetId,CreatedBy as POId_Createdby,CreatedDateTime as POId_Cdate,UpdatedBy as POId_Uby,UpdatedDateTime as POId_UDate,KYCType as postifficeid,KYCNumber as `ID Card issued By Post Office`,KYCIssueDate as idcard_issuedate
    from T_Nar_allclients A
    JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b
    on  b.TargetId=A.TargetId
    where ClientOrSpouse='M' and KYCType='IDP4'  and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_JobID AS (
    select b.TargetId,CreatedBy as JobID_Createdby,CreatedDateTime as JobID_Cdate,UpdatedBy as JobID_Uby,UpdatedDateTime as JobID_UDate,KYCType as govid,KYCNumber as `Job/Work card Issued by Govt`,KYCIssueDate as jobcard_issuedate
    from T_Nar_allclients A
    JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b
    on  b.TargetId=A.TargetId
    where ClientOrSpouse='M' and KYCType='IDP5'  and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_BPL AS (
    select b.TargetId,CreatedBy as BPL_Createdby,CreatedDateTime as BPL_Cdate,UpdatedBy as BPL_Uby,UpdatedDateTime as BPL_UDate,KYCType as Bplid,KYCNumber as `BPL Card`,KYCIssueDate as BPL_issuedate
    from T_Nar_allclients A
    JOIN   {source_catalog}.{source_schema}.`pragati-kycmaster` b
    on  b.TargetId=A.TargetId
    where ClientOrSpouse='M' and KYCType='IDP7' and  b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_EmpLicCard AS (
    select b.TargetId,CreatedBy as EmpLicCard_Createdby,CreatedDateTime as EmpLicCard_Cdate,UpdatedBy as EmpLicCard_Uby,UpdatedDateTime as EmpLicCard_UDate,KYCType as EMPLOYEEID,KYCNumber as `EMPLOYEE  LICENSE CARD`,KYCIssueDate as Eplcard_issuedate
    from T_Nar_allclients A
    JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b
    on  b.TargetId=A.TargetId
    where ClientOrSpouse='M' and KYCType='APD6'  and b.ETL_IS_ACTIVE = 1
  ),

  T_Nar_allclients_documents AS (
    select a.targetid
    ,Aadhar_Cby,Aadhar_Cdate,Aadhar_Uby,Aadhar_UDate,Aadharid,AadharCard,Dob_aadhar,Aadhar_issuedate
    ,Voter_Cby,Voter_Cdate,Voter_Uby,Voter_UDate,voterid,voterCard,Dob_Voter,Voter_issuedate
    ,Ration_Cby,Ration_Cdate,Ration_Uby,Ration_UDate,RationId,RationCard,Ration_issuedate
    ,Pan_Cby,Pan_Cdate,Pan_Uby,Pan_UDate,Panid,PanCard,Pan_issuedate
    ,Driving_Cby,Driving_Cdate,Driving_Uby,Driving_UDate,Drivingid,`Driving License`,Driving_issuedate
    ,Passport_Cby,Passport_Cdate,Passport_Uby,Passport_UDate,Passportid,Passport,Passport_issuedate
    ,POId_Createdby,POId_Cdate,POId_Uby,POId_UDate,postifficeid,`ID Card issued By Post Office`,idcard_issuedate
    ,JobID_Createdby,JobID_Cdate,JobID_Uby,JobID_UDate,govid,`Job/Work card Issued by Govt`,jobcard_issuedate
    ,BPL_Createdby,BPL_Cdate,BPL_Uby,BPL_UDate,Bplid,`BPL Card`,BPL_issuedate
    ,EmpLicCard_Createdby,EmpLicCard_Cdate,EmpLicCard_Uby,EmpLicCard_UDate,EMPLOYEEID,`EMPLOYEE  LICENSE CARD`,Eplcard_issuedate
    FROM T_Nar_allclients  A
    left JOIN T_Nar_allclients_Aadhar B on A.TargetID=B.Targetid
    left JOIN T_Nar_allclients_Voter C  on A.TargetID=C.Targetid
    left JOIN T_Nar_allclients_Ration D on A.TargetID=D.Targetid
    left JOIN T_Nar_allclients_PAN E on A.TargetID=E.Targetid
    left JOIN T_Nar_allclients_Driving F on A.TargetID=F.Targetid
    left JOIN T_Nar_allclients_Passport G on A.TargetID=G.Targetid
    left JOIN T_Nar_allclients_idcard H on A.TargetID=H.Targetid
    left JOIN T_Nar_allclients_JobID I on A.TargetID=I.Targetid
    left JOIN T_Nar_allclients_BPL J on A.TargetID=J.Targetid
    left JOIN T_Nar_allclients_EmpLicCard K on A.TargetID=K.Targetid
  ),
  
  T_Nar_allclients_maxid_mobile AS (
    select a.ClientId,a.TargetId,MAX(b.SequenceId) as maxseqid 
    from T_Nar_allclients a
    join  {source_catalog}.{source_schema}.`pragati-kycdetails` b
    on a.TargetId=b.TargetId
    where  b.ETL_IS_ACTIVE = 1
    group by a.ClientId,a.TargetId
  ),

  T_Nar_allclients_mobile AS (
    select a.TargetId,b.ClientDateOfBirth,b.SpouseDateOfBirth,CorrespondenceHouseNumber,CorrespondenceStreet1,CorrespondenceStreet2,CorrespondenceLandMark,CorrespondenceVillage,CorrespondencePanchayat,CorrespondenceTown,CorrespondenceAddressLine1,CorrespondenceAddressLine2,CorrespondencePincode,CorrespondenceDistrict,b.MobileNumber,b.PhoneNumber
    from T_Nar_allclients_maxid_mobile a
    join  {source_catalog}.{source_schema}.`pragati-kycdetails` b 
    on a.TargetId=b.TargetId and a.maxseqid=b.SequenceId  where  b.ETL_IS_ACTIVE = 1
  ),

  P_allKycs_all AS (
    select distinct a.ClientId,b.*,ClientDateOfBirth,SpouseDateOfBirth,CorrespondenceHouseNumber,CorrespondenceStreet1,CorrespondenceStreet2,CorrespondenceLandMark,CorrespondenceVillage,CorrespondencePanchayat,CorrespondenceTown,CorrespondenceAddressLine1,CorrespondenceAddressLine2,CorrespondencePincode,CorrespondenceDistrict,cast(null as STRING) As CKYC_ID,c.MobileNumber,c.PhoneNumber
    from T_Nar_allclients a
    left join T_Nar_allclients_documents b
    on a.TargetId=b.TargetId
    left join T_Nar_allclients_mobile c
    on c.TargetId=a.TargetId
  ),

  p_TwoWheeler_Rejectiondata_Final as  (SELECT a.ClientId,a.targetid,a.Aadhar_Cby,a.Aadhar_Cdate,a.Aadhar_Uby,a.Aadhar_UDate,a.Aadharid,a.AadharCard,a.Dob_aadhar,a.Aadhar_issuedate,a.Voter_Cby,a.Voter_Cdate,a.Voter_Uby,a.Voter_UDate,a.voterid,a.voterCard,a.Dob_Voter,a.Voter_issuedate,a.Ration_Cby,a.Ration_Cdate,a.Ration_Uby,a.Ration_UDate,a.RationId,a.RationCard,a.Ration_issuedate,a.Pan_Cby,a.Pan_Cdate,a.Pan_Uby,a.Pan_UDate,a.Panid,a.PanCard,a.Pan_issuedate,a.Driving_Cby,a.Driving_Cdate,a.Driving_Uby,a.Driving_UDate,a.Drivingid,a.`Driving License` Driving_License,a.Driving_issuedate,a.Passport_Cby,a.Passport_Cdate,a.Passport_Uby,a.Passport_UDate,a.Passportid,a.Passport,a.Passport_issuedate,a.POId_Createdby,a.POId_Cdate,a.POId_Uby,a.POId_UDate,a.postifficeid,a.`ID Card issued By Post Office` ID_Card_issued_By_Post_Office,a.idcard_issuedate,a.JobID_Createdby,a.JobID_Cdate,a.JobID_Uby,a.JobID_UDate,a.govid,a.`Job/Work card Issued by Govt` Job_Work_card_Issued_by_Govt,a.jobcard_issuedate,a.BPL_Createdby,a.BPL_Cdate,a.BPL_Uby,a.BPL_UDate,a.Bplid,a.`BPL Card` BPL_Card,a.BPL_issuedate,a.EmpLicCard_Createdby,a.EmpLicCard_Cdate,a.EmpLicCard_Uby,a.EmpLicCard_UDate,a.EMPLOYEEID,a.`EMPLOYEE  LICENSE CARD` EMPLOYEE_LICENSE_CARD,a.Eplcard_issuedate,CASE WHEN a.ClientDateOfBirth is null and b.ClientOrSpouse='M' and b.KYCType='IDP6' THEN b.DateOfBirth ELSE a.ClientDateOfBirth END ClientDateOfBirth,a.SpouseDateOfBirth,a.CorrespondenceHouseNumber,a.CorrespondenceStreet1,a.CorrespondenceStreet2,a.CorrespondenceLandMark,a.CorrespondenceVillage,a.CorrespondencePanchayat,a.CorrespondenceTown,a.CorrespondenceAddressLine1,a.CorrespondenceAddressLine2,a.CorrespondencePincode,a.CorrespondenceDistrict,CASE WHEN c.CKYCID is not null THEN c.CKYCID ELSE a.CKYC_ID END CKYC_ID,a.MobileNumber,a.PhoneNumber
  from P_allKycs_all a
  LEFT OUTER JOIN  {source_catalog}.{source_schema}.`pragati-kycmaster` b
  ON A.TargetId=B.TargetId
  LEFT OUTER JOIN  {source_catalog}.{source_schema}.`azuresource-tbl_bfilckycmis_clientwise` c
  ON a.ClientId = c.ClientId  where  b.ETL_IS_ACTIVE = 1 and c.ETL_IS_ACTIVE = 1
),

T_sun_TWOwheeler_Rejectionsdata1 AS (
    select a.hierarchyid, a.clientid, a.LoanProposalId, a.ProposalDate,
        a.CBUpdateId,b.CBResponseId, pm.ProductName, a.ProductId, pm.productcode, b.CBStatus,
        cast(Null as timestamp) as CBresponsedate,
        cast(Null as timestamp) as CBsubmitteddate,
        cast(NUll  as varchar(100)) as Retailstatus,
        cast(0  as Float) as FOIR,
        cast(NULL as string) as EligibilityStatus,
        cast(0 as Float) as EligibleAmount,
        cast(NULL  as string) as ActiveTWOwheeler_Applicant,
        cast(0  as Float) as Overdue_Applicant,
        cast(0  as int) as NoofDefaultAccount_Applicant,
        cast(0  as Float) as TotalExposure_Applicant,
        cast(NULL  as string) as ActiveTWOwheeler_COApplicant,
        Cast(0  as float) as Overdue_COApplicant,
        Cast(0  as int) as NoofDefaultAccount_COApplicant,
         Null as FinalCBRemark,
        cast('' as string) as TotalFinal_CBRemarks
    From (select hierarchyid, clientid, LoanProposalId, ProposalDate,
        CBUpdateId,ProductId FROM  {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` where (cast(proposaldate as date) = cast((current_date - 1) as date) or cast(CreatedDateTime as date)=cast((current_date - 1) as date)) and ProductType is null) a
        left join (SELECT CBStatus,CBResponseId,LoanProposalId,CBUpdateId FROM  {source_catalog}.{source_schema}.`pragati-creditbureauupdate`) b on a.LoanProposalId=b.LoanProposalId and a.CBUpdateId=b.CBUpdateId
        left join (SELECT DerivedProductId,ProductId FROM  {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster`) dpm on dpm.DerivedProductId=a.ProductId
        left join (SELECT ProductId,ProductName,productcode FROM  {source_catalog}.{source_schema}.`pragati-productmaster`) pm on pm.ProductId=dpm.ProductId
    where pm.ProductName like '%TWO%' --and a.ETL_IS_ACTIVE = 1 
    --and b.ETL_IS_ACTIVE = 1 
    --and dpm.ETL_IS_ACTIVE = 1
     --and pm.ETL_IS_ACTIVE = 1
),






T_sun_TWOwheeler_Rejectionsdata2 AS
(SELECT 
    a.hierarchyid,
    a.clientid,
    a.LoanProposalId,
    a.ProposalDate,
    a.CBUpdateId,
    TRIM(CASE 
        WHEN coalesce(a.cbresponseid,'0')='0' THEN b.cbresponseid
        WHEN coalesce(a.cbresponseid,'')='' THEN b.cbresponseid
        WHEN coalesce(a.cbresponseid,'0')='0' THEN c.cbresponseid
        WHEN a.cbresponseid='' THEN c.cbresponseid
        WHEN coalesce(a.cbresponseid,'0')='0' THEN d.CBReportId
        WHEN a.cbresponseid='' THEN d.CBReportId
        ELSE a.cbresponseid
    END) CBResponseId,
    a.ProductName,
    a.ProductId,
    a.productcode,
    a.CBStatus,
    e.DATE_OF_ISSUE CBresponsedate,
    h.DateCreated CBsubmitteddate,
    CASE 
        WHEN e.CB_Type ='Retail' and string(e.STATUS) in ('10','11') THEN 'Hit'
        WHEN a.Retailstatus IS NULL THEN 'Nohit'
    END Retailstatus,
    f.MaxEMI FOIR,
    g.EligibilityStatus,
    g.EligibleAmount,
    CASE 
        WHEN lower(e.cb_type) in ('retail') and lower(e.account_status) Not like '%closed%' and upper(e.ACCOUNT_TYPE) like '%TWO%' THEN 'Yes'
        WHEN a.ActiveTWOwheeler_Applicant IS NULL THEN 'No'
    END ActiveTWOwheeler_Applicant,
    a.Overdue_Applicant,
    a.NoofDefaultAccount_Applicant,
    a.TotalExposure_Applicant,
    a.ActiveTWOwheeler_COApplicant,
    a.Overdue_COApplicant,
    a.NoofDefaultAccount_COApplicant,
    a.FinalCBRemark,
    a.TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata1 a
left join (SELECT loanproposalid,cbresponseid FROM  {source_catalog}.{source_schema}.`pragati-preapprovedproposal`) b on a.loanproposalid=b.loanproposalid
left join (SELECT loanproposalid,cbresponseid FROM  {source_catalog}.{source_schema}.`pragati-surakshapreapprovedproposal`) c on a.loanproposalid=c.loanproposalid
left join (SELECT loanproposalid,CBReportId FROM  {source_catalog}.{source_schema}.`pragati-instantloanproposal`) d on a.loanproposalid=d.loanproposalid
LEFT JOIN (SELECT DataKey,CB_Type,STATUS,ACCOUNT_STATUS,
ACCOUNT_TYPE,
DATE_OF_ISSUE FROM  {source_catalog}.{source_schema}.`consumerloan-rawdatareceivedbycbteam_retail`) e on a.cbresponseid=cast(DataKey as STRING)
LEFT JOIN (SELECT MaxEMI,DataKey FROM  {source_catalog}.{source_schema}.`consumerloan-tbl_hhi_details`) f
ON a.cbresponseid=f.datakey
LEFT JOIN (SELECT ReportId,EligibilityStatus,EligibleAmount FROM  {source_catalog}.{source_schema}.`consumerloan-tbl_twresponsesummary`) g
ON a.cbresponseid=g.reportid
LEFT JOIN (SELECT DataKey,DateCreated FROM  {source_catalog}.{source_schema}.`consumerloan-cb_submission_retail`) h
ON a.cbresponseid=h.DataKey --where 
--(b.ETL_IS_ACTIVE = 1 and b.ETL_IS_ACTIVE is Null) 
--and
--(c.ETL_IS_ACTIVE = 1 and  c.ETL_IS_ACTIVE is Null) and
--(d.ETL_IS_ACTIVE = 1 and  d.ETL_IS_ACTIVE is Null) and
--(e.ETL_IS_ACTIVE = 1 and  e.ETL_IS_ACTIVE is Null) and
--(f.ETL_IS_ACTIVE = 1 and f.ETL_IS_ACTIVE is Null) and
--(g.ETL_IS_ACTIVE = 1 and g.ETL_IS_ACTIVE is Null)

 ),

Overdue_Applicant AS (
    SELECT 
        foo.cbresponseid, 
        foo.Overdue_Applicant
    FROM
    (select A.cbresponseid, SUM(coalesce(b.OVERDUE_AMT,'0')) as Overdue_Applicant
    from T_sun_TWOwheeler_Rejectionsdata2 a
        join (SELECT DataKey,CB_Type,STATUS,ACCOUNT_STATUS,ACCOUNT_TYPE,DATE_OF_ISSUE,OVERDUE_AMT FROM  {source_catalog}.{source_schema}.`consumerloan-rawdatareceivedbycbteam_retail`) b on a.cbresponseid = b.datakey
    where lower(b.cb_type) <> 'coretail' and int(b.OVERDUE_AMT) > 0
    group by a.cbresponseid) foo
    LEFT JOIN T_sun_TWOwheeler_Rejectionsdata2 b
    ON foo.cbresponseid = b.cbresponseid
),

NoofDefaultAccount_Applicant AS (
    select distinct a.cbresponseid, count(b.ACCOUNT_STATUS) as NoofDefaultAccount_Applicant
    from T_sun_TWOwheeler_Rejectionsdata2 a
        join (SELECT DataKey,CB_Type,STATUS,ACCOUNT_STATUS,ACCOUNT_TYPE,DATE_OF_ISSUE,OVERDUE_AMT FROM  {source_catalog}.{source_schema}.`consumerloan-rawdatareceivedbycbteam_retail`) b on a.cbresponseid=b.datakey
    where (lower(b.ACCOUNT_STATUS) in (
    'sub-standard',
    'settled',
    'charge off/written off',
    'loss',
    'doubtful',
    'post write-off settled',
    'special mention',
    'suit filed',
    'wilful default',
    'post write off settled'
    ) or lower(b.ACCOUNT_STATUS) like '%restructured%') and lower(b.cb_type) in ('retail')
    group by a.cbresponseid
),

T_sun_TWOwheeler_Rejectionsdata3 AS
(SELECT 
    a.hierarchyid,
    a.clientid,
    a.LoanProposalId,
    a.ProposalDate,
    a.CBUpdateId,
    a.CBResponseId,
    a.ProductName,
    a.ProductId,
    a.productcode,
    a.CBStatus,
    a.CBresponsedate,
    a.CBsubmitteddate,
    a.Retailstatus,
    a.FOIR,
    a.EligibilityStatus,
    a.EligibleAmount,
    a.ActiveTWOwheeler_Applicant,
    a.Overdue_Applicant,
    CASE WHEN b.NoofDefaultAccount_Applicant IS NOT NULL THEN b.NoofDefaultAccount_Applicant ELSE a.NoofDefaultAccount_Applicant END NoofDefaultAccount_Applicant,
    a.TotalExposure_Applicant,
    a.ActiveTWOwheeler_COApplicant,
    a.Overdue_COApplicant,
    a.NoofDefaultAccount_COApplicant,
    a.FinalCBRemark,
    a.TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata2 a
LEFT JOIN NoofDefaultAccount_Applicant b
ON A.cbresponseid=b.cbresponseid),

TotalExposure_Applicant AS (
select A.cbresponseid,CASE WHEN int(b.CURRENT_BAL) < 0 THEN 0 END as TotalExposure_Applicant
from T_sun_TWOwheeler_Rejectionsdata3 a
join  {source_catalog}.{source_schema}.`consumerloan-rawdatareceivedbycbteam_retail` b on a.cbresponseid=B.datakey
where lower(b.cb_type) <> 'coretail' and (b.ETL_IS_ACTIVE = 1 and b.ETL_IS_ACTIVE is Null)),

T_sun_TWOwheeler_Rejectionsdata4 as
(SELECT 
    a.hierarchyid,
    a.clientid,
    a.LoanProposalId,
    a.ProposalDate,
    a.CBUpdateId,
    a.CBResponseId,
    a.ProductName,
    a.ProductId,
    a.productcode,
    a.CBStatus,
    a.CBresponsedate,
    a.CBsubmitteddate,
    a.Retailstatus,
    a.FOIR,
    a.EligibilityStatus,
    a.EligibleAmount,
    CASE WHEN lower(c.cb_type) in ('coretail') and lower(c.ACCOUNT_STATUS) Not like '%closed%' and upper(c.ACCOUNT_TYPE) like '%TWO%' THEN 'Yes' WHEN a.ActiveTWOwheeler_Applicant IS NULL THEN 'No' END ActiveTWOwheeler_Applicant,
    a.Overdue_Applicant,
    a.NoofDefaultAccount_Applicant,
    CASE WHEN b.TotalExposure_Applicant IS NOT NULL THEN b.TotalExposure_Applicant ELSE a.TotalExposure_Applicant
    END TotalExposure_Applicant,
    a.ActiveTWOwheeler_COApplicant,
    a.Overdue_COApplicant,
    a.NoofDefaultAccount_COApplicant,
    a.FinalCBRemark,
    a.TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata3 a
LEFT JOIN TotalExposure_Applicant b
ON A.cbresponseid=b.cbresponseid
LEFT JOIN  {source_catalog}.{source_schema}.`consumerloan-rawdatareceivedbycbteam_retail` c
ON a.cbresponseid=c.datakey where (c.ETL_IS_ACTIVE = 1 and c.ETL_IS_ACTIVE is Null)
),

Overdue_COApplicant AS (
SELECT 
    A.cbresponseid, SUM(coalesce(int(OVERDUE_AMT),'0')) as Overdue_COApplicant
FROM T_sun_TWOwheeler_Rejectionsdata4 a
JOIN  {source_catalog}.{source_schema}.`consumerloan-rawdatareceivedbycbteam_retail` b
ON A.cbresponseid=b.datakey
where lower(b.cb_type)='coretail' and int(OVERDUE_AMT)>0 and (b.ETL_IS_ACTIVE = 1 and b.ETL_IS_ACTIVE is Null)
   group by A.cbresponseid),

T_sun_TWOwheeler_Rejectionsdata5 AS
(SELECT 
    a.hierarchyid,
    a.clientid,
    a.LoanProposalId,
    a.ProposalDate,
    a.CBUpdateId,
    a.CBResponseId,
    a.ProductName,
    a.ProductId,
    a.productcode,
    a.CBStatus,
    a.CBresponsedate,
    a.CBsubmitteddate,
    a.Retailstatus,
    a.FOIR,
    a.EligibilityStatus,
    a.EligibleAmount,
    a.ActiveTWOwheeler_Applicant,
    a.Overdue_Applicant,
    a.NoofDefaultAccount_Applicant,
    a.TotalExposure_Applicant,
    a.ActiveTWOwheeler_COApplicant,
    CASE WHEN b.Overdue_COApplicant IS NOT NULL THEN b.Overdue_COApplicant ELSE a.Overdue_COApplicant END Overdue_COApplicant,
    a.NoofDefaultAccount_COApplicant,
    a.FinalCBRemark,
    a.TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata4 a
LEFT JOIN Overdue_COApplicant b
ON A.cbresponseid=b.cbresponseid),

NoofDefaultAccount_COApplicant AS ( 
select distinct a.cbresponseid, count(b.ACCOUNT_STATUS) as NoofDefaultAccount_COApplicant
   from T_sun_TWOwheeler_Rejectionsdata5 a
      join  {source_catalog}.{source_schema}.`consumerloan-rawdatareceivedbycbteam_retail` b on a.cbresponseid=b.datakey
   where (lower(b.ACCOUNT_STATUS) in (
    'sub-standard',
    'settled',
    'charge off/written off',
    'loss',
    'doubtful',
    'post write-off settled',
    'special mention',
    'suit filed',
    'wilful default',
    'post write off settled'
) or lower(b.ACCOUNT_STATUS) like '%restructured%') and lower(b.cb_type) in ('coretail')
    group by a.cbresponseid),

T_sun_TWOwheeler_Rejectionsdata6 AS (
SELECT 
    a.hierarchyid,
    a.clientid,
    a.LoanProposalId,
    a.ProposalDate,
    a.CBUpdateId,
    a.CBResponseId,
    a.ProductName,
    a.ProductId,
    a.productcode,
    a.CBStatus,
    a.CBresponsedate,
    a.CBsubmitteddate,
    a.Retailstatus,
    a.FOIR,
    a.EligibilityStatus,
    a.EligibleAmount,
    a.ActiveTWOwheeler_Applicant,
    a.Overdue_Applicant,
    a.NoofDefaultAccount_Applicant,
    a.TotalExposure_Applicant,
    a.ActiveTWOwheeler_COApplicant,
    a.Overdue_COApplicant,
    a.FinalCBRemark,
    CASE WHEN b.NoofDefaultAccount_COApplicant IS NOT NULL THEN b.NoofDefaultAccount_COApplicant ELSE a.NoofDefaultAccount_COApplicant END NoofDefaultAccount_COApplicant,
    -- CASE 
    -- WHEN a.ActiveTWOwheeler_Applicant = 'Yes' and a.FinalCBRemark is null and a.cbstatus='R' THEN 'Rejected Due to ActiveTWOwheeler_Applicant' 
    -- WHEN a.ActiveTWOwheeler_COApplicant='Yes' and a.FinalCBRemark is null and a.cbstatus='R' THEN 'Rejected Due to ActiveTWOwheeler_COApplicant'
    -- WHEN int(a.NoofDefaultAccount_Applicant)>0 and a.FinalCBRemark is null and a.cbstatus='R' THEN 'Rejected Due to NoofDefaultAccount_Applicant'
    -- WHEN int(a.NoofDefaultAccount_COApplicant)>0 and a.FinalCBRemark is null and a.cbstatus='R' THEN 'Rejected Due to NoofDefaultAccount_COApplicant'
    -- WHEN int(a.Overdue_Applicant)>0 and a.FinalCBRemark is null and cbstatus='R' THEN 'Rejected Due to Overdue_Applicant'
    -- WHEN int(a.Overdue_COApplicant)>0 and a.FinalCBRemark is null and cbstatus='R' THEN 'Rejected Due to Overdue_COApplicant'
    -- WHEN (lower(a.Retailstatus)='hit' and int(a.TotalExposure_Applicant)>220380 ) and a.FinalCBRemark is null and a.cbstatus='R' THEN 'Rejected Due to TotalExposure_Applicant'
    -- WHEN (lower(a.Retailstatus)='Nohit' and int(a.TotalExposure_Applicant)>145380 ) and a.FinalCBRemark is null and a.cbstatus='R' THEN 'Rejected Due to TotalExposure_Applicant'
    -- WHEN int(a.FOIR)<345 and a.cbstatus='R' and a.FinalCBRemark is null THEN 'Rejected Due to FOIR'
    -- WHEN a.FinalCBRemark is null and a.cbstatus='R' and a.EligibilityStatus='Eligible' THEN 'As per CB eligbile'
    -- END FinalCBRemark,
    CASE 
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' THEN 'Rejected Due To ActiveTWOwheeler_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND NoofDefaultAccount_Applicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and NoofDefaultAccount_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' THEN 'Rejected Due To ActiveTWOwheeler_Applicant and NoofDefaultAccount_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and NoofDefaultAccount_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and NoofDefaultAccount_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 AND Overdue_Applicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and NoofDefaultAccount_COApplicant and Overdue_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 AND Overdue_Applicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and NoofDefaultAccount_COApplicant and Overdue_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND Overdue_Applicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and Overdue_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND Overdue_Applicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and Overdue_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND Overdue_Applicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and Overdue_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and NoofDefaultAccount_COApplicant and Overdue_Applicant and Overdue_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and NoofDefaultAccount_COApplicant and Overdue_Applicant and Overdue_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and Overdue_Applicant and Overdue_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and Overdue_Applicant and Overdue_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND Overdue_COApplicant > 0 THEN 'Rejected Due To ActiveTWOwheeler_Applicant and Overdue_COApplicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 AND (Retailstatus IN ('Hit','Nohit') and TotalExposure_Applicant>145380 ) THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and NoofDefaultAccount_COApplicant and Overdue_Applicant and Overdue_COApplicant and TotalExposure_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.NoofDefaultAccount_COApplicant > 0 AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 AND (Retailstatus IN ('Hit','Nohit') and TotalExposure_Applicant>145380 ) THEN 'Rejected Due To ActiveTWOwheeler_Applicant and NoofDefaultAccount_COApplicant and Overdue_Applicant and Overdue_COApplicant and TotalExposure_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 
        AND (Retailstatus IN ('Hit','Nohit') and TotalExposure_Applicant>145380 ) THEN 'Rejected Due To ActiveTWOwheeler_Applicant and Overdue_Applicant and Overdue_COApplicant and TotalExposure_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND a.ActiveTWOwheeler_COApplicant='Yes' AND Overdue_Applicant > 0 AND Overdue_COApplicant > 0 AND (Retailstatus IN ('Hit','Nohit') and TotalExposure_Applicant>145380 ) THEN 'Rejected Due To ActiveTWOwheeler_Applicant and ActiveTWOwheeler_COApplicant and Overdue_Applicant and Overdue_COApplicant and TotalExposure_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND Overdue_COApplicant > 0 AND (Retailstatus IN ('Hit','Nohit') and TotalExposure_Applicant>145380 ) THEN 'Rejected Due To ActiveTWOwheeler_Applicant and Overdue_COApplicant and TotalExposure_Applicant'
        WHEN a.CBStatus='R' AND a.ActiveTWOwheeler_Applicant='Yes' AND Overdue_Applicant > 0 AND (Retailstatus IN ('Hit','Nohit') and TotalExposure_Applicant>145380 ) THEN 'Rejected Due To ActiveTWOwheeler_Applicant and Overdue_Applicant and TotalExposure_Applicant'
    END TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata5 a
LEFT JOIN NoofDefaultAccount_COApplicant b
ON A.cbresponseid=b.cbresponseid),

T_sun_TWOwheeler_Rejectionsdata7 AS (
SELECT 
    a.hierarchyid,
    a.clientid,
    a.LoanProposalId,
    a.ProposalDate,
    a.CBUpdateId,
    a.CBResponseId,
    a.ProductName,
    a.ProductId,
    a.productcode,
    a.CBStatus,
    a.CBresponsedate,
    a.CBsubmitteddate,
    a.Retailstatus,
    a.FOIR,
    a.EligibilityStatus,
    a.EligibleAmount,
    a.ActiveTWOwheeler_Applicant,
    a.Overdue_Applicant,
    a.NoofDefaultAccount_Applicant,
    a.TotalExposure_Applicant,
    a.ActiveTWOwheeler_COApplicant,
    a.Overdue_COApplicant,
    a.NoofDefaultAccount_COApplicant,
    a.FinalCBRemark,
    CASE 
        WHEN a.FOIR < 345 and a.cbstatus = 'R' AND len(a.TotalFinal_CBRemarks) > 15 THEN CONCAT(a.TotalFinal_CBRemarks,' and FOIR')
        WHEN a.FOIR < 345 and a.cbstatus = 'R' AND len(a.TotalFinal_CBRemarks) <= 15 THEN CONCAT(a.TotalFinal_CBRemarks,' FOIR')
        ELSE a.TotalFinal_CBRemarks
    END TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata6 a),

T_sun_TWOwheeler_Rejectionsdata8 AS (
SELECT 
    a.hierarchyid,
    a.clientid,
    a.LoanProposalId,
    a.ProposalDate,
    a.CBUpdateId,
    a.CBResponseId,
    a.ProductName,
    a.ProductId,
    a.productcode,
    a.CBStatus,
    a.CBresponsedate,
    a.CBsubmitteddate,
    a.Retailstatus,
    a.FOIR,
    a.EligibilityStatus,
    a.EligibleAmount,
    a.ActiveTWOwheeler_Applicant,
    a.Overdue_Applicant,
    a.NoofDefaultAccount_Applicant,
    a.TotalExposure_Applicant,
    a.ActiveTWOwheeler_COApplicant,
    a.Overdue_COApplicant,
    a.NoofDefaultAccount_COApplicant,
    a.FinalCBRemark,
    CASE
        WHEN a.cbstatus='R' and a.EligibilityStatus='Eligible' THEN 'As per CB eligbile'
        ELSE a.TotalFinal_CBRemarks
    END TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata7 a),

p_TwoWheeler_Rejectiondata_Final1 as (SELECT
   current_date() AS createddatetime,
    hierarchyid,
    clientid,
    LoanProposalId,
    ProposalDate,
    CBUpdateId,
    CBResponseId,
    ProductName,
    ProductId,
    productcode,
    CBStatus,
    CBresponsedate,
    CBsubmitteddate,
    Retailstatus,
    FOIR,
    EligibilityStatus,
    EligibleAmount,
    ActiveTWOwheeler_Applicant,
    Overdue_Applicant,
    NoofDefaultAccount_Applicant,
    TotalExposure_Applicant,
    ActiveTWOwheeler_COApplicant,
    Overdue_COApplicant,
    NoofDefaultAccount_COApplicant,
    FinalCBRemark,
    CASE 
        WHEN FinalCBRemark ='Rejected Due To' THEN ''
        ELSE TotalFinal_CBRemarks
    END TotalFinal_CBRemarks
FROM T_sun_TWOwheeler_Rejectionsdata8),

T_Vraju_Daily_Proposals_TW AS (
  SELECT a.HierarchyId , a.ClientId , a.LoanProposalID , a.LoanProposalCode , a.ProposalDate , a.ProposalStatus
        , a.WorkFlowStatus , a.ApprovedDate , a.CancelDate , a.CancelRemarks , a.CreatedBy AS Proposal_StaffID, Z.UserName AS Proposal_StaffName,
         PM.ProductCode
  FROM  {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` a
    JOIN  {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` AS DPM ON a.ProductId = DPM.DerivedProductId
    JOIN  {source_catalog}.{source_schema}.`pragati-productmaster` AS PM ON DPM.ProductId = PM.ProductId
    JOIN  {source_catalog}.{source_schema}.`azuresource-dim_productmaster` AS x ON PM.Productcode = x.Product_Id
      LEFT JOIN  {source_catalog}.{source_schema}.`pragatimain-usermaster` Z ON a.CreatedBy=Z.UserID 
      where  
       (a.ETL_IS_ACTIVE = 1 or a.ETL_IS_ACTIVE is Null)  and (dpm.ETL_IS_ACTIVE = 1 or dpm.ETL_IS_ACTIVE is Null)  and (pm.ETL_IS_ACTIVE = 1 or pm.ETL_IS_ACTIVE is Null) and(z.ETL_IS_ACTIVE = 1 or z.ETL_IS_ACTIVE is Null)
   and x.PRODUCT_CATEGORY1 in ('Two Wheelers','TW loyalty') and a.ProposalDate >= '2023-07-01'
   ),

T_Vraju_Weely_DisbData_2_wheeler_Vraju AS (
  SELECT 
    A.ZONE AS ZoneName,
    A.State AS StateName,
    A.Region,
    A.AREA AS Area,
    A.UMBaseLocationBranchName AS UnitOffice,
    A.BRANCHID AS BranchID,
    A.BRANCHNAME AS BranchName,
    A.HierarchyId,
    CLP.LoanProposalCode,
    CLP.LoanProposalId,
    Clp.ClientId,
    CM.ClientCode,
    CM.ClientName,
    CLs.ClientLoanId,
    CLS.ClientLoanCode,
    CLS.ClientProductSequenceNo,
    CLP.ProductCode,
    CO.CenterId,
    CO.CenterCode,
    CASE 
      WHEN CO.CenterMeetingDay = 1 THEN 'Monday'
      WHEN CO.CenterMeetingDay = 2 THEN 'Tuesday'
      WHEN CO.CenterMeetingDay = 3 THEN 'Wednesday'
      WHEN CO.CenterMeetingDay = 4 THEN 'Thursday'
      ELSE 'Friday'
    END AS CenterMeetingDay,
    CS.Status AS CenterStatus,
    C.GroupId,
    C.GroupCode,
    CLP.ProposalDate,
    CLS.DisbursementDate,
    CLS.LoanAmountDisbursed,
    CLS.LoanCancelledDate,
    CLS.LoanClosedDate,
    CLP.Proposal_StaffID,
    CLP.Proposal_StaffName,
    CLS.CreatedBy AS Disb_StaffID,
    D.UserName AS Disb_StaffName,
    CAST(NULL AS STRING) AS DeliveryDate
  FROM 
    T_Vraju_Daily_Proposals_TW CLP
    LEFT JOIN  {source_catalog}.{source_schema}.`pragati-clientloansubscription` CLS ON CLS.LoanProposalId = CLP.LoanProposalId
    LEFT JOIN  {source_catalog}.{source_schema}.`pragati-clientmaster` CM ON CM.ClientId = CLP.ClientId
    LEFT JOIN  {source_catalog}.{source_schema}.`pragati-groupmaster` C ON CM.GroupId = C.GroupId
    LEFT JOIN  {source_catalog}.{source_schema}.`pragati-centermaster` CO ON C.CenterId = CO.CenterId
    LEFT JOIN  {source_catalog}.{source_schema}.`azuresource-statuscurrentcenters` CS ON CO.CenterId = CS.CenterSmartID
    LEFT JOIN  {source_catalog}.{source_schema}.`pragatimain-usermaster` D ON CLS.CreatedBy = D.UserID AND CLS.CreatedBy = D.LoginId
    LEFT JOIN  {mart_catalog}.{mart_schema}.`p_hierarchy_sop` A ON A.HierarchyId = CLP.HierarchyId
  WHERE 
    (CLS.ETL_IS_ACTIVE = 1 OR CLS.ETL_IS_ACTIVE IS NULL)
    AND (CM.ETL_IS_ACTIVE = 1 OR CM.ETL_IS_ACTIVE IS NULL)
    AND (C.ETL_IS_ACTIVE = 1 OR C.ETL_IS_ACTIVE IS NULL)
    AND (CO.ETL_IS_ACTIVE = 1 OR CO.ETL_IS_ACTIVE IS NULL)
    AND (CS.ETL_IS_ACTIVE = 1 OR CS.ETL_IS_ACTIVE IS NULL)
    --AND (A.ETL_IS_ACTIVE = 1 OR A.ETL_IS_ACTIVE IS NULL)
    AND (D.ETL_IS_ACTIVE = 1 OR D.ETL_IS_ACTIVE IS NULL)
) ,--select DisbursementDate from T_Vraju_Weely_DisbData_2_wheeler_Vraju,

T_Vraju_vw_TWProposalStatus_VV AS (
  SELECT DISTINCT
    *,
    CASE
      WHEN X.DeliveryDate IS NOT NULL THEN 'Delivered'
      WHEN X.DisbursementDate IS NOT NULL THEN 'Delivery Pending'
      WHEN X.`DP Status` = 'A' AND X.DisbursementDate IS NULL THEN 'Disbursement Pending'
      WHEN X.`DP Status` = 'Pending' THEN 'DP Pending'
      WHEN REPLACE(X.CB_Status, 'ELIGIBLE', 'A') = 'A' AND X.DVU = 'A' THEN 'CPV Pending'
      WHEN X.CB_Status IS NULL THEN 'CB Pending'
      WHEN X.CB_Status = 'R' THEN 'CB Rejected'
      WHEN X.DVU IS NULL THEN 'DVU Pending'
      WHEN X.DVU = 'R' THEN 'DVU Rejected'
      ELSE '' 
    END AS FinalStatus
  FROM (
    SELECT
      A.LoanProposalId,
      A.LoanProposalCode,
      A.ClientCode,
      A.ClientId,
      A.ClientName,
      A.ProductCode,
      PT.ProposalDate,
      PT.ProposalStatus,
      CB.CB_Status,
      CB.CB_Date,
      A.VerifiedStatus AS DVU,
      A.VerificationDate AS `DVU Date`,
      A.RemarkForClient AS `DVU Remark1`,
      A.RemarkForCoApplicant AS `DVU Remark2`,
      A.CPV2_Status AS CPV,
      CPV.CPV_DE_Date AS CPV_Date,
      CASE 
        WHEN A.CPV2_STATUS = 'R' THEN CPV.Remark
        ELSE '' 
      END AS `CPV Remark`,
      CASE 
        WHEN SAN.MarginMoney = COALESCE(SAN.Payment1Amount, 0) + COALESCE(SAN.Payment2Amount, 0) AND SAN.Payment1Amount IS NOT NULL THEN 'A'
        WHEN SAN.Loanproposalid IS NOT NULL AND COALESCE(SAN.MarginMoney, 0) >= (COALESCE(SAN.Payment1Amount, 0) + COALESCE(SAN.Payment2Amount, 0)) THEN 'Pending'
        ELSE NULL 
      END AS `DP Status`,
      -- CASE 
      --   WHEN PT.LoanDisbursementDate = CAST('1900-01-01 00:00:00.000' AS TIMESTAMP) THEN NULL
      --   ELSE PT.LoanDisbursementDate 
      -- END 
      --PT.LoanDisbursementDate  AS 
      DisbursementDate,
      TSO.HandoverDate AS DeliveryDate,
      CASE 
        WHEN COALESCE(ca.LoanDecision, '') = 'Reroute' THEN 'Yes' 
        ELSE 'No' 
      END AS `Reroute Status`,
      CASE 
        WHEN COALESCE(ca.RerouteStatus, '') = 'Approved' THEN 'Approved' 
      END AS `Reroute Approved`,
      SAN.Make AS `Manufacture`,
      SAN.Model,
      SAN.MarginMoney AS `DP_Amount`,
      SAN.OnRoadPriceByVendor,
      twts.StampCharges
    FROM
       {source_catalog}.{source_schema}.`consumerloan-tbl_tw_coapplicantdetails` A
    LEFT JOIN
       {source_catalog}.{source_schema}.`consumerloan-tbl_tw_cpv` CPV ON A.LoanProposalId = CPV.LoanProposalId
    LEFT JOIN
       {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` PT ON A.LoanProposalId = PT.LoanProposalId
    LEFT JOIN
       {source_catalog}.{source_schema}.`consumerloan-tbl_tw_sanctionedapplication` SAN ON A.LoanProposalId = SAN.Loanproposalid
    LEFT JOIN
       {source_catalog}.{source_schema}.`consumerloan-tbl_tw_stock` TSO ON A.LoanProposalId = TSO.LoanProposalId
    LEFT JOIN
       {source_catalog}.{source_schema}.`consumerloan-tbl_tw_creditappraisal` ca ON ca.LoanproposalId = A.LoanProposalId
    LEFT JOIN
       {source_catalog}.{source_schema}.`consumerloan-tbl_tw_ticketsize` twts ON twts.ProductID = SAN.ProductCode AND SAN.ApprovedAmount = twts.TicketSize
    LEFT JOIN (
      SELECT * 
      FROM (
        SELECT 
          ROW_NUMBER() OVER (PARTITION BY LoanProposalId ORDER BY CB_DATE DESC) AS R,
          *
        FROM 
           {source_catalog}.{source_schema}.`consumerloan-tbl_tw_cb_response`
      ) D
      WHERE D.R = 1 AND (D.etl_is_active = 1 OR D.etl_is_active IS NULL)
    ) CB ON A.LoanProposalId = CB.LoanproposalID
    WHERE 
   (a.etl_is_active = 1 OR a.etl_is_active IS NULL) and
      (CPV.etl_is_active = 1 OR CPV.etl_is_active IS NULL)
      AND (PT.etl_is_active = 1 OR PT.etl_is_active IS NULL)
      AND (SAN.etl_is_active = 1 OR SAN.etl_is_active IS NULL)
      AND (TSO.etl_is_active = 1 OR TSO.etl_is_active IS NULL)
      AND (twts.etl_is_active = 1 OR twts.etl_is_active IS NULL)
  ) X
)   ,


T_Vraju_Weely_DisbData_2_wheeler_Vraju_New AS (
  SELECT
            a.ZoneName,a.StateName,CenterStatus,a.Region,a.Area,a.UnitOffice,a.BranchID,a.BranchName,a.HierarchyId,a.LoanProposalCode,a.LoanProposalId,a.ClientId,a.ClientCode,a.ClientName,a.ClientLoanId,a.ClientLoanCode,a.ClientProductSequenceNo,a.ProductCode,a.Centerid,a.CenterCode,a.CenterMeetingDay,a.GroupId,a.GroupCode,a.Proposaldate,a.DisbursementDate,a.LoanAmountDisbursed,a.LOANCANCELLEDDATE,a.LoanClosedDate,a.Proposal_StaffID,a.Proposal_StaffName,a.Disb_StaffID,a.Disb_StaffName,
            
            CASE WHEN a.DisbursementDate BETWEEN '2016-04-01' AND '2016-12-31' THEN a.DisbursementDate ELSE b.DeliveryDate END as DeliveryDate
            
            ,c.CoApplicantName CoApplicantName,c.RelationWithApp RelationWithApp,d.VendorId VendorId,e.VendorName Vendor_Name,d.Model Model,d.Make Vechicle_Brand,f.EngineNumber EngineNumber,f.RegistrationNumber RegistrationNumber,f.RCRegistrationDate RCRegistrationDate,f.RegistrationAuthority RegistrationAuthority,f.ChassisNumber ChassisNumber,b.ProposalStatus,b.CB_Status,b.CB_Date,b.DVU,b.`DVU Date` DVU_Date,b.`DVU Remark1` DVU_Remark1,b.`DVU Remark2` DVU_Remark2,b.CPV,b.CPV_Date,b.`CPV Remark` CPV_Remark,b.`DP Status` DP_Status,b.DP_Amount,b.`Reroute Status` Reroute_Status,b.`Reroute Approved` Reroute_Approved,b.OnRoadPriceByVendor,b.StampCharges,CASE WHEN a.LoanClosedDate IS NOT NULL THEN 'LoanCLosed' WHEN b.FinalStatus IS NULL AND coalesce(h.CancelDate, '1900-01-01') <> '1900-01-01' THEN 'Proposal Level Loan Cancelled' WHEN b.FinalStatus IS NULL AND coalesce(h.CancelDate, '1900-01-01') = '1900-01-01' THEN 'Proposal Level Loans Not Cancelled' WHEN (b.ProposalStatus IS NULL OR b.ProposalStatus = 'N') AND b.CB_Status IS NULL THEN 'Proposal Level No Status From CB' WHEN b.FinalStatus = 'CB Rejected' AND coalesce(CAST(h.CancelDate as DATE),'1900-01-01') = '1900-01-01' THEN 'CB Rejeted Proposal Not Canelled In PT' WHEN b.FinalStatus = 'CPV Pending' AND b.CPV = 'R' THEN 'CPV Rejected' WHEN b.DVU = 'R' THEN 'DVU Rejected' ELSE b.FinalStatus END FinalStatus,
            
            CASE WHEN d.MarginMoney = d.Payment1Amount THEN d.Payment1ReceiptDate ELSE d.Payment2ReceiptDate END DPPaymentDate,g.MobileNumber Client_Mobile_No,g.PhoneNumber Client_Phone_No,h.CancelDate Proposalcancelleddate,c.MobileNumber_Coapp MobileNumber_Coapp,i.CreatedDateTime HHI_Date,i.Annual_HHI,i.Annual_HHE,CASE WHEN k.VendorType = 'Two Wheeler' THEN k.PaymentNoGeneratedDate ELSE NULL END PaymentNoGeneratedDate,CASE WHEN k.VendorType = 'Two Wheeler' THEN k.PaymentNo ELSE NULL END PaymentNo, 
        --         CASE 
        --     WHEN l.ActiveTWOwheeler_Applicant = 'Yes' AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to ActiveTWOwheeler_Applicant' 
        --     WHEN l.ActiveTWOwheeler_COApplicant = 'Yes' AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to ActiveTWOwheeler_COApplicant'
        --     WHEN CAST(l.NoofDefaultAccount_Applicant AS INT) > 0 AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to NoofDefaultAccount_Applicant'
        --     WHEN CAST(l.NoofDefaultAccount_COApplicant AS INT) > 0 AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to NoofDefaultAccount_COApplicant'
        --     WHEN CAST(l.Overdue_Applicant AS INT) > 0 AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to Overdue_Applicant'
        --     WHEN CAST(l.Overdue_COApplicant AS INT) > 0 AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to Overdue_COApplicant'
        --     WHEN LOWER(l.Retailstatus) = 'hit' AND CAST(l.TotalExposure_Applicant AS INT) > 220380 AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to TotalExposure_Applicant'
        --     WHEN LOWER(l.Retailstatus) = 'nohit' AND CAST(l.TotalExposure_Applicant AS INT) > 145380 AND l.FinalCBRemark IS NULL AND l.cbstatus = 'R' THEN 'Rejected Due to TotalExposure_Applicant'
        --     WHEN CAST(l.FOIR AS INT) < 345 AND l.cbstatus = 'R' AND l.FinalCBRemark IS NULL THEN 'Rejected Due to FOIR'
        --     WHEN l.FinalCBRemark IS NULL AND l.cbstatus = 'R' AND l.EligibilityStatus = 'Eligible' THEN 'As per CB eligible'
        --     WHEN b.FinalStatus = 'CB Rejected' AND l.FinalCBRemark IS NULL THEN 'Proposal Level Cancelled No CB Remarks'
        --     WHEN l.FinalCBRemark IS NULL AND b.FinalStatus = 'CB Rejected' THEN 'HHI Cancelled'
        --     ELSE l.FinalCBRemark
        -- END AS FinalCBRemark,
            Row_Number() OVER(Partition BY a.LoanProposalid ORDER BY a.Loanproposalid) AS Seq
      FROM T_Vraju_Weely_DisbData_2_wheeler_Vraju a
  LEFT JOIN 
    T_Vraju_vw_TWProposalStatus_VV b ON a.LoanProposalID = b.LoanProposalId
  LEFT JOIN 
     {source_catalog}.{source_schema}.`consumerloan-tbl_tw_coapplicantdetails` c ON a.LoanProposalID = c.LoanProposalId
  LEFT JOIN 
     {source_catalog}.{source_schema}.`consumerloan-tbl_tw_sanctionedapplication` d ON a.LoanProposalID = d.LoanProposalId
  LEFT JOIN 
    P_Vraju_TW_VendorMaster e ON e.VendorId = d.VendorId
  LEFT JOIN 
     {source_catalog}.{source_schema}.`consumerloan-tbl_tw_stock` f ON a.LoanProposalID = f.LoanProposalId
  LEFT JOIN 
    P_allkycs_all g ON g.Clientid = a.Clientid
  LEFT JOIN 
     {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` h ON h.LoanProposalId = a.LoanProposalId
  LEFT JOIN 
     {source_catalog}.{source_schema}.`rdsp_trans-mfi_household_details` i ON i.Clientid = a.Clientid
  LEFT JOIN 
     {source_catalog}.{source_schema}.`azuresource-upload_master` k ON k.LoanProposalId = a.LoanProposalId
  LEFT JOIN 
    p_TwoWheeler_Rejectiondata_Final1 l ON a.LoanProposalId = l.LoanProposalId
  WHERE  
    (c.ETL_IS_ACTIVE IS NULL OR c.ETL_IS_ACTIVE = 1) AND 
    (d.ETL_IS_ACTIVE IS NULL OR d.ETL_IS_ACTIVE = 1) AND 
    (i.ETL_IS_ACTIVE IS NULL OR i.ETL_IS_ACTIVE = 1) AND 
    (f.ETL_IS_ACTIVE IS NULL OR f.ETL_IS_ACTIVE = 1) AND 
    (h.ETL_IS_ACTIVE IS NULL OR h.ETL_IS_ACTIVE = 1) AND 
    (k.ETL_IS_ACTIVE IS NULL OR k.ETL_IS_ACTIVE = 1)
),


--select count(*) from T_Vraju_Weely_DisbData_2_wheeler_Vraju_New;
 DistinctLoanProposals AS (
    SELECT DISTINCT LoanProposalId
    FROM T_Vraju_Weely_DisbData_2_wheeler_Vraju_New
),

final_cte as (
SELECT 
    t.LoanProposalId,
    t.ZoneName,
    t.StateName,
    t.CenterStatus,
    t.Region,
    t.Area,
    t.UnitOffice,
    t.BranchID,
    t.BranchName,
    t.HierarchyId,
    t.LoanProposalCode,
    t.ClientId,
    t.ClientCode,
    t.ClientName,
    t.ClientLoanId,
    t.ClientLoanCode,
    t.ClientProductSequenceNo,
    t.ProductCode,
    t.Centerid,
    t.CenterCode,
    t.CenterMeetingDay,
    t.GroupId,
    t.GroupCode,
    t.Proposaldate,
    t.DisbursementDate,
    t.LoanAmountDisbursed,
    t.LOANCANCELLEDDATE,
    t.LoanClosedDate,
    t.Proposal_StaffID,
    t.Proposal_StaffName,
    t.Disb_StaffID,
    t.Disb_StaffName,
    t.DeliveryDate,
    t.CoApplicantName,
    t.RelationWithApp,
    t.VendorId,
    t.Vendor_Name,
    t.Model,
    t.Vechicle_Brand,
    t.EngineNumber,
    t.RegistrationNumber,
    t.RCRegistrationDate,
    t.RegistrationAuthority,
    t.ChassisNumber,
    t.ProposalStatus,
    t.CB_Status,
    t.CB_Date,
    t.DVU,
    t.DVU_Date,
    t.DVU_Remark1,
    t.DVU_Remark2,
    t.CPV,
    t.CPV_Date,
    t.CPV_Remark,
    t.DP_Status,
    t.DP_Amount,
    t.Reroute_Status,
    t.Reroute_Approved,
    t.OnRoadPriceByVendor,
    t.StampCharges,
    t.FinalStatus,
    t.DPPaymentDate,
    t.Client_Mobile_No,
    t.Client_Phone_No,
    t.Proposalcancelleddate,
    t.MobileNumber_Coapp,
    t.HHI_Date,
    t.Annual_HHI,
    t.Annual_HHE,
    t.PaymentNoGeneratedDate,
    t.PaymentNo,
    m.FinalCBRemark,
    t.Seq
FROM 
    DistinctLoanProposals d
JOIN 
    T_Vraju_Weely_DisbData_2_wheeler_Vraju_New t ON d.LoanProposalId = t.LoanProposalId
  LEFT JOIN 
  p_TwoWheeler_Rejectiondata_Final1 l ON t.LoanProposalId = l.LoanProposalId
  left join {source_catalog}.{source_schema}.`report_mart-p_twowheeler_rejectiondata` M 
  on d.LoanProposalId = m.LoanProposalId

  )

select *  FROM final_cte

;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"tw_itlogin Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on tw_itlogin: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on tw_itlogin : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.tw_itlogin")

    logger(
            logger_level_info,
            f"tw_itlogin writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table tw_itlogin : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table tw_itlogin : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "tw_itlogin").mode("overwrite").save()
    logger(
            logger_level_info,
            f"tw_itlogin writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table tw_itlogin : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table tw_itlogin : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)