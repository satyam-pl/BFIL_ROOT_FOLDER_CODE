# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_tw_mis_report.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/TW_MIS_REPORT"
    desti_path = "BFIL-MART/REPORTING/TW_MIS_REPORT"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH PTTEMP AS (
  select a. *
 from  {source_catalog}.{source_schema}.`consumerloan-ptsmart_migration` a
 inner join  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_coapplicantdetails` coApp on coApp.LoanProposalId = a.LoanProposalId and coApp.ProductCode= a.ProductCode
 where to_date(ProposalDate) > '2023-06-30'
),

 --select * from PTTEMP;

StockTemp AS (
    SELECT 
        stock.EngineNumber,
        stock.ApprovedAmount,
        stock.ProductId,
        stock.ChassisNumber,
        stock.RegistrationNumber,
        TO_DATE(stock.RCRegistrationDate) AS RCRegistrationDate,
        stock.RegistrationAuthority,
        stock.LoanproposalId,
        TO_DATE(PTtem.LoanDisbursementDate) AS LoanDisbursementDate,
        PTtem.LoanAmountDisbursed,
        TO_DATE(PTtem.CancelDate) AS CancelDate,
        TO_DATE(PTtem.LoanClosedDate) AS LoanClosedDate,
        InvoiceDocumentPath,
        InsuranceDocumentPath,
        RegistrationCopyExtractDocPath,
        RCDocumentPath
    FROM 
         {source_catalog}.{source_schema}.`consumerloan-tbl_tw_stock` stock
    INNER JOIN 
        PTTEMP PTtem 
    ON 
        PTtem.LoanProposalId = stock.LoanproposalId 
    WHERE 
        stock.ETL_IS_ACTIVE = 1 OR stock.ETL_IS_ACTIVE IS NULL
),

 --select * from StockTemp;


 Temp AS (
  SELECT 
    co.ClientName,
    co.BranchID,
    p.BranchName,
    p.UMBaseLocationBranchName as unitname,
    p.Area,
    p.Region,
    p.Zone,
    --cb.cb_status,
    co.StateName,
    co.LoanProposalCode,
    co.LoanProposalId,
    co.ClientId,
    co.ClientCode,
    co.MobileNumber,
    co.CoApplicantName,
    co.MobileNumber_Coapp,
    co.RelationWithApp,
    co.ProductCode,
    to_date(gf.ProposalDate) AS ProposalDate,
    to_date(pt.LoanDisbursementDate) AS LoanDisbursementDate,
    pt.LoanAmountDisbursed,
    to_date(pt.CancelDate) AS CancelDate,
    to_date(pt.LoanClosedDate) AS LoanClosedDate,
    sa.VendorId,
    lg.Branch_Name AS `Vendor_Name`,
    sa.Model,
    pt.EngineNumber,
    pt.ChassisNumber,
    pt.RegistrationNumber,
    to_date(pt.RCRegistrationDate) AS RCRegistrationDate,
    pt.RegistrationAuthority,
    CASE 
      WHEN cb.CB_Status = 'A' THEN 'Approved'
      WHEN cb.CB_Status = 'R' THEN 'Rejected'
      ELSE NULL 
    END AS CB_Status,
    to_date(cb.CB_Date) AS CB_Date,
    cb.CBEligibleAmount,
    CASE 
      WHEN co.CoApplicantVoterImage1 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.CoApplicantVoterImage1 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS CoApplicantVoterImage1,
    CASE 
      WHEN co.CoApplicantVoterImage2 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.CoApplicantVoterImage2 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS CoApplicantVoterImage2,
    CASE 
      WHEN co.CoApplicantPANImage1 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.CoApplicantPANImage1 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS CoApplicantPANImage1,
    CASE 
      WHEN co.CoApplicantPANImage2 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.CoApplicantPANImage2 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS CoApplicantPANImage2,
    CASE 
      WHEN co.ApplicantVoterImage1 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.ApplicantVoterImage1 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS ApplicantVoterImage1,
    CASE 
      WHEN co.ApplicantVoterImage2 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.ApplicantVoterImage2 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS ApplicantVoterImage2,
    CASE 
      WHEN co.ApplicantPANImage1 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.ApplicantPANImage1 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS ApplicantPANImage1,
    CASE 
      WHEN co.ApplicantPANImage2 LIKE '%https://bfilcustomerdms%' THEN 'Yes'
      WHEN co.ApplicantPANImage2 LIKE '%C:/PTSMARTFTPFILES%' THEN 'Not available'
      ELSE 'Not available' 
    END AS ApplicantPANImage2,
    co.Address,
    co.Address_Coapp,
    CASE 
      WHEN co.VerifiedStatus = 'A' THEN 'Approved'
      WHEN co.VerifiedStatus = 'R' THEN 'Rejected'
      ELSE NULL 
    END AS Proposal_Assessment_Status,
    to_date(co.VerificationDate) AS Proposal_Assessment_Date,
    CASE 
      WHEN co.CPV2_STATUS = 'A' THEN 'Approved'
      WHEN co.CPV2_STATUS IS NULL THEN 'CPV2 Pending'
      WHEN co.CPV2_STATUS = 'R' THEN 'Rejected'
      ELSE NULL 
    END AS CPV_Status,
    to_date(cpv.VerificationDate) AS CPV_Date, 
    CASE 
      WHEN co.CPV2_STATUS = 'R' THEN cpv.Remark 
      ELSE '' 
    END AS CPV_Remark, 
  CASE
    WHEN COALESCE(sa.Payment1Amount, 0) = 0 THEN ''
    WHEN COALESCE(sa.Payment1Amount, 0) + COALESCE(sa.Payment2Amount, 0) < COALESCE(sa.marginmoney, 0) THEN 'Pending'
    WHEN COALESCE(sa.Payment1Amount, 0) + COALESCE(sa.Payment2Amount, 0) = COALESCE(sa.marginmoney, 0) THEN 'Complete'
END AS DPStatus
,
    sa.MarginMoney AS DP_Amount,
    to_date(sa.Payment1ReceiptDate) AS DPPaymentDate,
    sa.OnRoadPriceByVendor,
    '' AS Tenure_Type,
    tik.CSIPJoint,
    tik.LPF,
    tik.StampCharges,
    up.UTRNo,
    to_timestamp(up.PaymentDate) AS URTPaymentDate,
    up.ProductPrice AS URTPaymentAmount,
    co.CB_Expire_Date,
    co.CB_Expire_Status,
    CASE
      WHEN InvoiceDocumentPath IS NOT NULL THEN 'Yes' 
      ELSE 'No' 
    END AS Invoice,
    CASE
      WHEN InsuranceDocumentPath IS NOT NULL THEN 'Yes' 
      ELSE 'No' 
    END AS Insurance,
    CASE
      WHEN RCDocumentPath IS NOT NULL THEN 'Yes' 
      ELSE 'No' 
    END AS RC,
    CASE
      WHEN RegistrationCopyExtractDocPath IS NOT NULL THEN 'Yes' 
      ELSE 'No' 
    END AS RC_Extract,
    CASE 
      WHEN doc.BO_Handedoverdate IS NULL THEN 'BCM Not Confirmed'
      WHEN doc.BO_Handedoverdate IS NOT NULL AND doc.RO_RecipientConfirmationdate IS NULL THEN 'RO Not received'
      WHEN doc.BO_Handedoverdate IS NOT NULL AND doc.RO_RecipientConfirmationdate IS NOT NULL AND doc.RO_Handedoverdate IS NULL THEN 'RO Not Despatch'
      WHEN doc.BO_Handedoverdate IS NOT NULL AND doc.RO_RecipientConfirmationdate IS NOT NULL AND doc.RO_Handedoverdate IS NOT NULL AND doc.Zonal_confirmationentrydate IS NULL THEN 'HO Not received' 
      WHEN doc.BO_Handedoverdate IS NOT NULL AND doc.RO_RecipientConfirmationdate IS NOT NULL AND doc.RO_Handedoverdate IS NOT NULL AND doc.Zonal_confirmationentrydate IS NOT NULL AND doc.Archival_Receiveddate IS NOT NULL THEN 'Archival received' 
      WHEN doc.BO_Handedoverdate IS NOT NULL AND doc.RO_RecipientConfirmationdate IS NOT NULL AND doc.RO_Handedoverdate IS NOT NULL AND doc.Zonal_confirmationentrydate IS NOT NULL THEN 'HO received' 
      ELSE '' 
    END AS Status,
    --0 as status,
    CASE 
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus IS NULL AND co.CPV_Status IS NULL AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'CB Approved' 
      WHEN cb.CB_Status = 'R' AND co.VerifiedStatus IS NULL AND co.CPV_Status IS NULL AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'CB Rejected' 
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV_Status IS NULL AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'Assessment Approved' 
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'R' AND co.CPV_Status IS NULL AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'Assessment Rejected'
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV_Status = 'A' AND co.CPV2_STATUS = 'A' AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'CPV2 Approved' 
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV_Status = 'A' AND co.CPV2_STATUS IS NULL AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'CPV1 Approved' 
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV_Status = 'A' AND co.CPV2_STATUS = 'R' AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'CPV Rejeted' 
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV_Status = 'R' AND co.CPV2_STATUS IS NULL AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'CPV Pending'
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV_Status = 'R' AND co.CPV2_STATUS = 'R' AND sa.Payment1Amount IS NULL AND sa.Payment2Amount IS NULL THEN 'CPV Rejeted' 
      WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV2_STATUS = 'A' AND sa.Payment1Amount IS NULL THEN 'DP Pending' 
    WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV2_STATUS = 'A' AND COALESCE(sa.Payment1Amount, 0) + COALESCE(sa.Payment2Amount, 0) < COALESCE(sa.marginmoney, 0) THEN 'DP Pending' 
    WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV2_STATUS = 'A' AND COALESCE(sa.Payment1Amount, 0) + COALESCE(sa.Payment2Amount, 0) = COALESCE(sa.marginmoney, 0) AND pt.LoanDisbursementDate IS NULL THEN 'DP Completed'
    WHEN cb.CB_Status = 'A' AND co.VerifiedStatus = 'A' AND co.CPV2_STATUS = 'A' AND COALESCE(sa.Payment1Amount, 0) + COALESCE(sa.Payment2Amount, 0) = COALESCE(sa.marginmoney, 0) AND pt.LoanDisbursementDate IS NOT NULL THEN 'Disbursement Completed'
    ELSE NULL
END AS Final_Status
  FROM  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_coapplicantdetails` co
  LEFT JOIN  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_clientdetails` cl ON co.LoanProposalId = cl.LoanProposalId
  LEFT JOIN  {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` gf on gf.LoanProposalid = co.LoanProposalID
  LEFT JOIN  {mart_catalog}.{mart_schema}.`p_hierarchy_sop` p ON co.BranchID = p.BranchID
  LEFT JOIN StockTemp pt ON co.LoanProposalId = pt.LoanProposalId 
  LEFT JOIN  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_sanctionedapplication` sa ON co.LoanProposalId = sa.Loanproposalid
  LEFT JOIN  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_cb_response` cb ON co.LoanProposalId = cb.LoanproposalID
  LEFT JOIN  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_cpv` cpv ON co.LoanProposalId = cpv.LoanProposalId
  LEFT JOIN  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_ticketsize` tik ON pt.ApprovedAmount = tik.TicketSize AND pt.ProductId = tik.ProductID
  LEFT JOIN  {source_catalog}.{source_schema}.`consumerloan-login` lg ON sa.VendorId = lg.VendorID
  LEFT JOIN  {source_catalog}.{source_schema}.`azuresource-upload_master` up ON up.LoanProposalId = co.LoanProposalId
  left join  {source_catalog}.{source_schema}.`consumerloan-tbl_tw_document_repository` doc  on doc.LoanProposalId = co.LoanProposalId
  WHERE to_date(gf.ProposalDate) > '2023-06-30'

       
 and  (co.ETL_IS_ACTIVE = 1 OR co.ETL_IS_ACTIVE IS NULL) 
    AND (gf.ETL_IS_ACTIVE = 1 OR gf.ETL_IS_ACTIVE IS NULL)
    --AND (p.ETL_IS_ACTIVE = 1 OR p.ETL_IS_ACTIVE IS NULL)
    AND (sa.ETL_IS_ACTIVE = 1 OR sa.ETL_IS_ACTIVE IS NULL)
    AND (cb.ETL_IS_ACTIVE = 1 OR cb.ETL_IS_ACTIVE IS NULL)
    AND (cpv.ETL_IS_ACTIVE = 1 OR cpv.ETL_IS_ACTIVE IS NULL)
    AND (tik.ETL_IS_ACTIVE = 1 OR tik.ETL_IS_ACTIVE IS NULL)
    AND (lg.ETL_IS_ACTIVE = 1 OR lg.ETL_IS_ACTIVE IS NULL)
    AND (up.ETL_IS_ACTIVE = 1 OR up.ETL_IS_ACTIVE IS NULL)
    ORDER BY gf.ProposalDate DESC
),

--select * from Temp

 tbl_tw_MIS_Report as 
(select ClientName,BranchID,BranchName,unitname,
Area,Region,Zone,StateName,LoanProposalCode,LoanProposalId,ClientId,ClientCode,MobileNumber,CoApplicantName,
MobileNumber_Coapp,RC_Extract,Insurance,
RelationWithApp,ProductCode,ProposalDate,LoanDisbursementDate,LoanAmountDisbursed,CancelDate,LoanClosedDate,VendorId,Model,EngineNumber,ChassisNumber,RegistrationNumber,RC
,RCRegistrationDate,RegistrationAuthority,Status,CB_Date,CBEligibleAmount,vendor_name,CoApplicantVoterImage1,CoApplicantVoterImage2,CoApplicantPANImage1,CoApplicantPANImage2,ApplicantVoterImage1,CB_Expire_Status
,ApplicantVoterImage2,ApplicantPANImage1,ApplicantPANImage2,Address,Address_Coapp,Proposal_Assessment_Status,Proposal_Assessment_Date,CPV_Status,CPV_Date,CPV_Remark
,DPStatus, DP_Amount,DPPaymentDate,OnRoadPriceByVendor,Tenure_Type,CSIPJoint,LPF,StampCharges,UTRNo,URTPaymentDate,Invoice,CB_Expire_Date,CB_Status,
cast(URTPaymentAmount as numeric(18,2)),Final_Status from Temp a),

final_cte as (select  LoanProposalId, ClientName,
BranchID,
BranchName,
unitname,
Area,
Region,
Zone,
StateName,
LoanProposalCode,
ClientId,
ClientCode,
MobileNumber,
CoApplicantName,
MobileNumber_Coapp,
RC_Extract,
Insurance,
RelationWithApp,
ProductCode,
ProposalDate,
LoanDisbursementDate,
LoanAmountDisbursed,
CancelDate,
LoanClosedDate,
VendorId,
Model,
EngineNumber,
ChassisNumber,
RegistrationNumber,
RC,
RCRegistrationDate,
RegistrationAuthority,
Status,
CB_Date,
CBEligibleAmount,
vendor_name,
CoApplicantVoterImage1,
CoApplicantVoterImage2,
CoApplicantPANImage1,
CoApplicantPANImage2,
ApplicantVoterImage1,
CB_Expire_Status,
ApplicantVoterImage2,
ApplicantPANImage1,
ApplicantPANImage2,
Address,
Address_Coapp,
Proposal_Assessment_Status,
Proposal_Assessment_Date,
CPV_Status,
CPV_Date,
CPV_Remark,
DPStatus,
DP_Amount,
DPPaymentDate,
OnRoadPriceByVendor,
Tenure_Type,
CSIPJoint,
LPF,
StampCharges,
UTRNo,
URTPaymentDate,
Invoice,
CB_Expire_Date,
CB_Status,
URTPaymentAmount,
Final_Status from tbl_tw_MIS_Report)

--select count(LoanProposalId) from final_cte where LoanDisbursementDate >= '2024-06-01' --group by LoanProposalId;--where LoanDisbursementDate <= ;
--select count(distinct(LoanProposalId)), sum(LoanAmountDisbursed)  from final_cte where LoanDisbursementDate is not null -- group by LoanAmountDisbursed;


select * from final_cte 

;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"tw_mis_report Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on tw_mis_report: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on tw_mis_report : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.tw_mis_report")

    logger(
            logger_level_info,
            f"tw_mis_report writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table tw_mis_report : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table tw_mis_report : ", str(e))


# COMMAND ----------

# %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
# try :
#     # Write DataFrame to Snowflake table
#     df.write.format("snowflake").options(**options).option("dbtable", "tw_mis_report").mode("overwrite").save()
#     logger(
#             logger_level_info,
#             f"tw_mis_report writing to snowflake table has been successfully completed.",
#             execution_log_list,
#             filename,
#     )
# except Exception as e:
#     logger(
#         logger_level_error,
#         f"error occured while writing data into snowflake table tw_mis_report : {str(e)}",
#         execution_log_list,
#         filename,
#     )
#     print(*execution_log_list, sep="\n")
#     # Handle the exception or display the error message as needed
#     raise Exception("error occured while writing data into snowflake table tw_mis_report : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)