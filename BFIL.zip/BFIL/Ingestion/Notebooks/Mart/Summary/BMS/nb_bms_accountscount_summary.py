# Databricks notebook source
spark.conf.set('spark.sql.session.timeZone', 'Asia/Kolkata')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SET mart_catalog = '${dbutils.widgets.get("mart_catalog")}';
# MAGIC SET mart_schema = '${dbutils.widgets.get("mart_schema")}';
# MAGIC SET source_catalog = '${dbutils.widgets.get("source_catalog")}';
# MAGIC SET source_schema = '${dbutils.widgets.get("source_schema")}';
# MAGIC
# MAGIC
# MAGIC Create or replace table ${mart_catalog}.${mart_schema}.BMSAccountsCount_Summary
# MAGIC WITH Acc_BASE AS (
# MAGIC   select 'MerchantSourced'SourceType, OperatorID, AgentID , AccountType, AccountNumber, AccountOpenDate,
# MAGIC         cast(null as STRING)Type, cast(null as STRING) as Balance_Type, cast(null as FLOAT)Balance,
# MAGIC         cast(null as DATE)Bal_Date
# MAGIC       from ${mart_catalog}.${mart_schema}.firewallaccountfacts
# MAGIC       where lower(left(AgentID,3)) in ('i00','i0u')
# MAGIC ),
# MAGIC
# MAGIC Acc_BASE1 AS (
# MAGIC   SELECT * FROM (
# MAGIC     SELECT * FROM Acc_BASE
# MAGIC     UNION
# MAGIC     select 'MerchantSelf'SourceType, OperatorID, cast(merchant_id as STRING) AgentID, AccountType, AccountNumber, AccountOpenDate,
# MAGIC               cast(null as STRING)Type, cast(null as STRING) as Balance_Type, cast(null as FLOAT)Balance,
# MAGIC               cast(null as DATE)Bal_Date
# MAGIC           from ${mart_catalog}.${mart_schema}.firewallaccountfacts A
# MAGIC               Join ${source_catalog}.bfil.`rdsp-merchant_master` B on A.AccountNumber=B.MerchantAccNo
# MAGIC           where left(merchant_id,3) in ('i00','i0u')
# MAGIC               and AccountNumber not in (select AccountNumber
# MAGIC               from Acc_Base)
# MAGIC   )
# MAGIC ),
# MAGIC
# MAGIC Acc AS (
# MAGIC   select * from Acc_BASE1
# MAGIC   union
# MAGIC       select 'BMOSourced' As SourceType, OperatorID, AgentID, AccountType, AccountNumber, AccountOpenDate,
# MAGIC           cast(null as STRING)Type, cast(null as STRING) as Balance_Type, cast(null as FLOAT)Balance,
# MAGIC           cast(null as DATE)Bal_Date
# MAGIC       from ${mart_catalog}.${mart_schema}.firewallaccountfacts
# MAGIC       where lower(left(AgentID,1)) <>'i' and upper(OperatorID)='RDSP-M'
# MAGIC           and AccountNumber not in (select AccountNumber
# MAGIC           from Acc_BASE1)
# MAGIC ),
# MAGIC
# MAGIC T_Nar_BMSAccountsdata AS (
# MAGIC   SELECT 
# MAGIC     A.SourceType,
# MAGIC     A.OperatorID,
# MAGIC     A.AgentID,
# MAGIC     A.AccountType,
# MAGIC     A.AccountNumber,
# MAGIC     A.AccountOpenDate,
# MAGIC     CASE 
# MAGIC       WHEN CAST(A.AccountOpenDate as DATE) >= date_add(last_day(add_months(CAST(current_date() AS DATE), -1)), 1) THEN 'NTB'
# MAGIC       WHEN CAST(A.AccountOpenDate as DATE) <= last_day(add_months(CAST(current_date() AS DATE), -1)) THEN 'ETB'
# MAGIC     END AS Type,
# MAGIC     CASE WHEN CAST(A.Balance as INT) = 0 THEN 'Zero' WHEN  CAST(A.Balance as INT) <> 0 THEN 'Non Zero' WHEN A.Balance_Type IS NULL THEN 'NA'
# MAGIC     END AS Balance_Type,
# MAGIC     CASE WHEN upper(A.AccountType) IN ('CR','SB','RD','FD') THEN B.BAL_YESTERDAY 
# MAGIC     END AS Balance,
# MAGIC     -- (select top 1 DATE1 from SRFC_Indus..X_CA_Balance_BFIL_Accounts_daily) A.Bal_Date
# MAGIC     CAST(getdate() as DATE) - 1  Bal_Date
# MAGIC   FROM Acc A
# MAGIC   LEFT JOIN ${mart_catalog}.finacle.ibl_balances_report_vw B
# MAGIC   ON A.AccountNumber = B.FORACID
# MAGIC ),
# MAGIC
# MAGIC T_Nar_BMSAccountsdata_Summary AS (
# MAGIC   select SourceType, OperatorID, AgentID As MerchantID, AccountType, Type, Balance_Type, Bal_Date,
# MAGIC         COUNT(AccountNumber)Acc_COunt, SUM(coalesce(Balance,0))Balance
# MAGIC     from T_Nar_BMSAccountsdata
# MAGIC     group by SourceType,OperatorID, AgentID, AccountType,Type,Balance_Type,Bal_Date
# MAGIC ),
# MAGIC
# MAGIC T_Nar_BMSAccountsdata_Summary1 AS (
# MAGIC   select current_timestamp() AS ReportDatetime, Type, SourceType, MerchantID, Balance_Type, Bal_Date,
# MAGIC         coalesce(sum(case when AccountType='SB' and Type='ETB' then coalesce(Acc_COunt,0) end),0) SB_ETB,
# MAGIC         coalesce(sum(case when AccountType='RD' and Type='ETB' then coalesce(Acc_COunt,0) end),0) RD_ETB,
# MAGIC         coalesce(sum(case when AccountType='FD' and Type='ETB' then coalesce(Acc_COunt,0) end),0) FD_ETB,
# MAGIC         coalesce(sum(case when AccountType='CR' and Type='ETB' then coalesce(Acc_COunt,0) end),0) CR_ETB,
# MAGIC         coalesce(sum(case when AccountType='SB' and Type='NTB' then coalesce(Acc_COunt,0) end),0) SB_NTB,
# MAGIC         coalesce(sum(case when AccountType='RD' and Type='NTB' then coalesce(Acc_COunt,0) end),0) RD_NTB,
# MAGIC         coalesce(sum(case when AccountType='FD' and Type='NTB' then coalesce(Acc_COunt,0) end),0) FD_NTB,
# MAGIC         coalesce(sum(case when AccountType='CR' and Type='NTB' then coalesce(Acc_COunt,0) end),0) CR_NTB
# MAGIC     from T_Nar_BMSAccountsdata_Summary
# MAGIC     group by ReportDatetime,Type,SourceType,MerchantID,Balance_Type,Bal_Date
# MAGIC )
# MAGIC
# MAGIC SELECT * FROM T_Nar_BMSAccountsdata_Summary1
# MAGIC
# MAGIC