# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_pbi_summary_disbursementfacts.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/PBI_SUMMARY_DISBURSEMENTFACTS"
    desti_path = "BFIL-MART/REPORTING/PBI_SUMMARY_DISBURSEMENTFACTS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
with PBI_Summary_DisbursementFacts as (
Select hierarchyid,last_day(DisbursementDate)DisbursementMonth,ProductCategory,DisbursementType,
DisbursementMode,Tenure,IsLoanCancelled,Loanstatus,BankType,count(1)NOL,sum(LoanAmountDisbursed)LoanAmountDisbursed  
from {mart_catalog}.{mart_schema}.`disbursement_facts`
group by hierarchyid,DisbursementMonth,ProductCategory,DisbursementType,DisbursementMode,Tenure,IsLoanCancelled,Loanstatus,BankType)
select hierarchyid,DisbursementMonth,DisbursementType,Tenure,IsLoanCancelled,BankType,NOL,LoanAmountDisbursed,case
when DisbursementMode = 'DM3' then 'In Bank A/c'
when DisbursementMode = 'DM1' then 'Cash/Product'
when LoanStatus = 'Open' then '2. Open'
when LoanStatus = 'pre-Closure' then '3. PreClosed'
when LoanStatus = 'Closed' then '4. Closed'
else LoanStatus End  as LoanStatus, case
when ProductCategory = 'MFI' then '1. MFI'
when ProductCategory in ('Unnati','UnnatiPls') then '2. Unnati'
when ProductCategory = 'FUL' then '3. CDS'
when ProductCategory = 'Two Wheelers' then '4. Two Wheelers'
when ProductCategory = 'Retail Loan' then '5. BSS Loans'
when ProductCategory like 'RDSP%' then '6. BMS Loans'
else ProductCategory End   as ProductCategory from PBI_Summary_DisbursementFacts""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"pbi_summary_disbursementfacts Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on pbi_summary_disbursementfacts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on pbi_summary_disbursementfacts : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.pbi_summary_disbursementfacts")

    logger(
            logger_level_info,
            f"pbi_summary_disbursementfacts writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table pbi_summary_disbursementfacts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table pbi_summary_disbursementfacts : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "pbi_summary_disbursementfacts").mode("overwrite").save()
    logger(
            logger_level_info,
            f"pbi_summary_disbursementfacts writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table pbi_summary_disbursementfacts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table pbi_summary_disbursementfacts : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)