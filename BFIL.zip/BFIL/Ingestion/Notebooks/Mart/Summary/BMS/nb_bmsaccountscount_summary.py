# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_bmsaccountscount_summary.dbc"

# COMMAND ----------

spark.conf.set('spark.sql.session.timeZone', 'Asia/Kolkata')

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/BMSACCOUNTSCOUNT_SUMMARY"
    desti_path = "BFIL-MART/REPORTING/BMSACCOUNTSCOUNT_SUMMARY"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
WITH Acc_BASE AS (
  select 'MerchantSourced'SourceType, OperatorID, AgentID , AccountType, AccountNumber, AccountOpenDate,
        cast(null as STRING)Type, cast(null as STRING) as Balance_Type, cast(null as FLOAT)Balance,
        cast(null as DATE)Bal_Date
      from {mart_catalog}.{mart_schema}.firewallaccounts_facts
      where lower(left(AgentID,3)) in ('i00','i0u')
),
Acc_BASE1 AS (
  SELECT * FROM (
    SELECT * FROM Acc_BASE
    UNION
    select 'MerchantSelf'SourceType, OperatorID, cast(merchant_id as STRING) AgentID, AccountType, AccountNumber, AccountOpenDate,
              cast(null as STRING)Type, cast(null as STRING) as Balance_Type, cast(null as FLOAT)Balance,
              cast(null as DATE)Bal_Date
          from {mart_catalog}.{mart_schema}.firewallaccounts_facts A
              Join {source_catalog}.{source_schema}.`rdsp-merchant_master` B on A.AccountNumber=B.MerchantAccNo
          where left(merchant_id,3) in ('i00','i0u')
              and AccountNumber not in (select AccountNumber
              from Acc_Base)
  )
),
Acc AS (
  select * from Acc_BASE1
  union
      select 'BMOSourced' As SourceType, OperatorID, AgentID, AccountType, AccountNumber, AccountOpenDate,
          cast(null as STRING)Type, cast(null as STRING) as Balance_Type, cast(null as FLOAT)Balance,
          cast(null as DATE)Bal_Date
      from {mart_catalog}.{mart_schema}.firewallaccounts_facts
      where lower(left(AgentID,1)) <>'i' and upper(OperatorID)='RDSP-M'
          and AccountNumber not in (select AccountNumber
          from Acc_BASE1)
),
T_Nar_BMSAccountsdata AS (
  SELECT 
    A.SourceType,
    A.OperatorID,
    A.AgentID,
    A.AccountType,
    A.AccountNumber,
    A.AccountOpenDate,
    CASE 
      WHEN CAST(A.AccountOpenDate as DATE) >= date_add(last_day(add_months(CAST(current_date() AS DATE), -1)), 1) THEN 'NTB'
      WHEN CAST(A.AccountOpenDate as DATE) <= last_day(add_months(CAST(current_date() AS DATE), -1)) THEN 'ETB'
    END AS Type,
    CASE WHEN CAST(A.Balance as INT) = 0 THEN 'Zero' WHEN  CAST(A.Balance as INT) <> 0 THEN 'Non Zero' WHEN A.Balance_Type IS NULL THEN 'NA'
    END AS Balance_Type,
    CASE WHEN upper(A.AccountType) IN ('CR','SB','RD','FD') THEN B.BAL_YESTERDAY 
    END AS Balance,
    -- (select top 1 DATE1 from SRFC_Indus..X_CA_Balance_BFIL_Accounts_daily) A.Bal_Date
    CAST(getdate() as DATE) - 1  Bal_Date
  FROM Acc A
  LEFT JOIN {mart_catalog}.finacle.ibl_balances_report_vw B
  ON A.AccountNumber = B.FORACID
),
T_Nar_BMSAccountsdata_Summary AS (
  select SourceType, OperatorID, AgentID As MerchantID, AccountType, Type, Balance_Type, Bal_Date,
        COUNT(AccountNumber)Acc_COunt, SUM(coalesce(Balance,0))Balance
    from T_Nar_BMSAccountsdata
    group by SourceType,OperatorID, AgentID, AccountType,Type,Balance_Type,Bal_Date
),
T_Nar_BMSAccountsdata_Summary1 AS (
  select current_timestamp() AS ReportDatetime, Type, SourceType, MerchantID, Balance_Type, Bal_Date,
        coalesce(sum(case when AccountType='SB' and Type='ETB' then coalesce(Acc_COunt,0) end),0) SB_ETB,
        coalesce(sum(case when AccountType='RD' and Type='ETB' then coalesce(Acc_COunt,0) end),0) RD_ETB,
        coalesce(sum(case when AccountType='FD' and Type='ETB' then coalesce(Acc_COunt,0) end),0) FD_ETB,
        coalesce(sum(case when AccountType='CR' and Type='ETB' then coalesce(Acc_COunt,0) end),0) CR_ETB,
        coalesce(sum(case when AccountType='SB' and Type='NTB' then coalesce(Acc_COunt,0) end),0) SB_NTB,
        coalesce(sum(case when AccountType='RD' and Type='NTB' then coalesce(Acc_COunt,0) end),0) RD_NTB,
        coalesce(sum(case when AccountType='FD' and Type='NTB' then coalesce(Acc_COunt,0) end),0) FD_NTB,
        coalesce(sum(case when AccountType='CR' and Type='NTB' then coalesce(Acc_COunt,0) end),0) CR_NTB
    from T_Nar_BMSAccountsdata_Summary
    group by ReportDatetime,Type,SourceType,MerchantID,Balance_Type,Bal_Date
)
SELECT * FROM T_Nar_BMSAccountsdata_Summary1""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"bmsaccountscount_summary Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on bmsaccountscount_summary: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on bmsaccountscount_summary : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.bmsaccountscount_summary")

    logger(
            logger_level_info,
            f"bmsaccountscount_summary writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table bmsaccountscount_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table bmsaccountscount_summary : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "bmsaccountscount_summary").mode("overwrite").save()
    logger(
            logger_level_info,
            f"bmsaccountscount_summary writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table bmsaccountscount_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table bmsaccountscount_summary : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)