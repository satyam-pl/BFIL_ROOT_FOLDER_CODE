# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_bucket_resolution.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )    
    
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/BUCKET_RESOLUTION"
    desti_path = "BFIL-MART/REPORTING/BUCKET_RESOLUTION"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    df = (
        spark.sql(
            f"""WITH CTE_Report AS (
        SELECT 
                Hierarchyid,
                Branch_type,
                BranchID,
                branchname,
                statename,
                ZoneName,
                Region,
                Districtname,
                centerstaffid,
                centerid,
                clientcode,
                Joindate,
                clientid,
                Expected_NPAdate,
                EWI,
                NOL,
                POS,
                Arrear,
                LastRepaymentDate,
                Max_Disbursementdate,
                Max_Loancloseddate,
                GroupID,
                centermeetingday,
                centername,
                cmtime,
                --staffid, -- Commented on 06-06-2025 | instead use centerstaffid
                centercode,
                --CMday, -- Commented on 06-06-2025 | instead use centermeetingday
                CenterStatus,
                staffname,
                Area,
                Unitname,
                Ageing_client_CM,
                Client_DPD,
                Clientname,
                Spousename,
                ISdeath,
                Npa_date,
                As_on_NPA,
                Mar20_NPA,
                Mar21_NPA,
                Monthend_Status,
                client_type,
                Ageing_client_PM,
                Monthend_status_PM,
                DPDstartdate,
                suvidha_client,
                Coll_paid_status_PM,
                Arrear_4EWI_PM,
                Mtd_due,
                MTD_coll,
                M_PriDue, -- Changed on 06-06-2025 (OLD COLUMN NAME Mtd_pridue)
                M_priColl, -- Changed on 06-06-2025 (OLD COLUMN NAME MTD_pricoll)
                M_IntDue, -- Changed on 06-06-2025 (OLD COLUMN NAME Mtd_intdue)
                M_IntColl, -- Changed on 06-06-2025 (OLD COLUMN NAME MTD_intcoll)
                MTD_Due_Coll,
                PaidEWI,
                Coll_paid_status_CM,
                Arrear_4EWI_CM,
                client_Ason_status,
                As_on_CollPaid,
                PM_CollPaid,
                MobileNumber,
                PhoneNumber,
                ClientNPAstatus_PM,
                Arrear_PM,
                POS_PM,
                LC_PM,
                ISdeath_PM,
                Grosscoll,
                Ageing,
                Ageing_PM
                FROM {source_catalog}.{source_schema}.`azuresource-t_din_branchwise_pos_oct`
                WHERE Branch_type= 'SMPT'
                or
            client_Ason_status NOT in (                                              
            'GNPA_mar20_writeoff_Dec22',                                  
            'GNPA_mar20_writeoff_Jun23',                                  
            'GNPA_Mar20_writeoff_mar22',                                  
            'GNPA_mar20_writeoff_Mar23',                                  
            'GNPA_mar20_writeoff_Sep22',                                  
            'GNPA_mar20_writeoff_sep23',                                  
            'GNPA_mar21_writeoff_Dec22',                                  
            'GNPA_mar21_writeoff_Jun23',                                  
            'GNPA_Mar21_writeoff_mar22',                                  
            'GNPA_mar21_writeoff_Mar23',          
            'GNPA_mar21_writeoff_Sep22',                                  
            'GNPA_mar21_writeoff_sep23')
            OR ISdeath!='yes' or Ageing!='ClosedClient' 
            or Ageing is not null
    ),
    CTE_Report2 AS (
        SELECT 
                a.Hierarchyid,
                a.Branch_type,
                a.BranchID,
                a.branchname,
                a.statename,
                a.ZoneName,
                a.Region,
                a.Districtname,
                a.centerstaffid,
                a.centerid,
                a.clientcode,
                a.Joindate,
                a.clientid,
                Expected_NPAdate,
                NOL,
                a.POS,
                Arrear,
                a.Max_Disbursementdate,
                Max_Loancloseddate,
                a.GroupID,
                a.centermeetingday,
                a.centername,
                a.cmtime,
                -- a.staffid, --Commented on 06-06-2025
                a.centercode,
                -- a.CMday,  --Commented on 06-06-2025
                a.CenterStatus,
                a.staffname,
                a.Area,
                a.Unitname,
                Ageing_client_CM,
                Client_DPD,
                a.Clientname,
                a.Spousename,
                a.ISdeath,
                a.Npa_date,
                a.As_on_NPA,
                a.Mar20_NPA,
                a.Mar21_NPA,
                Monthend_Status,
                a.client_type,
                a.Ageing_client_PM,
                a.Monthend_status_PM,
                a.DPDstartdate,
                a. suvidha_client,
                Coll_paid_status_PM,
                Arrear_4EWI_PM,
                a.Mtd_due,
                a.M_PriDue, -- Mtd_pridue,
                a.M_priColl, -- MTD_pricoll,
                a.M_IntDue, -- Mtd_intdue,
                a.M_IntColl, -- MTD_intcoll,
                a.PaidEWI,
                Coll_paid_status_CM,
                Arrear_4EWI_CM,
                client_Ason_status,
                a.As_on_CollPaid,
                a.PM_CollPaid,
                MobileNumber,
                PhoneNumber,
                a.ClientNPAstatus_PM,
                a.Arrear_PM,
                POS_PM,
                LC_PM,
                ISdeath_PM,
                a.Grosscoll,
                a.Ageing,
                Ageing_PM,
                --b.ClientNPAstatus as Client_status_cm,
                b.ClientNPAstatus_PM as Client_status_cm ,
                b.Ageing as Ageing_Cm,
                b.IsDeath as IsDeath_Cm,
                b.POS as Pos_cm,
                b.PrINcipalINArears as Principalinarears,
                b.INterestINArears as interestinarears,
                b.NoOfDaysInArrears as AsonDpd,
                b.EWi as EWI,
                b.LastRepaymentDate as LastRepaymentDate,
                b.MTD_Due as Mtd_due_cm,
                b.MTD_Coll as Mtd_Coll_Cm,
                b.MTD_Due_Coll as Mtd_due_Coll_Cm
            FROM CTE_Report a
            LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary b ON a.clientid = b.clientid
    ),
    CTE_Update AS (
        SELECT
    a.Branch_type,
    a.centerstaffid,
    a.centerid,
    a.clientcode,
    a.Joindate,
    a.clientid,
    a.Expected_NPAdate,
    a.EWI,
    a.NOL,
    a.POS,
    a.Arrear,
    a.Max_Disbursementdate,
    a.Max_Loancloseddate,
    a.GroupID,
    a.centermeetingday,
    a.centername,
    a.cmtime,
    -- a.staffid, --Commented on 06-06-2025
    a.centercode,
    -- a.CMday,  --Commented on 06-06-2025
    a.CenterStatus,
    a.staffname,
    a.Ageing_client_CM,
    a.Client_DPD,
    a.Clientname,
    a.Spousename,
    a.ISdeath,
    a.Npa_date,
    a.As_on_NPA,
    a.Mar20_NPA,
    a.Mar21_NPA,
    a.Monthend_Status,
    a.client_type,
    a.Ageing_client_PM,
    a.Monthend_status_PM,
    a.DPDstartdate,
    a.suvidha_client,
    a.Coll_paid_status_PM,
    a.Arrear_4EWI_PM,
    a.Mtd_due,
    a.M_PriDue, -- Mtd_pridue,
    a.M_priColl, -- MTD_pricoll,
    a.M_IntDue, -- Mtd_intdue,
    a.M_IntColl, -- MTD_intcoll,
    a.PaidEWI,
    a.Coll_paid_status_CM,
    a.Arrear_4EWI_CM,
    a.client_Ason_status,
    a.As_on_CollPaid,
    a.PM_CollPaid,
    a.MobileNumber,
    a.PhoneNumber,
    a.ClientNPAstatus_PM,
    a.Arrear_PM,
    a.POS_PM,
    a.LC_PM,
    a.ISdeath_PM,
    a.Grosscoll,
    a.Ageing,
    a.Ageing_PM,
    a.ClientNPAstatus_PM as Client_status_cm,
    a.Ageing_Cm,
    a.IsDeath_Cm,
    a.Pos_cm,
    a.Principalinarears,
    a.interestinarears,
    a.AsonDpd,
    a.LastRepaymentDate,
    a.Mtd_due_cm,
    a.Mtd_Coll_Cm,
    a.Mtd_due_Coll_Cm,
    CASE WHEN b.Hierarchyid IS NOT NULL THEN b.Hierarchyid ELSE a.Hierarchyid END AS New_Hierarchyid,
    CASE WHEN c.Branchid IS NOT NULL THEN c.Branchid ELSE a.branchid END AS branchid,
    CASE WHEN c.BranchName IS NOT NULL THEN c.BranchName ELSE a.branchname END AS branchname,
    CASE WHEN c.ZONE IS NOT NULL THEN c.ZONE ELSE a.ZoneName END AS ZoneName,
    CASE WHEN c.Region IS NOT NULL THEN c.Region ELSE a.region END AS region,
    CASE WHEN c.district IS NOT NULL THEN c.district ELSE a.Districtname END AS Districtname,
    CASE WHEN c.state IS NOT NULL THEN c.state ELSE a.statename END AS statename,
    CASE WHEN c.UMBaseLocationBranchName IS NOT NULL THEN c.UMBaseLocationBranchName ELSE a.Unitname END AS Unitname,
    CASE WHEN c.AREA IS NOT NULL THEN c.AREA ELSE a.Area END AS Area,
    c.SBHState as SBH
        FROM CTE_Report2 a
        LEFT JOIN {source_catalog}.{source_schema}.`ptsmart-clientmaster` b ON a.clientid = b.clientid
        LEFT JOIN {mart_catalog}.{mart_schema}.p_hierarchy_sop c ON b.Hierarchyid = c.Hierarchyid
    ),
    CTE_Bucket_Update AS (
        SELECT 
            *,
            CASE 
        WHEN Ageing = '[1 To 30]' THEN dateadd(day, (31 - Client_DPD), '2024-04-30')
        WHEN Ageing = '[31 To 60]' THEN dateadd(day, (61 - Client_DPD), '2024-04-30')
        WHEN Ageing = '[61 To 90]' THEN dateadd(day, (91 - Client_DPD), '2024-04-30')
    END AS Bucket_Movementdate,
    CASE
        WHEN Ageing = '[1 To 30]' THEN dateadd(day, (31 - AsonDpd), '2024-04-30')
        WHEN Ageing = '[31 To 60]' THEN dateadd(day, (61 - AsonDpd), '2024-04-30')
        WHEN Ageing = '[61 To 90]' THEN dateadd(day, (91 - AsonDpd), '2024-04-30')
    END AS Bucket_movementdate_Ason,
        CASE
            WHEN Ageing = '[1 To 30]' AND Bucket_Movementdate <= CURRENT_DATE() - 1 THEN 1
            WHEN Ageing = '[31 To 60]' AND Bucket_Movementdate <= CURRENT_DATE() - 1 THEN 2
            WHEN Ageing = '[60 To 90]' AND Bucket_Movementdate <= CURRENT_DATE() - 1 THEN 3
        -- ELSE a.Mtd_Exp_Flow
        END AS Mtd_Exp_Flow,
        CASE
            WHEN Ageing = 'Current1' AND CTE_update.Ageing_Cm IN ('[1 To 30]', '[31 To 60]', '[61 To 90]', '[>90]') AND CTE_update.ISdeath_cm IS NULL THEN 'Current_Forwardflow'
            WHEN Ageing = '[1 To 30]' AND CTE_update.Ageing_cm IN ('[31 To 60]', '[61 To 90]', '[>90]') 
            THEN '1-30_Forwardflow'
            WHEN Ageing = '[31 To 60]' AND CTE_update.Ageing_cm IN ('[61 To 90]', '[>90]') THEN '31-60_Forwardflow'
            WHEN Ageing = '[61 To 90]' AND CTE_update.Ageing_cm IN ('[>90]') THEN '61-90_Forwardflow'
        END AS Forwardflow_Status
        FROM CTE_Update
    ),
    c_Updated_Mtd_Exp_Flow as (
        select *,
    CASE
        WHEN Ageing = '[1 To 30]' AND (Principalinarears + interestinarears) = 0 AND CTE_Bucket_Update.Mtd_Exp_Flow IS NULL THEN 1
        WHEN Ageing = '[31 To 60]' AND (Principalinarears + interestinarears) = 0 AND CTE_Bucket_Update.Mtd_Exp_Flow IS NULL THEN 2
        WHEN Ageing = '[61 To 90]' AND (Principalinarears + interestinarears) = 0 AND CTE_Bucket_Update.Mtd_Exp_Flow IS NULL THEN 3
    ELSE Mtd_Exp_Flow
            END AS Updated_Mtd_Exp_Flow
    from CTE_Bucket_Update
    ),
    c_Updated_Mtd_Exp_Flow2 as (
        select *,
    CASE
                WHEN Ageing = '[1 To 30]' AND Ageing_cm NOT IN ('[31 To 60]','[61 To 90]', '[>90]') AND Bucket_movementdate_Ason >= '2024-06-01' 
        AND c_Updated_Mtd_Exp_Flow.Updated_Mtd_Exp_Flow IS NULL THEN 1
                WHEN Ageing = '[31 To 60]' AND Ageing_cm NOT IN ('[61 To 90]', '[>90]') AND Bucket_movementdate_Ason >= '2024-06-01' 
        AND c_Updated_Mtd_Exp_Flow.Updated_Mtd_Exp_Flow IS NULL THEN 2
                WHEN Ageing = '[61 To 90]' AND Ageing_cm NOT IN ( '[>90]') AND Bucket_movementdate_Ason >= '2024-06-01' 
        AND c_Updated_Mtd_Exp_Flow.Updated_Mtd_Exp_Flow IS NULL THEN 3
    ELSE c_Updated_Mtd_Exp_Flow.Updated_Mtd_Exp_Flow
            END AS Updated_Mtd_Exp_Flow2
    from c_Updated_Mtd_Exp_Flow
    ),
    update_forward AS (
    select *,
    CASE
        WHEN Ageing = '[1 To 30]' AND Ageing_cm = 'Current1' AND c_Updated_Mtd_Exp_Flow2.Forwardflow_Status IS NULL THEN 'Backwardflow'
        WHEN Ageing = '[31 To 60]' AND Ageing_cm IN ('Current1', '[1 To 30]') AND c_Updated_Mtd_Exp_Flow2.Forwardflow_Status IS NULL THEN 'Backwardflow'
        WHEN Ageing = '[61 To 90]' AND Ageing_cm IN ('Current1', '[1 To 30]', '[31 To 60]') AND c_Updated_Mtd_Exp_Flow2.Forwardflow_Status IS NULL THEN 'Backwardflow'
        WHEN Ageing = '[>90]' AND Ageing_cm IN ('Current1', '[1 To 30]', '[31 To 60]', '[61 To 90]') AND c_Updated_Mtd_Exp_Flow2.Forwardflow_Status IS NULL THEN 'Backwardflow'
        ELSE c_Updated_Mtd_Exp_Flow2.Forwardflow_Status
        END AS Updated_Forwardflow_Status 
    from c_Updated_Mtd_Exp_Flow2
    ),
    same_bucket AS
    (
        Select *,
        CASE
    WHEN update_forward.Updated_Forwardflow_Status IS NULL AND Ageing = 'Current1' AND Ageing_cm = 'Current1' THEN 'Same_Bucket'
                WHEN update_forward.Updated_Forwardflow_Status IS NULL AND Ageing = '[1 To 30]' AND Ageing_cm = '[1 To 30]' THEN 'Same_Bucket'
                WHEN update_forward.Updated_Forwardflow_Status IS NULL AND Ageing = '[1 To 30]' AND Ageing_cm = '[1 To 30]' THEN 'Same_Bucket'
                WHEN update_forward.Updated_Forwardflow_Status IS NULL AND Ageing = '[1 To 30]' AND Ageing_cm = '[1 To 30]' THEN 'Same_Bucket'
                WHEN update_forward.Updated_Forwardflow_Status IS NULL AND Ageing = '[31 To 60]' AND Ageing_cm = '[31 To 60]' THEN 'Same_Bucket'
                WHEN update_forward.Updated_Forwardflow_Status IS NULL AND Ageing = '[61 To 90]' AND Ageing_cm = '[61 To 90]' THEN 'Same_Bucket'
                WHEN update_forward.Updated_Forwardflow_Status IS NULL AND Ageing = '[>90]' AND Ageing_cm = '[>90]' THEN 'Same_Bucket'
                ELSE update_forward.Updated_Forwardflow_Status
                END AS Updated_Forwardflow_Status2
    from update_forward
    ),
    Final_CTE as 
    (
    SELECT
    New_Hierarchyid,
    Branch_type,
    BranchID,
    branchname,
    statename,
    ZoneName,
    Region,
    Districtname,
    centerstaffid,
    centerid,
    clientcode,
    Joindate,
    clientid,
    Expected_NPAdate,
    EWI,
    NOL,
    POS,
    Arrear,
    LastRepaymentDate,
    Max_Disbursementdate,
    Max_Loancloseddate,
    GroupID,
    centermeetingday,
    centername,
    cmtime,
    --staffid,
    centercode,
    --CMday,
    CenterStatus,
    staffname,
    Area,
    Unitname,
    Ageing_client_CM,
    Client_DPD,
    Clientname,
    Spousename,
    ISdeath,
    Npa_date,
    As_on_NPA,
    Mar20_NPA,
    Mar21_NPA,
    Monthend_Status,
    client_type,
    Ageing_client_PM,
    Monthend_status_PM,
    DPDstartdate,
    suvidha_client,
    Coll_paid_status_PM,
    Arrear_4EWI_PM,
    Mtd_due,
    Mtd_Coll_Cm,
    M_PriDue, -- Mtd_pridue
    M_priColl, -- MTD_pricoll
    M_IntDue, -- Mtd_intdue
    M_IntColl, -- MTD_intcoll
    Mtd_due_Coll_Cm,
    PaidEWI,
    Coll_paid_status_CM,
    Arrear_4EWI_CM,
    client_Ason_status,
    As_on_CollPaid,
    PM_CollPaid,
    MobileNumber,
    PhoneNumber,
    ClientNPAstatus_PM,
    Arrear_PM,
    POS_PM,
    LC_PM,
    ISdeath_PM,
    Grosscoll,
    Ageing,
    Ageing_PM,
    Ageing_Cm,
    IsDeath_Cm,
    Pos_cm,
    Principalinarears,
    interestinarears,
    AsonDpd,
    EWI,
    LastRepaymentDate,
    Mtd_due_cm,
    Bucket_Movementdate,
    Bucket_movementdate_Ason,
    Updated_Mtd_Exp_Flow2
    Updated_Forwardflow_Status2
    from same_bucket   
    ),
    finaltable2 AS (
    SELECT 
        New_Hierarchyid,
        BranchID,
        branchname,
        statename,
        ZoneName,
        Region,
        Districtname,
        SBH,
        Area,
        Unitname,
        CAST((SUM(pos) / 10000000) AS DECIMAL(10, 7)) AS Prvs_Mnth_pos,
        COUNT(DISTINCT CASE WHEN Ageing = 'Current1' THEN clientid END) AS LC_Current,
        CAST((SUM(CASE WHEN Ageing = 'Current1' THEN Pos END) / 10000000) AS DECIMAL(10, 7)) AS Current_Base_Pos_Cr,
        COUNT(DISTINCT CASE WHEN Forwardflow_Status = 'Current_Forwardflow' THEN clientid END) AS LC_Current_Forwardflow,
        CAST(SUM(CASE WHEN Forwardflow_Status = 'Current_Forwardflow' THEN IFNULL(Pos_cm, 0) END) / 10000000 AS DECIMAL(10, 7)) AS Current_Forwardflow_Poscr,
        CAST((SUM(CASE WHEN Ageing = 'Current1' THEN IFNULL(Mtd_due_cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS Current_MTD_DueCr,
        CAST((SUM(CASE WHEN Ageing = 'Current1' THEN IFNULL(Mtd_due_Coll_Cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS Current_MTD_Due_CollCr,
        COUNT(DISTINCT CASE WHEN Ageing = '[1 To 30]' THEN clientid END) AS `LC_1-30`,
        CAST((SUM(CASE WHEN Ageing = '[1 To 30]' THEN IFNULL(Pos, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `1-30_Base_PosCr`,
        COUNT(CASE WHEN Mtd_Exp_Flow = 1 THEN clientid END) AS `1-30_Mtd_Exp_Flow_Lc`,
        CAST((SUM(CASE WHEN Mtd_Exp_Flow = 1 THEN IFNULL(Pos, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `1-30_Mtd_Exp_Flow_Poscr`,
        COUNT(DISTINCT CASE WHEN Forwardflow_Status = '1-30_Forwardflow' THEN clientid END) AS `LC_1-30_Forwardflow`,
        CAST(SUM(CASE WHEN Forwardflow_Status = '1-30_Forwardflow' THEN IFNULL(Pos_cm, 0) END) / 10000000 AS DECIMAL(10, 7)) AS `1-30_Forwardflow_Poscr`,
        CAST((SUM(CASE WHEN Ageing = '[1 To 30]' THEN IFNULL(Mtd_due_cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `1-30_Mtd_Duecr`,
        CAST((SUM(CASE WHEN Ageing = '[1 To 30]' THEN IFNULL(Mtd_due_Coll_Cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `1-30_Mtd_Due_Collcr`,
        COUNT(DISTINCT CASE WHEN Ageing = '[31 To 60]' THEN clientid END) AS `LC_31-60`,
        CAST((SUM(CASE WHEN Ageing = '[31 To 60]' THEN IFNULL(Pos, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `31-60_Base_PosCr`,
        COUNT(CASE WHEN Mtd_Exp_Flow = 2 THEN clientid END) AS `31-60_Mtd_Exp_Flow_Lc`,
        CAST((SUM(CASE WHEN Mtd_Exp_Flow = 2 THEN IFNULL(Pos, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `31-60_Mtd_Exp_Flow_Poscr`,
        COUNT(DISTINCT CASE WHEN Forwardflow_Status = '31-60_Forwardflow' THEN clientid END) AS `LC_31-60_Forwardflow`,
        CAST(SUM(CASE WHEN Forwardflow_Status = '31-60_Forwardflow' THEN IFNULL(Pos_cm, 0) END) / 10000000 AS DECIMAL(10, 7)) AS `31-60_Forwardflow_Poscr`,
        CAST((SUM(CASE WHEN Ageing = '[31 To 60]' THEN IFNULL(Mtd_due_cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `31-60_Mtd_Duecr`,
        CAST((SUM(CASE WHEN Ageing = '[31 To 60]' THEN IFNULL(Mtd_due_Coll_Cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `31-60_Mtd_Due_Collcr`,
        COUNT(DISTINCT CASE WHEN Ageing = '[61 To 90]' THEN clientid END) AS `LC_61-90`,
        CAST((SUM(CASE WHEN Ageing = '[61 To 90]' THEN IFNULL(Pos, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `61-90_Base_PosCr`,
        COUNT(CASE WHEN Mtd_Exp_Flow = 3 THEN clientid END) AS `61-90_Mtd_Exp_Flow_Lc`,
        CAST((SUM(CASE WHEN Mtd_Exp_Flow = 3 THEN IFNULL(Pos, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `61-90_Mtd_Exp_Flow_Poscr`,
        COUNT(DISTINCT CASE WHEN Forwardflow_Status = '61-90_Forwardflow' THEN clientid END) AS `LC_61-90_Forwardflow`,
        CAST((SUM(CASE WHEN Forwardflow_Status = '61-90_Forwardflow' THEN IFNULL(Pos_cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `61-90_Forwardflow_Poscr`,
        CAST((SUM(CASE WHEN Ageing = '[61 To 90]' THEN IFNULL(Mtd_due_cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `61-90_Mtd_Duecr`,
        CAST((SUM(CASE WHEN Ageing = '[61 To 90]' THEN IFNULL(Mtd_due_Coll_Cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `61-90_Mtd_Due_Collcr`,
        COUNT(DISTINCT CASE WHEN Ageing = '[>90]' THEN clientid END) AS `LC_>90`,
        CAST((SUM(CASE WHEN Ageing = '[>90]' THEN IFNULL(Pos, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `>90_Base_PosCr`,
        CAST((SUM(CASE WHEN Ageing = '[>90]' THEN IFNULL(Mtd_Coll_Cm, 0) END) / 10000000) AS DECIMAL(10, 7)) AS `>90_Mtd_Collcr`
    FROM 
        same_bucket
    GROUP BY 
        New_Hierarchyid, BranchID, branchname, statename, ZoneName, Region, Districtname, SBH, Area, Unitname 
        )
    select * from finaltable2;"""
        )
        .repartition(50)
        .cache()
    )
    logger(
        logger_level_info,
        f"bucket_resolution Query execution has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on bucket_resolution: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on bucket_resolution", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.bucket_resolution")

    logger(
        logger_level_info,
        f"bucket_resolution writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table bucket_resolution : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table bucket_resolution : ", str(e)
    )

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "bucket_resolution").mode("overwrite").save()
    logger(
            logger_level_info,
            f"bucket_resolution writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table bucket_resolution : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table bucket_resolution : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)