# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_fieldactionables.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/FIELDACTIONABLES"
    desti_path = "BFIL-MART/REPORTING/FIELDACTIONABLES"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
WITH T_Veer_HHI_AA AS (
    SELECT
a.Hierarchyid,
a.Branchid,
a.BranchName,
--a.ZoneName,
a.zone as Zonename,
a.Region,
a.Area,
--a.StateName,
a.state as StateName,
a.Branch_Type,
a.District,
a.UnitName,
a.TargetID,
a.TargetDate,
a.CBStatus,
a.Clientid,
a.Clientcode,
a.Clientname,
a.UCICID,
--a.UCIC_Date,
a.SpouseName,
a.JoinDate,
a.DropoutDate,
a.DateofBirth,
a.Gender,
a.MaritalStatus,
a.Groupid,
a.Centerid,
a.Centercode,
a.CenterName,
a.CentermeetingDay,
a.Staffid,
--a.Death_Status,
--a.Death_date,
a.BankName,
a.BankBranch,
a.Bankaccountnumber,
a.IFSCCode,
a.ClientNameASPerBank,
--a.MobileNumber,
a.Aadhar as UID,
a.VOTER as VoterID,
null as PanCard,
a.CKYCID,
null as Min_Disbdate,
a.EKYC_CaptureDate,
a.HHI_date,
--a.Cifid,
a.Ckycidremarks,
--a.Acc_Status,
        CASE
            WHEN B.Deathdate IS NOT NULL THEN 'Death'
            WHEN B.NPA_date IS NOT NULL THEN '[>90]'
            WHEN B.ALL_Client_ageing IS NOT NULL THEN B.ALL_Client_ageing
            ELSE A.DormantWithLoanWithoutLoan
        END AS DormantWithLoanWithoutLoan
    FROM {mart_catalog}.{mart_schema}.clientfacts A
    JOIN {mart_catalog}.{mart_schema}.dailyloanfacts B ON A.Clientid = B.ClientId
    WHERE
        COALESCE(A.HHI_date, '1900-01-01') = '1900-01-01'
        AND B.Branch_Type = 'MFI'
        AND COALESCE(A.DropoutDate, '1900-01-01') = '1900-01-01'
),

--select * from T_Veer_HHI_AA;

T_Veer_AC_NOLdata as(
SELECT
    A.ClientId,
    DormantWithLoanWithoutLoan,
    CASE
        WHEN B.AC_NOL = 0 AND A.DormantWithLoanWithoutLoan IS NULL THEN 'NO Active Loan'
        ELSE A.DormantWithLoanWithoutLoan
    END AS DormantWithLoanWithoutLoan
FROM (
    SELECT
        A.ClientId,
        COUNT(1) AS Cnt,
        COUNT(CASE WHEN COALESCE(LoanClosedDate, '1900-01-01') = '1900-01-01' THEN ClientLoanId END) AS AC_NOL
    FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` A
    JOIN T_Veer_HHI_AA B ON A.ClientId = B.ClientID
    WHERE
        DormantWithLoanWithoutLoan IS NULL
        AND A.ProductType IS NULL
    GROUP BY A.ClientId
) B
JOIN T_Veer_HHI_AA A ON A.ClientId = B.ClientId),
--select * from T_Veer_AC_NOLdata;


 T_Veer_HHI_Pending as ( Select Clientid,Groupid,Centerid ,DormantWithLoanWithoutLoan as Status1,    
cast(null as Int)Group_NOC,cast(null as Int)Center_NOC, cast(null as Date) All_Loan_ClosedDATE,        
cast(null as Int) All_Loan_ClosedDays  ,  
Cast(2 as Int)  Priority    
from   T_Veer_HHI_AA      
where DormantWithLoanWithoutLoan='Current1'),

T_Veer_Group_AA_CNT as (
  Select Groupid,Count(Clientid)Group_NOC     
from {mart_catalog}.{mart_schema}.clientfacts
where   Branch_Type='MFI' and  COALESCE(DropoutDate,'1900-01-01')='1900-01-01'    
Group by Groupid ),


T_Veer_Center_AA_CNT as (Select Centerid,Count(Clientid)Center_NOC         
from {mart_catalog}.{mart_schema}.clientfacts    
where   Branch_Type='MFI' and  COALESCE(DropoutDate,'1900-01-01')='1900-01-01'    
Group by Centerid   ), 

update_T_Veer_HHI_Pending AS (
    SELECT a.*,
     b1.Group_NOC as New_Group_NOC,
     b2.Center_NOC as New_Center_NOC
    FROM 
        T_Veer_HHI_Pending A
    LEFT JOIN 
        T_Veer_Group_AA_CNT B1 ON A.Groupid = B1.Groupid
    LEFT JOIN 
        T_Veer_Center_AA_CNT  B2 ON A.Centerid = B2.Centerid
),

--select * from update_T_Veer_HHI_Pending;
T_Veer_week_overall_HHI as (select *,DATEDIFF(day,GETDATE(),max_ExpectedPaidUPDATE) as days_remaining      
from (select ClientId,max(ExpectedPaidUPDATE) as max_ExpectedPaidUPDATE        
from {mart_catalog}.{mart_schema}.dailyloanfacts         
where LoanClosedDate is null  and Branch_Type='MFI'   group by ClientId) as T        
where max_ExpectedPaidUPDATE >=GETDATE() and datediff(day,GETDATE(),max_ExpectedPaidUPDATE) <= 84  ),

--select days_remaining from T_Veer_week_overall_HHI,
    

--select * from T_Veer_week_overall_HHI;

update_1 as (
    select clientid,days_remaining AS All_Loan_ClosedDays
    from T_Veer_week_overall_HHI
),

update12_T_Veer_HHI_Pending AS (
    SELECT
        a.Clientid,
a.Groupid,
a.Centerid,
a.Status1,
a.Group_NOC,
a.Center_NOC,

a.New_Group_NOC,
a.New_Center_NOC,

        CASE
            WHEN B.max_ExpectedPaidUPDATE IS NOT NULL THEN B.max_ExpectedPaidUPDATE
            ELSE A.All_Loan_ClosedDATE
        END AS All_Loan_ClosedDATE,
        c.All_Loan_ClosedDays,
        CASE
            WHEN c.All_Loan_ClosedDays <= 84 AND A.new_Group_NOC >= 4 AND A.new_Center_NOC >= 8 THEN 1
            ELSE A.Priority
        END AS Priority
    FROM
        update_T_Veer_HHI_Pending A
    LEFT JOIN
        T_Veer_week_overall_HHI B ON A.ClientID = B.ClientID
    left join update_1 c on a.Clientid = c.Clientid
),

 -- select * from update12_T_Veer_HHI_Pending;
   PBI_MFI_Clients_HHIPending as(select Branch_Type, Hierarchyid, Branchid, BranchName, zone as ZoneName, Region, Area, state as StateName,       
        DISTRICT as Districtname, UnitName, A.Clientid, Clientcode, Clientname, JoinDate,       
       DropoutDate, DateofBirth, Gender, MaritalStatus, A.Groupid, A.Centerid,       
          Centercode, CenterName, CentermeetingDay, Staffid,       
       Null as UID, voter as VoterID, null as PanCard, CKYCID, HHI_date,'HHI Pending' as Status,    
    Group_NOC, Center_NOC ,All_Loan_ClosedDATE ,All_Loan_ClosedDays ,Priority             
from {mart_catalog}.{mart_schema}.clientfacts A    
JOin update12_T_Veer_HHI_Pending B on A.ClientID=B.Clientid    
where Branch_Type='MFI' and HHI_date is null and  COALESCE(DropoutDate,'1900-01-01')='1900-01-01'  ), 

--select count(*) from PBI_MFI_Clients_HHIPending where Priority in (1,2),

--select count(*) from {mart_catalog}.{mart_schema}.clientfacts where Branch_Type='MFI' and HHI_date is null and  COALESCE(DropoutDate,'1900-01-01')='1900-01-01'  and Priority = 1

--select * from PBI_MFI_Clients_HHIPending;getting null records

PBI_MFI_Clients_HHIExpiry_Next30 AS (
    SELECT a.* 
    FROM (
        SELECT 
            Branch_Type, 
            Hierarchyid, 
            Branchid, 
            BranchName,
            zone AS ZoneName, 
            Region, 
            Area, 
            state AS StateName,
            DISTRICT AS Districtname, 
            UnitName, 
            Clientid, 
            Clientcode, 
            Clientname, 
            JoinDate,
            DropoutDate, 
            DateofBirth, 
            Gender, 
            MaritalStatus, 
            Groupid, 
            Centerid,
            Centercode, 
            CenterName, 
            CentermeetingDay, 
            Staffid,
            NULL AS UID, 
            VOTER AS VoterID,
            NULL AS PanCard, 
            CKYCID, 
            HHI_date,
            DATEADD(day, 365, HHI_date) AS HHI_Expirydate,
            'HHI Expiry (Next 30 days)' AS Status
        FROM {mart_catalog}.{mart_schema}.clientfacts 
        WHERE Branch_Type = 'MFI' 
        AND COALESCE(DropoutDate, '1900-01-01') = '1900-01-01'
    ) a
    WHERE a.HHI_Expirydate BETWEEN CURRENT_DATE() AND DATEADD(day, 30, CURRENT_DATE())
),  

Client_GropLesthan4 AS (
    SELECT
        Branch_Type,
        Hierarchyid,
        Branchid,
        BranchName,
        Zone as ZoneName,
        Region,
        Area,
        state StateName,
        DISTRICT as Districtname,
        UnitName,
        Clientid,
        Clientcode,
        Clientname,
        JoinDate,
        DropoutDate,
        DateofBirth,
        Gender,
        MaritalStatus,
        a.Groupid,
        Centerid,
        Centercode,
        CenterName,
        CentermeetingDay,
        Staffid,
        Null as UID,
       VOTER as  VoterID,
       null as  PanCard,
        CKYCID,
        HHI_date,
        DATE_ADD(HHI_date, 365) AS HHI_Expirydate,
        CASE WHEN b.noofclients IS NULL THEN 'Group less than 4' ELSE NULL END AS Status,
        CASE WHEN b.noofclients IS NULL THEN 'Yes' ELSE 'No' END AS Arrear_Status
    FROM {mart_catalog}.{mart_schema}.clientfacts a
    LEFT JOIN (
        SELECT groupid, COUNT(DISTINCT clientid) AS noofclients
        FROM {mart_catalog}.{mart_schema}.clientfacts
        WHERE Branch_Type = 'MFI' AND COALESCE(DropoutDate, '1900-01-01') = '1900-01-01'
        GROUP BY groupid
        HAVING COUNT(DISTINCT clientid) < 4
    ) b ON a.Groupid = b.Groupid
    WHERE COALESCE(a.DropoutDate, '1900-01-01') = '1900-01-01'
),
PBI_MFI_Clients_GropLesthan4 as (SELECT ab.Branch_Type,
ab.Hierarchyid,
ab.Branchid,
ab.BranchName,
ab.ZoneName,
ab.Region,
ab.Area,
ab.StateName,
ab.Districtname,
ab.UnitName,
ab.Clientid,
ab.Clientcode,
ab.Clientname,
ab.JoinDate,
ab.DropoutDate,
ab.DateofBirth,
ab.Gender,
ab.MaritalStatus,
ab.Groupid,
ab.Centerid,
ab.Centercode,
ab.CenterName,
ab.CentermeetingDay,
ab.Staffid,
ab.UID,
ab.VoterID,
ab.PanCard,
ab.CKYCID,
ab.HHI_date,
ab.HHI_Expirydate,
ab.Status,
ab.Arrear_Status,
bc.CODDate,
ab.Branch_Type,
ab.StateName,
ab.Region,
ab.ZoneName,
ab.Area,
ab.BranchID,
ab.BranchName,
ab.ClientId,
ab.ClientCode,
ab.ClientName,
ab.CenterId,
ab.centername,
ab.StaffId,
ab.Groupid,
bc.TargetId,
ab.centercode,
ab.CenterMeetingDay,
bc.NoOfDaysInArrears1,
bc.POS,
--bc.NO_Of_Active_Loans,
Null as NO_Of_Active_Loans,
bc.PrINcipalINArears,
bc.INterestINArears,
bc.LastRepaymentDate,
bc.EWi,
Null as Max_DisbursementDate,
Null as Ageing,
Null as Ageing_As_Per_DPD,
bc.Remarks_writeoff,
Null as Fin_POS,
Null as CMTime,
Null as staffname,
bc.days_to_r91,
Null as Date_91_Days,
Null as IsDeath,
Null as Var_balance,
bc.Month_End_Status,
bc.Monthend_Ageing,
Null as Month_END_POS,
bc.client_Type,
Null as CenterStatus,
bc.As_on_NPA,
bc.NPA_date,
bc.ClientNPAstatus,
null as SB_AccountID,
Null as MobileNum,
Null as Mar20_NPA,
Null as Mar21_NPA,
null as Monthend_center_Status,
Null as daily_center_Status,
Null as BranchGrowthStatus,
Null as Suvidha_client,
Null as As_on_Paidstatus,
Null as PM_Paidstatus,
Null as DPDstartdate,
null as MTD_Due,
null as MTD_Coll,
null as MTD_DuevsColl,
null as PaidEWI,
null as Last_Repayment_Date,
null as As_on_CollPaid,
    CASE
        WHEN (bc.PrINcipalINArears + bc.INterestINArears) > 0 THEN 'Yes'
        ELSE 'No'
    END AS Updated_Arrear_Status
FROM Client_GropLesthan4 ab
left join {mart_catalog}.{mart_schema}.dailyloanfacts bc on ab.clientid=bc.clientid  ),



PBI_MFI_Clients_HHI_Expired as (select Branch_Type, Hierarchyid, Branchid, BranchName,Zone as ZoneName, Region, Area,state as StateName,                 
       DISTRICT as Districtname, UnitName, Clientid, Clientcode, Clientname, JoinDate,                 
       DropoutDate, DateofBirth, Gender, MaritalStatus, Groupid, Centerid,                 
          Centercode, CenterName, CentermeetingDay, Staffid,                 
                          Null as UID,VOTER as VoterID,Null as PanCard, CKYCID, HHI_date,'HHI Expired' as Status                 
from {mart_catalog}.{mart_schema}.clientfacts where Branch_Type='MFI' and datediff(day,HHI_date,getdate())>365 and  COALESCE(DropoutDate,'1900-01-01')='1900-01-01' ),   

    Client_CenterLesthan8 AS (
    SELECT
        Branch_Type,
        Hierarchyid,
        Branchid,
        BranchName,
        zone as ZoneName,
        Region,
        Area,
        state as StateName,
        DISTRICT as Districtname,
        UnitName,
        Clientid,
        Clientcode,
        Clientname,
        JoinDate,
        DropoutDate,
        DateofBirth,
        Gender,
        MaritalStatus,
        a.Groupid,
        a.Centerid,
        Centercode,
        CenterName,
        CentermeetingDay,
        Staffid,
        Null as UID,
        VOTER as VoterID,
        null as PanCard,
        CKYCID,
        HHI_date,
        DATE_ADD(HHI_date, 365) AS HHI_Expirydate,
        'Center less than 8' AS Status,
        NULL AS Arrear_Status
    FROM {mart_catalog}.{mart_schema}.clientfacts a
    JOIN (
        SELECT Centerid, COUNT(DISTINCT clientid) AS noofclients
        FROM {mart_catalog}.{mart_schema}.clientfacts
        WHERE Branch_Type = 'MFI' AND COALESCE(DropoutDate, '1900-01-01') = '1900-01-01'
        GROUP BY Centerid
        HAVING COUNT(DISTINCT clientid) < 8
    ) b ON a.Centerid = b.Centerid
    WHERE COALESCE(a.DropoutDate, '1900-01-01') = '1900-01-01'
),-- select * from {mart_catalog}.{mart_schema}.clientfacts,

Arrear_Status_Yes AS (
    SELECT
        a.*,
        'Yes' AS Arrear_Status
    FROM
        Client_CenterLesthan8 a
    JOIN
        {mart_catalog}.{mart_schema}.dailyloanfacts b ON a.clientid = b.clientid
    WHERE
        (b.PrINcipalINArears + b.INterestINArears) > 0
),
Arrear_Status_No AS (
    SELECT
        a.*,
        CASE
            WHEN a.Arrear_Status IS NULL THEN 'No'
            ELSE a.Arrear_Status
        END AS Arrear_Status
    FROM
       Client_CenterLesthan8 a
) ,     
PBI_MFI_Clients_CenterLesthan8 as(
SELECT *
FROM Arrear_Status_Yes

UNION ALL

SELECT *
FROM Arrear_Status_No),

cte_group
as (Select b.HierarchyId,c.ClientId,b.GroupId 
from {source_catalog}.{source_schema}.`pragati-groupmaster` b 
left join {source_catalog}.{source_schema}.`pragati-clientmaster` c on b.GroupId = c.groupid  and c.ETL_IS_ACTIVE = 1
and COALESCE(DropoutDate,'1900-01-01')='1900-01-01'
where b.ETL_IS_ACTIVE=1 and COALESCE(b.DissolvedDate,'1900-01-01')='1900-01-01'   ),
cte_group1
as (Select HierarchyId,GroupId,count(1) k from cte_group 
where clientid is not null  group by 
GroupId ,HierarchyId
having count(1) < 4),

cte_Centre
as (Select a.HierarchyId,c.ClientId,a.CenterId from {source_catalog}.{source_schema}.`pragati-centermaster` a 
left join {source_catalog}.{source_schema}.`pragati-groupmaster` b on a.CenterId = b.CenterId and b.ETL_IS_ACTIVE = 1
left join {source_catalog}.{source_schema}.`pragati-clientmaster` c on b.GroupId = c.groupid  and c.ETL_IS_ACTIVE = 1
and COALESCE(DropoutDate,'1900-01-01')='1900-01-01'
where a.ETL_IS_ACTIVE=1 and COALESCE(a.DissolvedDate,'1900-01-01')='1900-01-01'   ),
cte_Centre1
as (Select HierarchyId,CenterId,Count(1) k from cte_Centre 
where clientid is not null  group by 
CenterId ,HierarchyId
having count(1) < 8),


initial_FieldActionables AS (
    -- Target Flows
    SELECT Hierarchyid, Targetid, '00000000000000' AS Clientid, '' AS Groupid, '' AS Centerid, 'Target Flow' AS Category, 'TD Assessment is Pending' AS ActionName, 'BCM' AS ActionOwner
    FROM {mart_catalog}.{mart_schema}.targetfacts
    WHERE TargetCurrentStatus = 'CB Success'
    
    UNION ALL
    
    SELECT Hierarchyid, Targetid, '' as Clientid, '' AS Groupid, '' AS Centerid, 'Target Flow' AS Category, 'Partial TD' AS ActionName, 'SM' AS ActionOwner
    FROM {mart_catalog}.{mart_schema}.targetfacts
    WHERE TargetCurrentStatus = 'Partial TD'
    
    UNION ALL
    
    SELECT Hierarchyid, Targetid, '' as Clientid, '' AS Groupid, '' AS Centerid, 'Target Flow' AS Category, 'Auth Done, GRT Not Done' AS ActionName, 'BM' AS ActionOwner
    FROM {mart_catalog}.{mart_schema}.targetfacts
    WHERE TargetCurrentStatus IN ('Authorization Done_Manual','Authorization Done_Auto')
    
    UNION ALL
    
    SELECT Hierarchyid, Targetid, '' as Clientid, '' AS Groupid, '' AS Centerid, 'Target Flow' AS Category, 'GRT Done - Client Not Joined' AS ActionName, 'SM' AS ActionOwner
    FROM {mart_catalog}.{mart_schema}.targetfacts
    WHERE TargetCurrentStatus = 'GRT Done - Client Not Joined'
    
    UNION ALL
    
    SELECT Hierarchyid, Targetid, '' as Clientid, '' AS Groupid, '' AS Centerid, 'Target Flow' AS Category, 'Auth Done, Housing Survey Pending' AS ActionName, 'SM' AS ActionOwner
    FROM {mart_catalog}.{mart_schema}.targetfacts
    WHERE TargetCurrentStatus = 'Auth Done, Housing Survey Pending'
    
    -- Proposal Flows
    UNION ALL
    
    SELECT Hierarchyid, '' AS Targetid, Clientid, '' AS Groupid, '' AS Centerid, 'Proposal Flow' AS Category, 'Proposal Assessment Pending' AS ActionName, 'BCM' AS ActionOwner
    FROM {mart_catalog}.{mart_schema}.proposal_facts
    WHERE PaymentStatus = 'BCM Pending'
    
    UNION ALL
    
    SELECT Hierarchyid, '' AS Targetid, Clientid, '' AS Groupid, '' AS Centerid, 'House Hold Income' AS Category, 'HHI Pending P1' AS ActionName, 'SM' AS ActionOwner
    FROM PBI_MFI_Clients_HHIPending
    WHERE Priority = 1
    
    UNION ALL
    
    SELECT Hierarchyid, '' AS Targetid, Clientid, '' AS Groupid, '' AS Centerid, 'House Hold Income' AS Category, 'HHI Pending P2' AS ActionName, 'SM' AS ActionOwner
    FROM PBI_MFI_Clients_HHIPending
    WHERE Priority = 2
    
    UNION ALL
    
    SELECT Hierarchyid, '' AS Targetid, Clientid, '' AS Groupid, '' AS Centerid, 'House Hold Income' AS Category, 'HHI Expiry (Next 30 days)' AS ActionName, 'SM' AS ActionOwner
    FROM PBI_MFI_Clients_HHIExpiry_Next30
    
    UNION ALL
    
    SELECT Hierarchyid, '' AS Targetid, Clientid, '' AS Groupid, '' AS Centerid, 'House Hold Income' AS Category, 'HHI Expired' AS ActionName, 'SM' AS ActionOwner
    FROM PBI_MFI_Clients_HHI_Expired
    
    UNION ALL
    
    -- SELECT DISTINCT Hierarchyid, '' AS Targetid, '' AS Clientid, Groupid, '' AS Centerid, 'Group Center Size' AS Category, 'Group Size < 4' AS ActionName, 'SM' AS ActionOwner
    -- FROM PBI_MFI_Clients_GropLesthan4
    
    -- UNION ALL
    
    -- SELECT DISTINCT Hierarchyid, '' AS Targetid, '' AS Clientid, '' AS Groupid, Centerid, 'Group Center Size' AS Category, 'Center Size < 8' AS ActionName, 'SM' AS ActionOwner
    -- FROM PBI_MFI_Clients_CenterLesthan8

    SELECT DISTINCT Hierarchyid, '' AS Targetid, '' AS Clientid, Groupid, '' AS Centerid, 'Group Center Size' AS Category, 'Group Size < 4' AS ActionName, 'SM' AS ActionOwner
    FROM cte_group1
    
    UNION ALL
    
    SELECT DISTINCT Hierarchyid, '' AS Targetid, '' AS Clientid, '' AS Groupid, Centerid, 'Group Center Size' AS Category, 'Center Size < 8' AS ActionName, 'SM' AS ActionOwner
    FROM cte_Centre1


--     UNION
--   SELECT Hierarchyid ,'' ,Clientid ,'' Groupid ,'' Centerid ,'Sahayata Loan Voter ID Not Available' Category ,'Sahayata Loan Voter ID Not Available' ActionName ,'SM' ActionOwner
--   FROM [dcprrpt01\sql2019].Prayas.dbo.ECLGS_NPAMark_VoterID_NA
    
),
--SELECT * FROM FieldActionables;
FieldActionables AS (
    SELECT
        current_date() AS ReportDate,
        *
    FROM initial_FieldActionables
),

FieldActionables_select AS (

SELECT
    ReportDate,
    hierarchyid,
    Category,
    ActionName,
    ActionOwner
FROM FieldActionables
)

select * from FieldActionables_select;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"fieldactionables Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on fieldactionables: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on fieldactionables : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.fieldactionables")

    logger(
            logger_level_info,
            f"fieldactionables writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table fieldactionables : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table fieldactionables : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "fieldactionables").mode("overwrite").save()
    logger(
            logger_level_info,
            f"fieldactionables writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table fieldactionables : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table fieldactionables : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)