# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Summary/MFI/nb_first_loan_disbursement"

# COMMAND ----------

filename = "nb_target_facts_daily.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        "Required notebook imports have been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/TARGET_FACTS_DAILY"
    desti_path = "BFIL-MART/REPORTING/TARGET_FACTS_DAILY"

    logger(
        logger_level_info,
        "Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """with final_cte as (
SELECT
    current_timestamp() reportGenDate,
    a.hierarchyid,
    TargetCurrentStatus,
    TargetDate,
    a.JoinDate,
    last_day(to_date(TargetDate,'dd-MMM-yyyy')) AS TargetMonth,
    CASE
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'),current_date() - 1) < 1 THEN '01. 00-00 Days' 
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'),current_date() - 1) <= 7 THEN '02. 01-07 Days'
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'),current_date() - 1) <= 14 THEN '03. 08-14 Days'
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'),current_date() - 1) <= 21 THEN '04. 15-21 Days'
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'),current_date() - 1) > 21 THEN '05. GT 21 Days'
        ELSE 'Error'
    END AS Ageing,
    CASE
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'), c.First_DisbursementDate) < 1 THEN '01. 00-00 Days'
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'), c.First_DisbursementDate) <= 7 THEN '02. 01-07 Days'
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'), c.First_DisbursementDate) <= 14 THEN '03. 08-14 Days'
        WHEN date_diff(DAY,to_date(a.TargetDate,'dd-MMM-yyyy'), c.First_DisbursementDate) > 21 THEN '05. GT 21 Days'
        ELSE 'Error'
    END AS Ageing_TD_LoandisbDate,
    CASE
        WHEN date_diff(DAY,cast(a.Joindate as date), c.First_DisbursementDate) < 1 THEN '01. 00-00 Days'
        WHEN date_diff(DAY,cast(a.Joindate as date), c.First_DisbursementDate) <= 7 THEN '02. 01-07 Days'
        WHEN date_diff(DAY,cast(a.Joindate as date), c.First_DisbursementDate) <= 14 THEN '03. 08-14 Days'
        WHEN date_diff(DAY,cast(a.Joindate as date), c.First_DisbursementDate) > 21 THEN '05. GT 21 Days'
        ELSE 'Error'
    END AS Ageing_MA_LoandisbDate,
    dayofweek(to_date(TargetDate,'dd-MMM-yyyy')) AS Weekday,
    COUNT(1) AS `NOT`
FROM {mart_catalog}.{mart_schema}.targetfacts a
left join {mart_catalog}.{mart_schema}.first_loan_disbursement c on a.TargetID = c.TargetID
WHERE to_date(TargetDate,'dd-MMM-yyyy') > current_date() - 45   
GROUP BY
    
    a.hierarchyid,
    TargetCurrentStatus,
    TargetDate,
    a.JoinDate,
    Weekday,
    TargetMonth,
    Ageing,
     Ageing_MA_LoandisbDate,
     Ageing_TD_LoandisbDate
)
    select * from final_cte""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"Error while initializing the parameters and query: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("Error while initializing the parameters and query: ", str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"target_facts_daily Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on target_facts_daily: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on target_facts_daily : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.target_facts_daily")

    logger(
            logger_level_info,
            f"target_facts_daily writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table target_facts_daily : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table target_facts_daily : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "target_facts_daily").mode("overwrite").save()
    logger(
            logger_level_info,
            f"target_facts_daily writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table target_facts_daily : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table target_facts_daily : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)