# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_unnatimfidata_f.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/UNNATIMFIDATA_F"
    desti_path = "BFIL-MART/REPORTING/UNNATIMFIDATA_F"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """with CTE_ClientID_CenterStatus
as (Select a.ClientID,b.CenterID,A.GroupId,A.HierarchyID,A.TargetID,A.JoinDate, CM.CenterMeetingDay, CAST(NULL as FLOAT) as amount,
Max( case when  Cl.ETL_IS_ACTIVE=1   and ProductType is null   then cl.DisbursementDate end )Max_Disb,    
Count(case when POS>0 and Branch_Type in('SMPT','HIL') then 1 end)NOL,          
coalesce(Max(NoOfDaysInArrears1),0)Max_DPD          
from {source_catalog}.{source_schema}.`pragati-clientmaster` a
left JOin  {source_catalog}.{source_schema}.`pragati-groupmaster`  b on a.GroupId=b.GroupID
left JOin  {source_catalog}.{source_schema}.`pragati-Centermaster`  Cm on b.CenterID=Cm.CenterID
left JOin  {source_catalog}.{source_schema}.`pragati-clientloansubscription`  Cl on a.ClientID=Cl.ClientID
left JOin  {mart_catalog}.{mart_schema}.dailyloanfacts  C on a.ClientId =C.ClientId
where cast(a.DropOutDate as date) is null AND a.ETL_IS_ACTIVE=1  
and Cm.ETL_IS_ACTIVE=1  
Group by a.ClientID,b.CenterID,A.GroupId,A.HierarchyID,A.TargetID,A.JoinDate, CM.CenterMeetingDay) ,

CTE_Client_CenterStatus_C AS
(Select A.*,
case when coalesce(B.NOC_NonArrear,0)>=0 and coalesce(B.NOC_Arrear,0)=0 then 'Good Center'          
when coalesce(B.NOC_Arrear,0) between 1 and 3  then    'Bad Center A'          
when coalesce(B.NOC_Arrear,0)>3 then    'Bad Center B' end  Center_Status ,
(case when B.NOC_Arrear>1 then 'Yes' else 'No' end) Center_Arrear,
(case when C.NOC_Arrear>1 then 'Yes' else 'No' end) Group_Arrear,''Center_Eligible_Status
from   CTE_ClientID_CenterStatus as A
left Join ( Select CenterID,
Sum(NOL)NOL,
Count(Distinct ClientID)NOC,          
Count(case when Max_DPD=0 then   1 end)NOC_NonArrear,          
Count(case when Max_DPD>0 then   1 end)NOC_Arrear from  CTE_ClientID_CenterStatus  Group by CenterID  ) B  on A.CenterID=B.CenterID
left Join ( Select GroupId,
Sum(NOL)NOL,
Count(Distinct ClientID)NOC,          
Count(case when Max_DPD=0 then   1 end)NOC_NonArrear,          
Count(case when Max_DPD>0 then   1 end)NOC_Arrear from  CTE_ClientID_CenterStatus  
Group by GroupId  ) C  on A.GroupId=C.GroupId)

 Select   * from CTE_Client_CenterStatus_C;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"unnatimfidata_f Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on unnatimfidata_f: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on unnatimfidata_f : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.unnatimfidata_f")


    logger(
            logger_level_info,
            f"unnatimfidata_f writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table unnatimfidata_f : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table unnatimfidata_f : ", str(e))


# COMMAND ----------

# %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
# try :
#     # Write DataFrame to Snowflake table
#     df.write.format("snowflake").options(**options).option("dbtable", "unnatimfidata_f").mode("overwrite").save()
#     logger(
#             logger_level_info,
#             f"unnatimfidata_f writing to snowflake table has been successfully completed.",
#             execution_log_list,
#             filename,
#     )
# except Exception as e:
#     logger(
#         logger_level_error,
#         f"error occured while writing data into snowflake table unnatimfidata_f : {str(e)}",
#         execution_log_list,
#         filename,
#     )
#     print(*execution_log_list, sep="\n")
#     # Handle the exception or display the error message as needed
#     raise Exception("error occured while writing data into snowflake table unnatimfidata_f : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)