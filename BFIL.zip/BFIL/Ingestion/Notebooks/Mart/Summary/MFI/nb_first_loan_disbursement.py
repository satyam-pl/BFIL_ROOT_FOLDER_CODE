# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_first_loan_disbursement.dbc"

# COMMAND ----------

spark.conf.set('spark.sql.session.timeZone', 'Asia/Kolkata')

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/FIRST_LOAN_DISBURSEMENT"
    desti_path = "BFIL-MART/REPORTING/FIRST_LOAN_DISBURSEMENT"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
SELECT B.TargetId, B.clientid ,A.First_DisbursementDate FROM
(
SELECT ClientID,Min(DisbursementDate)First_DisbursementDate FROM
(Select ClientId,DisbursementDate,ClientLoanId
from  {source_catalog}.{source_schema}.`pragati-clientloansubscription`
where  ProductType is null AND ETL_IS_ACTIVE = '1'
union
Select ClientId,DisbursementDate,ClientLoanId
from  {source_catalog}.{source_schema}.`pragati-clientloansubscription` --Top 100000
where  ProductType is null 
union
Select CustomerId as ClientId,DisbursementDate, CustomerLoanID
from   {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement`
where ProductType is null )  Group by ClientID) A
JOIN {source_catalog}.{source_schema}.`pragati-clientmaster` B
ON A.ClientID = B.ClientId where b.ETL_IS_ACTIVE=1 """.format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"first_loan_disbursement Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on first_loan_disbursement: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on first_loan_disbursement : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{mart_catalog}.{mart_schema}.first_loan_disbursement")

    logger(
            logger_level_info,
            f"first_loan_disbursement writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table first_loan_disbursement : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table first_loan_disbursement : ", str(e))
