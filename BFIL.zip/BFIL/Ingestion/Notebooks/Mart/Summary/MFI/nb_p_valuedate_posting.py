# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_valuedate_posting.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_VALUEDATE_POSTING"
    desti_path = "BFIL-MART/REPORTING/P_VALUEDATE_POSTING"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
with process_log as
(
select vogpDatetime,VOGPProcessDateTime,hierarchyid,transactiondate from {source_catalog}.{source_schema}.`pragati-processlog`  where etl_is_active = 1
),
at_loan_trans as (
select CreatedBy,UpdatedBy,transactiontype,createddatetime,amount,CollectionMode, hierarchyid,datepart('hour',createddatetime) as  Hour,valuedate,actualvaluedate,case when valuedate <> actualvaluedate then "NotEqual" else "Equal" end as  VDAD , to_date(ActualValueDate),tabrowguid  from {source_catalog}.{source_schema}.`pragati-at_loantransactions` where 
DebitOrCredit='C' and TransactionType='C' and etl_is_active = 1 and ActualValueDate >= date_sub(current_date(), 90)),

process as (
select process_log.vogpDatetime as VOGP_St,process_log.VOGPProcessDateTime as VOGP_ET,at_loan_trans.* ,
case
when substring(cast(createddatetime as string), 12, 5) <=  substring(cast(VOGP_St as string), 12, 5) then 'Before'
when substring(cast(createddatetime as string), 12, 5) Between  substring(cast(VOGP_St as string), 12, 5) and substring(cast(VOGP_Et as string), 12, 5) then 'During'
when substring(cast(createddatetime as string), 12, 5) >= substring(cast(VOGP_Et as string), 12, 5) then 'After'
when  valuedate > actualvaluedate  then 'After' else '' end as VOGP_Status  from process_log inner join at_loan_trans  on process_log.hierarchyid=at_loan_trans.hierarchyid and at_loan_trans.ActualValueDate=process_log.transactiondate    ),

P_Valuedate_Posting as (
Select HierarchyId, ifnull(CreatedBy,UpdatedBy) as StaffID,transactiontype, 
to_date(CreatedDateTime)CD,Valuedate,ActualValueDate,Hour,VDAD,VOGP_Status,
sum(Amount) amount,case when tabrowguid is null then 'Web' else 'tab' end as Mode from process group by HierarchyId,StaffID ,VDAD,Hour,Valuedate,ActualValueDate,
VOGP_Status,CD,transactiontype,Mode having amount <> 0 and transactiontype = 'C' ),

final_cte as (
select HierarchyId,ActualValueDate,
case when CD<=ActualValueDate and vogp_status = 'Before' and Hour between 1 and 7 then '1 - 06-08 AM'                
when CD<=ActualValueDate and vogp_status = 'Before' and Hour between 8 and 9 then '2 - 08-10 AM'                
when CD<=ActualValueDate and vogp_status = 'Before' and Hour between 10 and 14 then '3 - 10-02 PM'                
when CD<=ActualValueDate and vogp_status = 'Before' and Hour between 15 and 18 then '4 - 02-06 PM'                
when CD<=ActualValueDate and vogp_status = 'Before' and Hour between 19 and 20 then '5 - 06-08 PM'                
when CD<=ActualValueDate and vogp_status = 'Before' and Hour >20 then '6 - After 08 PM'                
when CD<=ActualValueDate and vogp_status = 'During' then '7 - During VOGP'                
when CD<=ActualValueDate and vogp_status = 'After' then '8 - After VOGP Same Day'                
when CD>ActualValueDate and vogp_status = 'After' then '9 - After VOGP Next Day'                
Else 'error' end as Final_Status,count(1)Tran_Count,sum(Amount)Amount from P_Valuedate_Posting group by HierarchyId,ActualValueDate,Final_Status)

select * from final_cte""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_valuedate_posting Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_valuedate_posting: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_valuedate_posting : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_valuedate_posting")
    
    logger(
            logger_level_info,
            f"p_valuedate_posting writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_valuedate_posting : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table p_valuedate_posting : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "p_valuedate_posting").mode("overwrite").save()
    logger(
            logger_level_info,
            f"p_valuedate_posting writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_valuedate_posting : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_valuedate_posting : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)