# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "p_dailyloanfacts_client_pd_ct_summary.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )    
    
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT_SUMMARY"
    desti_path = "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT_SUMMARY"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )
    query = """WITH month_end_status
AS
(
SELECT 
 monthlf.Ageing_client_CM as Ageing_client_PM
,monthlf.client_Ason_status as Month_end_status
,monthlf.HierarchyId as HierarchyId
,monthlf.Clientid as Clientid
,monthlf.Ageing as Monthend_Ageing
,monthlf.Client_DPD as Client_DPD_PM
,monthlf.NPA_date as NPA_date
,sum(monthlf.POS) as Month_END_POS
,monthlf.client_Type as client_Type
,monthlf.client_Ason_status as clientNPAstatus_PM
from  {source_catalog}.{source_schema}.`azuresource-p_loanfacts_client` monthlf 
group by hierarchyId,Ageing_client_CM,Ageing,
Clientid,Client_DPD,NPA_date ,client_Ason_status,client_Type
)  
--select * from month_end_status
,
D2K_NPA_C as (

  ---customerid, NPA_Date,AssetClassName these 3 columns are sufficeint customerid, NPA_Date,AssetClassName
select sum(PrincipleOutstanding) as PrincipleOutstanding, sum(IntOverdue) as IntOverdue, sum(TotalProvision) as TotalProvision,
customerid CLIENTID, NPA_Date,AssetClassName,'yes' As_on_NPA
from (
select distinct  max(CreatedDateTime) as CreatedDateTime,
NCIF_Id,customerid, AssetClassName, NCIF_NPA_Date as NPA_Date,
cast( PrincipleOutstanding as  decimal (18,2) ) as PrincipleOutstanding,cast( IntOverdue  as decimal(18,2))as IntOverdue, cast(TotalProvision as decimal(18,2)) as TotalProvision
from {source_catalog}.{source_schema}.`ptsmartnpa-d2k_npadetailsfrommanagedfiles`
where lower(sourcename)='pt smart' and  NCIF_NPA_Date is not null
and AssetClassName is not  Null
group by NCIF_Id,customerid, AssetClassName, NCIF_NPA_Date ,PrincipleOutstanding,IntOverdue,TotalProvision
)
group by customerid,AssetClassName,NPA_Date
),

 
 ClientNPAstatus_PM as 
 (
select  distinct clientid,	Monthend_Status ClientNPAstatus
from     {source_catalog}.{source_schema}.`azuresource-p_loanfacts`
  where freezed='y' and lower(assetcl_br) in('db1','db2','db3','los','sub')  and upper(branch_type)<>'HIL'
),

client_summary_sub as (
select  D.CODDATE,D.Branch_Type,D.State,D.Region,D.Zone,D.Area,D.BranchID,D.BranchName,D.HierarchyId,
D.ClientId,D.ClientCode, D.ClientName,D.Spousename,
D.CenterId,D.centername,D.CenterStaffID as StaffId,Groupid,TargetId,
D.centercode,D.CenterMeetingDay,
max(D.JoinDate)as JoinDate,
Max(case when loancloseddate is null then D.NoOfDaysInArrears1 end )as NoOfDaysInArrears ,
Sum(coalesce(D.POS,0)) as POS ,
Count(*) as NO_Of_Active_Loans,
Sum(coalesce(PrINcipalINArears,0)) as PrINcipalINArears,
Sum(coalesce(INterestINArears,0)) as INterestINArears  ,
max(LastRepaymentDate)as LastRepaymentDate,
SUM( case when loancloseddate is null then D.EWI end ) as EWi,
max(case when  loancloseddate is null then DisbursementDate end )as Max_DisbursementDate  ,
D.ALL_Client_ageing as  Ageing_As_Per_DPD,
Sum(case when Freezed1 = 'Y' then POS end ) as Fin_POS ,
CAST(CenterMeetingTime as Date)  AS CMTime
from  {mart_catalog}.{mart_schema}.dailyloanfacts D
where (  (Freezed_OP ='Y') or (loancloseddate is not null )   )
group by D.CODDATE,D.Branch_Type,D.State,D.Region,D.Zone,D.Area,D.BranchID,D.BranchName,D.HierarchyId,
D.ClientId,D.ClientCode, D.ClientName,D.CenterId,D.centername,D.CenterStaffID ,Groupid,TargetId,D.Spousename,
D.centercode,D.CenterMeetingDay,D.ALL_Client_ageing,CAST(CenterMeetingTime as Date)
),

-- select * from client_summary_sub;

closed_clients as (
SELECT   CLIENTID, 'Closed' as status ,
Count(case when LoanClosedDate is not null then ClientLOanID end) closed_Cnt,
Count(ClientLOanID) total_Cnt
FROM {mart_catalog}.{mart_schema}.dailyloanfacts Group by CLIENTID
)
,

Death_clients as (
SELECT  distinct  CLIENTID,'yes' Isdeath
 FROM {mart_catalog}.{mart_schema}.dailyloanfacts where deathdate is not null
)

,
------  client_summary_sub2
client_summary_sub2 as (
select Sub.CODDATE,Sub.Branch_Type,Sub.State,Sub.Region,Sub.Zone,Sub.Area,Sub.BranchID,Sub.BranchName,Sub.HierarchyId,Sub.ClientId,Sub.ClientCode, 
Sub.ClientName,Sub.Spousename,Sub.CenterId,Sub.centername,Sub.StaffId,Sub.Groupid,Sub.TargetId,Sub.centercode,Sub.CenterMeetingDay,Sub.JoinDate,
Sub.NoOfDaysInArrears,Sub.POS,Sub.NO_Of_Active_Loans,Sub.PrINcipalINArears,Sub.INterestINArears,Sub.LastRepaymentDate,Sub.EWi,Sub.Max_DisbursementDate,
Sub.Fin_POS,Sub.CMTime,
um.username as staffname,cstatus.status as CenterStatus,
      (case when DT.clientid is not null then Dt.Isdeath else null  end) as IsDeath,
      (case when clst.clientid is not null
       and lower(clst.remarks) in('writeoff_mar22','writeoff_jun22','writeoff_sep22','writeoff_dec22','writeoff_mar23','writeoff_jun23','writeoff_sep23','closed deals mar22') then 'Y' else Null end) as Remarks_writeoff,

	  (case when cc.CLIENTID is not null   and Pos=0 then 'ClosedClients' else  Sub.Ageing_As_Per_DPD  end) as Ageing_As_Per_DPD,
	  	   
	  (case when D.CLIENTID IS NOT NULL Then D.NPA_date else Null end)NPA_date,
	  (case when D.CLIENTID IS NOT NULL Then D.As_on_NPA else 'no' end)As_on_NPA,

      (case when As_on_NPA='no' and sub.NoOfDaysInArrears BETWEEN 1 AND 91 then (91-sub.NoOfDaysInArrears) end) as days_to_r91,

      (case when As_on_NPA='no' and sub.NoOfDaysInArrears BETWEEN 1 AND 91 then DATEADD(DAY,(91-sub.NoOfDaysInArrears),sub.CODDATE)
			when As_on_NPA='no' and Ageing_As_Per_DPD='[>90]' then null       end) as Expected_NPA_date,
	  (CASE WHEN CNS.CLIENTID IS NOT NULL and  As_on_NPA='yes' THEN CNS.ClientNPAstatus 
			WHEN    As_on_NPA='yes' THEN 'NPA IN CurrentMonth'
			WHEN    As_on_NPA='no' and Expected_NPA_date is not null and NoOfDaysInArrears between 1 and 90 THEN concat('Expected NPA in ' , date_format(cast(Expected_NPA_date as date), 'MMM'))
			WHEN L.CLIENTID IS NOT NULL and L.client_type like '%arc%' THEN L.client_type
			WHEN L.CLIENTID IS NOT NULL and As_on_NPA ='no' and L.ClientNPAstatus_PM like '%writeoff%' THEN L.ClientNPAstatus_PM
			WHEN L.CLIENTID IS NOT NULL and As_on_NPA ='no' and L.ClientNPAstatus_PM like '%Closeddeals%' THEN L.ClientNPAstatus_PM
	 			 else Ageing_As_Per_DPD  END ) ClientNPAstatus,
      (case when L.CLIENTID is not null then L.Month_End_Status  
			when Joindate >=   cast(date_format(now(),'yyyy-MM-01') as date) then   'New Client'   end) as Month_End_Status,

      (case when L.CLIENTID is not null then L.Month_END_POS else 0 end) as Month_END_POS,

      (case when L.client_Type is not null then L.client_Type else 'Regular' end) as client_Type,
      (case when L.CLIENTID is not null and L.Monthend_Ageing<>'ClosedClient'  then L.Monthend_Ageing
			when Joindate >=   cast(date_format(now(),'yyyy-MM-01') as date ) then   'New Client'   end) as Monthend_Ageing,

      (case when Ageing_As_Per_DPD <>'[>90]' and ClientNPAstatus like '%arc%' then '[>90]'
		    when Ageing_As_Per_DPD <>'[>90]' and ClientNPAstatus like '%Writeoff%' then '[>90]'
	        when Ageing_As_Per_DPD <>'[>90]' and ClientNPAstatus like '%Closeddeals%' then '[>90]'
			when Ageing_As_Per_DPD <>'[>90]' and  As_on_NPA='yes' then '[>90]' else Ageing_As_Per_DPD end) as Ageing
from client_summary_sub sub
left join (select * from {source_catalog}.{source_schema}.`pragatimain-usermaster` where etl_is_active = '1') um on um.UserId =sub.StaffId
left join {source_catalog}.{source_schema}.`azuresource-p_clstagging` clst on clst.ClientId = sub.clientid
left join closed_clients cc on cc.ClientId=sub.CLIENTID
left join D2K_NPA_C D on D.CLIENTID=sub.CLIENTID
left join ClientNPAstatus_PM CNS on CNS.CLIENTID=sub.CLIENTID
left join month_end_status L ON sub.CLIENTID=L.CLIENTID
--left join {source_catalog}.{source_schema}.`azuresource-p_loanfacts` monthlf on monthlf.CLIENTID=sub.CLIENTID
left join  {source_catalog}.{source_schema}.`azuresource-statuscurrentcenters` cstatus ON sub.CenterId = cstatus.CenterSmartID
left join Death_clients DT ON sub.CLIENTID=DT.CLIENTID

),
-- select * from client_summary

CTE_PM_requiredColumns
as (
select Clientid,
Arrear_4EWI_CM PM_Paidstatus ,
As_on_CollPaid PM_CollPaid,
Arrear Arrear_PM,
client_Ason_status ClientNPAstatus_PM ,
EWI EWI_PM  ,Expected_NPAdate Expected_NPAdate_PM ,
isdeath,
Ageing,
(case when As_on_NPA ='Yes' then 1
   when As_on_NPA ='NO' and client_Ason_status like '%writeoff%'  then 1
   when As_on_NPA ='NO' and client_Ason_status like '%ARC%'  then 1  else 0 end ) NPA_PM_Tag
from  {source_catalog}.{source_schema}.`azuresource-p_loanfacts_client`
),



CTE_RequiredColumn as
(
select clientid,
Min(DPDStartDate)DPDStartDate,
max(LastRepaymentDate)as LastRepaymentDate     ,
sum(EWI)EWI,
sum(M_PriColl +M_IntColl) As_on_M_coll,
sum(M_PriDue + M_IntDue)MTD_Due,
sum(M_PriColl + M_IntColl)MTD_Coll,
sum(PrincipalInArears  + InterestInArears)Arrear,
SUM(case
when     (M_PriDue +M_IntDue) >0.00
and  (   (M_PriColl +M_IntColl)   >=  (M_PriDue +M_IntDue) )    then (M_PriDue +M_IntDue)  else(M_PriColl +M_IntColl) end)  MTD_Due_Coll
from {mart_catalog}.{mart_schema}.dailyloanfacts
where
upper(freezed_op) = 'Y'
or (loancloseddate is not null)
group by clientid
),

CTE_Ason_collPaid as
(
select distinct clientid,
(
case
   when ( MTD_Coll >1 or  MTD_Due >1 )      and  MTD_Coll >= MTD_Due  then  'Fullypayment'
   when (MTD_Coll >=1   and MTD_Due >0   )  and  MTD_Coll >= EWI      then  'PartialPayment'
   when (MTD_Coll >=1   and MTD_Due >0   )  and  MTD_Coll <  EWI      then  'NotPaid'
   when (coalesce(MTD_Due,0) = 0  and coalesce(MTD_Coll,0) = 0)       then  'NoDueNoCollection'
   when (coalesce(MTD_Due,0)) = 0  and MTD_Coll >=1                   then  'NoDueButPaid'
   when MTD_Due > 0  and MTD_Coll <1                                  then  'NotPaid'
	END) Ason_collPaid
from CTE_RequiredColumn
),

CTE_PaidEWI as
(
select distinct clientid, Arrear, (coalesce(As_on_M_coll,0)/coalesce(EWI,0)) PaidEWI
from CTE_RequiredColumn
),

CTE_CMPaid_status as
(
select distinct clientid, PaidEWI,Arrear, (
case when  PaidEWI=0                and Arrear>=1   then '[0 EWI]'
   when PaidEWI >0 and PaidEWI<1   and Arrear>=1   then '[<1 EWI]'
   when PaidEWI>=1 and PaidEWI<2   and Arrear>=1   then '[1 EWI]'
   when PaidEWI>=2 and PaidEWI<3   and Arrear>=1   then '[2 EWI]'
   when PaidEWI>=3 and PaidEWI<4   and Arrear>=1   then '[3 EWI]'
   when PaidEWI>=4 and PaidEWI<5   and Arrear>=1   then '[4 EWI]'
   when PaidEWI>=5 and PaidEWI<6   and Arrear>=1   then '[5 EWI]'
   when PaidEWI>=6 and PaidEWI<7   and Arrear>=1   then '[6 EWI]'
   when PaidEWI>=7 and PaidEWI<8   and Arrear>=1   then '[7 EWI]'
   when PaidEWI>=8 and PaidEWI<9   and Arrear>=1   then '[8 EWI]'
   when PaidEWI>=9 and PaidEWI<10  and Arrear>=1   then '[9 EWI]'
   when PaidEWI>=10 and PaidEWI<11 and Arrear>=1   then '[10 EWI]'
   when PaidEWI>=11                and Arrear>=1   then '[11 EWI]'
END)   CMPaid_status
 from CTE_PaidEWI
),

 CTE_Ason_Paidstatus as
(
select distinct clientid,
coalesce((case when  CMPaid_status >=  '[4 EWIs]' then 1 else 0 end ),0)  As_on_Paidstatus
 from CTE_CMPaid_status
),

 CTE_centerArrear_CM as
(
select a.Centerid,(case when NoOfDaysInArrears >0 then 'Arrearcenter' else 'NonArrearcenter' end ) Ason_Center_Status
from
(select distinct Centerid,Max(NoOfDaysInArrears1) NoOfDaysInArrears
  from {mart_catalog}.{mart_schema}.dailyloanfacts group by Centerid ) A group by A.Centerid,(case when NoOfDaysInArrears >0 then 'Arrearcenter' else 'NonArrearcenter' end )
),

CTE_centerArrear_PM as
(
select a.Centerid,(case when NoOfDaysInArrears >0 then 'Arrearcenter' else 'NonArrearcenter' end ) PM_Center_Status
from
(select distinct Centerid,Max(NoOfDaysInArrears) NoOfDaysInArrears
  from {source_catalog}.{source_schema}.`azuresource-p_loanfacts` group by Centerid ) A group by A.Centerid,(case when NoOfDaysInArrears >0 then 'Arrearcenter' else 'NonArrearcenter' end )
),

CTE_Suv_client as
(
select distinct clientid, 'yes'     suv_client
 from {mart_catalog}.{mart_schema}.dailyloanfacts where  loancloseddate is  null and  productcode='854'
) 
,
 CTE_BRanch_details as
(
select distinct Branchid,   UMBaseLocationBranchName UnitName,SBHState SBH
 from {mart_catalog}.{mart_schema}.p_hierarchy_sop
),
-- select * from client_summary_sub2

client_summary as
(
select
 sub2.CODDate
,sub2.Branch_Type
,sub2.State as StateName
,sub2.Region
,sub2.Zone as ZoneName
,sub2.Area
,UnitName
,SBH
,sub2.BranchID
,sub2.BranchName
,sub2.HierarchyId
,sub2.ClientId
,sub2.ClientCode
,sub2.ClientName
,sub2.CenterId
,sub2.centername
,sub2.StaffId
,sub2.Groupid
,sub2.TargetId
,sub2.centercode
,sub2.CenterMeetingDay
,sub2.NoOfDaysInArrears
,sub2.POS
,sub2.NO_Of_Active_Loans
,sub2.PrINcipalINArears
,sub2.INterestINArears
,sub2.EWi
,sub2.Max_DisbursementDate
,sub2.Ageing_As_Per_DPD
,( case when    sub2.Ageing =  '[>90]'  and 
sub2.monthend_ageing  in ('Current1','New Client') and (sub2.PrINcipalINArears + sub2.INterestINArears)=0
     then  'Current1'     else sub2.Ageing  end ) as Ageing
,sub2.Remarks_writeoff
,sub2.Fin_POS
,sub2.CMTime
,sub2.staffname
,sub2.days_to_r91
,sub2.Expected_npa_date
,M.IsDeath
-- ,sub2.Var_balance  --script pending for this column
,sub2.Month_End_Status
,sub2.Monthend_Ageing
,sub2.Month_END_POS
,sub2.client_Type
,sub2.CenterStatus
,sub2.As_on_NPA --column mapping pending
,sub2.NPA_date --column mapping pending
,sub2.ClientNPAstatus  --column mapping pending
-- , ( case when  CAST( npa_date as DATE   ) < '2020-09-01' then 'yes' else 'No' end )  Mar20_NPA
-- , ( case when  CAST( npa_date as Date ) between '2020-09-01' and  '2021-03-31'  then 'yes' else 'No' END  )  Mar21_NPA
--, Null RegularizationDate
, PM_Center_Status
,Ason_Center_Status
--,'' BranchGrowthStatus
,(case when S.clientid is not null then s.suv_client else 'No' end) as suv_client
,ASP.As_on_Paidstatus
,M.PM_Paidstatus
, c.MTD_Due
, c.MTD_Coll
, c.MTD_Due_Coll
,e.PaidEWI
,ASCl.Ason_collPaid
,m.PM_CollPaid
,c.DPDstartdate
,sub2.LastRepaymentDate
,ClientNPAstatus_PM
, M.Arrear_PM
, NPA_PM_Tag
from client_summary_sub2  sub2
Left Join CTE_requiredColumn    C   on sub2.clientid=  C.clientid
Left Join CTE_PM_requiredColumns M    on sub2.clientid=  M.clientid
Left Join CTE_Suv_client     S    on sub2.clientid=  S.clientid
Left Join CTE_PaidEWI        E    on sub2.clientid=  E.clientid
Left Join CTE_CMPaid_status    CMP  on sub2.clientid=  CMP.clientid
Left Join CTE_Ason_Paidstatus  ASP  on sub2.clientid=  ASP.clientid
Left Join CTE_Ason_collPaid    ASCL on sub2.clientid=  ASCL.clientid
Left Join CTE_centerArrear_CM    CRCM on sub2.centerid=  CRCM.centerid
Left Join CTE_centerArrear_PM    CRPM on sub2.centerid=  CRPM.centerid
Left Join CTE_BRanch_details    BR  on sub2.Branchid=  BR.Branchid
),
-- select * from client_summary

Ageingflow as
( select Clientid ,
  (case
when lower(Monthend_ageing)  in ('new client','current1') and lower(Ageing)  <> 'current1'  and (PrINcipalINArears +INterestINArears)>0   then 'NewArrearAdded'
when Monthend_ageing  is null and Ageing  <> 'current1'  and (PrINcipalINArears +INterestINArears)>0   then 'NewArrearAdded'
when
       (case
       when Ageing = 'Current1' then 1
       when Ageing = '[1 To 30]' then 2
       when Ageing = '[31 To 60]' then 3
       when Ageing = '[61 To 90]' then 4
       when Ageing = '[>90]' then 5  else 100 end) >
       (case
       when Monthend_Ageing in ('Current1','New Client') then 1
       when Monthend_Ageing = '[1 To 30]' then 2
       when Monthend_Ageing = '[31 To 60]' then 3
       when Monthend_Ageing = '[61 To 90]' then 4
     when Monthend_Ageing = '[>90]' then 5  else 100 end) then 'Forward Flow'
when (case
       when Ageing = 'Current1' then 1
       when Ageing = '[1 To 30]' then 2
       when Ageing = '[31 To 60]' then 3
       when Ageing = '[61 To 90]' then 4
       when Ageing = '[>90]' then 5  else 100 end) =
       (case
       when Monthend_Ageing in ('Current1','New Client') then 1
       when Monthend_Ageing = '[1 To 30]' then 2
       when Monthend_Ageing = '[31 To 60]' then 3
       when Monthend_Ageing = '[61 To 90]' then 4
       when Monthend_Ageing = '[>90]' then 5  else 100 end) then 'No Change'
when   (case
       when Ageing = 'Current1' then 1
       when Ageing = '[1 To 30]' then 2
       when Ageing = '[31 To 60]' then 3
       when Ageing = '[61 To 90]' then 4
       when Ageing = '[>90]' then 5  else 100 end) <
       (case when Monthend_Ageing in ('Current1','New Client') then 1
       when Monthend_Ageing = '[1 To 30]' then 2
       when Monthend_Ageing = '[31 To 60]' then 3
       when Monthend_Ageing = '[61 To 90]' then 4
       when Monthend_Ageing = '[>90]' then 5  else 100 end) then 'Backward Flow'
when   lower(Monthend_Ageing) not in ('current1','new client') and   lower(Ageing) = 'current1'    then 'ArrearClear'
when  Monthend_Ageing  is null         and lower(Ageing) = 'current1'    then 'ArrearClear'
when  lower(Ageing_As_Per_DPD) = 'closedclients'         and Ageing='Current1'    then 'ArrearClear'
else 'Error' end) Ageing_Flow,
(case when coalesce(MTD_Coll,0)>=(coalesce(Arrear_PM,0)+coalesce(MTD_Due,0))
then   (coalesce(Arrear_PM,0)+coalesce(MTD_Due,0)) else  coalesce(MTD_Coll,0) end) Grosscoll
from   client_summary
),

CTE_dailyloanfacts_client_summary AS
(select distinct C.*,
A.Ageing_Flow,
A.Grosscoll
from client_summary c
left join Ageingflow A on c.clientid=a.clientid),

T_bal_Clients_var AS (
select Hierarchyid,clientid
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1')
WHERE ETL_IS_ACTIVE = '1'),

T_bal_Clients_var1 AS (
select a.clientid,a.hierarchyid,sum(b.amount) as var_amount
from  T_bal_Clients_var a
 join (SELECT amount,clientid,hierarchyid,debitorcredit,transactiontype
 FROM {source_catalog}.{source_schema}.`pragati-at_loantransactions` WHERE ETL_IS_ACTIVE = '1') b
 on a.clientid=b.clientid and a.hierarchyid=b.hierarchyid
 where lower(b.transactiontype)='a' and lower(b.debitorcredit)='c'
 group by a.clientid,a.hierarchyid),

T_bal_Clients_var2 AS (
select a.clientid,a.hierarchyid,sum(b.amount) as var_withdraw
 from T_bal_Clients_var1 a
 join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-at_loantransactions` WHERE ETL_IS_ACTIVE = '1') b
 on a.clientid=b.clientid and a.hierarchyid=b.hierarchyid
 where lower(b.transactiontype)='a' and lower(b.debitorcredit)='d'
 group by a.clientid,a.hierarchyid),

T_bal_var_amount3_1 AS (
 select a.ClientId ,a.HierarchyId,
coalesce(a.var_amount,0) as Var_deposit,coalesce(b.var_withdraw,0) as Var_withdrawal,(coalesce(Var_deposit,0)-coalesce(Var_withdrawal,0)) Var_balance
from T_bal_Clients_var1 a
left join T_bal_Clients_var2 b on a.ClientId =b.ClientId),

T_bal_var_amount3 AS (
select * from T_bal_var_amount3_1 where Var_balance != 0.00),

T_bal_var_amount4 AS (
select s.Branchid, s.branchname,s.ZONE ZONENAME, s.state STATENAME, s.region, s.Area, s.UMBaseLocationBranchName unitName,
            a.clientid, b.clientcode, b.clientname, d.centermeetingday, u.userid as staffid, u.username as staffname,
            d.centercode, d.centername, a.Var_deposit, a.Var_withdrawal, a.Var_balance, B.TARGETID
      from T_bal_var_amount3 a
            left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') b on a.clientid=b.clientid
            left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1') c on c.groupid=b.groupid
            left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1') d on d.centerid=c.centerid
            left join (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-usermaster` WHERE ETL_IS_ACTIVE = '1') u on u.userid=d.staffid
            left join {mart_catalog}.{mart_schema}.p_hierarchy_sop s on s.Hierarchyid=u.hierarchyid),

T_bal_var_amount5 AS (
select c.*, d.Ewi
      from T_bal_var_amount4 c
            left join
            (select a.clientid, sum(b.Ewi) Ewi
            from T_bal_var_amount4 a
                  join CTE_dailyloanfacts_client_summary b on a.clientid=b.clientid
            group by a.clientid)d on c.clientid=d.clientid),

T_bal_var_amount6 AS (
select A.CLIENTID, A.Var_balance, a.targetid
      from T_bal_var_amount5 a
            left join CTE_dailyloanfacts_client_summary b on a.clientid=b.clientid),

T_bal_var_amount7 AS (
SELECT A.*
FROM T_bal_var_amount6 A
LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-kycdetails` WHERE ETL_IS_ACTIVE = '1') B ON A.TARGETID=B.TARGETID
      WHERE B.LOANPROPOSALID IS NULL),

final_cte(
SELECT A.*,B.Var_balance FROM 
CTE_dailyloanfacts_client_summary A
LEFT JOIN T_bal_var_amount7 B ON B.CLIENTID =  A.ClientId)

select * from final_cte;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query.{str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query.", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct_summary Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_dailyloanfacts_client_pd_ct_summary: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_dailyloanfacts_client_pd_ct_summary", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option(
        "mergeSchema", "true"
    ).option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct_summary")

    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct_summary writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_dailyloanfacts_client_pd_ct_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table p_dailyloanfacts_client_pd_ct_summary : ", str(e)
    )

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "p_dailyloanfacts_client_pd_ct_summary").mode("overwrite").save()
    
    logger(
            logger_level_info,
            f"p_dailyloanfacts_client_pd_ct_summary writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct_summary : ", str(e))

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)