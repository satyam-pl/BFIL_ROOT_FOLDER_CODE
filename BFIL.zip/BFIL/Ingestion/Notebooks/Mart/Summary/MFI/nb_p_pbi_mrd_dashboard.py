# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_pbi_mrd_dashboard.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )    
    
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_PBI_MRD_DASHBOARD"
    desti_path = "BFIL-MART/REPORTING/P_PBI_MRD_DASHBOARD"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH T_bal_Prime_final_pbfi AS (
    SELECT 
        ZoneName,
        StateName,
        SBH_State,
        Region,
        Area,
        Unit,
        BranchID,
        BranchName,
        centercode,
        centername,
        CM_day,
        StaffId,
        staffname,
        ClientId,
        ClientCode,
        ClientName,
        Pos_Apr30th,
        Arrear_Amount_Apr30th,
        Ewi_Dec31st,
        MTDDue,
        TotalCollection,
        POS,
        Arears,
        NoOfDaysInArrears,
        clientNPAstatus,
        NPA_date,
        Expected_Npadate,
        ExpNpa_Cmdate,
        Last_Repayment_Date,
        Regularizationdate,
        IsDeath,
        CODDate,
        Paid_Status,
        Paid_Ewi,
        Client_Status,
        ExpNpa_date_Mb,
        Productname,
        Maxdisbursementdate,
        Risk_category,
        Visitdate,
        Vistit_Empid,
        Vistit_Empname,
        Visit_Emp_Designation,
        Hierarchyid,
        Month_END_POS,
        Monthend_Ageing,
        Month_End_Status,
        EWi,
        Ageing_As_Per_DPD,
        Ageing,
        Productcode,
        LastMTD_Due,
        LastMTD_Coll,
        LastMTD_Duecoll,
        DueVsColl,
        NULL AS Exp_Npa,
        NULL AS Pbi_Status,
        NULL AS Mtd_Exp_Tipover,
        NULL AS PaidEwis,
        Spousename,
        Activeloans
    FROM {source_catalog}.{source_schema}.`azuresource-t_bal_prime_final`
),

UpdatedData AS (
    SELECT
        a.*,
        --a.Expected_NPAdate AS NewExp_Npa,
        CASE
            WHEN clientNPAstatus = 'NPA In Jan' AND Arears <> 0 THEN 'Mtd Tipped over'
            WHEN clientNPAstatus = 'Expected NPA in Feb' AND Exp_Npa BETWEEN '2025-01-01' AND '2025-01-31' THEN 'MTNM'
            WHEN clientNPAstatus = 'Expected NPA in Mar' AND Exp_Npa BETWEEN '2025-01-01' AND '2025-01-31' THEN 'MTNM'
            WHEN a.Expected_Npadate >= '2025-02-01' THEN 'Saved'
            WHEN a.IsDeath = 'Yes' AND a.Expected_Npadate IS NULL THEN 'Saved'
            WHEN a.IsDeath IS NULL AND Arears = 0 THEN 'Saved'
            WHEN clientNPAstatus = 'Expected NPA in Jan' THEN 'Risk in Jan'
            WHEN clientNPAstatus = 'NPA In Jan'
                AND Exp_Npa BETWEEN CURRENT_DATE() AND LAST_DAY(CURRENT_DATE())
            THEN 'Risk in Jan'
            ELSE a.Pbi_Status
        END AS NewPbi_Status,
        CASE
            WHEN Exp_Npa BETWEEN '2025-01-01' AND DATE_ADD(CURRENT_DATE(), -1) THEN 'Mtd Exp Tip over'
            WHEN a.Pbi_Status = 'Mtd Tipped over' THEN 'Mtd Tipped over'
            ELSE a.Mtd_Exp_Tipover
        END AS New_Mtd_Exp_Tipover,
        CASE
            WHEN FLOOR(COALESCE(TotalCollection, 0) / IFNULL(Ewi_Dec31st, 1)) >= 5 THEN '5Ewi'
            WHEN FLOOR(COALESCE(TotalCollection, 0) / IFNULL(Ewi_Dec31st, 1)) >= 4 AND a.PaidEwis IS NULL THEN '4Ewi'
            WHEN FLOOR(COALESCE(TotalCollection, 0) / IFNULL(Ewi_Dec31st, 1)) >= 3 AND a.PaidEwis IS NULL THEN '3Ewi'
            WHEN FLOOR(COALESCE(TotalCollection, 0) / IFNULL(Ewi_Dec31st, 1)) >= 2 AND a.PaidEwis IS NULL THEN '2Ewi'
            WHEN FLOOR(COALESCE(TotalCollection, 0) / IFNULL(Ewi_Dec31st, 1)) >= 1 AND a.PaidEwis IS NULL THEN '1Ewi'
            WHEN a.PaidEwis IS NULL THEN 'Not Paid'
            ELSE a.PaidEwis
        END AS New_PaidEwis
    FROM T_bal_Prime_final_pbfi a
    LEFT JOIN {source_catalog}.{source_schema}.`azuresource-t_din_branchwise_pos_oct` b ON a.clientid = b.clientid
),


P_Pbi_Mrd_Dashboard as(
select Hierarchyid,COUNT(1) Noc,SUM(pos) Pos,NewPbi_Status as Pbi_Status,New_PaidEwis as PaidEwis,New_Mtd_Exp_Tipover as Mtd_Exp_Tipover,Risk_category
 from UpdatedData 
group by  Hierarchyid,NewPbi_Status,New_PaidEwis,New_Mtd_Exp_Tipover,Risk_category)

select * from P_Pbi_Mrd_Dashboard;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query.{str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query.", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_pbi_mrd_dashboard Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_pbi_mrd_dashboard: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_pbi_mrd_dashboard", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option(
        "mergeSchema", "true"
    ).saveAsTable(f"{mart_catalog}.{mart_schema}.p_pbi_mrd_dashboard")

    logger(
        logger_level_info,
        f"p_pbi_mrd_dashboard writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_pbi_mrd_dashboard : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table p_pbi_mrd_dashboard : ", str(e)
    )

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "p_pbi_mrd_dashboard").mode("overwrite").save()
    logger(
            logger_level_info,
            f"p_pbi_mrd_dashboard writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_pbi_mrd_dashboard : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_pbi_mrd_dashboard : ", str(e))

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)