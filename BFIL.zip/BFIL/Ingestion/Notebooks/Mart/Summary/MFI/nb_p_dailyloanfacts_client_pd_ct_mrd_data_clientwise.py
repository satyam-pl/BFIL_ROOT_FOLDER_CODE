# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_dailyloanfacts_client_pd_ct_mrd_data_clientwise.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )    
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT_MRD_DATA_CLIENTWISE"
    desti_path = "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT_MRD_DATA_CLIENTWISE"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )
    
    query = """WITH T_bal_Prime_final_pbfi AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        ClientId,
        ClientCode,
        ClientName,
        CenterId,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DUE_COLL as MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        ason_collpaid as As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        NULL AS is_regularised,
        NULL AS MTNM,
        NULL AS PartialPaid,
        NULL AS MTDExpTipOver,
        NULL AS MTDTipOver,
        NULL AS MRD_Status,
        NULL AS baseCount,
        NULL AS Maxdisbursementdate,
        NULL AS Productcode,
        NULL AS MRD_Target,
        NULL AS unit,
        NULL AS Mrd_target_pos
    FROM
        {mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct
    WHERE
        Branch_Type = 'SMPT'
    ),
    InitialData AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        ClientId,
        ClientCode,
        ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        NULL AS is_regularised,
        NULL AS MTNM,
        NULL AS PartialPaid,
        NULL AS MTDExpTipOver,
        NULL AS MTDTipOver,
        NULL AS MRD_Status,
        NULL AS Maxdisbursementdate,
        NULL AS Productcode,
        NULL AS MRD_Target,
        NULL AS unit,
        NULL AS Mrd_target_pos,
        1 AS baseCount
    FROM
        T_bal_Prime_final_pbfi
    ),
    UpdateStep1 AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        ClientId,
        ClientCode,
        ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        NULL AS PartialPaid,
        NULL AS MRD_Status,
        NULL AS Maxdisbursementdate,
        NULL AS Productcode,
        NULL AS MRD_Target,
        NULL AS unit,
        NULL AS Mrd_target_pos,
        1 AS baseCount,
        CASE
        WHEN RegularizationDate IS NOT NULL THEN 1
        ELSE 0
        END AS is_regularised,
        CASE
        WHEN last_day(Date_91_Days) > last_day(Coddate) THEN 1
        ELSE 0
        END AS MTNM,
        CASE
        WHEN last_day(Date_91_Days) > last_day(Coddate) THEN 1
        ELSE 0
        END AS MTDExpTipOver,
        CASE
        WHEN As_on_NPA = 'Yes'
        AND ExpectedNPAdate_PM < CURRENT_DATE - 1 THEN 1
        ELSE 0
        END AS MTDTipOver
    FROM
        InitialData
    ),
    UpdateStep2 AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        ClientId,
        ClientCode,
        ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        MTNM,
        NULL AS PartialPaid,
        NULL AS MRD_Status,
        NULL AS Maxdisbursementdate,
        NULL AS Productcode,
        NULL AS MRD_Target,
        NULL AS unit,
        NULL AS Mrd_target_pos,
        1 AS baseCount,
        CASE
        WHEN RegularizationDate IS NOT NULL
        AND ISdeath = 'Yes'
        AND POS > 0 THEN 0
        ELSE is_regularised
        END AS is_regularised,
        CASE
        WHEN RegularizationDate IS NOT NULL
        AND ISdeath = 'Yes'
        AND POS > 0 THEN 1
        WHEN As_on_NPA = 'Yes'
        AND ExpectedNPAdate_PM > CURRENT_DATE - 1 THEN 1
        ELSE MTDExpTipOver
        END AS MTDExpTipOver,
        CASE
        WHEN As_on_NPA = 'Yes'
        AND RegularizationDate IS NOT NULL THEN 0
        ELSE MTDTipOver
        END AS MTDTipOver
    FROM
        UpdateStep1
    ),
    UpdateStep3 AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        ClientId,
        ClientCode,
        ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        is_regularised,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        baseCount,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        NULL AS PartialPaid,
        NULL AS MRD_Status,
        NULL AS Maxdisbursementdate,
        NULL AS Productcode,
        NULL AS MRD_Target,
        NULL AS unit,
        NULL AS Mrd_target_pos,
        MTDExpTipOver,
        MTDTipOver,
        MTNM,
        CASE
        WHEN is_regularised = 1 THEN '1. Regularised'
        WHEN MTNM = 1 THEN '2. MTNM'
        WHEN MTDExpTipOver = 1 THEN '3. MTDExpTipOver'
        WHEN MTDTipOver = 1 THEN '4. MTDTipOver'
        ELSE 'Error'
        END AS MRD_Status
    FROM
        UpdateStep2
    ),
    JoinStep AS (
    SELECT
        a.ZoneName,
        a.StateName,
        SBH,
        a.Region,
        a.Area,
        a.BranchID,
        a.BranchName,
        a.Hierarchyid,
        a.ClientId,
        a.ClientCode,
        a.ClientName,
        centerid,
        a.centername,
        a.StaffId,
        a.staffname,
        a.centercode,
        CenterMeetingDay,
        a.Month_End_Status,
        a.Monthend_Ageing,
        a.Month_END_POS,
        a.POS,
        a.CODdate,
        PrINcipalINArears,
        INterestINArears,
        is_regularised,
        a.Ageing,
        baseCount,
        a.Ageing_As_Per_DPD,
        a.NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        a.ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        MTNM,
        MTDTipOver,
        MTDExpTipOver,
        a.NPA_Date,
        a.clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        a.Last_repayment_date,
        a.IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        NULL AS PartialPaid,
        NULL AS MRD_Status,
        NULL AS MRD_Target,
        NULL AS unit,
        NULL AS Mrd_target_pos,
        b.Maxdisbursementdate,
        b.productcode
    FROM
        UpdateStep3 a
        LEFT JOIN {mart_catalog}.{mart_schema}.`bfil-datamart-t_bal_prime_final` b ON a.clientid = b.clientid
    ),
    UpdateStep4 AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        ClientId,
        ClientCode,
        baseCount,
        ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        is_regularised,
        MTNM,
        NULL AS PartialPaid,
        MTDExpTipOver,
        MTDTipOver,
        Null as MRD_Status,
        Maxdisbursementdate,
        Productcode,
        NULL AS unit,
        NULL AS Mrd_target_pos,
        CASE
        WHEN ZoneName IN ('Central Zone 1', 'Central Zone 2') THEN 0.35
        ELSE 0.30
        END AS MRD_Target
    FROM
        JoinStep
    ),
    UpdateStep5 AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        ClientId,
        ClientCode,
        ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        baseCount,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        is_regularised,
        MTNM,
        MTDExpTipOver,
        MTDTipOver,
        NULL AS PartialPaid,
        MTDExpTipOver,
        MTDTipOver,
        NULL AS MRD_Status,
        Maxdisbursementdate,
        Productcode,
        MRD_Target,
        NULL AS unit,
        Month_END_POS * MRD_Target AS Mrd_target_pos
    FROM
        UpdateStep4
    ),
    FinalUpdate AS (
    SELECT
        ZoneName,
        StateName,
        SBH,
        a.Region,
        a.Area,
        a.BranchID,
        baseCount,
        a.BranchName,
        a.Hierarchyid,
        ClientId,
        ClientCode,
        ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        Ageing_Flow,
        Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        MTNM,
        MTDExpTipOver,
        MTDTipOver,
        1 AS IsFocus,
        Null as BucketMovement_Date,
        Null as Regularizationdate,
        Null as ExpectedNPAdate_PM,
        Null as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        Null as newmrd_tag,
        is_regularised,
        NULL AS MRD_Status,
        Maxdisbursementdate,
        Productcode,
        MRD_Target,
        Mrd_target_pos,
        b.UMBaseLocationBranchName AS unit
    FROM
        UpdateStep5 a
        LEFT JOIN {mart_catalog}.{mart_schema}.p_hierarchy_sop b ON a.Hierarchyid = b.Hierarchyid
    ),
    CTE_PM_requiredColumns as (
    select
        Clientid,
        Arrear_4EWI_CM PM_Paidstatus,
        As_on_CollPaid PM_CollPaid,
        Arrear Arrear_PM,
        client_Ason_status ClientNPAstatus_PM,
        EWI EWI_PM,
        Expected_NPAdate Expected_NPAdate_PM,
        isdeath isdeath_PM,
        Ageing Ageing_PM,
        (
        case
            when As_on_NPA = 'Yes' then 1
            when As_on_NPA = 'NO'
            and client_Ason_status like '%writeoff%' then 1
            when As_on_NPA = 'NO'
            and client_Ason_status like '%ARC%' then 1
            else 0
        end
        ) NPA_PM_Tag
    from
        {source_catalog}.{source_schema}.`azuresource-p_loanfacts_client`
    ),
    P_Dailyloanfacts_client_PD_CT_MRD_Data_Clientwise as (
    SELECT
        ZoneName,
        StateName,
        SBH,
        Region,
        Area,
        BranchID,
        BranchName,
        Hierarchyid,
        a.ClientId,
        a.ClientCode,
        a.ClientName,
        centerid,
        centername,
        StaffId,
        staffname,
        centercode,
        CenterMeetingDay,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        POS,
        CODdate,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        NoOfDaysInArrears AS Noofdaysinarrears,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_DuevsColl,
        ewi,
        baseCount,
        Ageing_Flow,
        a.Arrear_PM,
        As_on_CollPaid,
        As_on_NPA,
        Date_91_Days,
        NPA_Date,
        clientNPAstatus AS ClientnPAstatus,
        a.ClientNPAstatus_PM,
        Last_repayment_date,
        IsDeath AS ISdeath,
        PaidEWI,
        MTNM,
        MTDExpTipOver,
        MTDTipOver,
        1 AS IsFocus,
        0 as BucketMovement_Date,
        0 as Regularizationdate,
        b.Expected_NPAdate_PM,
        0 as Risk_Category,
        CAST(0 AS FLOAT) AS FTD_Coll,
        0 as newmrd_tag,
        is_regularised,
        0 AS PartialPaid,
        0 AS MRD_Status,
        Maxdisbursementdate,
        Productcode,
        MRD_Target,
        Mrd_target_pos,
        unit
    FROM
        FinalUpdate a
        left join CTE_PM_requiredColumns b on a.Clientid = b.Clientid
    )
    select * from P_Dailyloanfacts_client_PD_CT_MRD_Data_Clientwise;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct_mrd_data_clientwise Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_dailyloanfacts_client_pd_ct_mrd_data_clientwise: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_dailyloanfacts_client_pd_ct_mrd_data_clientwise", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option(
        "mergeSchema", "true"
    ).option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct_mrd_data_clientwise")

    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct_mrd_data_clientwise writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_dailyloanfacts_client_pd_ct_mrd_data_clientwise : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table p_dailyloanfacts_client_pd_ct_mrd_data_clientwise : ", str(e)
    )

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("delta").mode("overwrite").option(
    "mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct_mrd_data_clientwise")
    
    logger(
            logger_level_info,
            f"p_dailyloanfacts_client_pd_ct_mrd_data_clientwise writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct_mrd_data_clientwise : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct_mrd_data_clientwise : ", str(e))

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)