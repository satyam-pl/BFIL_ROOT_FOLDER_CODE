# Databricks notebook source
# MAGIC %sql
# MAGIC  SET mart_catalog = '${dbutils.widgets.get("mart_catalog")}';
# MAGIC  SET mart_schema = '${dbutils.widgets.get("mart_schema")}';
# MAGIC  SET source_catalog = '${dbutils.widgets.get("source_catalog")}';
# MAGIC  SET source_schema = '${dbutils.widgets.get("source_schema")}';
# MAGIC CREATE OR REPLACE TABLE ${mart_catalog}.${mart_schema}.Target_Facts_MoM
# MAGIC SELECT
# MAGIC   HierarchyID
# MAGIC     , TargetCurrentStatus
# MAGIC     , last_day(to_date(TargetDate, 'dd-MMM-yyyy')) TargetMonth
# MAGIC     /* DATEPART(weekday ,TargetDate)Weekday ,*/, count(1) `NOT`
# MAGIC FROM
# MAGIC   ${mart_catalog}.${mart_schema}.targetfacts
# MAGIC GROUP BY HierarchyID,TargetCurrentStatus,TargetMonth;