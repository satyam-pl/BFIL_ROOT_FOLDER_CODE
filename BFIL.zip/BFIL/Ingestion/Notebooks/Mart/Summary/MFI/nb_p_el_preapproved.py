# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_el_preapproved.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_EL_PREAPPROVED"
    desti_path = "BFIL-MART/REPORTING/P_EL_PREAPPROVED"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """With T_Veer_EL_Base_1 AS(
Select A.HierarchyId,A.ClientId,A.CBAmountEL as CBAmount,A.CBExpiryDate,A.TempProposalId, CancelDate,Remarks as CancelRemarks,0 PA
from {source_catalog}.{source_schema}.`pragati-preapprovedproposalho` a
Left JOin {source_catalog}.{source_schema}.`pragati-preapprovedproposal` B on a.ClientId=B.ClientId and A.TempProposalId=B.TempProposalId
where A.CBAmountEL>0 and (a.etl_is_active = 1 )),  

T_Veer_EL_Base_1_updated AS (
    SELECT 
        a.*,
        CASE 
            WHEN b.ClientId IS NOT NULL THEN 1
            ELSE a.PA
        END AS PA13
    FROM 
        T_Veer_EL_Base_1 a
    LEFT JOIN {mart_catalog}.{mart_schema}.preapproved_data
         b 
    ON 
        a.ClientID = b.ClientId  
) ,

 active_P AS (
    SELECT
        ClientId,
        LoanAmountRequested,
        LoanAmountApproved,
        ProposalDate,
        BCMLoanCancelledDate,
        CancelDate,
        CancelRemarks
    FROM {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` clp
    JOIN {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` D ON Clp.ProductId = D.DerivedProductId
    JOIN {source_catalog}.{source_schema}.`pragati-productmaster` P ON D.ProductId = P.ProductId
    WHERE (clp.ETL_IS_ACTIVE = 1  )  
      and   ProductCode='1100' and (COALESCE(LoanDisbursementDate, '1900-01-01') = '1900-01-01')
),

DIS AS(
Select    ClientID,DisbursementDate,LoanAmountDisbursed,LOANCANCELLEDDATE,DeviationCancelledDate
FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` clp  
Join {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` D on Clp.ProductId=D.DerivedProductId
Join {source_catalog}.{source_schema}.`pragati-productmaster` P on D.ProductId=P.ProductId
where (clp.ETL_IS_ACTIVE = 1 or clp.ETL_IS_ACTIVE is Null)  and 
(d.ETL_IS_ACTIVE = 1 or d.ETL_IS_ACTIVE is Null) and
(p.etl_is_active = 1 or  p.ETL_IS_ACTIVE is Null)
      AND Clp.ProductType IS NULL 
      AND ProductCode = '1100'),

T_Veer_EL_Base_1_f AS(
Select a.*,B.ProposalDate,LoanAmountRequested,LoanAmountApproved,BCMLoanCancelledDate,B.CancelDate as P_CancelDate,
B.CancelRemarks as P_CancelRemarks,DisbursementDate,LoanAmountDisbursed,LOANCANCELLEDDATE,DeviationCancelledDate,
cast(Null as varchar(200) )Final_Status, Cast(Null as varchar(50))Ageig 
from  T_Veer_EL_Base_1 a    
left JOin active_P B on A.ClientID=B.ClientID
left JOin Dis C on A.ClientID=C.ClientID),

Final_Status AS (
    SELECT 
        a.*,
        CASE 
            WHEN a.DisbursementDate IS NOT NULL
                AND (a.LOANCANCELLEDDATE IS NULL 
                AND a.DeviationCancelledDate IS NULL) 
                THEN '05. Disbursed'
            ELSE
                CASE 
                    WHEN a.Final_Status IS NULL 
                        AND a.DisbursementDate IS NOT NULL
                        AND (a.LOANCANCELLEDDATE IS NOT NULL 
                        OR a.DeviationCancelledDate IS NOT NULL) 
                        THEN '06. Disbursed Cancel'
                    ELSE
                        CASE 
                            WHEN a.Final_Status IS NULL 
                                AND a.ProposalDate IS NOT NULL 
                                THEN '03. Pending Disbursement'
                            ELSE
                                CASE 
                                    WHEN a.Final_Status = 'Proposal Pick' 
                                        AND a.ProposalDate IS NOT NULL 
                                        AND (a.BCMLoanCancelledDate IS NOT NULL 
                                        OR a.P_CancelDate IS NOT NULL) 
                                        THEN '04. Proposal Cancel'
                                    ELSE
                                        CASE 
                                            WHEN a.Final_Status IS NULL 
                                                AND a.CancelDate IS NOT NULL 
                                                THEN '02. Preapproved Cancel'
                                            ELSE
                                                CASE 
                                                    WHEN a.Final_Status IS NULL 
                                                        THEN '01. Preapproved available'
                                                    ELSE a.Final_Status
                                                END
                                        END
                                END
                        END
                END
        END AS Final_Status1,
        CASE 
            WHEN a.Final_Status <> '01. Preapproved available'
                THEN 0
            ELSE a.PA
        END AS PA12
    FROM 
        T_Veer_EL_Base_1_f a
),

T_Veer_EL_Base_Ageig AS (
    SELECT 
        DISTINCT a.*, 
        b.ALL_Client_ageing AS Ageig2
    FROM 
        Final_Status a
    LEFT JOIN 
       {mart_catalog}.{mart_schema}.dailyloanfacts b
    ON 
        a.ClientId = b.ClientId
        
),
T_Veer_EL_Base_Ageig_range AS (
    SELECT 
       DISTINCT a.*,
        CASE 
            WHEN a.Ageig2 = 'Current1' THEN '01. Current1'
            WHEN a.Ageig2 = '[1 To 30]' THEN '02. [1 To 30]'
            WHEN a.Ageig2 = '[31 To 60]' THEN '03. [31 To 60]'
            WHEN a.Ageig2 = '[61 To 90]' THEN '04. [61 To 90]'
            WHEN a.Ageig2 = '[>90]' THEN '05. [>90]'
            WHEN a.Ageig2 IS NULL THEN '06. No Active Loans'
            ELSE a.Ageig2
        END AS Ageig3
    FROM 
        T_Veer_EL_Base_Ageig a
),

p_el_preapproved AS(
Select DISTINCT HierarchyId,
ClientId,
CBAmount,
CBExpiryDate,
TempProposalId,
CancelDate,
CancelRemarks,
ProposalDate,
Ageig3 as Ageig,
pa12 as pa,  
Final_Status1 as Final_Status,
LoanAmountRequested,
LoanAmountApproved,
BCMLoanCancelledDate,
P_CancelDate,
P_CancelRemarks,
DisbursementDate,
LoanAmountDisbursed,
LOANCANCELLEDDATE,
DeviationCancelledDate
,Getdate() as ReportDate 
from T_Veer_EL_Base_Ageig_range)

SELECT * FROM p_el_preapproved  ;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_el_preapproved Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_el_preapproved: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_el_preapproved : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_el_preapproved")

    logger(
            logger_level_info,
            f"p_el_preapproved writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_el_preapproved : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table p_el_preapproved : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "p_el_preapproved").mode("overwrite").save()
    logger(
            logger_level_info,
            f"p_el_preapproved writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_el_preapproved : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_el_preapproved : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)