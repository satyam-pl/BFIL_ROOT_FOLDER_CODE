# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_mfi_daily_dropoutclients_summary.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/MFI_DAILY_DROPOUTCLIENTS_SUMMARY"
    desti_path = "BFIL-MART/REPORTING/MFI_DAILY_DROPOUTCLIENTS_SUMMARY"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH final_cte AS (
  SELECT
    hierarchyid,
    LAST_DAY(dropoutdate) AS DropOutMonth,
    Dategap_Cat,
    COUNT(clientid) AS count,
     Datediff(Day, Joindate, dropoutdate) AS Dategap
  FROM (
    SELECT
      hierarchyid,
      clientid,
      joindate,
      dropoutdate,
      CASE
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 0 AND 30 THEN  '01. [0 M]' 
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 31 AND 60 THEN '02. [1 M]'
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 61 AND 90 THEN '03. [2 M]' 
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 91 AND 120 THEN '04. [3 M]'
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 121 AND 150 THEN '05. [4 M]'
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 151 AND 180 THEN '06. [5 M]'
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 181 AND 210 THEN '07. [6 M]'
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 211 AND 240 THEN '08. [07-12 Month]' 
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 241 AND 1205 THEN '09. [13-24 Month]' 
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) BETWEEN 1206 AND 6030 THEN '10. [25 Months & Above]'
        WHEN DATEDIFF(Day, JoinDate, DropOutDate) >= 6031 THEN '25 Months & Above'
      END AS Dategap_Cat
    FROM {source_catalog}.{source_schema}.`pragati-clientmaster`
    WHERE DropOutDate >= '2023-04-01' AND (ETL_IS_ACTIVE = 1)
    and DropOutDate is not null
    and DropOutDate>=JoinDate
  ) AS subquery
  GROUP BY hierarchyid, LAST_DAY(dropoutdate), Dategap_Cat,Datediff(Day, Joindate, dropoutdate)
)

SELECT * FROM final_cte;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"mfi_daily_dropoutclients_summary Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on mfi_daily_dropoutclients_summary: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on mfi_daily_dropoutclients_summary : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.mfi_daily_dropoutclients_summary")

    logger(
            logger_level_info,
            f"mfi_daily_dropoutclients_summary writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table mfi_daily_dropoutclients_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table mfi_daily_dropoutclients_summary : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "mfi_daily_dropoutclients_summary").mode("overwrite").save()
    logger(
            logger_level_info,
            f"mfi_daily_dropoutclients_summary writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table mfi_daily_dropoutclients_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table mfi_daily_dropoutclients_summary : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)