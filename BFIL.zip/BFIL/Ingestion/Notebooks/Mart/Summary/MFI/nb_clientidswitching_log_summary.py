# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_clientidswitching_log_summary.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/CLIENTIDSWITCHING_LOG_SUMMARY"
    desti_path = "BFIL-MART/REPORTING/CLIENTIDSWITCHING_LOG_SUMMARY"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
        WITH ClientidSwitching_log AS
    (SELECT
            a.HierarchyID,
            a.CreatedDateTime AS ClientSwitched_Date,
            a.CreatedBy AS CreatedBy,
            u.UserName AS ClientSwitched_StaffName,
            a.ClientID,
            a.ClientName,
            a.OldClientCode,
            a.NewClientCode,
            COALESCE(c.DropOutDate,CAST('1900-01-01' AS DATE)) AS DropOutDate,
            COALESCE(c.JoinDate,CAST('1900-01-01' AS DATE)) AS JoinDate, 
            CASE
        WHEN LEFT(OldClientCode,5) <> LEFT(NewClientCode,5) THEN 'Branch Change'
        WHEN LEFT(OldClientCode,9) <> LEFT(NewClientCode,9) THEN 'Center Change'
        WHEN LEFT(OldClientCode,12) <> LEFT(NewClientCode,12) THEN 'Group Change' ELSE 'Within Group' END as SwitchType 
        FROM
            (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientidswitching_log` WHERE ETL_IS_ACTIVE = '1' OR  ETL_IS_ACTIVE IS NULL) a
            LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-usermaster` WHERE ETL_IS_ACTIVE = '1' OR  ETL_IS_ACTIVE IS NULL) u
            ON a.CreatedBy = u.UserId AND a.CreatedBy = u.LoginId
            LEFT join (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR  ETL_IS_ACTIVE IS NULL) c 
            ON a.ClientId = c.ClientId AND a.HierarchyID = c.HierarchyID
            WHERE a.CreatedDateTime >= CURRENT_DATE - 30
    )

    SELECT 
        b.ZONE as ZONE_Name,b.Branch_Type,b.Region,b.AREA,b.UMBaseLocationBranchName as UnitName,b.Branchid as BRANCH_ID,b.BranchName as BRANCH_NAME,a.*
    FROM ClientidSwitching_log a
    LEFT JOIN {mart_catalog}.{mart_schema}.p_hierarchy_sop b
    ON b.HierarchyID = a.HierarchyID
    WHERE b.Branch_Type = 'MFI';
""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"clientidswitching_log_summary Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on clientidswitching_log_summary: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on clientidswitching_log_summary : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.clientidswitching_log_summary")
    
    logger(
            logger_level_info,
            f"clientidswitching_log_summary writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table clientidswitching_log_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table clientidswitching_log_summary : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "clientidswitching_log_summary").mode("overwrite").save()
    logger(
            logger_level_info,
            f"clientidswitching_log_summary writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table clientidswitching_log_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table clientidswitching_log_summary : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)