# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "p_dailyloanfacts_client_pd_ct.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )    
    
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT"
    desti_path = "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )
    query = """with CTE_PM_requiredColumns as (
    select
        Clientid,
        Arrear_4EWI_CM PM_Paidstatus,
        As_on_CollPaid PM_CollPaid,
        Arrear Arrear_PM,
        client_Ason_status ClientNPAstatus_PM,
        EWI EWI_PM,
        Expected_NPAdate Expected_NPAdate_PM,
        isdeath isdeath_PM,
        Ageing Ageing_PM,
        (
        case
            when As_on_NPA = 'Yes' then 1
            when As_on_NPA = 'NO'
            and client_Ason_status like '%writeoff%' then 1
            when As_on_NPA = 'NO'
            and client_Ason_status like '%ARC%' then 1
            else 0
        end
        ) NPA_PM_Tag
    from
        {source_catalog}.{source_schema}.`azuresource-p_loanfacts_client`
    ),
    CTE_RequiredColumn as (
    select
        clientid,
        Min(DPDStartDate) DPDStartDate,
        max(LastRepaymentDate) as LastRepaymentDate,
        sum(EWI) EWI,
        sum(M_PriColl + M_IntColl) As_on_M_coll,
        sum(M_PriDue + M_IntDue) MTD_Due,
        sum(M_PriColl + M_IntColl) MTD_Coll,
        sum(PrincipalInArears + InterestInArears) Arrear,
        SUM(
        case
            when (M_PriDue + M_IntDue) > 0.00
            and (
            (M_PriColl + M_IntColl) >= (M_PriDue + M_IntDue)
            ) then (M_PriDue + M_IntDue)
            else (M_PriColl + M_IntColl)
        end
        ) MTD_Due_Coll
    from
        {mart_catalog}.{mart_schema}.dailyloanfacts
    where
        freezed_op = 'Y'
        or (loancloseddate is not null)
    group by
        clientid
    ),
    CTE_Ason_collPaid as (
    select
        distinct clientid,
        (
        case
            when (
            MTD_Coll > 1
            or MTD_Due > 1
            )
            and MTD_Coll >= MTD_Due then 'Fullypayment'
            when (
            MTD_Coll >= 1
            and MTD_Due > 0
            )
            and MTD_Coll >= EWI then 'PartialPayment'
            when (
            MTD_Coll >= 1
            and MTD_Due > 0
            )
            and MTD_Coll < EWI then 'NotPaid'
            when (
            coalesce(MTD_Due, 0) = 0
            and coalesce(MTD_Coll, 0) = 0
            ) then 'NoDueNoCollection'
            when (coalesce(MTD_Due, 0)) = 0
            and MTD_Coll >= 1 then 'NoDueButPaid'
            when MTD_Due > 0
            and MTD_Coll < 1 then 'NotPaid'
        END
        ) Ason_collPaid
    from
        CTE_RequiredColumn
    ),
    CTE_PaidEWI as (
    select
        distinct clientid,
        Arrear,
        (coalesce(As_on_M_coll, 0) / coalesce(EWI, 0)) PaidEWI
    from
        CTE_RequiredColumn
    ),
    CTE_CMPaid_status as (
    select
        distinct clientid,
        PaidEWI,
        Arrear,
        (
        case
            when PaidEWI = 0
            and Arrear >= 1 then '[0 EWI]'
            when PaidEWI > 0
            and PaidEWI < 1
            and Arrear >= 1 then '[<1 EWI]'
            when PaidEWI >= 1
            and PaidEWI < 2
            and Arrear >= 1 then '[1 EWI]'
            when PaidEWI >= 2
            and PaidEWI < 3
            and Arrear >= 1 then '[2 EWI]'
            when PaidEWI >= 3
            and PaidEWI < 4
            and Arrear >= 1 then '[3 EWI]'
            when PaidEWI >= 4
            and PaidEWI < 5
            and Arrear >= 1 then '[4 EWI]'
            when PaidEWI >= 5
            and PaidEWI < 6
            and Arrear >= 1 then '[5 EWI]'
            when PaidEWI >= 6
            and PaidEWI < 7
            and Arrear >= 1 then '[6 EWI]'
            when PaidEWI >= 7
            and PaidEWI < 8
            and Arrear >= 1 then '[7 EWI]'
            when PaidEWI >= 8
            and PaidEWI < 9
            and Arrear >= 1 then '[8 EWI]'
            when PaidEWI >= 9
            and PaidEWI < 10
            and Arrear >= 1 then '[9 EWI]'
            when PaidEWI >= 10
            and PaidEWI < 11
            and Arrear >= 1 then '[10 EWI]'
            when PaidEWI >= 11
            and Arrear >= 1 then '[11 EWI]'
        END
        ) CMPaid_status
    from
        CTE_PaidEWI
    ),
    CTE_Ason_Paidstatus as (
    select
        distinct clientid,
        coalesce(
        (
            case
            when CMPaid_status >= '[4 EWIs]' then 1
            else 0
            end
        ),
        0
        ) As_on_Paidstatus
    from
        CTE_CMPaid_status
    ),
    CTE_centerArrear_CM as (
    select
        a.Centerid,(
        case
            when NoOfDaysInArrears > 0 then 'Arrearcenter'
            else 'NonArrearcenter'
        end
        ) Ason_Center_Status
    from
        (
        select
            distinct Centerid,
            Max(NoOfDaysInArrears1) NoOfDaysInArrears
        from
            {mart_catalog}.{mart_schema}.dailyloanfacts
        group by
            Centerid
        ) A
    group by
        A.Centerid,(
        case
            when NoOfDaysInArrears > 0 then 'Arrearcenter'
            else 'NonArrearcenter'
        end
        )
    ),
    CTE_centerArrear_PM as (
    select
        a.Centerid,(
        case
            when NoOfDaysInArrears > 0 then 'Arrearcenter'
            else 'NonArrearcenter'
        end
        ) PM_Center_Status
    from
        (
        select
            distinct Centerid,
            Max(Arrear) NoOfDaysInArrears
        from
            {source_catalog}.{source_schema}.`azuresource-p_loanfacts_client`
        group by
            Centerid
        ) A
    group by
        A.Centerid,(
        case
            when NoOfDaysInArrears > 0 then 'Arrearcenter'
            else 'NonArrearcenter'
        end
        )
    ),
    CTE_Suv_client as (
    select
        distinct clientid,(
        case
            when productcode = '854'
            and loancloseddate is null then 'yes'
            else 'No'
        end
        ) suv_client
    from
        {mart_catalog}.{mart_schema}.dailyloanfacts
    where
        loancloseddate is null
    ),
    CTE_BRanch_details as (
    select
        distinct Branchid,
        UMBaseLocationBranchName UnitName,
        SBHState SBH
    from
        {mart_catalog}.{mart_schema}.`p_hierarchy_sop`
    ),
    CTE_Client_1 as (
    select
        p.CODDATE,
        p.Branch_Type,
        p.statename as statename,
        p.Region,
        p.ZoneName as ZoneName,
        p.Area,
        br.UnitName,
        p.BranchID,
        p.BranchName,
        p.HierarchyId,
        p.ClientId,
        p.ClientCode,
        p.ClientName,
        p.CenterId,
        p.centername,
        p.StaffId as StaffId,
        p.Groupid,
        p.TargetId,
        p.centercode,
        p.CenterMeetingDay,
        p.NoOfDaysInArrears as NoOfDaysInArrears,
        p.POS,
        p.PrINcipalINArears,
        p.INterestINArears,
        p.EWi,(
        case
            when P.NoOfDaysInArrears between 61
            and 90 then m.Expected_NPAdate_PM
            when P.NoOfDaysInArrears between 31
            and 60 then dateadd(day, 59, P.DPDstartdate)
            when P.NoOfDaysInArrears between 1
            and 30 then dateadd(day, 29, P.DPDstartdate)
        end
        ) BucketMovement_Date,
        Ageing,
        0 as ALL_Client_ageing,
        (
        case
            when cd.type_new in (
            'Writeoff_Mar22',
            'Writeoff_Jun22',
            'Writeoff_sep22',
            'Writeoff_Dec22',
            'Closed deals',
            'Writeoff_Mar23',
            'Writeoff_Jun23',
            'writeoff_sep23',
            'writeoff_Dec23',
            'Arc_Dec21',
            'Arc_Feb23',
            'Arc_Mar23'
            ) then 'Y'
            else 'N'
        end
        ) as Remarks_Writeoff,
        p.Fin_POS,
        p.CMTime,
        p.staffname,
        p.days_to_r91,
        p.Date_91_Days,
        p.IsDeath,
        p.Var_balance,
        p.Month_End_Status,
        p.Monthend_Ageing,
        p.Month_END_POS,
        p.client_Type,
        p.CenterStatus,
        p.As_on_NPA,
        p.NPA_date,
        P.ClientNPAstatus,
        (
        case
            when CAST(p.npa_date as DATE) < '2020-09-01' then 'yes'
            else 'No'
        end
        ) Mar20_NPA,
        (
        case
            when CAST(p.npa_date as Date) between '2020-09-01'
            and '2021-03-31' then 'yes'
            else 'No'
        END
        ) Mar21_NPA,
        P.PM_Center_Status,
        P.Ason_Center_Status,
        P.suv_client,
        ASP.As_on_Paidstatus,
        M.PM_Paidstatus,
        c.MTD_Due,
        c.MTD_Coll,
        c.MTD_Due_Coll,
        e.PaidEWI,
        ASCl.Ason_collPaid,
        m.PM_CollPaid,
        c.DPDstartdate,
        p.LastRepaymentDate as Last_Repayment_Date,
        P.SBH,
        P.ClientNPAstatus_PM,
        M.Arrear_PM,
        P.NPA_PM_Tag,
        p.Ageing_As_Per_DPD
    from
        {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary P
        Left Join CTE_requiredColumn C on P.clientid = C.clientid
        left join {mart_catalog}.{mart_schema}.dailyloanfacts cd on P.clientid = cd.clientid
        Left Join CTE_PM_requiredColumns M on P.clientid = M.clientid
        Left Join CTE_Suv_client S on P.clientid = S.clientid
        Left Join CTE_PaidEWI E on P.clientid = E.clientid
        Left Join CTE_CMPaid_status CMP on P.clientid = CMP.clientid
        Left Join CTE_Ason_Paidstatus ASP on P.clientid = ASP.clientid
        Left Join CTE_Ason_collPaid ASCL on P.clientid = ASCL.clientid
        Left Join CTE_centerArrear_CM CRCM on P.centerid = CRCM.centerid
        Left Join CTE_centerArrear_PM CRPM on P.centerid = CRPM.centerid
        Left Join CTE_BRanch_details BR on P.Branchid = BR.Branchid
    ),
    CTE_Ageingflow as (
    select
        Clientid,
        (
        case
            when Monthend_ageing in ('New Client', 'current1')
            and Ageing <> 'current1'
            and (PrINcipalINArears + INterestINArears) > 0 then 'NewArrearAdded'
            when Monthend_ageing is null
            and Ageing <> 'current1'
            and (PrINcipalINArears + INterestINArears) > 0 then 'NewArrearAdded'
            when (
            case
                when Ageing = 'Current1' then 1
                when Ageing = '[1 To 30]' then 2
                when Ageing = '[31 To 60]' then 3
                when Ageing = '[61 To 90]' then 4
                when Ageing = '[>90]' then 5
                else 100
            end
            ) > (
            case
                when Monthend_Ageing in ('Current1', 'New Client') then 1
                when Monthend_Ageing = '[1 To 30]' then 2
                when Monthend_Ageing = '[31 To 60]' then 3
                when Monthend_Ageing = '[61 To 90]' then 4
                when Monthend_Ageing = '[>90]' then 5
                else 100
            end
            ) then 'Forward Flow'
            when (
            case
                when Ageing = 'Current1' then 1
                when Ageing = '[1 To 30]' then 2
                when Ageing = '[31 To 60]' then 3
                when Ageing = '[61 To 90]' then 4
                when Ageing = '[>90]' then 5
                else 100
            end
            ) = (
            case
                when Monthend_Ageing in ('Current1', 'New Client') then 1
                when Monthend_Ageing = '[1 To 30]' then 2
                when Monthend_Ageing = '[31 To 60]' then 3
                when Monthend_Ageing = '[61 To 90]' then 4
                when Monthend_Ageing = '[>90]' then 5
                else 100
            end
            ) then 'No Change'
            when (
            case
                when Ageing = 'Current1' then 1
                when Ageing = '[1 To 30]' then 2
                when Ageing = '[31 To 60]' then 3
                when Ageing = '[61 To 90]' then 4
                when Ageing = '[>90]' then 5
                else 100
            end
            ) < (
            case
                when Monthend_Ageing in ('Current1', 'New Client') then 1
                when Monthend_Ageing = '[1 To 30]' then 2
                when Monthend_Ageing = '[31 To 60]' then 3
                when Monthend_Ageing = '[61 To 90]' then 4
                when Monthend_Ageing = '[>90]' then 5
                else 100
            end
            ) then 'Backward Flow'
            when Monthend_Ageing not in ('Current1', 'New Client')
            and Ageing = 'Current1' then 'ArrearClear'
            when Monthend_Ageing is null
            and Ageing = 'Current1' then 'ArrearClear'
            when Ageing_As_Per_DPD = 'Closedclients'
            and Ageing = 'Current1' then 'ArrearClear'
            else 'Error'
        end
        ) Ageing_Flow,
        (
        case
            when coalesce(MTD_Coll, 0) >=(coalesce(Arrear_PM, 0) + coalesce(MTD_Due, 0)) then (coalesce(Arrear_PM, 0) + coalesce(MTD_Due, 0))
            else coalesce(MTD_Coll, 0)
        end
        ) Grosscoll
    from
        CTE_Client_1
    ),
    CTE_CT as (
    select
        C.*,
        A.Ageing_Flow,
        A.Grosscoll
    from
        CTE_Client_1 c
        left join CTE_Ageingflow A on c.clientid = a.clientid
    )
    select * from CTE_CT;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query.{str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query.", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_dailyloanfacts_client_pd_ct: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_dailyloanfacts_client_pd_ct", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option(
        "mergeSchema", "true"
    ).option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct")

    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_dailyloanfacts_client_pd_ct : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table p_dailyloanfacts_client_pd_ct : ", str(e)
    )

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "p_dailyloanfacts_client_pd_ct").mode("overwrite").save()
    
    logger(
            logger_level_info,
            f"p_dailyloanfacts_client_pd_ct writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct : ", str(e))

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)