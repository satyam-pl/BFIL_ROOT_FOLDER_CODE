# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_igl1_focus_eligible.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_IGL1_FOCUS_ELIGIBLE"
    desti_path = "BFIL-MART/REPORTING/P_IGL1_FOCUS_ELIGIBLE"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """
with CTE_ClientID_CenterStatus
as (Select a.ClientID,b.CenterID,A.GroupId,A.HierarchyID,A.TargetID,A.JoinDate, CM.CenterMeetingDay, null as amount,
Max( case when  Cl.ETL_IS_ACTIVE=1   and ProductType is null   then cl.DisbursementDate end )Max_Disb,    
Count(case when POS>0 and Branch_Type in('SMPT','HIL') then 1 end)NOL,          
coalesce(Max(NoOfDaysInArrears1),0)Max_DPD          
from {source_catalog}.{source_schema}.`pragati-clientmaster` a
left JOin  {source_catalog}.{source_schema}.`pragati-groupmaster`  b on a.GroupId=b.GroupID
left JOin  {source_catalog}.{source_schema}.`pragati-Centermaster`  Cm on b.CenterID=Cm.CenterID
left JOin  {source_catalog}.{source_schema}.`pragati-clientloansubscription`  Cl on a.ClientID=Cl.ClientID
left JOin  {mart_catalog}.{mart_schema}.dailyloanfacts  C on a.ClientId =C.ClientId
where cast(a.DropOutDate as date) is null AND a.ETL_IS_ACTIVE=1  
and Cm.ETL_IS_ACTIVE=1  
Group by a.ClientID,b.CenterID,A.GroupId,A.HierarchyID,A.TargetID,A.JoinDate, CM.CenterMeetingDay) ,
t_veer_unnatimfidata_f AS
(Select A.*,
case when coalesce(B.NOC_NonArrear,0)>=0 and coalesce(B.NOC_Arrear,0)=0 then 'Good Center'          
when coalesce(B.NOC_Arrear,0) between 1 and 3  then    'Bad Center A'          
when coalesce(B.NOC_Arrear,0)>3 then    'Bad Center B' end  Center_Status ,
(case when B.NOC_Arrear>1 then 'Yes' else 'No' end) Center_Arrear,
(case when C.NOC_Arrear>1 then 'Yes' else 'No' end) Group_Arrear,''Center_Eligible_Status
from   CTE_ClientID_CenterStatus as A
left Join ( Select CenterID,
Sum(NOL)NOL,
Count(Distinct ClientID)NOC,          
Count(case when Max_DPD=0 then   1 end)NOC_NonArrear,          
Count(case when Max_DPD>0 then   1 end)NOC_Arrear from  CTE_ClientID_CenterStatus  Group by CenterID  ) B  on A.CenterID=B.CenterID
left Join ( Select GroupId,
Sum(NOL)NOL,
Count(Distinct ClientID)NOC,          
Count(case when Max_DPD=0 then   1 end)NOC_NonArrear,          
Count(case when Max_DPD>0 then   1 end)NOC_Arrear from  CTE_ClientID_CenterStatus  
Group by GroupId  ) C  on A.GroupId=C.GroupId),
T_Veer_IGL_Data1  AS (
SELECT distinct A.HierarchyID, A.TargetID, T.TargetDate, T.TargetCode, A.ClientID,
C.ClientCode, C.ClientName, A.JoinDate, A.CenterID, A.CenterMeetingDay,
A.Center_Arrear, A.Group_Arrear, Center_Eligible_Status AS Center_Eligible_Final,
B.MFI_Series AS MFI_PA, B.Unnati_Seeries AS Unnati_PA, B.FUL AS CDF_PA,Final_Eligible,CBScrub_InEligibility,
(CASE
WHEN MB.Final_Eligible IS NOT NULL THEN MB.Final_Eligible    else Null end ) Instant_Eligible1,      Null    AS Instant_Reject
FROM t_veer_unnatimfidata_f A
JOIN {source_catalog}.{source_schema}.`pragati-clientmaster` C ON A.ClientID = C.ClientId
JOIN {source_catalog}.{source_schema}.`pragati-targetmaster` T ON C.TargetId = T.TargetId
LEFT JOIN {mart_catalog}.{mart_schema}.preapproved_data B ON A.ClientID = B.ClientId
LEFT JOIN {source_catalog}.{source_schema}.`azuresource-p_veer_instantcb_mfi_cs_products` MB ON A.ClientID = MB.ClientID    
WHERE A.Max_Disb IS NULL AND A.JoinDate >='2022-04-01'  and c.ETL_IS_ACTIVE=1
),
T_Veer_IGL_Data as(
Select *, COALESCE(case when Instant_Eligible1 ='Eligible' then CBScrub_InEligibility
else   Instant_Eligible1  end ,Final_Eligible ) Instant_Eligible  from T_Veer_IGL_Data1),
T_Veer_InstantCBTargetsData_21 AS (
SELECT * FROM {source_catalog}.{source_schema}.`azuresource-p_instantcbtargetsdata`
WHERE CBDate >= DATE_SUB(CURRENT_DATE, 21) AND CBStatus = 'NOT ELIGIBLE' AND CB_Type = 'Disbursement'),
T_Veer_InstantCBTargetsData_Max_21 AS (SELECT TargetID, MAX(DataKey) AS Max_DataKey FROM T_Veer_InstantCBTargetsData_21
GROUP BY TargetID),
T_Veer_InstantCBTargetsData_21_F AS
 (
SELECT B.* FROM T_Veer_InstantCBTargetsData_Max_21 A
JOIN T_Veer_InstantCBTargetsData_21 B ON A.TargetID = B.TargetID AND A.Max_DataKey = B.DataKey),
update_T_Veer_IGL_Data AS (
--update_T_Veer_IGL_Data_1  as (
SELECT A.HierarchyID, A.TargetID, A.TargetDate, A.TargetCode, A.ClientID,
A.ClientCode, A.ClientName, A.JoinDate, A.CenterID, A.CenterMeetingDay,
A.Center_Arrear, A.Group_Arrear,  a.Center_Eligible_Final,
A.MFI_PA, A.Unnati_PA, A.CDF_PA,a.Instant_Eligible,
COALESCE(B.Rejection_reason, A.Instant_Reject) AS Instant_Reject,
CASE WHEN MFI_PA > 0 OR Unnati_PA > 0 THEN 'Pre approved available'
WHEN Instant_Eligible <> 'Eligible' THEN 'Instant Not Eligible'  
WHEN Center_Arrear = 'Yes' THEN 'Center Arrear'
 WHEN     B.Rejection_reason IS NOT NULL THEN 'Recently Instant Rejected'
 ELSE Instant_Eligible END AS Status1
FROM T_Veer_IGL_Data A  
LEFT JOIN T_Veer_InstantCBTargetsData_21_F B ON A.ClientID = B.TargetID
) ,
update_T_Veer_IGL_Data_1 AS (
SELECT  ClientID,Count(1)Cnt
FROM   {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` PB
where  BCMLoanCancelledDate is null  and  CancelDate is null
and  DeviationCancelledDate is null Group by ClientID)  ,
T_IGL1_Focus_Eligible1 AS (
SELECT
A.*,
CASE WHEN Status1 = 'Eligible' THEN 'Instant available' when Status1 is null then 'New Joines'  ELSE Status1   END AS Status0,
CASE WHEN Status1 IN ('Eligible', 'Pre approved available') THEN 'Eligible Clients'ELSE 'Non-Eligible Clients' END AS Final_Eligible
FROM update_T_Veer_IGL_Data A ),
T_IGL1_Focus_Eligible as (
Select A.*,coalesce(case when Status0='Instant available' and b.Cnt>=1 then 'Proposal Active' end,Status0)Status   from T_IGL1_Focus_Eligible1 a
left Join  update_T_Veer_IGL_Data_1 b on a.ClientID=b.ClientID
),
P_IGL1_Focus_Eligible AS (
SELECT  
distinct  A.CenterID,
Sop.ZONE_name AS ZoneName,
Sop.STATE AS State,
Sop.AREA_office AS Area,
Sop.Region,
Sop.UM_Base_Location_Branch_id AS Unitname,
Sop.BRANCH_ID,
Sop.BRANCH_NAME,
A.HierarchyID,
A.TargetID,
A.TargetDate,
A.TargetCode,
A.ClientID,
A.ClientCode,
A.ClientName,
A.JoinDate,
A.CenterMeetingDay,
A.Center_Arrear,
A.Group_Arrear,
A.Center_Eligible_Final,
A.MFI_PA,
A.Unnati_PA,
A.CDF_PA,
A.Instant_Eligible,
A.Instant_Reject,  
A.Status,
A.Final_Eligible,
CURRENT_DATE() AS Report_Date
FROM t_IGL1_Focus_Eligible A
JOIN {source_catalog}.{source_schema}.`azuresource-t_veer_hierarchy_sop` Sop ON A.HierarchyID = Sop.HierarchyId)
SELECT * FROM P_IGL1_Focus_Eligible;
""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_igl1_focus_eligible Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_igl1_focus_eligible: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_igl1_focus_eligible : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_igl1_focus_eligible")

    logger(
            logger_level_info,
            f"p_igl1_focus_eligible writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_igl1_focus_eligible : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table p_igl1_focus_eligible : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "p_igl1_focus_eligible").mode("overwrite").save()
    logger(
            logger_level_info,
            f"p_igl1_focus_eligible writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_igl1_focus_eligible : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_igl1_focus_eligible : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)