# Databricks notebook source
# MAGIC %sql
# MAGIC drop table edp_bfil_prod.bfil_mart.p_dailyloanfacts_client_pd_ct_npa_data_branchwise

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_dailyloanfacts_client_pd_ct_npa_data_branchwise.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )    
    
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT_NPA_DATA_BRANCHWISE"
    desti_path = "BFIL-MART/REPORTING/P_DAILYLOANFACTS_CLIENT_PD_CT_NPA_DATA_BRANCHWISE"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH P_Dailyloanfacts_client_PD_CT_Summary AS (
  SELECT 
    hierarchyid,
    Centermeetingday,
    CASE 
      WHEN Ageing = 'Current1' THEN '1. [Current]'
      WHEN Ageing = '[1 To 30]' THEN '2. [01 To 30]'
      WHEN Ageing = '[31 To 60]' THEN '3. [31 To 60]'
      WHEN Ageing = '[61 To 90]' THEN '4. [61 To 90]'
      WHEN Ageing = '[>90]' THEN '5. [NPA]'
    END AS Ageing,
    Month_end_Status,
    CASE 
      WHEN Monthend_Ageing = 'Current1' THEN '1. [Current]'
      WHEN Monthend_Ageing = '[1 To 30]' THEN '2. [01 To 30]'
      WHEN Monthend_Ageing = '[31 To 60]' THEN '3. [31 To 60]'
      WHEN Monthend_Ageing = '[61 To 90]' THEN '4. [61 To 90]'
      WHEN Monthend_Ageing = '[>90]' THEN '5. [NPA]'
      WHEN Monthend_Ageing = 'New Client' THEN '6. [New Client]'
    END AS Monthend_Ageing,
    centerstatus,
    as_on_NPA,
    CASE 
      WHEN Ageing_Flow = 'NewArrearAdded' THEN '1. [New Arrear Added]'
      WHEN Ageing_Flow = 'Forward Flow' THEN '2. [Forward Flow]'
      WHEN Ageing_Flow = 'Backward Flow' THEN '3. [Backward Flow]'
      WHEN Ageing_Flow = 'ArrearClear' THEN '4. [Arrears Cleared]'
      WHEN Ageing_Flow = 'ClosedClients' THEN '5. [Closed Clients]'
      WHEN Ageing_Flow = 'No Change' THEN '6. [No Change]'
    END AS Ageing_Flow,
    CASE 
      WHEN Ason_CollPaid = 'Fullypayment' THEN '1. [Fully Paid]'
      WHEN Ason_CollPaid = 'PartialPayment' THEN '2. [Partially Paid]'
      WHEN Ason_CollPaid = 'NotPaid' THEN '3. [Not Paid]'
      WHEN Ason_CollPaid = 'NoDueButPaid' THEN '4. [No Due But Paid]'
      WHEN Ason_CollPaid = 'NoDueNoCollection' THEN '5. [No Due No Collection]'
    END AS Ason_CollPaid,
    CASE 
      WHEN PM_CollPaid = 'Fullypayment' THEN '1. [Fully Paid]'
      WHEN PM_CollPaid = 'PartialPayment' THEN '2. [Partially Paid]'
      WHEN PM_CollPaid = 'NotPaid' THEN '3. [Not Paid]'
      WHEN PM_CollPaid = 'NoDueButPaid' THEN '4. [No Due But Paid]'
      WHEN PM_CollPaid = 'NoDueNoCollection' THEN '5. [No Due No Collection]'
    END AS PM_CollPaid,
    As_on_Paidstatus,
    PM_Paidstatus,
    NPA_PM_Tag,
    0 as MRD_tag,
    0 as br_flag,
    0 as pq_flag,
    SUM(MTD_Due) AS MTD_Due,
    SUM(MTD_Coll) AS MTD_Coll,
    SUM(MTD_Due_Coll) AS MTD_DuevsColl,
    SUM(PaidEWI) AS PaidEWI,
    SUM(Month_END_POS) AS Month_END_POS,
    SUM(POS) AS POS,
    SUM(POS) / 1e7 AS POS_Cr,
    SUM(PrincipalINArears) AS PrincipalINArears,
    SUM(InterestINArears) AS InterestINArears,
    COUNT(1) AS NOC,
    SUM(NO_Of_Active_Loans) AS NOL,
    CASE 
      WHEN Ageing_Flow = '1. [New Arrear Added]' THEN '#FF4F25'
      WHEN Ageing_Flow = '2. [Forward Flow]' THEN '#DDFD69'
      WHEN Ageing_Flow = '3. [Backward Flow]' THEN '#A9D08E'
      WHEN Ageing_Flow = '4. [Arrears Cleared]' THEN '#00B050'
    END AS Ageing_flow_Color
  FROM 
    {mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct_summary A
    --LEFT JOIN SMART_INFO..BucketwiseRetain_NPA_Target B 
      --ON A.hierarchyid = B.hierarchyid AND A.Monthend_Ageing = B.Ageing
  WHERE 
    branch_type = 'MFI'
  GROUP BY 
    hierarchyid,
    Centermeetingday,
    Ageing,
    Month_end_Status,
    Monthend_Ageing,
    centerstatus,
    as_on_NPA,
    Ageing_Flow,
    Ason_CollPaid,
    PM_CollPaid,
    As_on_Paidstatus,
    PM_Paidstatus,
    NPA_PM_Tag,
    MRD_tag,
    br_flag,
    pq_flag
),

 CTE_Dailyloanfacts AS (
    SELECT
        StateName,
        Region,
        ZoneName,
        Area,
        BranchID,
        BranchName,
        HierarchyId,
        ClientId,
        ClientCode,
        ClientName,
        CenterId,
        centername,
        StaffId,
        Groupid,
        TargetId,
        centercode,
        CenterMeetingDay,
        POS,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        staffname,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_Due_Coll,
        Ageing_Flow,
        Arrear_PM,
        1 AS IsFocus,
        1 AS WorkingDays_Total,
        1 AS WorkingDays_Completed,
        1 AS WorkingDays_Pending,
        '01-01-2024' as Date_91_Days,
        CASE
            WHEN Ageing_Flow = '1. [New Arrear Added]' THEN '#FF4F25'
            WHEN Ageing_Flow = '2. [Forward Flow]' THEN '#DDFD69'
            WHEN Ageing_Flow = '3. [Backward Flow]' THEN '#A9D08E'
            WHEN Ageing_Flow = '4. [Arrears Cleared]' THEN '#00B050'
            ELSE NULL
        END AS Ageing_flow_Color
        --COALESCE(Month_END_POS, 0) - COALESCE(Tolerance_Target, 0) AS Month_END_POS_Tolerance

    FROM
        {mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct_summary
    WHERE
        NPA_PM_Tag = 1 AND Branch_Type = 'SMPT'
),


P_Dailyloanfacts_client_PD_CT_NPA_Data_Clientwise AS (
    SELECT
        StateName,
        Region,
        ZoneName,
        Area,
        BranchID,
        BranchName,
        HierarchyId,
        ClientId,
        ClientCode,
        ClientName,
        CenterId,
        centername,
        StaffId,
        Groupid,
        TargetId,
        centercode,
        CenterMeetingDay,
        POS,
        PrINcipalINArears,
        INterestINArears,
        Ageing,
        Ageing_As_Per_DPD,
        staffname,
        Month_End_Status,
        Monthend_Ageing,
        Month_END_POS,
        client_Type,
        MTD_Due,
        MTD_Coll,
        MTD_Due_Coll,
        Ageing_Flow,
        Arrear_PM,
        IsFocus,
        WorkingDays_Total,
        WorkingDays_Completed,
        WorkingDays_Pending,
        Date_91_Days
    FROM CTE_Dailyloanfacts
),


 P_Dailyloanfacts_client_PD_CT_NPA_Data_centerwise AS (
    SELECT
        StateName,
        Region,
        ZoneName,
        Area,
        BranchID,
        BranchName,
        HierarchyId,
        CenterId,
        centername,
        centercode,
        staffid,
        staffname,
        IsFocus,
        WorkingDays_Total,
        WorkingDays_Completed,
        WorkingDays_Pending,
        COUNT(1) AS BaseClients,
        SUM(Month_END_POS) AS Base_POS,
        SUM(Arrear_PM) AS Base_Arrear,
        SUM(POS) AS As_on_POS,
        SUM(COALESCE(PrINcipalINArears, 0)) + SUM(COALESCE(INterestINArears, 0)) AS As_on_Arrear,
        SUM(MTD_Coll) AS MTD_Coll,
        SUM(CASE WHEN MTD_Coll > 0 THEN 1 ELSE 0 END) AS MTD_Coll_Clients,
        0 AS RecoveryTarget,
        CASE WHEN SUM(MTD_Coll) = 0 THEN 1 ELSE 0 END AS Zero_Centers,
        COUNT(DISTINCT Centerid) AS No_of_Centers,
        COUNT(DISTINCT Staffid) AS No_of_SMs
    FROM P_Dailyloanfacts_client_PD_CT_NPA_Data_Clientwise
    GROUP BY
        StateName,
        Region,
        ZoneName,
        Area,
        BranchID,
        BranchName,
        HierarchyId,
        CenterId,
        centername,
        centercode,
        staffid,
        staffname,
        IsFocus,
        WorkingDays_Total,
        WorkingDays_Completed,
        WorkingDays_Pending
),

 P_Dailyloanfacts_client_PD_CT_NPA_Data_SMWise AS (
    SELECT
        StateName,
        Region,
        ZoneName,
        Area,
        BranchID,
        BranchName,
        HierarchyId,
        staffid,
        staffname,
        IsFocus,
        WorkingDays_Total,
        WorkingDays_Completed,
        WorkingDays_Pending,
        SUM(BaseClients) AS BaseClients,
        SUM(Base_POS) AS Base_POS,
        SUM(Base_Arrear) AS Base_Arrear,
        SUM(As_on_POS) AS As_on_POS,
        SUM(As_on_Arrear) AS As_on_Arrear,
        SUM(MTD_Coll) AS MTD_Coll,
        SUM(MTD_Coll_Clients) AS MTD_Coll_Clients,
        0 AS RecoveryTarget,
        SUM(Zero_Centers) AS Zero_Centers,
        CASE WHEN SUM(MTD_Coll) = 0 THEN 1 ELSE 0 END AS Zero_SMs,
        SUM(No_of_Centers) AS No_of_Centers,
        SUM(No_of_SMs) AS No_of_SMs
    FROM P_Dailyloanfacts_client_PD_CT_NPA_Data_centerwise
    GROUP BY
        StateName,
        Region,
        ZoneName,
        Area,
        BranchID,
        BranchName,
        HierarchyId,
        staffid,
        staffname,
        IsFocus,
        WorkingDays_Total,
        WorkingDays_Completed,
        WorkingDays_Pending
),

P_Dailyloanfacts_client_PD_CT_NPA_Data_branchwise as(
SELECT
    StateName,
    Region,
    ZoneName,
    Area,
    BranchID,
    BranchName,
    HierarchyId,
    IsFocus,
    WorkingDays_Total,
    WorkingDays_Completed,
    WorkingDays_Pending,
    SUM(BaseClients) AS BaseClients,
    SUM(Base_POS) AS Base_POS,
    SUM(Base_Arrear) AS Base_Arrear,
    SUM(As_on_POS) AS As_on_POS,
    SUM(As_on_Arrear) AS As_on_Arrear,
    SUM(MTD_Coll) AS MTD_Coll,
    SUM(MTD_Coll_Clients) AS MTD_Coll_Clients,
    10000000 AS RecoveryTarget,
    SUM(Zero_Centers) AS Zero_Centers,
    SUM(Zero_SMs) AS Zero_SMs,
    SUM(No_of_Centers) AS No_of_Centers,
    SUM(No_of_SMs) AS No_of_SMs
FROM P_Dailyloanfacts_client_PD_CT_NPA_Data_SMWise
GROUP BY
    StateName,
    Region,
    ZoneName,
    Area,
    BranchID,
    BranchName,
    HierarchyId,
    IsFocus,
    WorkingDays_Total,
    WorkingDays_Completed,
    WorkingDays_Pending)




-- Execute the final selection
SELECT * FROM P_Dailyloanfacts_client_PD_CT_Summary;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query.{str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query.", str(e))

# COMMAND ----------

try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct_npa_data_branchwise Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_dailyloanfacts_client_pd_ct_npa_data_branchwise: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_dailyloanfacts_client_pd_ct_npa_data_branchwise", str(e))

# COMMAND ----------

try:
    df.write.format("delta").mode("overwrite").option(
        "mergeSchema", "true"
    ).option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_dailyloanfacts_client_pd_ct_npa_data_branchwise")

    logger(
        logger_level_info,
        f"p_dailyloanfacts_client_pd_ct_npa_data_branchwise writing to delta table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_dailyloanfacts_client_pd_ct_npa_data_branchwise : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into delta table p_dailyloanfacts_client_pd_ct_npa_data_branchwise : ", str(e)
    )

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "p_dailyloanfacts_client_pd_ct_npa_data_branchwise").mode("overwrite").save()
    logger(
            logger_level_info,
            f"p_dailyloanfacts_client_pd_ct_npa_data_branchwise writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct_npa_data_branchwise : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table p_dailyloanfacts_client_pd_ct_npa_data_branchwise : ", str(e))

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)