# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_preapproved_data.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/PREAPPROVED_DATA"
    desti_path = "BFIL-MART/REPORTING/PREAPPROVED_DATA"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH CTE_ClientID_CenterStatus AS (

SELECT

a.ClientID,

b.CenterID,

COUNT(CASE WHEN POS > 0 AND Branch_Type IN ('SMPT', 'HIL') THEN 1 END) AS NOL,

COALESCE(MAX(NoOfDaysInArrears1), 0) AS Max_DPD

FROM {source_catalog}.{source_schema}.`pragati-clientmaster` a

LEFT JOIN {source_catalog}.{source_schema}.`pragati-groupmaster` b ON a.GroupId = b.GroupID

LEFT JOIN {mart_catalog}.{mart_schema}.Dailyloanfacts c ON a.ClientId = c.ClientId

WHERE CAST(a.DropOutDate AS DATE) IS NULL AND a.etl_is_active = 1 or a.etl_is_active is Null

AND b.etl_is_active = 1 or b.etl_is_active is Null

GROUP BY a.ClientID, b.CenterID),

CTE_Client_CenterStatus_C AS (

SELECT

A.*,

CASE

WHEN COALESCE(NOC_NonArrear, 0) >= 0 AND COALESCE(NOC_Arrear, 0) = 0 THEN 'Good Center'

WHEN COALESCE(NOC_Arrear, 0) BETWEEN 1 AND 3 THEN 'Bad Center A'

WHEN COALESCE(NOC_Arrear, 0) > 3 THEN 'Bad Center B'

END AS Center_Status

FROM CTE_ClientID_CenterStatus AS A

LEFT JOIN (

SELECT

CenterID,

SUM(NOL) AS NOL,

COUNT(DISTINCT ClientID) AS NOC,

COUNT(CASE WHEN Max_DPD = 0 THEN 1 END) AS NOC_NonArrear,

COUNT(CASE WHEN Max_DPD > 0 THEN 1 END) AS NOC_Arrear

FROM CTE_ClientID_CenterStatus

GROUP BY CenterID) B ON A.CenterID = B.CenterID),

 

CTE_Unnati AS (

SELECT A.*

FROM (

WITH CTE_SurakshaPreApprovedProposalHO AS (

SELECT DISTINCT

ClientId,

mobileNumber,

CBAmount,

800 AS ProductCode,

(CASE WHEN CreatedBy = 'Unnati Plus' THEN 'UnnatiPls' ELSE 'Unnati' END) AS ProductName1,

CBExpiryDate,

CBResponseId,

MaxEWIAmount,

MAX(CAST(CreatedDateTime AS DATE)) AS Create_Date

FROM {source_catalog}.{source_schema}.`pragati-surakshapreapprovedproposalho`

WHERE CBExpiryDate >= CAST(current_date() AS DATE)

AND CBAmount > 0 AND MaxEWIAmount > 0 and etl_is_active = 1 and  CreatedBy <> 'Unnati Plus'

GROUP BY ClientId, mobileNumber, CBAmount, CBExpiryDate, CBResponseId, MaxEWIAmount, CreatedBy)

SELECT A.*, ROW_NUMBER() OVER (PARTITION BY ClientID ORDER BY CBExpiryDate DESC) AS Rankk

FROM CTE_SurakshaPreApprovedProposalHO AS A

WHERE ClientID NOT IN (SELECT A.ClientId

FROM CTE_SurakshaPreApprovedProposalHO A

JOIN {source_catalog}.{source_schema}.`pragati-surakshapreapprovedproposal` B ON A.ClientId = B.ClientId AND A.CBResponseId = B.CBResponseId

Left JOIN {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` Cls ON B.LoanProposalId = Cls.LoanProposalId

WHERE (B.LoanProposalId IS NOT NULL OR (SLCancelDate IS not NULL or SLCancelDate='')) AND B.MaxEWIAmount > 0 and b.ETL_IS_ACTIVE =1 )) A

JOIN CTE_Client_CenterStatus_C B ON A.ClientID = B.ClientID

WHERE Rankk = 1 AND (B.Center_Status = 'Bad Center A' AND ProductName1 = 'Unnati')),

 

CTE_Unnatipls AS (

SELECT A.*

FROM (

WITH CTE_SurakshaPreApprovedProposalHO AS (

SELECT DISTINCT

ClientId,

mobileNumber,

CBAmount,

800 AS ProductCode,

(CASE WHEN CreatedBy = 'Unnati Plus' THEN 'UnnatiPls' ELSE 'Unnati' END) AS ProductName1,

CBExpiryDate,

CBResponseId,

MaxEWIAmount,

MAX(CAST(CreatedDateTime AS DATE)) AS Create_Date

FROM {source_catalog}.{source_schema}.`pragati-surakshapreapprovedproposalho`

WHERE CBExpiryDate >= CAST(current_date() AS DATE) AND CBAmount > 0 AND MaxEWIAmount > 0 and etl_is_active = 1

and  CreatedBy = 'Unnati Plus'GROUP BY ClientId, mobileNumber, CBAmount, CBExpiryDate, CBResponseId, MaxEWIAmount, CreatedBy)

SELECT A.*, ROW_NUMBER() OVER (PARTITION BY ClientID ORDER BY CBExpiryDate DESC) AS Rankk

FROM CTE_SurakshaPreApprovedProposalHO AS A

WHERE ClientID NOT IN (

SELECT A.ClientId

FROM CTE_SurakshaPreApprovedProposalHO A

JOIN {source_catalog}.{source_schema}.`pragati-surakshapreapprovedproposal` B ON A.ClientId = B.ClientId AND A.CBResponseId = B.CBResponseId

Left JOIN {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` Cls ON B.LoanProposalId = Cls.LoanProposalId

WHERE (B.LoanProposalId IS NOT NULL OR (SLCancelDate IS not NULL or SLCancelDate='') ) AND B.MaxEWIAmount > 0  and b.ETL_IS_ACTIVE =1  )) A

JOIN CTE_Client_CenterStatus_C B ON A.ClientID = B.ClientID

WHERE Rankk = 1 AND (B.Center_Status = 'Bad Center B' AND ProductName1 = 'UnnatiPls')),

 

CTE_MFI AS (

SELECT C.*

FROM (

WITH CTE_PreApprovedProposalHO AS (

SELECT DISTINCT

ClientId,

mobileNumber,

CBAmount,

15 AS ProductCode,

'MFI' AS ProductName1,

CBExpiryDate,

CBResponseId,

MaxEWIAmount,

MAX(CAST(CreatedDateTime AS DATE)) AS Create_Date

FROM {source_catalog}.{source_schema}.`pragati-PreApprovedProposalHO`

WHERE CBExpiryDate >= CAST(current_date() AS DATE)AND CBAmount > 0 AND MaxEWIAmount > 0 and etl_is_active = 1

GROUP BY ClientId, mobileNumber, CBAmount, CBExpiryDate, CBResponseId, MaxEWIAmount)

 

SELECT A.*, ROW_NUMBER() OVER (PARTITION BY A.ClientID ORDER BY CBExpiryDate DESC) AS Rankk

FROM CTE_PreApprovedProposalHO AS A

WHERE ClientID NOT IN (

SELECT A.ClientId

FROM CTE_PreApprovedProposalHO A

JOIN {source_catalog}.{source_schema}.`pragati-PreApprovedProposal` B ON A.ClientId = B.ClientId AND A.CBResponseId = B.CBResponseId

Left JOIN {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` Cls ON B.LoanProposalId = Cls.LoanProposalId

WHERE (B.LoanProposalId IS NOT NULL OR (COALESCE(CancelDate,'1900-01-01')<>'1900-01-01' or CancelDate=''))

AND B.MaxEWIAmount > 0  and B.CBAmount>0 and b.etl_is_active=1 )) C

JOIN CTE_Client_CenterStatus_C D ON C.ClientID = D.ClientID WHERE Rankk = 1 AND D.Center_Status = 'Good Center'),

 

CTE_EL AS (

SELECT E.*FROM (

WITH CTE_PreApprovedProposalHO_EL AS (SELECT DISTINCT

ClientId,

mobileNumber,

CBAmountEL AS CBAmount,

1100 AS ProductCode,

'Emergency Loan-01' AS ProductName1,

CBExpiryDate,

CBResponseId,

MaxEWIAmount,

MAX(CAST(CreatedDateTime AS DATE)) AS Create_Date

FROM {source_catalog}.{source_schema}.`pragati-PreApprovedProposalHO`

WHERE CBExpiryDate >= CAST(current_date() AS DATE)AND MaxEWIAmount > 0 AND CBAmountEL > 0 and etl_is_active = 1

GROUP BY ClientId, mobileNumber, CBAmountEL, CBExpiryDate, CBResponseId, MaxEWIAmount)

SELECT A.*, ROW_NUMBER() OVER (PARTITION BY ClientID ORDER BY CBExpiryDate DESC) AS Rankk

FROM CTE_PreApprovedProposalHO_EL AS A

WHERE ClientID NOT IN (SELECT   A.ClientId FROM CTE_PreApprovedProposalHO_EL A

JOIN {source_catalog}.{source_schema}.`pragati-PreApprovedProposal` B ON A.ClientId = B.ClientId AND A.CBResponseId = B.CBResponseId

Left JOIN {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` Cls ON B.LoanProposalId = Cls.LoanProposalId

WHERE (B.LoanProposalId IS NOT NULL OR CancelDate IS Not NULL) AND B.MaxEWIAmount > 0 AND CBAmountEL > 0  )) E

JOIN CTE_Client_CenterStatus_C F ON E.ClientID = F.ClientID WHERE Rankk = 1),

 

CTE_PreApprovedAll AS (

SELECT *,'Unnati' as ProductName FROM CTE_Unnati

UNION ALL

SELECT *,'MFI' as ProductName FROM CTE_MFI WHERE  CBAmount>11000 or  MaxEWIAmount>200

UNION ALL

SELECT * ,'Emergency Loan-01' as ProductName FROM CTE_EL

Union all

Select *,'UnnatiPls' as ProductName from CTE_Unnatipls

UNION ALL

SELECT *,'FUL' as ProductName  FROM CTE_MFI WHERE   CBAmount<11000 or  MaxEWIAmount<200),

 

final_cte AS (

SELECT

Zone,

STATE,

Region,

SOP.Area,

SOP.UMBaseLocationBranchName AS Unit,

BrID AS BRANCH_ID,  

Cm.HierarchyID,

SOP.BRANCHNAME,

CEMA.StaffId,

UM.UserName AS Staffname,

CenterMeetingDay,

CEMA.CenterCode,

CEMA.CenterName,

CM.ClientCode,

CM.TargetId,

CM.ClientName,

S.ClientID,

COALESCE(MAX(CASE WHEN ProductName = 'Unnati' THEN CBAmount END), 0) AS Unnati,

COALESCE(MAX(CASE WHEN ProductName = 'UnnatiPls' THEN CBAmount END), 0) AS UnnatiPls,

COALESCE(MAX(CASE WHEN ProductName IN ('Unnati', 'UnnatiPls') THEN CBAmount END), 0) AS Unnati_Seeries,

0 AS Sahayata,

0 AS SahayataPls,

0 AS Sahayata_Series,

0 AS SAMMAAN,

0 AS SAMMAAN_Series,

COALESCE(MAX(CASE WHEN   ProductName = 'MFI' THEN CBAmount END), 0) AS MFI_Series,

COALESCE(MAX(CASE WHEN   ProductName = 'FUL'  THEN CBAmount END), 0) AS FUL,

0 AS Samridhi,

'' AS Remarks,

'' AS MobileNumber,

CAST(current_date() AS DATE) AS Report_Date,

MAX(CASE WHEN ProductName = 'Emergency Loan-01' THEN CBAmount END) AS Emergency_Loan,

MAX(CASE WHEN ProductName = 'Unnati' THEN CBExpiryDate END) AS Unnati_CBExpireDate,

MAX(CASE WHEN ProductName = 'Unnati' THEN Create_date END) AS Unnati_PushDate,

MAX(CASE WHEN ProductName = 'Unnati' THEN MaxEWIAmount END) AS Unnati_MaxEWI,

CAST(NULL AS DATE) AS Sahayata_CBExpiredate,

CAST(NULL AS DATE) AS Samman_CBExpiredate,

MAX(CASE WHEN ProductName = 'MFI' THEN CBExpiryDate END) AS MFI_CBExpiredate,

MAX(CASE WHEN ProductName = 'MFI' THEN Create_date END) AS MFI_Pushdate,

MAX(CASE WHEN ProductName = 'MFI' THEN MaxEWIAmount END) AS MFI_MaxEWI,

CAST(NULL AS DATE) AS Samridhi_CBExpiredate,

MAX(CASE WHEN ProductName = 'Emergency Loan-01' THEN CBExpiryDate END) AS Emergency_CBExpiredate,

MAX(HHI_CBExpiredate) AS HHI_CBExpiredate,

COUNT(CASE WHEN IGL2.Clientid IS NULL THEN 1 ELSE 0 END) AS is_IGL1

FROM CTE_PreApprovedAll S

LEFT JOIN {source_catalog}.{source_schema}.`pragati-CLIENTMASTER` CM ON S.CLIENTID = CM.ClientId

LEFT JOIN {source_catalog}.{source_schema}.`pragati-GroupMaster` GM ON CM.GroupId = GM.GroupId

LEFT JOIN {source_catalog}.{source_schema}.`pragati-CenterMaster` CEMA ON GM.centerid = CEMA.centerid

LEFT JOIN {source_catalog}.{source_schema}.`pragatiMain-UserMaster` UM ON CEMA.StaffId = UM.UserId

LEFT JOIN {source_catalog}.{source_schema}.`pragati-BranchMaster` BM ON CM.HierarchyId = BM.HierarchyId

LEFT JOIN {source_catalog}.{source_schema}.`azuresource-mastersopdata` SOP ON BM.BranchCode = SOP.BrID
left join {source_catalog}.{source_schema}.`ptsmart-clientloansubscription`  IGL2 ON S.ClientID = IGL2.ClientID
LEFT JOIN (SELECT

ClientID,

CreatedDateTime,

DATEADD(DAY, 365, CreatedDateTime) AS HHI_CBExpiredate

FROM {source_catalog}.{source_schema}.`rdsp_trans-mfi_household_details`) H ON S.ClientID = H.ClientID


LEFT JOIN (

SELECT ClientId FROM {source_catalog}.{source_schema}.`pragati-LoanWeeksSummary` WHERE COALESCE(LoanWeeks, 0) = 0

UNION

SELECT ClientID FROM {source_catalog}.{source_schema}.`pragati-ClientLoanSubscription` WHERE ProductType IS NULL

UNION

SELECT ClientID FROM {source_catalog}.{source_schema}.`ptsmart-clientloansubscription` WHERE ProductType IS NULL) IGL1 ON S.ClientID = IGL1.ClientID

WHERE CM.ETL_is_Active = '1' AND CEMA.ETL_is_Active = '1' AND GM.ETL_is_Active = '1' AND UM.ETL_is_Active = '1'

GROUP BY

Zone,

STATE,

Region,

SOP.Area,

SOP.UMBaseLocationBranchName,

BrID,

SOP.BRANCHNAME,

CM.HierarchyID,

CEMA.StaffId,

UM.UserName,

CenterMeetingDay,

CEMA.CenterCode, CEMA.CenterName,CM.ClientCode, CM.TargetId, CM.ClientName,

S.ClientID)

 

SELECT * FROM final_cte ;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"preapproved_data Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on preapproved_data: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on preapproved_data : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.preapproved_data")

    logger(
            logger_level_info,
            f"preapproved_data writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table preapproved_data : {str(e)}",
        execution_log_list,
        filename
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table preapproved_data : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "preapproved_data").mode("overwrite").save()
    logger(
            logger_level_info,
            f"preapproved_data writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table preapproved_data : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table preapproved_data : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)