# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_proposal_facts_basedata.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/PROPOSAL_FACTS_BASEDATA"
    desti_path = "BFIL-MART/REPORTING/PROPOSAL_FACTS_BASEDATA"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """SELECT
    HierarchyID,
    Proposaldate,
    last_day(Proposaldate) AS ProposalMonth,
    FinalRemarks AS Remarks,
    Paymentstatus,
  
    --`Proposal Type (outside CM/With CM)`,
    Proposal_CenterConfirm,
    ProductCategory,
    CASE
        WHEN EKYCSucessDate >= Proposaldate THEN 'Yes'
        ELSE 'No'
    END AS EKYCStatus,
    CASE
        WHEN coalesce(ApprovedAmount, 0) > 0
        AND coalesce(Cancelremarks, 'a') <> 'System Cancelled while tab sync process, due to disbursed not done on same day'
        AND EKYCSucessdate >= Proposaldate THEN 'in Sim2Sync'
        ELSE 'Not in Sim2Sync'
    END AS Sim2Sync_Status,
    COUNT(1) AS NOP,
    SUM(coalesce(ApprovedAmount, 0)) AS ApprovedAmount
FROM
    {mart_catalog}.{mart_schema}.disbursement_facts
GROUP BY
    HierarchyID,
    Proposaldate,
    Remarks,
    Paymentstatus,
  --  `Proposal Type (outside CM/With CM)`,
  Proposal_CenterConfirm,
    ProductCategory,
    CASE
        WHEN EKYCSucessDate >= Proposaldate THEN 'Yes'
        ELSE 'No'
    END,
    CASE
        WHEN coalesce(ApprovedAmount, 0) > 0
        AND coalesce(Cancelremarks, 'a') <> 'System Cancelled while tab sync process, due to disbursed not done on same day'
        AND EKYCSucessdate >= Proposaldate THEN 'in Sim2Sync'
        ELSE 'Not in Sim2Sync'
    END,
    last_day(Proposaldate);
""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"proposal_facts_basedata Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on proposal_facts_basedata: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on proposal_facts_basedata : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{mart_catalog}.{mart_schema}.proposal_facts_basedata")
    

    logger(
            logger_level_info,
            f"proposal_facts_basedata writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table proposal_facts_basedata : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table proposal_facts_basedata : ", str(e))
