# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_client_igl1data_batch.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_CLIENT_IGL1DATA_BATCH"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH P_Client_IGL1Data (
SELECT B.TargetId, A.First_DisbursementDate Min_Disbdate,A.ClientID FROM
(SELECT ClientID,Min(DisbursementDate)First_DisbursementDate FROM
(Select ClientId,DisbursementDate,ClientLoanId
from  (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` WHERE ETL_IS_ACTIVE = '1')
where  ProductType is null
union
Select ClientId,DisbursementDate,ClientLoanId
from  (SELECT * FROM {source_catalog}.{source_schema}.`ptsmart-clientloansubscription` WHERE ETL_IS_ACTIVE = '1')
where  ProductType is null
union
Select CustomerId as ClientId,DisbursementDate, CustomerLoanID
from   (SELECT * FROM {source_catalog}.{source_schema}.`rlmsbizxtend-customerloandisbursement`)
where ProductType is null and ETL_IS_ACTIVE = '1')  Group by ClientID) A
JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') B
ON A.ClientID = B.ClientId)

SELECT * FROM P_Client_IGL1Data;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_p_client_igl1data_batch Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_p_client_igl1data_batch: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_client_igl1data_batch : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_client_igl1data_batch")

    logger(
            logger_level_info,
            f"nb_p_client_igl1data_batch writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_p_client_igl1data_batch : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_p_client_igl1data_batch : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()