# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_pragatilive_ftddue_summary.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/P_PRAGATILIVE_FTDDUE_SUMMARY"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH T_Vraju_BM_UM_Total_Active_Centers AS (
select b.`ZONE` as `ZONE NAME`, b.state, b.`AREA` as `AREA OFFICE`, b.Region , b.BRANCHID as BRANCH_ID, b.`BRANCHNAME` `BRANCH NAME`,
        B.UMBaseLocationBranchName UnitOffice, b.DISTRICT, b.HierarchyId , a.CenterId ,
        a.CenterCode, a.CenterName,
        a.FormationDate, (case when a.CenterMeetingDay = 1 then 'Monday' when A.CenterMeetingDay = 2 then
'Tuesday' when A.CenterMeetingDay = 3 then 'Wednesday'when
A.CenterMeetingDay = 4 then 'Thursday' else 'Friday' end)  as CenterMeetingDay, a.StaffId
    from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) a 
    left join {mart_catalog}.{mart_schema}.p_hierarchy_sop b
    on a.HierarchyId = b.HierarchyId
    where coalesce(a.DissolvedDate,'1900-01-01' )='1900-01-01' and b.`ZONE` not in ('AP','TS')),

T_Vraju_BM_UM_GivenCenters_ActiveClients AS (
select a.*, count(distinct clm.clientid) `No Of Active Clients`
    from T_Vraju_BM_UM_Total_Active_Centers a join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) cm on a.centerid = cm.centerid
        Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) gm On cm.CenterId=gm.CenterId
        Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) clm On gm.GroupId=clm.GroupId
    where coalesce(clm.DropOutDate,'1900-01-01')='1900-01-01'
    Group by a.CenterId,a.CenterCode,a.CenterName,a.FormationDate,a.CenterMeetingDay,a.HierarchyId,a.BRANCH_ID,
a.`BRANCH NAME`,
a.DISTRICT,
a.`ZONE NAME`,a.Region,a.`AREA OFFICE`,a.STATE,a.UnitOffice,a.StaffId),

T_Vraju_BM_UM_Total_Active_Groups AS (
select a.CenterId, count(GroupId)ActiveGroups
    from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) A left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) B
        ON A.CenterId=B.CenterId
    where coalesce(b.DissolvedDate,'1900-01-01' )='1900-01-01'
    group by a.CenterId),

T_Vraju_Base_Loans_Vraju AS (
select clientLoanid, HierarchyId , CODDate as LastSyncDate_COB
    from {mart_catalog}.{mart_schema}.dailyloanfacts
    where DisbursementDate >='2017-01-01'
        and Branch_Type = '1. MFI' and coalesce(LoanCLosedDate,'1900-01-01' )='1900-01-01'),


T_Vraju_Due_base1_Vraju AS (
SELECT T.ClientLoanId, T.HierarchyId
        ,sum (case when  CAST(AV.valuedate as date) <= (CAST(GETDATE() as date) -1)   then    AV.PrincipalAmount end)  `Total Due Principle`,
        sum(case when    CAST(AV.valuedate as date) <= (CAST(GETDATE() as date)-1)  then     AV.InterestAmount end)  `Total Due Interest`,
        sum(case when    CAST(AV.TransactionDate as date) >=(CAST(GETDATE() as date)+1) and CAST(AV.TransactionDate as date) <= (CAST(GETDATE() as date)+5)  then AV.PrincipalAmount end)  `week Due Principle`,
        sum(case when CAST(AV.TransactionDate as date) >=(CAST(GETDATE() as date)+1) and CAST(AV.TransactionDate as date) <= (CAST(GETDATE() as date)+5)  then AV.InterestAmount end)  `Week Due Interest`
        ,AV.TransactionType
        ,AV.DebitOrCredit
    FROM T_Vraju_Base_Loans_Vraju T
        JOIN (SELECT valuedate,PrincipalAmount,InterestAmount,TransactionDate,HierarchyId,ClientLoanId,TransactionType,DebitOrCredit from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-at_loanschedules` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)) AV ON
        Av.ClientLoanId = T.ClientLoanId and T.HierarchyId=Av.HierarchyId
    where (upper(AV.TransactionType) ='C'and upper(AV.DebitOrCredit) ='D')
    group by T.ClientLoanId,T.HierarchyId,AV.TransactionType,AV.DebitOrCredit),

T_Vraju_Due_base1_Vraju_Client_LoanBase AS (
select a.*, b.LoanClosedDate, 
    pm.ProductCode, pm.ProductName, 
    b.ClientId, 
    cl.ClientCode,
        cl.ClientName, 
        cm.CenterMeetingDay, cm.StaffId, cm.CenterId, cm.CenterCode,
         b.ExpectedPaidupDate
    from T_Vraju_Due_base1_Vraju a 
        join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) b on a.ClientLoanId = b.ClientLoanId
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) DPM on b.ProductId = DPM.DerivedProductId
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-productmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) PM on PM.ProductId = DPM.ProductId
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AS CL ON b.ClientId = CL.ClientId
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AS E ON CL.GroupId = E.GroupId
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AS CM ON E.CenterId = CM.CenterId
        ),     

T_Vraju_Due_base1_Vraju_Client_LoanBase_C AS (
select Distinct ClientId, ClientCode, ClientName, max(ExpectedPaidupDate) as ExpectedPaidupDate,
        coalesce(sum(`week Due Principle`),0) as `week Due Principle`,
        coalesce(sum(`Week Due Interest`),0) as `Week Due Interest`,
        (coalesce(sum(`week Due Principle`),0) + (coalesce(sum(`Week Due Interest`),0))) as `Total Week Due`
    from T_Vraju_Due_base1_Vraju_Client_LoanBase
    Where coalesce(LoanClosedDate,'1900-01-01')='1900-01-01'
    group by ClientId,ClientCode,ClientName),

T_Vraju_Due_base1_Vraju_Client_LoanBase_C_U AS (
Select a.*, cl.HierarchyId, cm.CenterID, cm.CenterCode, cm.CenterMeetingDay
    from T_Vraju_Due_base1_Vraju_Client_LoanBase_C a
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AS CL ON a.ClientId = CL.ClientId
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AS E ON CL.GroupId = E.GroupId
        INNER JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AS CM ON E.CenterId = CM.CenterId),

T_Vraju_Due_base1_Vraju_Client_LoanBase_C_U_F1 AS (
select a.*, b.Ageing, b.Monthend_Ageing,
        NoOfDaysInArrears as AsOn_DPD,
        Cast(0 as int) as PM_DPD,
        cast(0 as float) as FTD_Coll,
        cast('' as STRING) as FTD_Coll_Status,
        (cast(0 as int)) as Today_CM, Date_91_Days, cast(0 as int) as ExpNPA_Date, b.POS
    from T_Vraju_Due_base1_Vraju_Client_LoanBase_C_U a
        left join {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary b on a.CLientid = b.Clientid),

T_Vraju_Mithun AS (
select centerid, getdate() as Centermeetingdate, CenterMeetingDay , CenterMeetingDayTemp, DissolvedDate, StaffId
        from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)
        where coalesce(DissolvedDate,'1900-01-01')='1900-01-01'
            and CenterMeetingDay =date_part('DAYOFWEEK', CURRENT_TIMESTAMP) - 1
            and CenterMeetingDayTemp is null
    union all
        select centerid, getdate() as Centermeetingdate, CenterMeetingDay , CenterMeetingDayTemp , DissolvedDate, StaffId
        from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)
        where coalesce(DissolvedDate,'1900-01-01')='1900-01-01'
            and CenterMeetingDay <>date_part('DAYOFWEEK', CURRENT_TIMESTAMP) - 1
            and CenterMeetingDayTemp=date_part('DAYOFWEEK', CURRENT_TIMESTAMP) - 1),

T_Vraju_Due_base1_Vraju_Client_LoanBase_C_U_F AS (
SELECT A.ClientId, A.ClientCode, A.ClientName, A.ExpectedPaidupDate, A.`week Due Principle`, A.`Week Due Interest`,A.`Total Week Due`,A.HierarchyId, A.CenterID, A.CenterCode, A.CenterMeetingDay,CASE WHEN A.Ageing IS NULL THEN '[>90]' ELSE A.Ageing END Ageing,CASE WHEN A.Monthend_Ageing IS NULL THEN 'ARC_WriteOff' ELSE A.Monthend_Ageing END Monthend_Ageing,A.AsOn_DPD,CASE WHEN b.Client_DPD IS NOT NULL THEN b.Client_DPD ELSE A.PM_DPD END PM_DPD,A.FTD_Coll,A.FTD_Coll_Status,A.Today_CM, A.Date_91_Days,CASE WHEN CAST(A.Date_91_Days as date) = cast(getdate() as date) THEN 1 ELSE A.ExpNPA_Date END ExpNPA_Date, A.POS 
FROM T_Vraju_Due_base1_Vraju_Client_LoanBase_C_U_F1 A
LEFT JOIN {mart_catalog}.{mart_schema}.p_loanfacts_client B
ON a.ClientId = b.clientid),


P_PragatiLive_FTDDue AS (
SELECT A.ClientId, A.ClientCode, A.ClientName, A.ExpectedPaidupDate, A.`week Due Principle` week_Due_Principle, A.`Week Due Interest` Week_Due_Interest,A.`Total Week Due` Total_Week_Due,A.HierarchyId, A.CenterID, A.CenterCode, A.CenterMeetingDay,CASE WHEN A.ExpNPA_Date = 1 and A.Ageing = '[61 To 90]' THEN '4. [Exp NPA Tpday]' ELSE A.Ageing END AS Ageing,A.Monthend_Ageing,A.AsOn_DPD,A.PM_DPD,A.FTD_Coll,A.FTD_Coll_Status,CASE WHEN b.Centerid IS NOT NULL THEN 1 ELSE A.Today_CM END Today_CM, A.Date_91_Days,A.ExpNPA_Date, A.POS, CAST(NULL AS DECIMAL(10,4)) MTD_Due,CAST(NULL AS DECIMAL(10,4)) MTD_Due_Coll, CAST(NULL AS DECIMAL(10,4)) MTD_Gross_coll, CAST(NULL AS DECIMAL(10,4)) MTD_Total_Coll, CAST(NULL AS DECIMAL(10,4)) Month_Start_OverDue, CASE WHEN C.ClientId IS NOT NULL THEN 1 ELSE 0 END as Ops_Excl, CASE WHEN A.ExpectedPaidupDate < cast(getdate() as date) THEN 1 ELSE 0 END AS TenureExpired
FROM T_Vraju_Due_base1_Vraju_Client_LoanBase_C_U_F A
LEFT JOIN T_Vraju_Mithun B
ON a.Centerid = b.Centerid
LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary C
ON a.ClientId = C.ClientId),

p_NewMRD_Base AS
(select Clientid, Ageing
from {source_catalog}.{source_schema}.`azuresource-p_clientloanfacts`
where Ageing in ('[31 To 60]','[61 To 90]') and lower(Branch_type)='smpt')

Select a.HierarchyId,centermeetingday,a.AGeing,Monthend_Ageing,ExpNPA_Date,FTD_Coll_Status,Today_CM,
(case when Total_Week_Due > 0 then 1 else 0 end) isDue,
case when b.clientid is null  then 0 else 1 end is_MRD,
Ops_Excl,TenureExpired,
case when ason_DPD-PM_DPD > 14 then '5. ForwardFlow'
when ason_DPD-PM_DPD > 7 then '4. ForwardFlow_1wk'
when ason_DPD-PM_DPD >= 0 then '3. Maintained'
when ason_DPD-PM_DPD >= -7 then '2. BackwardFlow_1wk'
when ason_DPD-PM_DPD >= -100 then '1. BackwardFlow'
else 'Error' end Flow,
COunt(1)FTD_Due_NOC,sum(Total_Week_Due)FTD_Due_Amount,
sum(FTD_Coll)FTD_Coll, sum(case when FTD_Coll <> 0 then 1 else 0 End )NOC_COll,
sum(case when FTD_Coll <> 0 then POS else 0 End )/1e7 NOC_COll_POS,
sum(MTD_Due)MTD_Due,sum(MTD_Due_Coll)MTD_Due_Coll,sum(MTD_Gross_coll)MTD_Gross_coll,sum(MTD_Total_Coll)MTD_Total_Coll
,sum(Month_Start_OverDue)Month_Start_OverDue,sum(POS)POS
from P_PragatiLive_FTDDue a 
left join p_NewMRD_Base b on a.ClientId = b.clientid 
group by a.HierarchyId,centermeetingday,a.AGeing,FTD_Coll_Status ,Today_CM,isDue,is_MRD,
Monthend_Ageing ,ExpNPA_Date,Flow,Ops_Excl,TenureExpired;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_pragatilive_ftddue_summary Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_pragatilive_ftddue_summary: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_pragatilive_ftddue_summary : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

    logger(
            logger_level_info,
            f"p_pragatilive_ftddue_summary writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_pragatilive_ftddue_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table p_pragatilive_ftddue_summary : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)