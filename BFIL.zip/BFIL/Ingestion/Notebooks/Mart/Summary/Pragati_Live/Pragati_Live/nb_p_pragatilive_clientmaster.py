# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_pragatilive_clientmaster.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/P_PRAGATILIVE_CLIENTMASTER"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """CREATE OR REPLACE VIEW {mart_catalog}.{mart_schema}.{mart_table} AS
    Select Hierarchyid,Clientid,Clientcode,Clientname,createdby SMID,joindate, Hour(createddatetime)Hour,createddatetime,Case when substring(cast(createddatetime as timestamp),12,5) <= (SELECT substring(max(cast(ETL_CREATED_DATE as timestamp)),12,5) from {source_catalog}.{source_schema}.clientmaster_rts WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) then '1.Before' else '2.After' End TimeStatus from {source_catalog}.{source_schema}.clientmaster_rts
    where CAST(joindate as date) = CAST(getdate() as date)
union 	
Select Hierarchyid, Clientid, Clientcode, Clientname, createdby SMID, joindate, Hour(createddatetime)Hour,createddatetime,Case when substring(cast(createddatetime as timestamp),12,5) <= (SELECT substring(max(cast(ETL_CREATED_DATE as timestamp)),12,5) from {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) then '1.Before' else '2.After' End TimeStatus
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) 
where CAST(joindate as date) >= CAST(getdate() as date)- 35;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
        mart_table=mart_table,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating View
try:
    spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_pragatilive_clientmaster Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_pragatilive_clientmaster: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_pragatilive_clientmaster : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)