# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_wcr_highredalert_final4_batch.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query_targetmaster = """SELECT Hierarchyid,Targetid,targetcode,Targetname,staffid,targetdate,createddatetime,ETL_IS_ACTIVE FROM {source_catalog}.{source_schema}.`pragati-targetmaster` WHERE ETL_IS_ACTIVE = '1' AND CAST(targetdate AS date) >= CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date) - INTERVAL 35 DAY;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )

    query_clientloanproposal_h_view = """SELECT createddatetime,Hierarchyid,Loanproposalid,Loanamountapproved,clientid,Updatedby,proposaldate,TEMPDISBURSEMENTDATE,ProductId,ProductType,CancelRemarks,EKYCSucessDate,ETL_IS_ACTIVE FROM {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` WHERE ETL_IS_ACTIVE = '1';""".format(
            mart_catalog=mart_catalog,
            mart_schema=mart_schema,
            source_catalog=source_catalog,
            source_schema=source_schema,
        )

    query_clientmaster = """SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1';""".format(
            mart_catalog=mart_catalog,
            mart_schema=mart_schema,
            source_catalog=source_catalog,
            source_schema=source_schema,
        )

    query_derivedproductmaster = """SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` WHERE ETL_IS_ACTIVE = '1';""".format(
            mart_catalog=mart_catalog,
            mart_schema=mart_schema,
            source_catalog=source_catalog,
            source_schema=source_schema,
        )

    query_productmaster = """SELECT * FROM {source_catalog}.{source_schema}.`pragati-productmaster` WHERE ETL_IS_ACTIVE = '1';""".format(
            mart_catalog=mart_catalog,
            mart_schema=mart_schema,
            source_catalog=source_catalog,
            source_schema=source_schema,
        )

except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))


# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df_query_productmaster = spark.sql(query_productmaster).repartition(50).cache()
    df_query_derivedproductmaster = spark.sql(query_derivedproductmaster).repartition(50).cache()
    df_query_clientmaster = spark.sql(query_clientmaster).repartition(50).cache()
    df_query_clientloanproposal_h_view = spark.sql(query_clientloanproposal_h_view).repartition(50).cache()
    df_query_targetmaster = spark.sql(query_targetmaster).repartition(50).cache()

    logger(
        logger_level_info,
        f"nb_pragati_live_batch_daily_refresh Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_pragati_live_batch_daily_refresh: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_pragati_live_batch_daily_refresh : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df_query_productmaster.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path + "PRODUCTMASTER_PRAGATI_LIVE").saveAsTable(f"{mart_catalog}.{mart_schema}.productmaster_pragati_live")

    df_query_derivedproductmaster.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path + "DERIVEDPRODUCTMASTER_PRAGATI_LIVE").saveAsTable(f"{mart_catalog}.{mart_schema}.derivedproductmaster_pragati_live")

    df_query_clientmaster.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path + "CLIENTMASTER_PRAGATI_LIVE").saveAsTable(f"{mart_catalog}.{mart_schema}.clientmaster_pragati_live")

    df_query_clientloanproposal_h_view.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path + "CLIENTLOANPROPOSAL_H_VIEW_PRAGATI_LIVE").saveAsTable(f"{mart_catalog}.{mart_schema}.clientloanproposal_h_view_pragati_live")

    df_query_targetmaster.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path + "TARGETMASTER_PRAGATI_LIVE").saveAsTable(f"{mart_catalog}.{mart_schema}.targetmaster_pragati_live")

    logger(
            logger_level_info,
            f"nb_pragati_live_batch_daily_refresh writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_pragati_live_batch_daily_refresh : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_pragati_live_batch_daily_refresh : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df_query_targetmaster.unpersist()
df_query_clientloanproposal_h_view.unpersist()
df_query_clientmaster.unpersist()
df_query_derivedproductmaster.unpersist()
df_query_derivedproductmaster.unpersist()