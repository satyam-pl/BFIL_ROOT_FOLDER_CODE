# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_pragatilive_day_sm.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/P_PRAGATILIVE_DAY_SM"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """with CTE_P_PragatiLive_TargetMaster as (
Select Hierarchyid,Targetid,targetcode,Targetname,staffid,targetdate, hour(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'))Hour,
Case when substring(Createddatetime,11,6) <= substring(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'),11,6) then '1.Before' else '2.After' End TimeStatus
from {source_catalog}.{source_schema}.`pragati-targetmaster`  WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL
union
Select   Hierarchyid,Targetid,targetcode,Targetname,staffid,targetdate, hour(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'))Hour,
Case when substring(Createddatetime,11,6) <= substring(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'),11,6) then '1.Before' else '2.After' End TimeStatus
from {source_catalog}.{source_schema}.`pragati-targetmaster`
where targetdate >= cast(current_timestamp as date)-35  and (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) ),

CTE_P_PragatiLive_ClientMaster as(
Select Hierarchyid,Clientid,Clientcode,Clientname,createdby SMID,joindate, hour(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'))Hour,
Case when substring(Createddatetime,11,6) <= substring(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'),11,6) then '1.Before' else '2.After' End TimeStatus
from {source_catalog}.{source_schema}.`pragati-clientmaster`  WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL
union
select Hierarchyid,Clientid,Clientcode,Clientname,createdby SMID,joindate, hour(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'))Hour,
Case when substring(Createddatetime,11,6) <= substring(from_utc_timestamp(current_timestamp(),'Asia/Kolkata'),11,6) then '1.Before' else '2.After' End TimeStatus
from {source_catalog}.{source_schema}.`pragati-clientmaster`
where joindate >= cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)-35  and (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)  ),

T_StaffDbProcess as (
select a.*                 
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-tabdbstaffprocessdetails` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) a inner join                   
(select staffid, max(SEQUENCEID ) SEQUENCEID                    
from {source_catalog}.{source_schema}.`pragati-tabdbstaffprocessdetails`  WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL                         
group by   staffid) b                     
on a.STAFFID =b.STAFFID                         
and a.SEQUENCEID=b.SEQUENCEID
),

CTE_P_PragatiLive_Day_SM AS (
Select HIERARCHYID,STAFFID ,1 as Cnt,cast('Acive Staff' as Varchar(200))as Type1, 0 as Target1,0 as Achive     ,'AAAAAAAAAAAAAA' CNt_Category
from T_StaffDBProcess ----- table needs to be changed
Group by HIERARCHYID,STAFFID
union
Select HIERARCHYID,SMID as StaffID,Count(ClientID) as Cnt,cast('MA' as Varchar(200))as Type1,0 as Target1,0 as Achive  ,'AAAAAAAAAAAAAA' CNt_Category
from CTE_P_PragatiLive_ClientMaster where Joindate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)
Group by HIERARCHYID,SMID
union
Select HIERARCHYID,Staffid as StaffID,Count(TargetID) as Cnt, 'TD' as Type1 ,0 as Target1,0 as Achive    ,'AAAAAAAAAAAAAA' CNt_Category
from CTE_P_PragatiLive_TargetMaster where TargetDate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)
Group by HIERARCHYID,Staffid
union
Select HIERARCHYID, Updatedby  as StaffID,Count(LoanProposalID)Cnt,  'MFI/Unnati-NOL' as Type1 ,0 as Target1,0 as Achive ,'AAAAAAAAAAAAAA' CNt_Category
from {mart_catalog}.{mart_schema}.p_pragatilive_hourly_proposal where ProposalDate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date) and  ProductCode in('15','800')
Group by HIERARCHYID, Updatedby
union
Select HIERARCHYID,Updatedby  as StaffID,Count(LoanProposalID)Cnt,  'CDF-NOL' as Type1 ,0 as Target1,0 as Achive ,'AAAAAAAAAAAAAA' CNt_Category
from {mart_catalog}.{mart_schema}.p_pragatilive_hourly_proposal where ProposalDate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date) and  ProductCode not in('15','800')
Group by HIERARCHYID,Updatedby
union
Select HIERARCHYID,Staffid as StaffID,Sum(Account_count) as Cnt , 'RD/RD' as Type1,0 as Target1,0 as Achive,'AAAAAAAAAAAAAA' CNt_Category
from {mart_catalog}.{mart_schema}.P_PragatiLive_AccountOpenData where AccountType in('RD','FD')
Group by HIERARCHYID,Staffid),

 CTE_activeStaff as (

    Select distinct HIERARCHYID,Staffid from CTE_P_PragatiLive_Day_SM
),

 cte_P_PragatiLive_Day_SM_Dup as (

select a.HIERARCHYID,a.STAFFID,0 CNt,'MFI/Unnati-NOL'Type1, 0 Target1,0 Achive, 'AAAAAAAAAAAAAA' CNt_Category
from CTE_activeStaff a left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'MFI/Unnati-NOL'
where b.staffid is null
Union
Select a.HIERARCHYID,a.STAFFID,0 CNt,'MA'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'MA'
where b.staffid is null
union
Select a.HIERARCHYID,a.STAFFID,0 CNt,'CDF-NOL'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'CDF-NOL'
where b.staffid is null
Union
Select a.HIERARCHYID,a.STAFFID,0 CNt,'RD/RD'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a
 left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'RD/RD'
where b.staffid is null
 union
Select a.HIERARCHYID,a.STAFFID,0 CNt,'TD'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a
left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'TD'
),

CTE_P_PragatiLive_combined as (

    select * from CTE_P_PragatiLive_Day_SM
    union all
    select * from cte_P_PragatiLive_Day_SM_Dup
)

select HIERARCHYID,STAFFID,CNt,Type1,
case when Type1='MA'   then  2
when Type1='RD/RD'            then  2
when Type1='CDF-NOL'          then  1
when Type1='MFI/Unnati-NOL'   then  5 else 0 end as Target1,
case when Type1='MA'        and Cnt>=Target1 then  1
when Type1='RD/RD'          and Cnt>=Target1 then  1
when Type1='CDF-NOL'        and Cnt>=Target1 then  1
when Type1='MFI/Unnati-NOL' and Cnt>=Target1 then  1 else 0 end as Achive,
case when cast(Cnt as INT) >= CAST(Target1 as INT) then concat(cast(Target1 as string), ' & More') else cast(cnt as string) end  as CNt_Category
From CTE_P_PragatiLive_combined;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_pragatilive_day_sm Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_pragatilive_day_sm: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_pragatilive_day_sm : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

    logger(
            logger_level_info,
            f"p_pragatilive_day_sm writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_pragatilive_day_sm : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table p_pragatilive_day_sm : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)