# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_bcm_pending.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/P_PRAGATILIVE_BCM_PENDING"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """select * from
(with CTE_PLD_cashlessdisbursements as (
    Select loanproposalid
from {source_catalog}.{source_schema}.`cashlessdisburs-cl_cashlessdisbursements`
where CAST(createddatetime as date) >= cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)-2 and ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL
),

 cte_PLD_BCM_Pending as(
select Hierarchyid,Clientid,LoanProposalid,ApprovedAmount LoanAmountApproved,PaymentStatus,Proposaldate   ,productcode
from {mart_catalog}.{mart_schema}.disbursement_facts
where  lower(paymentstatus) = 'bcm_pending' and productcode in (15,800,1100)
),

cte_bcm_pending as
(
Select Hierarchyid,Clientid,LoanProposalid,LoanAmountApproved,PaymentStatus,Proposaldate,productcode from cte_PLD_BCM_Pending
union
Select Hierarchyid,Clientid,LoanProposalid,LoanAmountApproved,'BCM_Pending' PaymentStatus,Proposaldate,productcode
from  {mart_catalog}.{mart_schema}.p_pragatilive_hourly_proposal
where  Proposaldate >= cast(from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')  as date) - 12 and productcode in (15,800,1100)
),

CTE_BCM_Pending_2 as (
select
a.Hierarchyid,a.Clientid,a.LoanProposalid,LoanAmountApproved,
(case when b.loanproposalid is not null or c.loanproposalid is not null then 'Approved' else paymentstatus end) as paymentstatus,
Proposaldate,productcode
from cte_bcm_pending a
left join CTE_PLD_cashlessdisbursements b on a.loanproposalid = b.loanproposalid
left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-cashlessdisbursements` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) c on a.loanproposalid = c.loanproposalid)

select hierarchyid,proposaldate,paymentstatus,sum(loanamountapproved)loanamountapproved,count(1)NOP ,case when productcode = '1100' then 1 else 0 end is_EL
from CTE_BCM_Pending_2 a
where lower(paymentstatus) = 'bcm_pending' and proposaldate >= cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)  - 12
group by hierarchyid,paymentstatus,proposaldate,case when productcode = '1100' then 1 else 0 end);""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"bcm_pending Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on bcm_pending: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on bcm_pending : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

    logger(
            logger_level_info,
            f"bcm_pending writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table bcm_pending : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table bcm_pending : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)