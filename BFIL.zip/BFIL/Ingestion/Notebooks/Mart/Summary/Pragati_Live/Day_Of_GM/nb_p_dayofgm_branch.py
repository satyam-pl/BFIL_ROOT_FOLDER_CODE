# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_dayofgm_branch.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/P_DAYOFGM_BRANCH"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH P_Veer_ClientAttendanceView  AS (
SELECT CreatedBy, HierarchyId, CenterId, AttendanceDate
FROM {source_catalog}.{source_schema}.`pragati-clientattendance`
where cast(AttendanceDate as date) >= cast(GETDATE() as date) - 3  and (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) ),

T_Veer_StaffShift_Check_1 AS (
SELECT SBH_State as  `SBH State`, Zone as ZoneName, Region, Area, BranchID, BranchName, a.StaffID,
    StaffName, a.CenterId as CenterId, b.CenterName,
    CenterStatus, Months, b.HierarchyId, b.DissolvedDate, b.StaffID as StaffID_New,
    cast(null as varchar(10) ) StaffID_Moved, cast(null as Date) StaffID_MovedDate
from (SELECT * FROM {source_catalog}.{source_schema}.`azureexcel-staffshift_check_may24` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) a
    inner join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) b on a.CenterID=b.CenterID),


_ClientAttendanceView_ AS (
select b.CenterId, b.StaffID, dateadd(mm,datediff(mm,'',AttendanceDate),'') as Month,
    AttendanceDate, CreatedBy, DENSE_RANK() over(partition by b.CenterId order by AttendanceDate) as RanksAll,
    DENSE_RANK() over(partition by b.CenterId,date_add(MONTH,date_diff(MONTH,'',AttendanceDate),'') order by AttendanceDate) as Ranks,concat('Staff',CAST((DENSE_RANK() over(partition by b.CenterId,date_add(MONTH,date_diff(MONTH,'',AttendanceDate),'') order by AttendanceDate)) as STRING),'_',
concat(date_format(CAST(AttendanceDate as date), 'MMM'), date_format(CAST(AttendanceDate as date), 'yy')))
from P_Veer_ClientAttendanceView  a inner join T_Veer_StaffShift_Check_1 b on a.CenterId=b.CenterId
where AttendanceDate >=cast(GETDATE() as date) -185),


`T_Veer_#_ClientAttendanceView_` AS (
select a.*
from _ClientAttendanceView_ a inner join (
SELECT CenterId, max(RanksAll) as RanksAll
    FROM _ClientAttendanceView_
    where StaffID<>CreatedBy
    group by CenterId) b
    on a.CenterId=b.CenterId and a.RanksAll=b.RanksAll),

T_Veer_StaffShift_Check_ AS (
SELECT
    A.`SBH State`,A.ZoneName, A.Region, A.Area, A.BranchID, A.BranchName, A.StaffID,
    A.StaffName, A.CenterId, A.CenterName,A.CenterStatus, A.Months, A.HierarchyId, A.DissolvedDate, A.StaffID_New,
    CASE WHEN b.CenterId IS NOT NULL THEN B.CreatedBy ELSE A.StaffID_Moved END StaffID_Moved,
    CASE WHEN b.CenterId IS NOT NULL THEN B.AttendanceDate ELSE A.StaffID_MovedDate END StaffID_MovedDate
FROM T_Veer_StaffShift_Check_1 A
LEFT JOIN  `T_Veer_#_ClientAttendanceView_` B
ON a.CenterId=b.CenterId),

T_Veer_StaffShift_Check_f AS (
SELECT `SBH State`, ZoneName, Region, Area, BranchID, BranchName, StaffID, StaffName, CenterId, CenterName, CenterStatus, Months,
    HierarchyId, DissolvedDate, StaffID_New as Staff_21stDec23,
    (Case when StaffID_New=StaffID then 'True' else 'False' end) as Check, StaffID_Moved, StaffID_MovedDate,
    (case when Months>6 then 1 when Months<=6 then 0 else 2 end)Rotation
FROM T_Veer_StaffShift_Check_
order by `SBH State`,ZoneName, Region, Area, BranchID, BranchName, StaffID, StaffName, CenterId),

P_Veer_StaffShift_Check_f AS (
Select BranchID, Count(CenterID) Cnt,
    Count(case when Rotation=1 then CenterID end)R_Cnt ,
    CASE 
        WHEN (R_Cnt*1.00/Cnt*1.00)*100 <=0 THEN '1.Green'
        WHEN (R_Cnt*1.00/Cnt*1.00) *100 <=5 THEN '2.Amber'
        WHEN (R_Cnt*1.00/Cnt*1.00)*100 >5 THEN '3.Red'
        ELSE '' 
    END `Center Rotation`
from T_Veer_StaffShift_Check_f
Group by BranchID),


T_nar_StaffConductedCenters AS (
select distinct A.HierarchyId, CenterId, CreatedBy, AttendanceDate
    from {source_catalog}.{source_schema}.`pragati-clientattendance` A
    where AttendanceDate between '2024-04-26' and '2024-05-10' and (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)),

T_nar_StaffConductedCenters_1 AS (
select A.HierarchyId, AttendanceDate CenterMeetingDate, B.BRANCHID, B.BRANCHNAME, A.CreatedBy StaffID, C.UserName,COUNT(distinct CenterId) NoofCentersCondected
from T_nar_StaffConductedCenters A
    join {mart_catalog}.{mart_schema}.p_hierarchy_sop B on A.HierarchyId=B.HierarchyId
    Left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-usermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) C on A.CreatedBy=C.UserId
group by A.HierarchyId,AttendanceDate,B.BRANCHID,BRANCHNAME,A.CreatedBy,C.UserName),

T_Veer_asonStaff AS (
Select A.HierarchyId, B.BRANCH_ID, Wrk_Days , AsonWrk_Days, Pending_WrkDays ,
    Count(distinct StaffId)Staff_Cnt
from T_nar_StaffConductedCenters_1 a
    JOin {source_catalog}.{source_schema}.`azuresource-t_veer_hierarchy_sop`  B on A.HierarchyId=B.HierarchyId
    left JOin (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-usermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) U on A.StaffID=U.UserId
    left JOin (SELECT * FROM {source_catalog}.{source_schema}.`pragati-codevalue` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) C on U.DesignationId=C.Code
where   upper(Value)='SANGAM MANAGER'
Group by A.HierarchyId,B.BRANCH_ID,Wrk_Days ,AsonWrk_Days, Pending_WrkDays),

T_Veer_PBI_MTD_DisData_PT AS (
Select a. HierarchyId, sop.BRANCHID BRANCH_ID,sop.BRANCHNAME,sop.ZONE,sop.STATE,sop.Region,sop.AREA,sop.UMBaseLocationBranchName Unit,
    Count(case when ProductCode in('15','800','1100')  then A.ClientLoanID end )Core_Loans_MTD_PT ,
    Count(case when ProductCode not in('15','800','1100')  then A.ClientLoanID end )MTD_Xsale_NOL
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) a
    inner join (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) b on a.ProductId=b.DerivedProductId
    inner join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-productmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) c on b.ProductId=c.ProductId
    Inner Join {mart_catalog}.{mart_schema}.p_hierarchy_sop sop on a.HierarchyId=sop.HierarchyId
where coalesce(DeviationCancelledDate,LOANCANCELLEDDATE) is null and CAST(DisbursementDate as date)>=CAST(DATE_FORMAT(CURRENT_DATE(), 'yyyy-MM-01') as date) and c.ProductCode<>'99'
Group by a.HierarchyId,BRANCH_ID,sop.BRANCHNAME,sop.ZONE,sop.STATE,sop.Region,sop.AREA,sop.UMBaseLocationBranchName),

T_Veer_PBI_MTD_ClientAddition AS (
Select a.HierarchyId, sop.BRANCHID BRANCH_ID, Count(ClientId)Total_NOC
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) a
    Inner Join {mart_catalog}.{mart_schema}.p_hierarchy_sop sop on a.HierarchyId=sop.HierarchyId
where JoinDate>= CAST(DATE_FORMAT(CURRENT_DATE(), 'yyyy-MM-01') as date)
Group by a.HierarchyId,BRANCH_ID),

T_Veer_PBI_MTD_Fin AS (
Select Coalesce( A.HierarchyId,B.HierarchyId)HierarchyId,
    Coalesce(A.BRANCH_ID,B.BRANCH_ID)BRANCH_ID,a.BRANCHNAME,a.ZONE,a.STATE,a.Region,a.AREA,a.Unit,
    a.Core_Loans_MTD_PT, A.MTD_Xsale_NOL, Total_NOC, CASE WHEN FD_Acocunts.HierarchyID IS NOT NULL THEN FD_Acocunts.MTD_FDAccnts ELSE 0 END MTD_FDAccnts, CASE WHEN RD_Acocunts.HierarchyID IS NOT NULL THEN RD_Acocunts.MTD_RDActivated ELSE 0 END MTD_RDActivated
from T_Veer_PBI_MTD_DisData_PT  a
full JOin T_Veer_PBI_MTD_ClientAddition b on a.HierarchyId=b.HierarchyId
LEFT JOIN (select  C.HierarchyID,
        date_format(B.RDStartDate,'MMM-yyyy') As MonthName,
        Count(Distinct A.RDAccountNumber) As MTD_RDActivated
From {mart_catalog}.{mart_schema}.rd_disbursementbase_fact As A
Join {mart_catalog}.{mart_schema}.liablilty_fact_bfil As B On B.RDAccountNumber = A.RDAccountNumber and B.RDLoanID = A.RDLoanID
Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) As C On C.ClientID = A.ClientID
Where (Cast(B.RDStartDate As Date) Between date_format(trunc(current_date(), 'month'), 'yyyy-MM-dd') and date_format(last_day(current_date()), 'yyyy-MM-dd'))
Group By  C.HierarchyID,date_format(B.RDStartDate,'MMM-yyyy')) RD_Acocunts 
ON RD_Acocunts.HierarchyID = a.HierarchyId
LEFT JOIN (Select  BFIL_HierarchyID As HierarchyID,
        date_format(AccountOpenDate,'MMM-yyyy') As MonthName,
        Count(AccountNumber) As MTD_FDAccnts
From {mart_catalog}.{mart_schema}.firewallaccountfacts
Where Upper(AccountType) ='FD'
and (Cast(AccountOpenDate As Date) Between date_format(trunc(current_date(), 'month'), 'yyyy-MM-dd') and date_format(last_day(current_date()), 'yyyy-MM-dd'))
Group By BFIL_HierarchyID,date_format(AccountOpenDate,'MMM-yyyy')) FD_Acocunts
ON FD_Acocunts.HierarchyID = a.HierarchyId
),

P_DayOfGM_Branch AS (
SELECT A.*,
    (case when coalesce(Staff_Cnt,0)>=coalesce(Manpower_Final,0) then Staff_Cnt else Manpower_Final end)StaffBase_Cnt,
    CASE 
        WHEN (coalesce(Core_Loans_MTD_PT,0)*1.00/StaffBase_Cnt*1.00)>=5 THEN '1.Green' 
        WHEN (coalesce(Core_Loans_MTD_PT,0)*1.00/StaffBase_Cnt*1.00)>=4 THEN '2.Amber' 
        WHEN (coalesce(Core_Loans_MTD_PT,0)*1.00/StaffBase_Cnt*1.00)<=3 THEN '3.Red'
    END `NOL/SM`,
    CASE 
        WHEN (coalesce(Total_NOC*1.00,0)/StaffBase_Cnt*1.00)>=2 THEN '1.Green' 
        WHEN (coalesce(Total_NOC*1.00,0)/StaffBase_Cnt*1.00)>=1.25  THEN '2.Amber' 
        WHEN (coalesce(Total_NOC*1.00,0)/StaffBase_Cnt*1.00)< 1.25  THEN '3.Red'
    END `MA/SM`,
    CASE 
        WHEN (coalesce(MTD_FDAccnts*1.00,0)/StaffBase_Cnt*1.00)>=1 THEN '1.Green' 
        WHEN (coalesce(MTD_FDAccnts*1.00,0)/StaffBase_Cnt*1.00)>=0.75 THEN '2.Amber' 
        WHEN (coalesce(MTD_FDAccnts*1.00,0)/StaffBase_Cnt*1.00)< 0.75 THEN '3.Red'
    END `FD/SM`,
    CASE 
        WHEN (coalesce(MTD_RDActivated,0)*1.00/StaffBase_Cnt*1.00)>=1 THEN '1.Green' 
        WHEN (coalesce(MTD_RDActivated,0)*1.00/StaffBase_Cnt*1.00)>=0.75   THEN '2.Amber' 
        WHEN (coalesce(MTD_RDActivated,0)*1.00/StaffBase_Cnt*1.00)< 0.75  THEN '3.Red'
    END `RD/SM`,
    CASE 
        WHEN (coalesce(MTD_Xsale_NOL,0)*1.00/StaffBase_Cnt*1.00)>=1 THEN '1.Green' 
        WHEN (coalesce(MTD_Xsale_NOL,0)*1.00/StaffBase_Cnt*1.00)>=0.75 THEN '2.Amber' 
        WHEN (coalesce(MTD_Xsale_NOL,0)*1.00/StaffBase_Cnt*1.00)< 0.75  THEN '3.Red'
    END `CDF/SM`,
    cast('' as STRING)as `CE Net`, 
    cast('' as STRING)as `30 90 Res`, 
    cast('' as STRING)as `90 Res`,
    CASE
        WHEN (Staff_Cnt*1.00/Manpower_Final*1.00)*100 >=100 THEN '1.Green'
        WHEN (Staff_Cnt*1.00/Manpower_Final*1.00)*100 >= 90 and (Staff_Cnt*1.00/Manpower_Final*1.00)*100 < 100 THEN '2.Amber'
        WHEN (Staff_Cnt*1.00/Manpower_Final*1.00)*100 <90 THEN '3.Red'
    END `Actual Vs Capacity`, 
    cast('' as STRING)as `Tab DB`, 
    cast('' as STRING)as `SM Avg Inc`, 
    cast('' as STRING)as `BM Inc`,
    Manpower_Final,
    Getdate() as Report_Date
FROM T_Veer_PBI_MTD_Fin A
    Full JOin {source_catalog}.{source_schema}.`azureexcel-p_dayofgm_branch_stafftarget_1` B on A.Branch_ID=B.BranchID
    full JOin T_Veer_asonStaff C on A.Branch_ID=C.Branch_ID),

P_Veer_B_Resolution_Dashboard AS (
Select *
from {mart_catalog}.{mart_schema}.bucket_resolution),

P_Veer_Coll_Dashboard AS (
Select New_Hierarchyid , BranchID, (coalesce(Current_MTD_DueCr,0)+coalesce(`1-30_Mtd_Duecr`,0)+coalesce(`31-60_Mtd_Duecr`,0)+coalesce(`61-90_Mtd_Duecr`,0)) as `0-90 Due`,
    (coalesce(Current_MTD_Due_CollCr,0)+coalesce(`1-30_Mtd_Due_Collcr`,0)+coalesce(`31-60_Mtd_Due_Collcr`,0)+coalesce(`61-90_Mtd_Due_Collcr`,0)) as `0-90 Due_Coll`,
    (coalesce(`31-60_Mtd_Exp_Flow_Poscr`,0)+coalesce(`61-90_Mtd_Exp_Flow_Poscr`,0)) as `30-90 MTD ExpFlow`,
    (coalesce(`31-60_Mtd_Exp_Flow_Poscr`,0)+coalesce(`61-90_Mtd_Exp_Flow_Poscr`,0)) - (coalesce(`61-90_Forwardflow_Poscr`,0)+coalesce(`31-60_Forwardflow_Poscr`,0)) as `30-90 Resolution`,
    `>90_Mtd_Collcr`*10000000 as `>90_Mtd_Coll`
from P_Veer_B_Resolution_Dashboard),

P_Veer_Coll_Dashboard_F AS (
Select *, 
  cast((nullif(`0-90 Due_Coll`,0)/nullif(`0-90 Due`,0))*100 as decimal(10,2)) `CE%`,
  cast((nullif(`30-90 Resolution`,0)/nullif(`30-90 MTD ExpFlow`,0))*100 as  decimal(10,2))`30-90 Res%`,
  `>90_Mtd_Coll` as `90 Recovery`,
  CASE 
      WHEN `CE%`>=99.75 THEN '1.Green'
      WHEN (`CE%` >= 99.5 and `CE%` <= 99.74) THEN '2.Amber'
      WHEN `CE%` <99.5 THEN '3.Red'
  END `CE Net`,
  CASE 
      WHEN `30-90 Res%`>70 THEN '1.Green'
      WHEN (`30-90 Res%` >= 70 and `30-90 Res%` <= 60) THEN '2.Amber'
      WHEN `30-90 Res%` <60 THEN '3.Red'
  END `30-90 Res`,
  CASE 
      WHEN `90 Recovery`>700000 THEN '1.Green'
      WHEN (`90 Recovery` >= 700000 and `90 Recovery` <= 400000) THEN '2.Amber'
      WHEN `30-90 Res%` <400000  THEN '3.Red'
  END `90 Recov`
from P_Veer_Coll_Dashboard),

P_Veer_Incentive_SM_BM_F AS (
Select A.*, (case when coalesce(SM_Cnt,0)>=coalesce(Manpower_Final,0) then SM_Cnt  else Manpower_Final end)StaffBase_Cnt,
    (SM_Inc_Amt/StaffBase_Cnt) as SM_Avg_AMt,
    Nullif(BM_Inc_AMt,0) /nullif(SM_Avg_AMt,0) `BM Inc`,
    CASE 
        WHEN round(SM_Avg_AMt,0)>=13000 THEN '1.Green'
        WHEN (round(SM_Avg_AMt,0)  between 10000 and 12999) THEN '2.Amber'
        WHEN round(SM_Avg_AMt,0)<10000 THEN '3.Red'
    END `SM Avg Incen`,
    CASE
        WHEN `BM Inc`>=2 THEN '1.Green'
        WHEN (`BM Inc` between 1.5 and 1.99) THEN '2.Amber'
        WHEN `BM Inc`<1.5 THEN '3.Red'
    END `BM Avg Incen`
from {source_catalog}.{source_schema}.`azureexcel-p_veer_incentive_sm_bm` a
    JOin P_DayOfGM_Branch B on A.Branch_ID=B.Branch_ID),

T_Veer_StaffDbProcess AS (
select a.*
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-tabdbstaffprocessdetails` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) a inner join
    (select staffid, max(SEQUENCEID) SEQUENCEID
    from {source_catalog}.{source_schema}.`pragati-tabdbstaffprocessdetails`
    where cast(TRANSACTIONDATE as date) <=cast(Getdate() as date) - 1  AND (ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) group by staffid) b
    on a.STAFFID =b.STAFFID and a.SEQUENCEID=b.SEQUENCEID
where cast(TRANSACTIONDATE as date) <=cast(Getdate() as date) - 1),

P_Veer_StaffDbProcess_Fin AS (
Select BRANCHID as Branchid , A.HierarchyId, max(DownloadedDatetime)DownloadedDatetime ,
    count(case when DownloadedDatetime<=cast(Getdate() as date) then STAFFID end)DB_DownLoad_Staff
from T_Veer_StaffDbProcess A
    JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop Sop on A.HIERARCHYID=Sop.HierarchyId
Group by   BRANCHID ,A.HierarchyId),

P_Veer_StaffDbProcess_1 AS (
Select A.HierarchyId, BRANCH_ID, (Staff_Cnt*AsonWrk_Days)DB_DownLoand_Actual ,
    Sum(DB_DownLoad_Staff)DB_DownLoad_StaffCnt, 
    CASE
        WHEN (DB_DownLoad_StaffCnt*1.00/DB_DownLoand_Actual*1.00)*100  >=100 THEN '1.Green'
        WHEN (DB_DownLoad_StaffCnt*1.00/DB_DownLoand_Actual*1.00)*100  >= 90
            and (DB_DownLoad_StaffCnt*1.00/DB_DownLoand_Actual*1.00)*100 < 100 THEN '2.Amber'
        WHEN (DB_DownLoad_StaffCnt*1.00/DB_DownLoand_Actual*1.00)*100   <90 THEN '3.Red'
        ELSE ''
    END `Tab DB Download`
from T_Veer_asonStaff a
    Join P_Veer_StaffDbProcess_Fin B on A.HierarchyId=B.HierarchyId
Group by  A.HierarchyId,BRANCH_ID,(Staff_Cnt*AsonWrk_Days)),

P_Veer_BM_Monitoring AS (
SeleCt BranchID, Count(distinct CenterID)Monitoring_Cnt,
CASE
    WHEN Monitoring_Cnt>=50 THEN '1.Green'
    WHEN (Monitoring_Cnt between 40 and 49) THEN '2.Amber'
    WHEN Monitoring_Cnt<40 THEN '3.Red'
END `BM Monitoring`
from {source_catalog}.{source_schema}.`azuresource-tum1_centermeeting` 
where (Venddate between '2024-01-01' and  cast(Getdate() as date) - 1) and upper(MonitorBy)='BM'
Group by BranchID),

P_Veer_Branch_Audit_Grading_F AS (
Select *,
    CASE
        WHEN upper(`Nov_23`)='A' THEN '1.Green'
        WHEN upper(`Nov_23`)='B' THEN '2.Amber'
        WHEN upper(`Nov_23`) in('C' ,'D') THEN '3.Red'
    END `Audit Grad`
from {source_catalog}.{source_schema}.`azureexcel-p_veer_branch_audit_grading`), 

P_DayOfGM_Branch_1 AS (
Select distinct B.BranchID as  Branch_ID,CASE WHEN coalesce(`NOL/SM`,'')='' OR `NOL/SM` = '' THEN '4.Non Starter' ELSE `NOL/SM` END Indicative_Scale , cast('1.NOL/SM'  as STRING)Type1, getdate() as Report_Date,BRANCH_Type
    from P_DayOfGM_Branch a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'

Union
    Select B.BranchID as Branch_ID, `MA/SM` Indicative_Scale, '2.MA/SM' Type1, getdate()  as Report_Date,BRANCH_Type
    from P_DayOfGM_Branch    a
        right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `FD/SM` Indicative_Scale, '3.FD/SM' Type1, getdate()  as Report_Date,BRANCH_Type
    from P_DayOfGM_Branch     a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `RD/SM` Indicative_Scale, '4.RD/SM' Type1, getdate()  as Report_Date,BRANCH_Type
    from P_DayOfGM_Branch    a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `CDF/SM` Indicative_Scale, '5.CDF/SM' Type1, getdate()  as Report_Date,BRANCH_Type
    from P_DayOfGM_Branch    a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as  Branch_ID, `CE Net` Indicative_Scale, '1.CE Net' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_Coll_Dashboard_F    a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BranchID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as  Branch_ID, `30-90 Res` Indicative_Scale, '2.30-90 Resolution' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_Coll_Dashboard_F    a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BranchID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as  Branch_ID, `90 Recov` Indicative_Scale, '3.90 Recovery' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_Coll_Dashboard_F    a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BranchID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `Actual Vs Capacity` Indicative_Scale, '1.Actual Vs Capacity' Type1, getdate() as Report_Date,BRANCH_Type
    from P_DayOfGM_Branch    a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `Tab DB Download` Indicative_Scale, '2.TAB DB Download' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_StaffDbProcess_1 a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `SM Avg Incen` Indicative_Scale, '3.SM Avg Incentive' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_Incentive_SM_BM_F A right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `BM Avg Incen` Indicative_Scale, '4.BM Incentive' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_Incentive_SM_BM_F A right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCH_ID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `BM Monitoring` Indicative_Scale, '1.BM Monitoring' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_BM_Monitoring     a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BranchID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID, `Center Rotation` Indicative_Scale, '2.Center Rotation' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_StaffShift_Check_f     a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.BRANCHID=B.BranchID
    where BRANCH_Type='MFI'
Union
    Select B.BranchID as Branch_ID , `Audit Grad` Indicative_Scale, '3.Audit Grading' Type1, getdate() as Report_Date,BRANCH_Type
    from P_Veer_Branch_Audit_Grading_F     a right JOin {mart_catalog}.{mart_schema}.p_hierarchy_sop  b on A.Branch_ID =B.BranchID
    where upper(BRANCH_Type)='MFI'
    )

SELECT * FROM P_DayOfGM_Branch_1;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"day_of_gm Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on day_of_gm: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on day_of_gm : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

    logger(
            logger_level_info,
            f"day_of_gm writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table day_of_gm : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table day_of_gm : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)