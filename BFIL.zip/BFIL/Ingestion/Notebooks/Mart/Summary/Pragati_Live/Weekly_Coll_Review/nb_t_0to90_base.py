# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_t_0to90_base.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    desti_path = "BFIL-MART/REPORTING/T_0TO90_BASE"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH T_bal_clients AS
(select distinct clientid,
    (case when ALL_Client_DPD='0' then 'Current1'
when ALL_Client_DPD between '1' and '7'   then '[01-07]'
when ALL_Client_DPD between '8' and '14'  then '[08-14]'
when ALL_Client_DPD between '15' and '21' then '[15-21]'
when ALL_Client_DPD between '22' and '30' then '[22-30]'
when ALL_Client_DPD between '31' and '40' then '[31-40]'
when ALL_Client_DPD between '41' and '50' then '[41-50]'
when ALL_Client_DPD between '51' and '60' then '[51-60]'
when ALL_Client_DPD between '61' and '70' then '[61-70]'
when ALL_Client_DPD between '71' and '80' then '[71-80]'
when ALL_Client_DPD between '81' and '90' then '[81-90]'end) as Client_Ageing
  from {mart_catalog}.{mart_schema}.dailyloanfacts_weekly
where (ALL_Client_ageing in ('Current1','[1 To 30]','[31 To 60]','[61 To 90]')) and NPA_Date is null and DeathDate is null and upper(Branch_Type)='MFI'),

T_bal_28to90_Base AS (
select Clientid, ClientLoanId, HierarchyId, DisbursementDate, LoanAmountDisbursed,
    NoOfDaysInArrears1 NoOfDaysInArrears, PrINcipalINArears, INterestINArears, EWI, CenterId,
    Expected_NPA_date as ExpNpa_date_LW, ALL_Client_ageing as ALL_Client_ageing_LW, pos as  Pos_PM, clientNpastatus, ALL_Client_ageing as Ageing ,
    (case
when NoOfDaysInArrears1=0  then '[00-00]'
when NoOfDaysInArrears1 between '1' and '30' then '[01-30]'
when NoOfDaysInArrears1 between '31' and '40' then '[31-40]'
when NoOfDaysInArrears1 between '41' and '50' then '[41-50]'
when NoOfDaysInArrears1 between '51' and '60' then '[51-60]'
when NoOfDaysInArrears1 between '61' and '70' then '[61-70]'
when NoOfDaysInArrears1 between '71' and '80' then '[71-80]'
when NoOfDaysInArrears1 between '81' and '90' then '[81-90]'
when NoOfDaysInArrears1>90  then '[Writeoff-Arc]'
end  ) as Loan_Ageing
  from {mart_catalog}.{mart_schema}.dailyloanfacts_weekly
  where ClientId in (select ClientId
    from T_bal_clients) and POS>0 and
    (ALL_Client_ageing in ('Current1','[1 To 30]','[31 To 60]','[61 To 90]'))),

t_bal_0to90_base_weekly AS (
SELECT A.*,CASE WHEN B.clientid IS NOT NULL THEN B.Client_Ageing ELSE NULL END Client_Ageing
FROM T_bal_28to90_Base A
LEFT JOIN T_bal_clients B
ON A.Clientid = B.clientid),	
	
T_bal_28to90_Base1 AS (
select 
  A.*,
  b.week_Due_Principle,
  b.Week_Due_Interest,
  b.Total_Due_Principle,
  b.Total_Due_Interest,
  CASE WHEN coalesce(b.week_Due_Principle,0)+coalesce(b.Week_Due_Interest,0) = 0 THEN A.EWI ELSE coalesce(b.week_Due_Principle,0)+coalesce(b.Week_Due_Interest,0) END Week_Total_Due,
  C.CenterMeetingDay
from t_bal_0to90_base_weekly A
LEFT JOIN {mart_catalog}.{mart_schema}.T_Vraju_Due_base1_Vraju B
ON A.ClientLoanId = B.ClientLoanId
left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1') C
ON C.CenterId = A.CenterId),

T_bal_28to90_Collections AS (
select b.*
  from T_bal_28to90_Base1 a
    join (SELECT * FROM {mart_catalog}.{mart_schema}.at_loantransactions_vw) b on a.HierarchyId=b.Hierarchyid and a.ClientId=b.clientid and a.ClientLoanId=b.clientloanid
    where lower(b.transactiontype)='c'
    and lower(b.debitorcredit)='c'
    and (b.valuedate between DATE_SUB(CURRENT_DATE(), DAYOFWEEK(CURRENT_DATE()) - 1) and CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date) - 1)
    and Amount<>0),

T_bal_28to90_Collections1 AS (
select ClientLoanId, sum(Amount) as Coll
  from T_bal_28to90_Collections
  group by ClientLoanId),

t2 AS (
  select CenterId, MAX(centermeetingdate) Max_Cmdate
  from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermeetinglog` WHERE ETL_IS_ACTIVE = '1')
  group by CenterId
),


t_bal_0to90_base_daily AS (
SELECT 
A.Clientid,A.ClientLoanId,A.HierarchyId,A.DisbursementDate,A.LoanAmountDisbursed,A.NoOfDaysInArrears,A.PrINcipalINArears,A.INterestINArears,A.EWI,A.CenterId,A.ExpNpa_date_LW,A.ALL_Client_ageing_LW,A.Pos_PM,A.clientNpastatus,A.Ageing,A.Loan_Ageing,A.Client_Ageing,A.week_Due_Principle,A.Week_Due_Interest,A.Total_Due_Principle,A.Total_Due_Interest,A.Week_Total_Due,A.CenterMeetingDay,coalesce(B.Coll,0) Weekly_Coll,
CASE WHEN C.CenterId IS NOT NULL THEN C.Max_Cmdate END Max_Cmdate1
  ,D.NoOfDaysInArrears1 AsonNoofdaysinarrear, D.NPA_date Npadate, D.Expected_NPA_date ExpNpa_date, D.POS,(case when coalesce(D.LoanClosedDate,'1900-01-01')='1900-01-01' then 'Active' else 'Closed' end) Loanstatus
 FROM T_bal_28to90_Base1 A
 LEFT JOIN T_bal_28to90_Collections1 B
 ON B.ClientLoanId = A.ClientLoanId
 LEFT JOIN t2 C
 ON C.CenterId = A.CenterId
 LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts D
 ON A.clientloanid=D.clientloanid)

select 
A.Clientid,A.ClientLoanId,A.HierarchyId,A.DisbursementDate,CAST(A.LoanAmountDisbursed as decimal(16,6)),CAST(A.NoOfDaysInArrears as INT),CAST(A.PrINcipalINArears as decimal(18,2)),CAST(A.INterestINArears as decimal(18,2)),CAST(A.EWI as decimal(18,4)),A.CenterId,A.ExpNpa_date_LW,A.ALL_Client_ageing_LW,CAST(A.Pos_PM as decimal(18,4)),A.clientNpastatus,A.Ageing,A.Loan_Ageing,A.Client_Ageing,A.week_Due_Principle,A.Week_Due_Interest,A.Total_Due_Principle,A.Total_Due_Interest,A.Week_Total_Due,A.CenterMeetingDay,A.Weekly_Coll,CASE WHEN CAST(A.Max_Cmdate1 as date) not between DATE_SUB(CURRENT_DATE(), DAYOFWEEK(CURRENT_DATE()) - 1) and DATE_ADD(CURRENT_DATE(), 7 - DAYOFWEEK(CURRENT_DATE())) THEN NULL ELSE A.Max_Cmdate1 END Max_Cmdate,A.AsonNoofdaysinarrear,A.Npadate,A.ExpNpa_date,A.POS,A.Loanstatus
from t_bal_0to90_base_daily A;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).coalesce(1).cache()
    logger(
        logger_level_info,
        f"nb_t_0to90_base Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_t_0to90_base: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_t_0to90_base : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.t_0to90_base")

    logger(
            logger_level_info,
            f"nb_t_0to90_base writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_t_0to90_base : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_t_0to90_base : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)