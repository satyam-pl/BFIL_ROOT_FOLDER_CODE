# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_t_0to90_base_dailycoll.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/T_0TO90_BASE_DAILYCOLL"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH ftd_Coll_0to90 AS (
(select HierarchyId, ClientId, ClientLoanId, ValueDate, Amount, PrincipalAmount, InterestAmount
    from {source_catalog}.{source_schema}.`pragati-at_loantransactions`
    where cast(ValueDate as date)=cast(GETDATE() as date) - 1 and Amount>0
  union all
    select HierarchyId, ClientId, ClientLoanId, ValueDate, Amount, PrincipalAmount, InterestAmount
    from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-at_loandaytransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)
    where cast(ValueDate as date)=cast(GETDATE() as date) - 1 and Amount>0)),

T_bal_dailycoll_0to90 AS (
select A.Hierarchyid, cast(A.valuedate as date) valuedate, A.ClientLoanId,A.clientid,sum(A.amount) Coll,count(distinct A.clientid) Noc, count(distinct A.clientloanid) NoL
  from ftd_Coll_0to90 A
INNER JOIN {mart_catalog}.{mart_schema}.t_0to90_base B
ON A.ClientLoanId = B.ClientLoanId
  group by A.Hierarchyid,A.valuedate,A.ClientLoanId,A.ClientId),

T_bal_0to90_Base_dailycoll AS ( 
SELECT Hierarchyid, valuedate, clientid, Coll, Noc, NoL
  FROM T_bal_dailycoll_0to90)

SELECT * FROM T_bal_0to90_Base_dailycoll;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"t_0to90_base_dailycoll Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on t_0to90_base_dailycoll: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on t_0to90_base_dailycoll : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

    logger(
            logger_level_info,
            f"t_0to90_base_dailycoll writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table t_0to90_base_dailycoll : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table t_0to90_base_dailycoll : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)