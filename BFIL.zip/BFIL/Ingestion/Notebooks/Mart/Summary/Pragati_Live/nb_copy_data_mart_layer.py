# Databricks notebook source
# Fetch base parameters from ADF

mart_catalog = dbutils.widgets.get("mart_catalog")
mart_schema = dbutils.widgets.get("mart_schema")
mart_table = dbutils.widgets.get("object_name")
mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
source_path = dbutils.widgets.get("source_path")
desti_path = dbutils.widgets.get("desti_path")
final_source_path = mart_layer_abfss_url + source_path
final_desti_path = mart_layer_abfss_url + desti_path

# COMMAND ----------

# Overwrite the Delta table

df = spark.read.parquet(final_source_path).coalesce(1).cache()
df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",final_desti_path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Write data into Snowflake

df.write.format("snowflake").options(**options).option("mergeSchema", "true").option("dbtable", f"{mart_table}").mode("overwrite").save()

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()