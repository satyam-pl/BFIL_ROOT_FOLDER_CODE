# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_pragatilive_clientmaster.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_PRAGATILIVE_CLIENTMASTER"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """Select 
  Hierarchyid
  ,Clientid
  ,Clientcode
  ,Clientname
  ,createdby SMID
  ,joindate
  ,Hour(createddatetime)Hour
  ,createddatetime
  ,Case when substring(cast(createddatetime as timestamp),12,5) <= (SELECT substring(max(cast(ETL_CREATED_DATE as timestamp)),12,5) from {source_catalog}.{source_schema}.clientmaster_rts WHERE ETL_IS_ACTIVE = '1') then '1.Before' else '2.After' End TimeStatus 
FROM {source_catalog}.{source_schema}.clientmaster_rts
where CAST(joindate as date) = CAST(getdate() as date) AND ETL_IS_ACTIVE = '1' AND (CAST(ETL_CREATED_DATE as date) = CAST(getdate() as date) OR CAST(ETL_LAST_UPDATED_DATE as date) = CAST(getdate() as date))
UNION 	
Select 
  Hierarchyid
  ,Clientid
  ,Clientcode
  ,Clientname
  ,createdby SMID
  ,joindate
  ,Hour(createddatetime)Hour
  ,createddatetime
  ,Case when substring(cast(createddatetime as timestamp),12,5) <= (SELECT substring(max(cast(ETL_CREATED_DATE as timestamp)),12,5) from {source_catalog}.{source_schema}.clientmaster_rts WHERE ETL_IS_ACTIVE = '1') then '1.Before' else '2.After' End TimeStatus
FROM (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') 
where CAST(joindate as date) >= CAST(getdate() as date)- 35;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_p_pragatilive_clientmaster Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_p_pragatilive_clientmaster: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_pragatilive_clientmaster : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_pragatilive_clientmaster")

    logger(
            logger_level_info,
            f"nb_p_pragatilive_clientmaster writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_p_pragatilive_clientmaster : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_p_pragatilive_clientmaster : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()