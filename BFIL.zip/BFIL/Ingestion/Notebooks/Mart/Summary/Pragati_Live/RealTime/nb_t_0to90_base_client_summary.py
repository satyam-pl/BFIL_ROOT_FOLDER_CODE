# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_t_0to90_base_client_summary.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/T_0TO90_BASE_CLIENT_SUMMARY"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH ftd_Coll_0to90 AS (
select HierarchyId, ClientId, ClientLoanId, valuedate, Amount
    from (select *,Row_number() over (partition by TransactionId order by CAST(ETL_CREATED_DATE as date) desc) rank from {source_catalog}.{source_schema}.at_loantransactions_rts_insert_only)
    where cast(ValueDate as date)=cast(GETDATE() as date) and rank = 1 and ETL_IS_ACTIVE = '1' and (cast(ETL_CREATED_DATE as date) = cast(getdate() as date)  or cast(ETL_LAST_UPDATED_DATE as date) = cast(getdate() as date)) and Amount>0
  union all
    select HierarchyId, ClientId, ClientLoanId, valuedate, Amount
    from (select *,Row_number() over (partition by TransactionId order by CAST(ETL_CREATED_DATE as date) desc) rank from {source_catalog}.{source_schema}.at_loandaytransactions_rts_insert_only)
    where cast(ValueDate as date)=cast(GETDATE() as date) and rank = 1 and ETL_IS_ACTIVE = '1' and (cast(ETL_CREATED_DATE as date) = cast(getdate() as date)  or cast(ETL_LAST_UPDATED_DATE as date) = cast(getdate() as date)) and Amount>0),

ftd_Coll1_0to90 AS (
  select ClientLoanId, SUM(Amount) Coll
  from ftd_Coll_0to90
  group by ClientLoanId
),

T_bal_0to90_Base_rts AS (
select A.Clientid,A.ClientLoanId,A.HierarchyId,A.DisbursementDate,A.LoanAmountDisbursed,A.NoOfDaysInArrears,A.PrINcipalINArears,A.INterestINArears,A.EWI,A.CenterId,A.ExpNpa_date_LW,A.ALL_Client_ageing_LW,A.Pos_PM,A.clientNpastatus,A.Ageing,A.Loan_Ageing,A.Client_Ageing,A.week_Due_Principle,A.Week_Due_Interest,A.Total_Due_Principle,A.Total_Due_Interest,A.Week_Total_Due,A.CenterMeetingDay,CASE WHEN A.Weekly_Coll IS NULL THEN 0 ELSE A.Weekly_Coll END Weekly_Coll1,A.Max_Cmdate
  ,A.AsonNoofdaysinarrear, A.Npadate, A.ExpNpa_date, A.POS,A.Loanstatus, B.Coll Ftd_Coll,CASE WHEN coalesce(A.Week_Total_Due,0) > 0.00 THEN (case when
Weekly_Coll1 >=(coalesce(A.Week_Total_Due,0)) then (coalesce(A.Week_Total_Due,0)) else Weekly_Coll1 end) END WTD_DuevsColl
  from {mart_catalog}.{mart_schema}.t_0to90_base A
  LEFT JOIN ftd_Coll1_0to90 B
  ON A.clientloanid = B.clientloanid),
  
T_bal_0to90_Base_Client1 AS ( 
SELECT Clientid, HierarchyId,
    CenterId, Ageing, ALL_Client_ageing_LW,
    Client_Ageing, clientNpastatus, max(CentermeetingDay) CentermeetingDay,
    max(ExpNpa_date_LW) ExpNpa_date_LW, max(Max_Cmdate) Max_Cmdate, max(Npadate) as Npadate, max(ExpNpa_date) as ExpNpa_date, sum(LoanAmountDisbursed) LoanAmountDisbursed,
    max(NoOfDaysInArrears) NoOfDaysInArrears,
    sum(coalesce(PrINcipalINArears,0)) PrINcipalINArears, sum(coalesce(INterestINArears,0)) INterestINArears,
    sum(coalesce(EWI,0)) EWI,
    sum(coalesce(Pos,0)) Pos,
    sum(coalesce(Weekly_Coll1,0)) Weekly_Coll,
    sum(coalesce(Total_Due_Principle,0)) `Total Due Principle`,
    sum(coalesce(Total_Due_Interest,0)) `Total Due Interest`,
    sum(coalesce(week_Due_Principle,0))  `week Due Principle`,
    sum(coalesce(Week_Due_Interest,0)) `Week Due Interest`,
    sum(coalesce(Week_Total_Due,0))  Week_Total_Due,
    max(AsonNoofdaysinarrear) AsonNoofdaysinarrear,
    sum(coalesce(Ftd_Coll,0)) Ftd_Coll,
    sum(coalesce(WTD_DuevsColl,0)) WTD_DuevsColl, max(DisbursementDate) as   Max_DisbursementDate
  FROM T_bal_0to90_Base_rts
  group by Clientid, HierarchyId,
    CenterId,Ageing,ALL_Client_ageing_LW,
     Client_Ageing ,clientNpastatus),

T_bal_0to90_Base_Client2 AS (
SELECT 
  A.Clientid, A.HierarchyId,A.CenterId,A.Ageing,A.ALL_Client_ageing_LW,
    A.Client_Ageing,A.clientNpastatus,A.CentermeetingDay,A.ExpNpa_date_LW,A.Max_Cmdate,A.Npadate,A.ExpNpa_date, A.LoanAmountDisbursed
    ,A.NoOfDaysInArrears,A.PrINcipalINArears,A.INterestINArears,A.EWI,A.Pos,A.Weekly_Coll,A.`Total Due Principle`,A.`Total Due Interest`
    ,A.`week Due Principle`,A.`Week Due Interest`,A.Week_Total_Due,CASE WHEN A.AsonNoofdaysinarrear>90 THEN 101 ELSE A.AsonNoofdaysinarrear END AsonNoofdaysinarrear1
    ,A.Ftd_Coll,A.WTD_DuevsColl,A.Max_DisbursementDate
    ,B.Var_balance
    ,(coalesce(A.Weekly_Coll,0)/coalesce(A.Week_Total_Due,0)) PaidEWI
    ,CASE WHEN PaidEWI>=5 THEN 'g.  [>=5 EWIs]'
          WHEN PaidEWI>=4 and PaidEWI<5 THEN 'f.  [4 EWIs]'
          WHEN PaidEWI>=3 and PaidEWI<4 THEN 'e.  [3 EWIs]'
          WHEN PaidEWI>=2 and PaidEWI<3 THEN 'd.  [2 EWIs]'
          WHEN (PaidEWI>=1 and PaidEWI<2) THEN 'c.  [1 EWI]'
          WHEN (PaidEWI=0 and PaidEWI<1) and (A.weekly_coll > 0) THEN 'b.  [<1 EWI]' 
          WHEN PaidEWI = 0 THEN 'a.  [0 EWI]' 
          WHEN A.Weekly_Coll < 0 THEN 'a.  [0 EWI Neg]' END PaidEWI_Status
    ,CASE WHEN (A.Weekly_Coll>(coalesce(A.Week_Total_Due,0))) THEN (A.Weekly_Coll-(coalesce(A.Week_Total_Due,0))) END Excess_Coll
    ,concat(cast(((coalesce(A.Weekly_Coll,0)/ coalesce((A.Week_Total_Due),0))*100) as STRING),'%') `Ce_Per%`
    ,CASE WHEN lower(A.ALL_Client_ageing_LW)='current1' THEN (case when A.npadate is not null then '5.Npa'
                                    when A.week_total_due<=A.wtd_duevscoll then '3.Stabilised'
                                    when A.week_total_due > A.wtd_duevscoll and A.Max_Cmdate is not null then '4.Forward Flow'
                                  when   A.Max_Cmdate is null then '6.CM Not Due Yet'
         end )
    WHEN lower(A.ALL_Client_ageing_LW)<>'current1' THEN (case when A.npadate is not null then '5.Npa'
                                    when AsonNoofdaysinarrear1=0  then '1.Current'
                                    when paidewi=1 then '3.Stabilised'
         when paidewi>1 then '2.Backward Flow'
         when paidewi = 0 and A.Max_Cmdate is not null then '4.Forward Flow'
         when paidewi = 0 and A.Max_Cmdate is null then '6.CM Not Due Yet'
   when A.weekly_coll<0   then '4.Forward Flow'
         end )     
    END Flow_Status
    ,(case when paidewi>=1 then 'Paid' else 'Not Paid' end) Paid_Status
FROM T_bal_0to90_Base_Client1 A
LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary B ON A.clientid=b.clientid
),

Paidnotpaid_Client_0to90 AS (
  select clientid, COUNT(1) Total, sum(case when paid_status='Paid' then 1 else 0 end) paid,
    sum(case when paid_status='Not Paid' then 1 else 0 end) Notpaid
  from T_bal_0to90_Base_Client2
  group by clientid
),

T_bal_0to90_Base_Client3 AS (
SELECT
    A.Clientid, A.HierarchyId,A.CenterId,A.Ageing,A.ALL_Client_ageing_LW,
    A.Client_Ageing,A.clientNpastatus,A.CentermeetingDay,A.ExpNpa_date_LW,A.Max_Cmdate,A.Npadate,A.ExpNpa_date, A.LoanAmountDisbursed,A.NoOfDaysInArrears,A.PrINcipalINArears,A.INterestINArears,A.EWI,A.Pos,A.Weekly_Coll,A.`Total Due Principle`,A.`Total Due Interest`,A.`week Due Principle`,A.`Week Due Interest`,A.Week_Total_Due, A.AsonNoofdaysinarrear1 AsonNoofdaysinarrear,A.Ftd_Coll,A.WTD_DuevsColl,A.Max_DisbursementDate
    ,A.Var_balance
    ,A.PaidEWI
    ,A.PaidEWI_Status
    ,A.Excess_Coll
    ,A.`Ce_Per%`
    ,A.Paid_Status
    ,case when b.clientid IS NOT NULL and  b.Total=b.paid then 'Paid' 
    when b.clientid IS NOT NULL and  b.Total<>b.paid then 'Not Paid'
    end ClientPaid_Status
    ,CASE 
          WHEN a.max_cmdate is not null and lower(A.ALL_Client_ageing_LW)='current1' and A.Npadate is null THEN 
        (case when  A.week_total_due>A.wtd_duevscoll then 'Yes' else 'No' end) END New_arrear
    ,CASE WHEN lower(New_arrear)='yes'
    and (CAST(A.Max_DisbursementDate as date) between CAST(getdate() as date) - 8 and CAST(getdate() as date) - 1) and lower(A.ALL_Client_ageing_LW)='current1' THEN '3.Stabilised' ELSE A.Flow_Status END Flow_Status1   
    ,CASE WHEN C.clientid IS NOT NULL THEN 'Yes' END Moratorium_Flag     
FROM T_bal_0to90_Base_Client2 A
LEFT JOIN Paidnotpaid_Client_0to90 B
ON a.clientid=b.clientid
LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts C ON a.clientid=C.clientid AND lower(C.M_flag)='y'
),

T_bal_0to90_Base_Client AS (
SELECT 
    A.Clientid, A.HierarchyId,A.CenterId,A.Ageing,A.ALL_Client_ageing_LW,
    A.Client_Ageing,A.clientNpastatus,A.CentermeetingDay,A.ExpNpa_date_LW,A.Max_Cmdate,A.Npadate,A.ExpNpa_date,A.LoanAmountDisbursed,A.NoOfDaysInArrears,A.PrINcipalINArears,A.INterestINArears,A.EWI,A.Pos,A.Weekly_Coll,A.`Total Due Principle`,A.`Total Due Interest`,A.`week Due Principle`,A.`Week Due Interest`,A.Week_Total_Due, A.AsonNoofdaysinarrear,A.Ftd_Coll,A.WTD_DuevsColl,A.Max_DisbursementDate
    ,A.Var_balance
    ,A.PaidEWI
    ,A.PaidEWI_Status
    ,A.Excess_Coll
    ,A.`Ce_Per%`
    ,A.Paid_Status
    ,A.ClientPaid_Status
    ,A.Moratorium_Flag
    ,CASE   WHEN lower(A.New_arrear)='yes' and (CAST(A.Max_DisbursementDate as date)   between  cast(getdate() as date)-8 and cast(getdate() as date)-1) THEN 'No' 
    WHEN lower(A.New_arrear)='yes' and lower(A.Moratorium_Flag)='yes' THEN 'No' 
    ELSE A.New_arrear 
    END New_arrear1
    ,CASE WHEN lower(New_arrear1)='yes' AND lower(a.Moratorium_Flag)='yes' THEN '3.Stabilised' ELSE A.Flow_Status1 END Flow_Status
    ,CASE WHEN b.Hierarchyid IS NOT NULL THEN 'CollectionFocussedBranch Client' ELSE NULL END CollectionFocussedBranchesTAG
    ,CASE WHEN C.Clientid IS NOT NULL THEN 1 ELSE 0 END Npa_flag
FROM T_bal_0to90_Base_Client3 A
LEFT JOIN {source_catalog}.{source_schema}.`azuresource-t_bal_focus_branches` B ON a.hierarchyid=b.Hierarchyid
LEFT JOIN {mart_catalog}.{mart_schema}.t_bal_npaflag C ON a.clientid=C.clientid),


Min_ExpNpa_date_LW AS (
  select min(ExpNpa_date_LW) Min_ExpNpa_date_LW from T_bal_0to90_Base_Client
)

Select hierarchyid
,CASE 
      WHEN ALL_Client_ageing_LW = 'Current1' THEN '01. Current'
      WHEN ALL_Client_ageing_LW = '[1 To 30]' THEN '02. [1 To 30]'
      WHEN ALL_Client_ageing_LW = '[31 To 60]' THEN '03. [31 To 90]'
      WHEN ALL_Client_ageing_LW = '[61 To 90]' THEN '03. [31 To 90]'
      ELSE ALL_Client_ageing_LW
END Ageing
,CASE WHEN lower(Client_Ageing) = 'current1' THEN '[00-00]' ELSE Client_Ageing END Client_Ageing, 
CentermeetingDay, ClientPaid_Status 
,Flow_Status
, PaidEWI_Status
,CASE WHEN New_Arrear1 is null THEN 'No' ELSE New_arrear1 END New_arrear
,Npa_flag
,(case when Max_Cmdate is null then 'Not Done' else 'Done' End ) CM_Status,
    (case when cast(ExpNpa_date_LW as date) < date_add((select Min_ExpNpa_date_LW from Min_ExpNpa_date_LW),11) then ExpNpa_date_LW else '1900-01-01' End )ExpNpa_date_LW_10Days,
    sum(Week_Total_Due)/1e7 FTW_Due, sum(WTD_DuevsColl)/1e7 WTD_DuevsColl,
    sum(Weekly_Coll)/1e7 WTD_Coll,
    sum(POS)/1e7 POS, Count(1)NOC
    ,sum(var_balance)/1e7 var_balance
  from T_bal_0to90_Base_Client
  group by hierarchyid,ALL_Client_ageing_LW,Client_Ageing,CentermeetingDay,ClientPaid_Status
  ,Flow_Status
  ,PaidEWI_Status
  ,ExpNpa_date_LW
  ,Npa_flag
  ,ExpNpa_date_LW_10Days,New_arrear,CM_Status;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_t_0to90_base_client_summary Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_t_0to90_base_client_summary: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_t_0to90_base_client_summary : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.t_0to90_base_client_summary")

    logger(
            logger_level_info,
            f"nb_t_0to90_base_client_summary writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_t_0to90_base_client_summary : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_t_0to90_base_client_summary : ", str(e))