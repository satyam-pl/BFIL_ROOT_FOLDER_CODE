# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_pragatiLive_hourly_proposal.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_PRAGATILIVE_HOURLY_PROPOSAL"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH cte_PLD_TargetFacts_LND as (
    select b.Clientid
from {mart_catalog}.{mart_schema}.targetfacts a
join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') b on a.TargetID=b.targetid
where lower(TargetCurrentStatus)='client done - loan not disbursed'
union
Select clientid
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1')
where cast(joindate as date) >=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)-4),

Cte_PLD_ClientFacts_MinDisbDate as (
Select Clientid,Min_Disbdate
from {mart_catalog}.{mart_schema}.clientfacts
where cast(Min_Disbdate as date) >= cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)-3
),

CTE_PLD_Clientloanproposal as (
Select cl.createddatetime,cl.Hierarchyid,cl.Loanproposalid,cl.clientid,''ClientCode,cl.Updatedby,proposaldate ,
tempdisbursementdate,LoanAmountApproved ,substring(cl.createddatetime,11,3)Hour,p.productCode,
'1.NOStatus' TimeStatus,cast(Null as varchar(20) ) is_IGL1,Cl.ProductId
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientloanproposal_h_view` WHERE ETL_IS_ACTIVE = '1') cl
join (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` WHERE ETL_IS_ACTIVE = '1') d on Cl.ProductId=D.DerivedProductId
join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-productmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) p on D.ProductId=P.ProductId
where cl.ProductType is null  and Loanamountapproved is not null
and coalesce(LoanAmountApproved,0) > 0
and coalesce(Cancelremarks,'a')<>'System Cancelled while tab sync process, due to disbursed not done on same day'
and coalesce(EKYCSucessdate,'1900-01-01')>'1900-01-01'
and Proposaldate>= cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)-34 ),

 CTE_P_PragatiLive_Hourly_Proposal_wf as(
Select cl.Hierarchyid,cl.Loanproposalid,cl.clientid,left(TemporaryProposalCode,16)ClientCode,cl.Updatedby,proposaldate,tempdisbursementdate,LoanAmountApproved ,substring(cl.createddatetime,11,3)Hour,p.productCode,
Case when substring(cl.createddatetime,11,6) <= (SELECT substring(max(cast(ETL_CREATED_DATE as timestamp)),11,6) from (select * from {source_catalog}.{source_schema}.clientloanproposal_rts WHERE ETL_IS_ACTIVE = '1')) then '1.Before' else '2.After' End TimeStatus,'Non IGL 1' is_IGL1
from  (SELECT * FROM {source_catalog}.{source_schema}.clientloanproposal_rts WHERE ETL_IS_ACTIVE = '1' and CAST(ProposalDate as date) = CAST(getdate() as date) and (CAST(ETL_CREATED_DATE as date) = CAST(getdate() as date) or CAST(ETL_LAST_UPDATED_DATE as date) = CAST(getdate() as date))) cl
JOin (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` WHERE ETL_IS_ACTIVE = '1') D on Cl.ProductId=D.DerivedProductId
Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-productmaster` WHERE ETL_IS_ACTIVE = '1') P on D.ProductId=P.ProductId
where cl.ProductType is null  and Loanamountapproved is not null
and coalesce(LoanAmountApproved,0) > 0
and coalesce(Cancelremarks,'a')<>'System Cancelled while tab sync process, due to disbursed not done on same day'
and coalesce(EKYCSucessdate,'1900-01-01')>'1900-01-01'
Union
Select cl.Hierarchyid,cl.Loanproposalid,cl.clientid,''ClientCode,cl.Updatedby,proposaldate ,tempdisbursementdate,LoanAmountApproved ,Hour,p.productCode,
Case when substring(cl.createddatetime,11,6) <= (SELECT substring(max(cast(ETL_CREATED_DATE as timestamp)),11,6) from (select * from {source_catalog}.{source_schema}.clientloanproposal_rts WHERE ETL_IS_ACTIVE = '1')) then '1.Before' else '2.After' End TimeStatus,CAST(NULL as STRING) is_IGL1
from  CTE_PLD_Clientloanproposal cl
JOin (SELECT * FROM {source_catalog}.{source_schema}.`pragatimain-derivedproductmaster` WHERE ETL_IS_ACTIVE = '1') D on Cl.ProductId=D.DerivedProductId
Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-productmaster` WHERE ETL_IS_ACTIVE = '1') P on D.ProductId=P.ProductId)

SELECT a.Hierarchyid,a.Loanproposalid,a.clientid,a.ClientCode,a.Updatedby,a.proposaldate,a.tempdisbursementdate,a.LoanAmountApproved ,a.Hour,a.productCode,
case 
when b.clientid is not null 
or c.clientid is not null  
or d.clientid is not null
then 'IGL 1' else a.is_IGL1 end as is_IGL1,a.TimeStatus
 from CTE_P_PragatiLive_Hourly_Proposal_wf a
left join cte_PLD_TargetFacts_LND b on a.clientid=b.clientid
left join Cte_PLD_ClientFacts_MinDisbDate c on a.clientid=c.clientid and a.proposaldate<= c.Min_Disbdate
left join edp_bfil_prod.bfil_mart.p_client_igl1data_batch d on A.clientid = d.clientid and a.proposaldate<= d.Min_Disbdate;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_p_pragatiLive_hourly_proposal Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_p_pragatiLive_hourly_proposal: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_pragatiLive_hourly_proposal : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_pragatilive_hourly_proposal")

    logger(
            logger_level_info,
            f"nb_p_pragatiLive_hourly_proposal writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_p_pragatiLive_hourly_proposal : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_p_pragatiLive_hourly_proposal : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()