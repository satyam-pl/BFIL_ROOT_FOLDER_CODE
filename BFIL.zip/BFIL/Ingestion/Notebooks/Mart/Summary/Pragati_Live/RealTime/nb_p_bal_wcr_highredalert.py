# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_bal_wcr_highredalert.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_BAL_WCR_HIGHREDALERT"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """With ftd_Coll_redhigh AS (
select ClientId, SUM(Amount) Coll from (
select HierarchyId, ClientId, ClientLoanId, ValueDate, Amount, PrincipalAmount, InterestAmount
  from (select *,Row_number() over (partition by TransactionId order by CAST(ETL_CREATED_DATE as date) desc) rank from {source_catalog}.{source_schema}.at_loantransactions_rts_insert_only WHERE ETL_IS_ACTIVE = '1' AND cast(ValueDate as date)=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date) and Amount>0)  Where rank = 1
  UNION
  select HierarchyId, ClientId, ClientLoanId, ValueDate, Amount, PrincipalAmount, InterestAmount
  from (select *,Row_number() over (partition by TransactionId order by CAST(ETL_CREATED_DATE as date) desc) rank from {source_catalog}.{source_schema}.at_loandaytransactions_rts_insert_only WHERE ETL_IS_ACTIVE = '1' AND CreatedBy <> 'SUMMARY' AND cast(ValueDate as date)=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date) and Amount>0) WHERE rank =1)
  group by ClientId)
  
select a.HierarchyId,a.ZoneName,a.StateName,a.SBH,a.Region,a.Area,a.Unit,a.BranchID,a.BranchName,a.centercode,
   a.CenterId,a.ClientId,a.ClientCode,a.StaffId,
   a.Max_DisbursementDate,
   a.LastRepaymentDate,
   a.Arrear,a.POS,a.Alert_Status,
   a.client_joined_this_FY,
  a.Joindate ,a.Fresh_Flow ,a.Week_Totaldue,a.CenterMeetingDay,
  CASE WHEN b.clientid IS NOT NULL THEN b.Coll ELSE 0 END Ftd_Coll,
  (Nullif(Ftd_Coll,0)/Nullif(coalesce(a.Week_Totaldue,0),0)) PaidEWI,
  CASE WHEN PaidEWI >= 1 THEN 'Paid' else 'Not Paid' END Paid_Status
from {mart_catalog}.{mart_schema}.P_Wcr_HighRedalert_final4_batch a
LEFT JOIN ftd_Coll_redhigh b
ON a.clientid = b.clientid;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_p_bal_wcr_highredalert Query has been successfully completed.",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_p_bal_wcr_highredalert: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_bal_wcr_highredalert : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_bal_wcr_highredalert")

    logger(
            logger_level_info,
            f"nb_p_bal_wcr_highredalert writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_p_bal_wcr_highredalert : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_p_bal_wcr_highredalert : ", str(e))


# COMMAND ----------

# DBTITLE 1,Writing Dataframe to Snowflake
# try :
#     # Write DataFrame to Snowflake table
#     df.write.format("snowflake").options(**options).option("dbtable", "tw_itlogin").mode("overwrite").save()
#     logger(
#             logger_level_info,
#             f"tw_itlogin writing to snowflake table has been successfully completed.",
#             execution_log_list,
#             filename,
#     )
# except Exception as e:
#     logger(
#         logger_level_error,
#         f"error occured while writing data into snowflake table tw_itlogin : {str(e)}",
#         execution_log_list,
#         filename,
#     )
#     print(*execution_log_list, sep="\n")
#     # Handle the exception or display the error message as needed
#     raise Exception("error occured while writing data into snowflake table tw_itlogin : ", str(e))