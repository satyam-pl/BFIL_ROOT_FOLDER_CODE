# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_t_0to90_base_dailycoll.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/T_0TO90_BASE_DAILYCOLL"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH ftd_Coll_0to90 AS (
select HierarchyId, ClientId, ClientLoanId, valuedate, Amount
    from (select *,Row_number() over (partition by TransactionId order by CAST(ETL_CREATED_DATE as date) desc) rank from {source_catalog}.{source_schema}.at_loantransactions_rts_insert_only)
    where cast(ValueDate as date)=cast(GETDATE() as date) and rank = 1 and ETL_IS_ACTIVE = '1' and (cast(ETL_CREATED_DATE as date) = cast(getdate() as date)  or cast(ETL_LAST_UPDATED_DATE as date) = cast(getdate() as date)) and Amount>0
  union all
    select HierarchyId, ClientId, ClientLoanId, valuedate, Amount
    from (select *,Row_number() over (partition by TransactionId order by CAST(ETL_CREATED_DATE as date) desc) rank from {source_catalog}.{source_schema}.at_loandaytransactions_rts_insert_only)
    where cast(ValueDate as date)=cast(GETDATE() as date) and rank = 1 and ETL_IS_ACTIVE = '1' and (cast(ETL_CREATED_DATE as date) = cast(getdate() as date)  or cast(ETL_LAST_UPDATED_DATE as date) = cast(getdate() as date)) and Amount>0),
	
ftd_Coll1_0to90 AS (
  select ClientLoanId, SUM(Amount) Coll
  from ftd_Coll_0to90
  group by ClientLoanId
),

T_bal_0to90_Base_rts AS (
select A.Clientid,A.ClientLoanId,A.HierarchyId,A.DisbursementDate,A.LoanAmountDisbursed,A.NoOfDaysInArrears,A.PrINcipalINArears,A.INterestINArears,A.EWI,A.CenterId,A.ExpNpa_date_LW,A.ALL_Client_ageing_LW,A.Pos_PM,A.clientNpastatus,A.Ageing,A.Loan_Ageing,A.Client_Ageing,A.week_Due_Principle,A.Week_Due_Interest,A.Total_Due_Principle,A.Total_Due_Interest,A.Week_Total_Due,A.CenterMeetingDay,CASE WHEN A.Weekly_Coll IS NULL THEN 0 END Weekly_Coll,A.Max_Cmdate
  ,A.AsonNoofdaysinarrear, A.Npadate, A.ExpNpa_date, A.POS,A.Loanstatus, B.Coll Ftd_Coll,(case when
Weekly_Coll >=(coalesce(A.Week_Total_Due,0)) then (coalesce(A.Week_Total_Due,0)) else Weekly_Coll end) WTD_DuevsColl
  from {mart_catalog}.{mart_schema}.t_0to90_base A
  LEFT JOIN ftd_Coll1_0to90 B
  ON A.clientloanid = B.clientloanid),
  

T_bal_dailycoll_0to90 AS (
select A.Hierarchyid, cast(A.valuedate as date) valuedate,A.ClientLoanId,A.clientid,sum(A.amount) Coll,
count(distinct A.clientid) Noc, count(distinct A.clientloanid) NoL
  from ftd_Coll_0to90 A
INNER JOIN T_bal_0to90_Base_rts B
ON A.ClientLoanId = B.ClientLoanId
group by A.Hierarchyid,A.valuedate,A.ClientLoanId,A.ClientId),

T_bal_0to90_Base_dailycoll AS ( 
SELECT * from {mart_catalog}.{mart_schema}.t_28to90_base_dailycoll
UNION ALL
SELECT Hierarchyid, valuedate, ClientLoanId,clientid, Noc, NoL, Coll
  FROM T_bal_dailycoll_0to90)

SELECT * FROM T_bal_0to90_Base_dailycoll""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_t_0to90_base_dailycoll Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_t_0to90_base_dailycoll: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_t_0to90_base_dailycoll : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.t_0to90_base_dailycoll")

    logger(
            logger_level_info,
            f"nb_t_0to90_base_dailycoll writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_t_0to90_base_dailycoll : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_t_0to90_base_dailycoll : ", str(e))