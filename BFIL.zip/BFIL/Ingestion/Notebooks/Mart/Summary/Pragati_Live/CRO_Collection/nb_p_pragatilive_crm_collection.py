# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_pragatilive_crm_collection.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/P_PRAGATILIVE_CRM_COLLECTION"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH T_Veer_CRM_CallData AS (
Select *
from (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-bfil_digitalcollection_insert` WHERE ETL_IS_ACTIVE = '1')
where    cast(CreatedDateTime as date) >='2024-03-01'),

T_Veer_CRM_CallData_1 AS (
Select *
from (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-bfil_digitalcollection_insert` WHERE ETL_IS_ACTIVE = '1')
where   cast(UpdatedDateTime as date) >='2024-03-01'),

T_Veer_CRM_CallData_2 AS (
Select distinct *
    from T_Veer_CRM_CallData
Union
    Select *
    from T_Veer_CRM_CallData_1),

T_Sampark_Calling_CRMCollection AS (
Select distinct coalesce(cast(UpdatedDateTime as date),  cast(CreatedDateTime as date)) as Date1 ,
    HIerarchyID, CreatedBy as StaffID, PTPDate,
    ClientId, ClientLoanID, ProductCode	, ProductName , EWI, Disposition, CallOrVisit,
    AmountToBePaid, TotalAmountTobePaid, AmountReceived, upiTxnId, PaymentType, CollectedLoanAmount
from T_Veer_CRM_CallData_2
WHERE lower(UserType) ='supportingstaff'and lower(ScreenName) ='arrear collection'),

T_Sampark_Calling_CRMCollection_S AS (
Select Date1, A.HIerarchyID , A.StaffID, B.CenterID, B.CentermeetingDay, A.ClientID, Disposition, CallOrVisit, PTPDate,
    Count(distinct ClientLoanID)NOL,
    Sum(coalesce(AmountReceived,0))CashLess_Mode_Amount,
    Sum(coalesce(CollectedLoanAmount,0))Cash_Mode_Amount ,
    sum(EWI) EWI,
    sum(case when AmountReceived > 0 then 1 else 0 end) CashLess_Mode_Count,
    sum(case when CollectedLoanAmount > 0 then 1 else 0 end) Cash_Mode_Count
from T_Sampark_Calling_CRMCollection a
    left Join {mart_catalog}.{mart_schema}.client_facts B on A.ClientID=B.ClientID
Group by Date1,A.HIerarchyID,B.CenterID,B.CentermeetingDay,A.StaffID,A.ClientID,CallOrVisit,Disposition,PTPDate),

P_CRM_CRO_Allocated_Base_F1_Pra AS (
Select region,supportstaffid,Designation,StaffName,Target,count(clientid) as client_cnt, 
count(distinct centerid) as center_cnt
from (SELECT * FROM {source_catalog}.{source_schema}.`azuresource-p_crm_cro_allocated_base` WHERE ETL_IS_ACTIVE = '1')
group by  region,supportstaffid,StaffName,Target,Designation),

P_PragatiLive_CRM_Collection_1 AS (
Select distinct  Date1,HIerarchyID,D.supportstaffid as StaffID ,D.Designation as Type  ,Target CRO_RCM_target_Day ,B.ClientId  as ClientId_A,B.CenterId as CenterId_A,  B.CenterID,   CentermeetingDay     ,B.ClientID   ,Disposition  ,CallOrVisit    ,NOL       ,CashLess_Mode_Amount , Cash_Mode_Amount            ,CashLess_Mode_Count ,Cash_Mode_Count  from   T_Sampark_Calling_CRMCollection_S    B  
Join P_CRM_CRO_Allocated_Base_F1_Pra D on B.Staffid=D.supportstaffid 
where Date1>='2024-03-01')

SELECT  * ,(
SELECT sum(CashLess_Mode_Amount+Cash_Mode_Amount)
FROM P_PragatiLive_CRM_Collection_1  AS T2
WHERE T2.Date1 <= T1.Date1
) AS RunningTotal
FROM  P_PragatiLive_CRM_Collection_1 AS T1;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_pragatilive_crm_collection Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_pragatilive_crm_collection: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_pragatilive_crm_collection : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

    logger(
            logger_level_info,
            f"p_pragatilive_crm_collection writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_pragatilive_crm_collection : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table p_pragatilive_crm_collection : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)