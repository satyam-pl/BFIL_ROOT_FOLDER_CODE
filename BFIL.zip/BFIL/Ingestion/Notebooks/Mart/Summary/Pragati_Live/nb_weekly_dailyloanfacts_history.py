# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_weekly_dailyloanfacts_history.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path_dailyloanfacts_client_summary_weekly = mart_layer_abfss_url + "BFIL-MART/FACTS/DAILYLOANFACTS_CLIENT_SUMMARY_weekly"

    path_dailyloanfacts_weekly = mart_layer_abfss_url + "BFIL-MART/FACTS/DAILYLOANFACTS_weekly"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query_dailyloanfacts_client_summary_weekly = """select ClientId from {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary where NPA_date is not null and Branch_Type='MFI';""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )

    query_dailyloanfacts_weekly = """SELECT * FROM {mart_catalog}.{mart_schema}.dailyloanfacts;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df_dailyloanfacts_weekly = spark.sql(query_dailyloanfacts_weekly).repartition(50).cache()
    df_dailyloanfacts_client_summary_weekly = spark.sql(query_dailyloanfacts_client_summary_weekly).repartition(50).cache()

    logger(
        logger_level_info,
        f"nb_weekly_dailyloanfacts_history Query has been successfully completed.{path_dailyloanfacts_weekly}",
        execution_log_list,
        filename,
    )

    logger(
        logger_level_info,
        f"nb_weekly_dailyloanfacts_history Query has been successfully completed.{path_dailyloanfacts_client_summary_weekly}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_weekly_dailyloanfacts_history: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_weekly_dailyloanfacts_history : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df_dailyloanfacts_weekly.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path_dailyloanfacts_weekly).saveAsTable(f"{mart_catalog}.{mart_schema}.dailyloanfacts_weekly")

    df_dailyloanfacts_client_summary_weekly.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path_dailyloanfacts_client_summary_weekly).saveAsTable(f"{mart_catalog}.{mart_schema}.dailyloanfacts_client_summary_weekly")

    logger(
            logger_level_info,
            f"nb_weekly_dailyloanfacts_history writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_weekly_dailyloanfacts_history : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_weekly_dailyloanfacts_history : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df_dailyloanfacts_weekly.unpersist()
df_dailyloanfacts_client_summary_weekly.unpersist()