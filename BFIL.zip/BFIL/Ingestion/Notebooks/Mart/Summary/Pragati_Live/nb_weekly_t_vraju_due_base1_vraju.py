# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_weekly_t_vraju_due_base1_vraju.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/T_VRAJU_DUE_BASE1_VRAJU"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH T_Vraju_BM_UM_Total_Active_Centers AS (
select b.`ZONE` as `ZONE NAME`, b.state, b.`AREA` as `AREA OFFICE`, b.Region , b.BRANCHID as BRANCH_ID, b.`BRANCHNAME` `BRANCH NAME`, B.UMBaseLocationBranchName UnitOffice, b.DISTRICT, b.HierarchyId , a.CenterId ,a.CenterCode, a.CenterName, a.FormationDate, (case when a.CenterMeetingDay = 1 then 'Monday' when A.CenterMeetingDay = 2 then
'Tuesday' when A.CenterMeetingDay = 3 then 'Wednesday'when
A.CenterMeetingDay = 4 then 'Thursday' else 'Friday' end)  as CenterMeetingDay, a.StaffId
    from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1') a 
    left join {mart_catalog}.{mart_schema}.p_hierarchy_sop b
    on a.HierarchyId = b.HierarchyId
    where coalesce(a.DissolvedDate,'1900-01-01' )='1900-01-01' and upper(b.`ZONE`) not in ('AP','TS')),

T_Vraju_BM_UM_GivenCenters_ActiveClients AS (
select a.*, count(distinct clm.clientid) `No Of Active Clients`
    from T_Vraju_BM_UM_Total_Active_Centers a join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1') cm on a.centerid = cm.centerid
        Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1') gm On cm.CenterId=gm.CenterId
        Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') clm On gm.GroupId=clm.GroupId
    where coalesce(clm.DropOutDate,'1900-01-01')='1900-01-01'
    Group by a.CenterId,a.CenterCode,a.CenterName,a.FormationDate,a.CenterMeetingDay,a.HierarchyId,a.BRANCH_ID,
a.`BRANCH NAME`,
-- a.[Branch growth status],
a.DISTRICT,
a.`ZONE NAME`,a.Region,a.`AREA OFFICE`,a.STATE,a.UnitOffice,a.StaffId),

T_Vraju_BM_UM_Total_Active_Groups AS (
select a.CenterId, count(GroupId)ActiveGroups
    from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1') A left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1') B
        ON A.CenterId=B.CenterId
    where coalesce(b.DissolvedDate,'1900-01-01' )='1900-01-01'
    group by a.CenterId),

T_Vraju_Base_Loans_Vraju AS (
select clientLoanid, HierarchyId , CODDate as LastSyncDate_COB
    from {mart_catalog}.{mart_schema}.dailyloanfacts
    where DisbursementDate >='2017-01-01'
        and Branch_Type = 'MFI' and coalesce(LoanCLosedDate,'1900-01-01' )='1900-01-01'),

T_Vraju_Due_base1_Vraju AS (
SELECT T.ClientLoanId, T.HierarchyId
        ,sum (case when  CAST(AV.valuedate as date) <=  CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')- INTERVAL 1 DAYS as date)   then    AV.PrincipalAmount end)  Total_Due_Principle,
        sum(case when  CAST(AV.valuedate as date) <=  CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')- INTERVAL 1 DAYS as date)  then     AV.InterestAmount end)  Total_Due_Interest,
        sum(case when CAST(AV.TransactionDate as date) >= CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')+ INTERVAL 1 DAYS as date) and CAST(AV.TransactionDate as date) <= CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')+ INTERVAL 5 DAYS as date)  then AV.PrincipalAmount end)  week_Due_Principle,
        sum(case when CAST(AV.TransactionDate as date) >= CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')+ INTERVAL 1 DAYS as date) and CAST(AV.TransactionDate as date) <= CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')+ INTERVAL 5 DAYS as date)  then AV.InterestAmount end) Week_Due_Interest
    FROM T_Vraju_Base_Loans_Vraju T
        JOIN (SELECT * FROM {mart_catalog}.{mart_schema}.accounttransactionsview) AV ON
Av.ClientLoanId = T.ClientLoanId and T.HierarchyId=Av.HierarchyId
    where (AV.TransactionType ='C'and AV.DebitOrCredit ='D')
    group by T.ClientLoanId,T.HierarchyId) 
	
Select * from T_Vraju_Due_base1_Vraju;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_weekly_t_vraju_due_base1_vraju Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_weekly_t_vraju_due_base1_vraju: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_weekly_t_vraju_due_base1_vraju : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.t_vraju_due_base1_vraju")

    logger(
            logger_level_info,
            f"nb_weekly_t_vraju_due_base1_vraju writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_weekly_t_vraju_due_base1_vraju : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_weekly_t_vraju_due_base1_vraju : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()