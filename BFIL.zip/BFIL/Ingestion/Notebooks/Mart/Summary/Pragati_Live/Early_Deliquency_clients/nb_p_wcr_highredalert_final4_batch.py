# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_wcr_highredalert_final4_batch.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_WCR_HIGHREDALERT_FINAL4_BATCH"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH P_allKycs_all AS (
select A.ClientId,B.PhoneNumber,B.MobileNumber
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') A
JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-kycdetails` WHERE ETL_IS_ACTIVE = '1') B
ON A.TargetId = B.TargetId),

T_sha_Feb20_NPA AS (
select distinct clientid from {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary           
where npa_date <='2021-03-31'),

P_Vraju_ClientWiseDPD_Final1 AS (
SELECT X.`ZONE`, x.STATE, X.Region,X.`Area` as Area,x.`UMBaseLocationBranchName` as Unit                                 
, x.BRANCHID, x.`BRANCHNAME`,                                                                       
D.ClientiD, cm.ClientCode, cm.Clientname,E.CenterMeetingDay,                
D.staffid,D.staffname ,cm.JoinDate,Ageing,                      
 D.POS, (D.PrINcipalINArears+D.INterestINArears)Arrear,D.NO_Of_Active_Loans,
D.Var_balance,                                             
D.LastRepaymentDate as Last_Repayment_Date,NoOfDaysInArrears,  d.suv_client,                                  
case when D.ClientiD in (select Distinct Clientid from T_sha_Feb20_NPA) then 'yes' else 'No' end as March1_NPA,                                                            
D.IsDeath,'' Month_End_Status,D.Monthend_Ageing,D.EWI,D.ClientNPAstatus ,                                                
 (MTD_Due) ,  (MTD_Coll) ,  (MTD_Due_Coll) ,
Ason_collPaid, PM_CollPaid,                                                                                                  
cast('' as STRING) as SpouseName,                                                                                                   
D.As_on_Paidstatus as 4_EWI_Paid_Arrear_Client_As_On,
D.PM_Paidstatus as 4_EWI_Paid_Arrear_Client_PM,                                                                                                 
cast('' as Varchar (500)) as ExceptRemarks,                                                                                                  
cast(''as TIMESTAMP) as ExceptLog_Date,                                                                                              
E.CenterID  ,  d.centername,d.centercode,  Max_DisbursementDate,
''New_CB                                                                                   
FROM {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary AS D 
left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') cm on d.ClientId=cm.ClientId 
left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1') AS C ON CM.GroupId = C.GroupId 
left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1') E on C.CenterId = E.CenterId                                                                                                          LEFT join {mart_catalog}.{mart_schema}.p_hierarchy_sop X on D.HierarchyId=X.HierarchyId
WHERE (lower(D.Ageing_As_Per_DPD) <> 'closedclients') and upper(D.Branch_Type) = 'MFI' and (lower(D.IsDeath) <> 'yes' or D.IsDeath is null) and D.clientnpastatus not in (
'GNPA_Mar20_writeoff_mar22',
'GNPA_mar20_writeoff_Dec22',
'GNPA_Mar20_writeoff_Jun22',
'GNPA_mar20_writeoff_Sep22',
'GNPA_mar20_writeoff_Mar23',
'GNPA_mar20_writeoff_sep23',
'GNPA_mar20_writeoff_Jun23',
'GNPA_mar21_writeoff_Dec22',
'GNPA_Mar21_writeoff_mar22',
'GNPA_mar21_writeoff_Jun22',
'GNPA_mar21_writeoff_Sep22',
'GNPA_mar21_writeoff_Mar23',
'GNPA_mar21_writeoff_Jun23',
'GNPA_mar21_writeoff_sep23')),

P_Vraju_ClientWiseDPD_Final AS (
    SELECT * FROM P_Vraju_ClientWiseDPD_Final1 where lower(March1_NPA) <> 'yes'
),

t_din_as_on_arrear AS (
select A.ZONE,A.STATE,A.Region,A.Area,A.Unit,A.BRANCHID,A.BRANCHNAME,A.ClientiD,A.ClientCode,A.Clientname,A.SpouseName,
A.CenterID,A.CenterMeetingDay,
A.NO_Of_Active_Loans,A.staffid,A.staffname,A.POS, A.Arrear,A.EWI,A.JoinDate,A.Last_Repayment_Date,A.NoOfDaysInArrears,A.March1_NPA,A.IsDeath,
A.Monthend_ageing, A.Ageing,A.ExceptRemarks,CASE WHEN ExceptLog_Date = '1900-01-01' THEN NULL ELSE ExceptLog_Date END ExceptLog_Date,A.suv_client,A.clientNPAstatus,
CASE WHEN D.DISTRICT IS NOT NULL THEN D.DISTRICT ELSE '' END DISTRICT,A.MTD_Due,A.MTD_Coll,A.MTD_Due_Coll,
 ''New_CB  ,A.var_balance
from P_Vraju_ClientWiseDPD_Final A
LEFT JOIN {mart_catalog}.{mart_schema}.p_hierarchy_sop D ON A.BRANCHID = D.BRANCHID
where (lower(A.Monthend_ageing)  in ('new client','current1') or A.Monthend_ageing is NULL) and lower(A.Ageing) not in ( 'current1','closedclients')), 

P_bal_Wcr_HighRedalert1 AS (
select a.Zone ZoneName,a.State StateName,a.Region,a.Area,a.BranchID,a.BranchName,a.HierarchyId,a.CenterId,a.CenterCode    
          ,a.ClientCode,a.ClientName,a.ClientId,a.JoinDate,        
   a.CenterMeetingDay CM_Day,a.CenterStaffID StaffId,CAST(a.DisbursementDate as date)DisbDate,        
CAST(a.LoanAmountDisbursed as int)DisbAmt,a.ProductCategory,        
Ceiling(a.NoOfDaysInArrears1/7)+1 ArrearWeeks,CAST(a.POS as int)POS,a.DPDStartdate,a.LastRepaymentDate,        
CAST((coalesce(a.PrincipalInArears,0)+coalesce(a.InterestInArears,0)) as int) Arrear,        
(case         
when DATE_DIFF(DAY,a.DisbursementDate,CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date)) <=43 then 'Red Alert'        
when DATE_DIFF(DAY,a.DisbursementDate,CAST(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date)) <=85 then 'High Alert' else 'Error' end) `Alert Status`   
from {mart_catalog}.{mart_schema}.dailyloanfacts a
where (coalesce(a.PrincipalInArears,0)+coalesce(a.InterestInArears,0))>0 
and Branch_Type='MFI'),

T_bal_rh AS (
select distinct clientid,`Alert Status`,DisbDate,        
ROW_NUMBER()over(partition by clientid order by DisbDate) seq        
from P_bal_Wcr_HighRedalert1         
where lower(`Alert Status`)<>'error' 
),

P_bal_Wcr_HighRedalert2 AS
(select 
  A.ZoneName,
  A.StateName,
  A.Region,
  A.Area,
  A.BranchID,
  A.BranchName,
  A.HierarchyId,
  A.CenterId,
  A.CenterCode,
  A.ClientCode,
  A.ClientName,
  A.ClientId,
  A.JoinDate,
  A.CM_Day,
  A.StaffId,
  A.DisbDate,
  A.DisbAmt,
  A.ProductCategory,
  A.ArrearWeeks,
  A.POS,
  A.DPDStartdate,
  A.LastRepaymentDate,
  A.Arrear,
  CASE WHEN b.clientid IS NOT NULL THEN B.`Alert Status` ELSE A.`Alert Status` END `Alert Status`
  from P_bal_Wcr_HighRedalert1 A
  LEFT JOIN T_bal_rh B
  ON a.clientid=b.clientid and B.seq = 1),

P_bal_Wcr_HighRedalert3
(select 
  A.ZoneName,
  A.StateName,
  A.Region,
  A.Area,
  A.BranchID,
  A.BranchName,
  A.HierarchyId,
  A.CenterId,
  A.CenterCode,
  A.ClientCode,
  A.ClientName,
  A.ClientId,
  A.JoinDate,
  A.CM_Day,
  A.StaffId,
  A.DisbDate,
  A.DisbAmt,
  A.ProductCategory,
  A.ArrearWeeks,
  A.POS,
  A.DPDStartdate,
  A.LastRepaymentDate,
  A.Arrear,
  CASE WHEN B.clientid IS NOT NULL THEN B.`Alert Status` ELSE A.`Alert Status` END `Alert Status`
  from P_bal_Wcr_HighRedalert2 A
  LEFT JOIN T_bal_rh B
  ON a.clientid=b.clientid AND B.seq = 2 AND B.`Alert Status` = 'High Alert'),

P_bal_Wcr_HighRedalert_final AS (
select distinct Hierarchyid,ClientId,`Alert Status`
from P_bal_Wcr_HighRedalert3     
where lower(`Alert Status`)<>'error'),

P_bal_Wcr_HighRedalert_final2 AS (
SELECT 
  A.*,
  B.JoinDate,
  CASE WHEN C.ClientiD IS NOT NULL THEN 'Yes' ELSE 'No' END Fresh_Flow,
  CASE WHEN d.Hierarchyid IS NOT NULL THEN D.SBHState ELSE NULL END SBH,
  CASE WHEN d.Hierarchyid IS NOT NULL THEN D.UMBaseLocationBranchName ELSE NULL END unit,
  CASE WHEN B.JoinDate between '2023-04-01' and '2024-03-31' THEN 'Yes' ELSE 'No' END client_joined_this_FY
from P_bal_Wcr_HighRedalert_final A
LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') B 
ON A.clientid=B.clientid
LEFT JOIN t_din_as_on_arrear C
ON A.clientid = C.ClientiD
LEFT JOIN {mart_catalog}.{mart_schema}.p_hierarchy_sop D
ON a.Hierarchyid=d.Hierarchyid),

T_bal_weekly_due AS (
select a.clientid,SUM((coalesce(c.week_Due_Principle,0)+coalesce(c.Week_Due_Interest,0))) Week_Totaldue
from P_bal_Wcr_HighRedalert_final2 a    
join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` WHERE ETL_IS_ACTIVE = '1') b on a.clientid=b.clientid    
join {mart_catalog}.{mart_schema}.T_Vraju_Due_base1_Vraju c on b.ClientLoanId=c.clientloanid    
group by a.clientid),

P_bal_Wcr_HighRedalert_final3 AS (
SELECT 
  A.Hierarchyid,A.ClientId,A.`Alert Status`,A.JoinDate,A.Fresh_Flow,A.SBH,A.unit,A.client_joined_this_FY,
  CASE WHEN B.clientid IS NOT NULL THEN B.Week_Totaldue ELSE NULL END Week_Totaldue
FROM P_bal_Wcr_HighRedalert_final2 A
LEFT JOIN T_bal_weekly_due B
ON A.ClientId = B.clientid),

P_bal_Wcr_HighRedalert_final4 AS (
select b.HierarchyId,b.ZoneName,b.StateName,a.SBH,b.Region,b.Area,a.Unit,b.BranchID,b.BranchName,b.centercode,    
   b.CenterId,b.ClientId,b.ClientCode,b.StaffId,
  --  b.staffname,
   b.NO_Of_Active_Loans,
   b.Max_DisbursementDate,    
   b.LastRepaymentDate,
   b.Ageing,
   (b.PrINcipalINArears+b.INterestINArears) as Arrear,b.POS,a.`Alert Status` Alert_Status,    
   a.client_joined_this_FY,
  a.Joindate ,a.Fresh_Flow ,a.Week_Totaldue,CenterMeetingDay    
from P_bal_Wcr_HighRedalert_final3 a    
join {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary b on a.ClientId=b.ClientId)

SELECT * from P_bal_Wcr_HighRedalert_final4""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"nb_p_wcr_highredalert_final4_batch Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on nb_p_wcr_highredalert_final4_batch: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_wcr_highredalert_final4_batch : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_wcr_highredalert_final4_batch")

    logger(
            logger_level_info,
            f"nb_p_wcr_highredalert_final4_batch writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table nb_p_wcr_highredalert_final4_batch : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table nb_p_wcr_highredalert_final4_batch : ", str(e))


# COMMAND ----------

# Clear Cache to free memory
df.unpersist()