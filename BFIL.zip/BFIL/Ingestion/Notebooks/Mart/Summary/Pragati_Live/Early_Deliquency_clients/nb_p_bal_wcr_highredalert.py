# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_p_bal_wcr_highredalert.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_table = dbutils.widgets.get("mart_table")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_url")
    desti_path = "BFIL-MART/REPORTING/P_BAL_WCR_HIGHREDALERT"
    path = mart_layer_abfss_url + desti_path

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH T_Vraju_BM_UM_Total_Active_Centers AS (
select b.`ZONE` as `ZONE NAME`, b.state, b.`AREA` as `AREA OFFICE`, b.Region , b.BRANCHID as BRANCH_ID, b.`BRANCHNAME` `BRANCH NAME`, B.UMBaseLocationBranchName UnitOffice, b.DISTRICT, b.HierarchyId , a.CenterId ,a.CenterCode, a.CenterName, a.FormationDate, (case when a.CenterMeetingDay = 1 then 'Monday' when A.CenterMeetingDay = 2 then
'Tuesday' when A.CenterMeetingDay = 3 then 'Wednesday'when
A.CenterMeetingDay = 4 then 'Thursday' else 'Friday' end)  as CenterMeetingDay, a.StaffId
    from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) a 
    left join {mart_catalog}.{mart_schema}.p_hierarchy_sop b
    on a.HierarchyId = b.HierarchyId
    where coalesce(a.DissolvedDate,'1900-01-01' )='1900-01-01' and b.`ZONE` not in ('AP','TS')),

T_Vraju_BM_UM_GivenCenters_ActiveClients AS (
select a.*, count(distinct clm.clientid) `No Of Active Clients`
    from T_Vraju_BM_UM_Total_Active_Centers a join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) cm on a.centerid = cm.centerid
        Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) gm On cm.CenterId=gm.CenterId
        Join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) clm On gm.GroupId=clm.GroupId
    where coalesce(clm.DropOutDate,'1900-01-01')='1900-01-01'
    Group by a.CenterId,a.CenterCode,a.CenterName,a.FormationDate,a.CenterMeetingDay,a.HierarchyId,a.BRANCH_ID,
a.`BRANCH NAME`,
-- a.[Branch growth status],
a.DISTRICT,
a.`ZONE NAME`,a.Region,a.`AREA OFFICE`,a.STATE,a.UnitOffice,a.StaffId),

T_Vraju_BM_UM_Total_Active_Groups AS (
select a.CenterId, count(GroupId)ActiveGroups
    from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) A left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) B
        ON A.CenterId=B.CenterId
    where coalesce(b.DissolvedDate,'1900-01-01' )='1900-01-01'
    group by a.CenterId),

T_Vraju_Base_Loans_Vraju AS (
select clientLoanid, HierarchyId , CODDate as LastSyncDate_COB
    from {mart_catalog}.{mart_schema}.dailyloanfacts
    where DisbursementDate >='2017-01-01'
        and Branch_Type = '1. MFI' and coalesce(LoanCLosedDate,'1900-01-01' )='1900-01-01'),

T_Vraju_Due_base1_Vraju AS (
SELECT T.ClientLoanId, T.HierarchyId
        ,sum (case when  CAST(AV.valuedate as date) <= (CAST(GETDATE() as date) -1)   then    AV.PrincipalAmount end)  `Total Due Principle`,
        sum(case when    CAST(AV.valuedate as date) <= (CAST(GETDATE() as date)-1)  then     AV.InterestAmount end)  `Total Due Interest`,
        sum(case when    CAST(AV.TransactionDate as date) >=(CAST(GETDATE() as date)+1) and CAST(AV.TransactionDate as date) <= (CAST(GETDATE() as date)+5)  then AV.PrincipalAmount end)  `week Due Principle`,
        sum(case when CAST(AV.TransactionDate as date) >=(CAST(GETDATE() as date)+1) and CAST(AV.TransactionDate as date) <= (CAST(GETDATE() as date)+5)  then AV.InterestAmount end)  `Week Due Interest`
    FROM T_Vraju_Base_Loans_Vraju T
        JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-at_loantransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AV ON
Av.ClientLoanId = T.ClientLoanId and T.HierarchyId=Av.HierarchyId
    where (AV.TransactionType ='C'and AV.DebitOrCredit ='D')
    group by T.ClientLoanId,T.HierarchyId),

P_allKycs_all AS (
select A.ClientId,B.PhoneNumber,B.MobileNumber
from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) A
JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-kycdetails` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) B
ON A.TargetId = B.TargetId),

T_sha_Feb20_NPA AS (
select distinct clientid from {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary           
where npa_date <='2021-03-31'),

P_Vraju_ClientWiseDPD_Final AS (
SELECT X.`ZONE`, x.STATE, X.Region,X.`Area` as Area,x.`UMBaseLocationBranchName` as Unit                                 
, x.BRANCHID, x.`BRANCHNAME`,                                                                       
D.ClientiD, cm.ClientCode, cm.Clientname,E.CenterMeetingDay,                
D.staffid,D.staffname ,cm.JoinDate,Ageing,                      
 D.POS, (D.PrINcipalINArears+D.INterestINArears)Arrear,D.NO_Of_Active_Loans,
D.Var_balance,                                             
D.LastRepaymentDate as Last_Repayment_Date,NoOfDaysInArrears,  d.suv_client,                                  
case when D.ClientiD in (select Distinct Clientid from T_sha_Feb20_NPA) then 'yes' else 'No' end as March1_NPA,                                                            
D.IsDeath,'' Month_End_Status,D.Monthend_Ageing,D.EWI,D.ClientNPAstatus ,                                                
 (MTD_Due) ,  (MTD_Coll) ,  (MTD_Due_Coll) ,
Ason_collPaid, PM_CollPaid,                                                                                                  
cast('' as STRING) as SpouseName,                                                                                                   
D.As_on_Paidstatus as 4_EWI_Paid_Arrear_Client_As_On,
D.PM_Paidstatus as 4_EWI_Paid_Arrear_Client_PM,                                                                                    
CASE WHEN G.MobileNumber IS NOT NULL THEN G.MobileNumber ELSE '' END MobileNumber,                                                                      
CASE WHEN G.PhoneNumber IS NOT NULL THEN G.PhoneNumber ELSE '' END PhoneNumber,                                                                                                  
cast('' as Varchar (500)) as ExceptRemarks,                                                                                                  
cast(''as TIMESTAMP) as ExceptLog_Date,                                                                                              
E.CenterID  ,  d.centername,d.centercode,  Max_DisbursementDate,CASE WHEN F.ProductCategory IS NOT NULL THEN F.ProductCategory ELSE '' END Max_produccategory,''New_CB                                                                                   
FROM {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary AS D 
left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) cm on d.ClientId=cm.ClientId 
left join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-groupmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) AS C ON CM.GroupId = C.GroupId 
left JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-centermaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) E on C.CenterId = E.CenterId                                                                                                          LEFT join {mart_catalog}.{mart_schema}.p_hierarchy_sop X on D.HierarchyId=X.HierarchyId
LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts F ON D.Clientid = F.Clientid and D.Max_DisbursementDate=F.DisbursementDate
LEFT JOIN P_allKycs_all G ON G.Clientid = cm.Clientid
WHERE lower(D.Ageing_As_Per_DPD) <> 'closedclients' and upper(D.Branch_Type) = '1. MFI' and lower(D.IsDeath) <> 'yes'
and D.ClientiD not in (select Distinct Clientid from T_sha_Feb20_NPA) and D.clientnpastatus not in (
'GNPA_Mar20_writeoff_mar22',
'GNPA_mar20_writeoff_Dec22',
'GNPA_Mar20_writeoff_Jun22',
'GNPA_mar20_writeoff_Sep22',
'GNPA_mar20_writeoff_Mar23',
'GNPA_mar20_writeoff_sep23',
'GNPA_mar20_writeoff_Jun23',
'GNPA_mar21_writeoff_Dec22',
'GNPA_Mar21_writeoff_mar22',
'GNPA_mar21_writeoff_Jun22',
'GNPA_mar21_writeoff_Sep22',
'GNPA_mar21_writeoff_Mar23',
'GNPA_mar21_writeoff_Jun23',
'GNPA_mar21_writeoff_sep23')),

t_din_as_on_arrear AS (
select A.ZONE,A.STATE,A.Region,A.Area,A.Unit,A.BRANCHID,A.BRANCHNAME,A.ClientiD,A.ClientCode,A.Clientname,A.SpouseName,
-- CASE WHEN (a.MobileNumber  = '' or a.MobileNumber is null) and E.MobileNumber is not NULL THEN E.MobileNumber WHEN a.PhoneNumber <> '' and ((a.MobileNumber = '') or (a.MobileNumber is null)) THEN A.PhoneNumber WHEN (a.MobileNumber = '' or a.MobileNumber is null) THEN NULL ELSE A.MobileNumber END MobileNumber,
A.PhoneNumber,A.CenterID,A.CenterMeetingDay,
A.NO_Of_Active_Loans,A.staffid,A.staffname,A.POS, A.Arrear,A.EWI,A.JoinDate,A.Last_Repayment_Date,A.NoOfDaysInArrears,A.March1_NPA,A.IsDeath,
A.Monthend_ageing, A.Ageing,A.ExceptRemarks,CASE WHEN ExceptLog_Date = '1900-01-01' THEN NULL ELSE ExceptLog_Date END ExceptLog_Date,A.suv_client,A.clientNPAstatus ,CASE WHEN B.Month_END_POS IS NOT NULL THEN B.Month_END_POS ELSE '' END Month_END_POS,CASE WHEN B.DPDstartdate IS NOT NULL THEN B.DPDstartdate ELSE '' END DPDstartdate,CASE WHEN B.Max_DisbursementDate IS NOT NULL THEN B.Max_DisbursementDate ELSE A.Max_Disbursementdate END Max_DisbursementDate,
CASE WHEN C.ProductCategory IS NOT NULL THEN C.ProductCategory ELSE '' END Max_Disbursed_ProductCategory,CASE WHEN D.DISTRICT IS NOT NULL THEN D.DISTRICT ELSE '' END DISTRICT,A.MTD_Due,A.MTD_Coll,A.MTD_Due_Coll,CASE WHEN B.CODDate IS NOT NULL THEN B.CODDate ELSE '' END CODDate,
-- CASE WHEN B.SB_AccountID IS NOT NULL THEN B.SB_AccountID ELSE '' END SB_AccountID ,
-- CASE WHEN E.MobileNumber IS NOT NULL THEN E.MobileNumber ELSE '' END MobileNum,'' OTP_Based_MobileNumber,
 ''New_CB  ,A.var_balance
from P_Vraju_ClientWiseDPD_Final A
LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary B on A.Clientid = B.Clientid
LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-kycdetails` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) E ON E.TargetId = B.TargetId
LEFT JOIN {mart_catalog}.{mart_schema}.dailyloanfacts C ON A.Clientid = C.Clientid
LEFT JOIN {mart_catalog}.{mart_schema}.p_hierarchy_sop D ON A.BRANCHID = D.BRANCHID
where lower(A.Monthend_ageing)  in ('new client','current1') and A.Monthend_ageing is NULL and lower(A.Ageing) not in ( 'current1','closedclients')), 

P_bal_Wcr_HighRedalert1 AS (
select a.Zone ZoneName,a.State StateName,a.Region,a.Area,a.BranchID,a.BranchName,a.HierarchyId,a.CenterId,a.CenterCode    
          ,a.ClientCode,a.ClientName,a.ClientId,a.JoinDate,        
   a.CenterMeetingDay CM_Day,a.CenterStaffID StaffId,CAST(a.DisbursementDate as date)DisbDate,        
CAST(a.LoanAmountDisbursed as int)DisbAmt,a.ProductCategory,        
Ceiling(a.NoOfDaysInArrears1/7)+1 ArrearWeeks,CAST(a.POS as int)POS,a.DPDStartdate,a.LastRepaymentDate,        
CAST((coalesce(a.PrincipalInArears,0)+coalesce(a.InterestInArears,0)) as int) Arrear,        
(case         
when DATE_DIFF(DAY,a.DisbursementDate,CAST(GETDATE() as date)) <=43 then 'Red Alert'        
when DATE_DIFF(DAY,a.DisbursementDate,CAST(GETDATE() as date)) <=85 then 'High Alert' else 'Error' end) `Alert Status`   
from {mart_catalog}.{mart_schema}.dailyloanfacts a
where (coalesce(a.PrincipalInArears,0)+coalesce(a.InterestInArears,0))>0 
and Branch_Type='1. MFI'),

T_bal_rh AS (
select distinct clientid,`Alert Status`,DisbDate,        
ROW_NUMBER()over(partition by clientid order by DisbDate) seq        
from P_bal_Wcr_HighRedalert1         
where lower(`Alert Status`)='error' 
),

P_bal_Wcr_HighRedalert2 AS
(select 
  A.ZoneName,
  A.StateName,
  A.Region,
  A.Area,
  A.BranchID,
  A.BranchName,
  A.HierarchyId,
  A.CenterId,
  A.CenterCode,
  A.ClientCode,
  A.ClientName,
  A.ClientId,
  A.JoinDate,
  A.CM_Day,
  A.StaffId,
  A.DisbDate,
  A.DisbAmt,
  A.ProductCategory,
  A.ArrearWeeks,
  A.POS,
  A.DPDStartdate,
  A.LastRepaymentDate,
  A.Arrear,
  CASE WHEN B.seq = 1 THEN B.`Alert Status` ELSE A.`Alert Status` END `Alert Status`
  from P_bal_Wcr_HighRedalert1 A
  LEFT JOIN T_bal_rh B
  ON a.clientid=b.clientid),

P_bal_Wcr_HighRedalert3
(select 
  A.ZoneName,
  A.StateName,
  A.Region,
  A.Area,
  A.BranchID,
  A.BranchName,
  A.HierarchyId,
  A.CenterId,
  A.CenterCode,
  A.ClientCode,
  A.ClientName,
  A.ClientId,
  A.JoinDate,
  A.CM_Day,
  A.StaffId,
  A.DisbDate,
  A.DisbAmt,
  A.ProductCategory,
  A.ArrearWeeks,
  A.POS,
  A.DPDStartdate,
  A.LastRepaymentDate,
  A.Arrear,
  CASE WHEN B.seq = 2 AND B.`Alert Status` = 'High Alert' THEN B.`Alert Status` ELSE A.`Alert Status` END `Alert Status`
  from P_bal_Wcr_HighRedalert2 A
  LEFT JOIN T_bal_rh B
  ON a.clientid=b.clientid),

P_bal_Wcr_HighRedalert_final AS (
select distinct Hierarchyid,ClientId,`Alert Status`,StaffId
from P_bal_Wcr_HighRedalert3     
where lower(`Alert Status`)<>'error'),

P_bal_Wcr_HighRedalert_final2 AS (
SELECT 
  A.*,
  B.JoinDate,
  CASE WHEN C.ClientiD IS NOT NULL THEN 'Yes' ELSE 'No' END Fresh_Flow,
  CASE WHEN d.Hierarchyid IS NOT NULL THEN D.SBHState ELSE NULL END SBH,
  CASE WHEN d.Hierarchyid IS NOT NULL THEN D.UMBaseLocationBranchName ELSE NULL END unit,
  CASE WHEN B.JoinDate between '2023-04-01' and '2024-03-31' THEN 'Yes' ELSE 'No' END client_joined_this_FY
from P_bal_Wcr_HighRedalert_final A
LEFT JOIN (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) B 
ON A.clientid=B.clientid
LEFT JOIN t_din_as_on_arrear C
ON A.clientid = C.ClientiD
LEFT JOIN {mart_catalog}.{mart_schema}.p_hierarchy_sop D
ON a.Hierarchyid=d.Hierarchyid),

T_bal_weekly_due AS (
select a.clientid,SUM((coalesce(c.`week Due Principle`,0)+coalesce(c.`Week Due Interest`,0))) Week_Totaldue
from P_bal_Wcr_HighRedalert_final2 a    
join (SELECT * FROM {source_catalog}.{source_schema}.`pragati-clientloansubscription` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL) b on a.clientid=b.clientid    
join T_Vraju_Due_base1_Vraju c on b.ClientLoanId=c.clientloanid    
group by a.clientid),

P_bal_Wcr_HighRedalert_final3 AS (
SELECT 
  A.Hierarchyid,A.ClientId,A.`Alert Status`,A.JoinDate,A.Fresh_Flow,A.SBH,A.unit,A.client_joined_this_FY,
  CASE WHEN B.clientid IS NOT NULL THEN B.Week_Totaldue ELSE NULL END Week_Totaldue,StaffId
FROM P_bal_Wcr_HighRedalert_final2 A
LEFT JOIN T_bal_weekly_due B
ON A.ClientId = B.clientid),

P_bal_Wcr_HighRedalert_final4 AS (
select b.HierarchyId,b.ZoneName,b.StateName,a.SBH,b.Region,b.Area,a.Unit,b.BranchID,b.BranchName,b.centercode,    
   b.CenterId,b.ClientId,b.ClientCode,a.StaffId,
  --  b.staffname,
   b.NO_Of_Active_Loans,
   b.Max_DisbursementDate,    
   b.LastRepaymentDate,
   b.Ageing,
   (b.PrINcipalINArears+b.INterestINArears) as Arrear,b.POS,a.`Alert Status` Alert_Status,    
   a.client_joined_this_FY,
  a.Joindate ,a.Fresh_Flow ,a.Week_Totaldue,CenterMeetingDay    
from P_bal_Wcr_HighRedalert_final3 a    
join {mart_catalog}.{mart_schema}.dailyloanfacts_client_summary b on a.ClientId=b.ClientId),

ftd_Coll_redhigh AS (
select ClientId, SUM(Amount) Coll from (
select ClientId, ValueDate, Amount
  from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-at_loantransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)
  where cast(ValueDate as date)=cast(GETDATE() as date) - 1 and Amount>0
union all
  select ClientId, ValueDate, Amount
  from (SELECT * FROM {source_catalog}.{source_schema}.`pragati-at_loandaytransactions` WHERE ETL_IS_ACTIVE = '1' OR ETL_IS_ACTIVE IS NULL)
  where cast(ValueDate as date)=cast(GETDATE() as date) - 1 and Amount>0)
  group by ClientId)

select a.HierarchyId,a.ZoneName,a.StateName,a.SBH,a.Region,a.Area,a.Unit,a.BranchID,a.BranchName,a.centercode,
   a.CenterId,a.ClientId,a.ClientCode,a.StaffId,
   a.Max_DisbursementDate,
   a.LastRepaymentDate,
   a.Arrear,a.POS,a.Alert_Status,
   a.client_joined_this_FY,
  a.Joindate ,a.Fresh_Flow ,a.Week_Totaldue,a.CenterMeetingDay,
  CASE WHEN b.clientid IS NOT NULL THEN b.Coll ELSE NULL END Ftd_Coll,
  (coalesce(Ftd_Coll,0)/coalesce(a.Week_Totaldue,0)) PaidEWI,
  CASE WHEN PaidEWI >= 1 THEN 'Paid' else 'Not Paid' END Paid_Status
from P_bal_Wcr_HighRedalert_final4 a
LEFT JOIN ftd_Coll_redhigh b
ON a.clientid = b.clientid;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"p_bal_wcr_highredalert Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on p_bal_wcr_highredalert: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on p_bal_wcr_highredalert : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.{mart_table}")

    logger(
            logger_level_info,
            f"p_bal_wcr_highredalert writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table p_bal_wcr_highredalert : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table p_bal_wcr_highredalert : ", str(e))

# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', source_row_count, destination_row_count, log_error_success, desti_path, 'NULL', execution_log_list)