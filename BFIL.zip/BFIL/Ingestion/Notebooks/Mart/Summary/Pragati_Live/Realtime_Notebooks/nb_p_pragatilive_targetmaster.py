# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_insert_log"

# COMMAND ----------

filename = "nb_p_pragatilive_targetmaster.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_PRAGATILIVE_TARGETMASTER"

    run_id = dbutils.widgets.get("run_id")
    table_name = dbutils.widgets.get("table_name")
    adb_synapse_connection_string = dbutils.widgets.get("adb_synapse_connection_string")
    synapse_catalog = dbutils.widgets.get("synapse_catalog")
    synapse_schema = dbutils.widgets.get("synapse_schema")

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH LatestTargetMaster AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY TargetId ORDER BY CAST(ETL_CREATED_DATE as date) DESC) AS rank
    FROM {source_catalog}.{source_schema}.targetmaster_append_rts
    WHERE ETL_IS_ACTIVE = '1'
),
FilteredLatestTargetMaster AS (
    SELECT *
    FROM LatestTargetMaster
    WHERE rank = 1
),
MaxCreatedDateSubquery AS (
    SELECT 
        SUBSTRING(MAX(CAST(ETL_CREATED_DATE AS timestamp)), 12, 5) AS MaxCreatedTime
    FROM FilteredLatestTargetMaster
),
FinalData AS (
    SELECT 
        Hierarchyid,
        Targetid,
        targetcode,
        Targetname,
        staffid,
        CAST(targetdate AS timestamp) AS targetdate,
        HOUR(createddatetime) AS Hour,
        CAST(createddatetime AS timestamp) AS createddatetime,
        CASE 
            WHEN SUBSTRING(CAST(createddatetime AS timestamp), 12, 5) <= 
                (SELECT MaxCreatedTime FROM MaxCreatedDateSubquery) 
            THEN '1.Before' 
            ELSE '2.After' 
        END AS TimeStatus
    FROM FilteredLatestTargetMaster A
    WHERE CAST(targetdate AS date) = CAST(GETDATE() AS date) 
      AND (CAST(ETL_CREATED_DATE AS date) = CAST(GETDATE() AS date) 
           OR CAST(ETL_LAST_UPDATED_DATE AS date) = CAST(GETDATE() AS date))

    UNION ALL

    SELECT 
        Hierarchyid,
        Targetid,
        targetcode,
        Targetname,
        staffid,
        CAST(targetdate AS timestamp) AS targetdate,
        HOUR(createddatetime) AS Hour,
        CAST(createddatetime AS timestamp) AS createddatetime,
        CASE 
            WHEN SUBSTRING(CAST(createddatetime AS timestamp), 12, 5) <= 
                (SELECT MaxCreatedTime FROM MaxCreatedDateSubquery WHERE) 
            THEN '1.Before' 
            ELSE '2.After' 
        END AS TimeStatus
    FROM {mart_catalog}.{mart_schema}.targetmaster_pragati_live B
    WHERE CAST(targetdate AS date) >= CAST(GETDATE() AS date) - INTERVAL 35 DAY
)
SELECT *
FROM FinalData;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).coalesce(1).cache()
    logger(
        logger_level_info,
        f"nb_p_pragatilive_targetmaster Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error while executing query on nb_p_pragatilive_targetmaster: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_pragatilive_targetmaster : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
# try :

#     df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_pragatilive_targetmaster")

#     logger(
#             logger_level_info,
#             f"nb_p_pragatilive_targetmaster writing to delta table has been successfully completed.",
#             execution_log_list,
#             filename,
#     )
# except Exception as e:
#     insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
#     logger(
#         logger_level_error,
#         f"error occured while writing data into delta table nb_p_pragatilive_targetmaster : {str(e)}",
#         execution_log_list,
#         filename,
#     )
#     print(*execution_log_list, sep="\n")
#     # Handle the exception or display the error message as needed
#     raise Exception("error occured while writing data into delta table nb_p_pragatilive_targetmaster : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing dataframe to Snowflake
try :

    df.write.format("snowflake").options(**options).option("mergeSchema", "true").option("dbtable", "p_pragatilive_targetmaster").mode("overwrite").save()

    logger(
            logger_level_info,
            f"nb_p_pragatilive_targetmaster writing to Snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error occured while writing data into Snowflake table nb_p_pragatilive_targetmaster : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into Snowflake table nb_p_pragatilive_targetmaster : ", str(e))


# COMMAND ----------

# DBTITLE 1,Insert Log
error = None
insert_log(run_id,table_name,log_status_success,synapse_catalog,synapse_schema,adb_synapse_connection_string,error)

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()