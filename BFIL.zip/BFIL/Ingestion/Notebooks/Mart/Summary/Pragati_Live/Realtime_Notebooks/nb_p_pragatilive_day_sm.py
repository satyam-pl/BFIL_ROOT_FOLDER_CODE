# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_insert_log"

# COMMAND ----------

filename = "nb_p_pragatilive_day_sm.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_PRAGATILIVE_DAY_SM"

    run_id = dbutils.widgets.get("run_id")
    table_name = dbutils.widgets.get("table_name")
    adb_synapse_connection_string = dbutils.widgets.get("adb_synapse_connection_string")
    synapse_catalog = dbutils.widgets.get("synapse_catalog")
    synapse_schema = dbutils.widgets.get("synapse_schema")

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH CTE_P_PragatiLive_TargetMaster as (SELECT * FROM {mart_catalog}.{mart_schema}.p_pragatilive_targetmaster),

CTE_P_PragatiLive_ClientMaster as(SELECT * FROM {mart_catalog}.{mart_schema}.p_pragatilive_clientmaster),

T_StaffDbProcess as (
select a.*                 
from (SELECT * FROM edp_curated_prod.bfil.tabdbstaffprocessdetails_rts) a inner join                   
(select staffid, max(SEQUENCEID ) SEQUENCEID                    
from edp_curated_prod.bfil.tabdbstaffprocessdetails_rts                         
group by   staffid) b                     
on a.STAFFID =b.STAFFID                         
and a.SEQUENCEID=b.SEQUENCEID),

CTE_P_PragatiLive_Day_SM AS (
Select HIERARCHYID,STAFFID ,1 as Cnt,cast('Acive Staff' as Varchar(200))as Type1, 0 as Target1,0 as Achive     ,'AAAAAAAAAAAAAA' CNt_Category
from T_StaffDBProcess 
Group by HIERARCHYID,STAFFID
UNION
Select HIERARCHYID,SMID as StaffID,Count(ClientID) as Cnt,cast('MA' as Varchar(200))as Type1,0 as Target1,0 as Achive  ,'AAAAAAAAAAAAAA' CNt_Category
from CTE_P_PragatiLive_ClientMaster where Joindate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)
Group by HIERARCHYID,SMID
UNION
Select HIERARCHYID,Staffid as StaffID,Count(TargetID) as Cnt, 'TD' as Type1 ,0 as Target1,0 as Achive    ,'AAAAAAAAAAAAAA' CNt_Category
from CTE_P_PragatiLive_TargetMaster where TargetDate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date)
Group by HIERARCHYID,Staffid
UNION
Select HIERARCHYID, Updatedby  as StaffID,Count(LoanProposalID)Cnt,  'MFI/Unnati-NOL' as Type1 ,0 as Target1,0 as Achive ,'AAAAAAAAAAAAAA' CNt_Category
from {mart_catalog}.{mart_schema}.p_pragatilive_hourly_proposal where ProposalDate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date) and  ProductCode in('15','800')
Group by HIERARCHYID, Updatedby
UNION
Select HIERARCHYID,Updatedby  as StaffID,Count(LoanProposalID)Cnt,  'CDF-NOL' as Type1 ,0 as Target1,0 as Achive ,'AAAAAAAAAAAAAA' CNt_Category
from {mart_catalog}.{mart_schema}.p_pragatilive_hourly_proposal where ProposalDate=cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata') as date) and  ProductCode not in('15','800')
Group by HIERARCHYID,Updatedby
UNION
Select HIERARCHYID,Staffid as StaffID,Sum(Account_count) as Cnt , 'RD/RD' as Type1,0 as Target1,0 as Achive,'AAAAAAAAAAAAAA' CNt_Category
from {mart_catalog}.{mart_schema}.P_PragatiLive_AccountOpenData where AccountType in('RD','FD')
Group by HIERARCHYID,Staffid),

 CTE_activeStaff as (

    Select distinct HIERARCHYID,Staffid from CTE_P_PragatiLive_Day_SM
),

 cte_P_PragatiLive_Day_SM_Dup as (

select a.HIERARCHYID,a.STAFFID,0 CNt,'MFI/Unnati-NOL'Type1, 0 Target1,0 Achive, 'AAAAAAAAAAAAAA' CNt_Category
from CTE_activeStaff a left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'MFI/Unnati-NOL'
where b.staffid is null
UNION
Select a.HIERARCHYID,a.STAFFID,0 CNt,'MA'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'MA'
where b.staffid is null
UNION
Select a.HIERARCHYID,a.STAFFID,0 CNt,'CDF-NOL'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'CDF-NOL'
where b.staffid is null
UNION
Select a.HIERARCHYID,a.STAFFID,0 CNt,'RD/RD'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a
 left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'RD/RD'
where b.staffid is null
 UNION
Select a.HIERARCHYID,a.STAFFID,0 CNt,'TD'Type1, 0 Target1,0 Achive,''
from CTE_activeStaff a
left join CTE_P_PragatiLive_Day_SM b on a.staffid = b.staffid and b.type1 = 'TD'
where b.staffid is null
),

CTE_P_PragatiLive_combined as (

    select * from CTE_P_PragatiLive_Day_SM
    UNION all
    select * from cte_P_PragatiLive_Day_SM_Dup
)

select HIERARCHYID,STAFFID,CNt,Type1,
case when Type1='MA'   then  2
when Type1='RD/RD'            then  2
when Type1='CDF-NOL'          then  1
when Type1='MFI/Unnati-NOL'   then  5 else 0 end as Target2,
case when Type1='MA'        and Cnt>=Target2 then  1
when Type1='RD/RD'          and Cnt>=Target2 then  1
when Type1='CDF-NOL'        and Cnt>=Target2 then  1
when Type1='MFI/Unnati-NOL' and Cnt>=Target2 then  1 else 0 end as Achive,
case when cast(Cnt as INT) >= CAST(Target2 as INT) then concat(cast(Target2 as string), ' & More') else cast(cnt as string) end  as CNt_Category
From CTE_P_PragatiLive_combined;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).coalesce(1).cache()
    logger(
        logger_level_info,
        f"nb_p_pragatilive_day_sm Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error while executing query on nb_p_pragatilive_day_sm: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_pragatilive_day_sm : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
# try :

#     df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_pragatilive_day_sm")

#     logger(
#             logger_level_info,
#             f"nb_p_pragatilive_day_sm writing to delta table has been successfully completed.",
#             execution_log_list,
#             filename,
#     )
# except Exception as e:
#     insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
#     logger(
#         logger_level_error,
#         f"error occured while writing data into delta table nb_p_pragatilive_day_sm : {str(e)}",
#         execution_log_list,
#         filename,
#     )
#     print(*execution_log_list, sep="\n")
#     # Handle the exception or display the error message as needed
#     raise Exception("error occured while writing data into delta table nb_p_pragatilive_day_sm : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing dataframe to Snowflake
try :

    df.write.format("snowflake").options(**options).option("mergeSchema", "true").option("dbtable", "p_pragatilive_day_sm").mode("overwrite").save()

    logger(
            logger_level_info,
            f"nb_p_pragatilive_day_sm writing to Snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error occured while writing data into Snowflake table nb_p_pragatilive_day_sm : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into Snowflake table nb_p_pragatilive_day_sm : ", str(e))


# COMMAND ----------

# DBTITLE 1,Insert Log
error = None
insert_log(run_id,table_name,log_status_success,synapse_catalog,synapse_schema,adb_synapse_connection_string,error)

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()