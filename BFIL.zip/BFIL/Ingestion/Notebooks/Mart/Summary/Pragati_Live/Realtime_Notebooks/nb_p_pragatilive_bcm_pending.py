# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_insert_log" 

# COMMAND ----------

filename = "nb_p_pragatilive_bcm_pending.dbc"

# COMMAND ----------

try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/P_PRAGATILIVE_BCM_PENDING"
    
    run_id = dbutils.widgets.get("run_id")
    table_name = dbutils.widgets.get("table_name")
    adb_synapse_connection_string = dbutils.widgets.get("adb_synapse_connection_string")
    synapse_catalog = dbutils.widgets.get("synapse_catalog")
    synapse_schema = dbutils.widgets.get("synapse_schema")

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """SELECT * from
(WITH cte_PLD_BCM_Pending as(
select Hierarchyid,Clientid,LoanProposalid,ApprovedAmount LoanAmountApproved,PaymentStatus,Proposaldate   ,productcode
from {mart_catalog}.{mart_schema}.disbursement_facts
where  lower(paymentstatus) = 'bcm pending' and productcode in (15,800,1100)
),

cte_bcm_pending as
(
Select Hierarchyid,Clientid,LoanProposalid,LoanAmountApproved,PaymentStatus,Proposaldate,productcode from cte_PLD_BCM_Pending
union
(Select Hierarchyid,Clientid,LoanProposalid,LoanAmountApproved,'BCM Pending' PaymentStatus,Proposaldate,productcode
from  {mart_catalog}.{mart_schema}.p_pragatilive_hourly_proposal
where  Proposaldate >= cast(from_utc_timestamp(current_timestamp(), 'Asia/Kolkata')  as date) and productcode in (15,800,1100))
),

CTE_BCM_Pending_2 as (
select
a.Hierarchyid,a.Clientid,a.LoanProposalid,LoanAmountApproved,
(case when b.loanproposalid is not null or c.loanproposalid is not null then 'Approved' else paymentstatus end) as paymentstatus,
Proposaldate,productcode
from cte_bcm_pending a
left join edp_bfil_prod.bfil_mart.cte_pld_cashlessdisbursements b on a.loanproposalid = b.loanproposalid
left join (SELECT * FROM {source_catalog}.{source_schema}.cashlessdisbursements_rts WHERE ETL_IS_ACTIVE = '1' AND (CAST(ETL_CREATED_DATE as date) = CAST(getdate() as date) OR CAST(ETL_LAST_UPDATED_DATE as date) = CAST(getdate() as date))) c on a.loanproposalid = c.loanproposalid)

select hierarchyid,proposaldate,paymentstatus,sum(loanamountapproved)loanamountapproved,count(1)NOP ,case when productcode = '1100' then 1 else 0 end is_EL
from CTE_BCM_Pending_2 a
where lower(paymentstatus) = 'bcm pending' and proposaldate >= cast(from_utc_timestamp(current_timestamp(),'Asia/Kolkata')  as date) - 6
group by hierarchyid,paymentstatus,proposaldate,case when productcode = '1100' then 1 else 0 end);""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).coalesce(1).cache()
    logger(
        logger_level_info,
        f"nb_p_pragatilive_bcm_pending Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error while executing query on nb_p_pragatilive_bcm_pending: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on nb_p_pragatilive_bcm_pending : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table
# try :

#     df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.p_pragatilive_bcm_pending")

#     logger(
#             logger_level_info,
#             f"nb_p_pragatilive_bcm_pending writing to delta table has been successfully completed.",
#             execution_log_list,
#             filename,
#     )
# except Exception as e:
#     insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
#     logger(
#         logger_level_error,
#         f"error occured while writing data into delta table nb_p_pragatilive_bcm_pending : {str(e)}",
#         execution_log_list,
#         filename,
#     )
#     print(*execution_log_list, sep="\n")
#     # Handle the exception or display the error message as needed
#     raise Exception("error occured while writing data into delta table nb_p_pragatilive_bcm_pending : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing dataframe to Snowflake Table
try:

    df.write.format("snowflake").options(**options).option(
        "mergeSchema", "true"
    ).option("dbtable", "p_pragatilive_bcm_pending").mode("overwrite").save()

    logger(
        logger_level_info,
        f"nb_p_pragatilive_bcm_pending writing to Snowflake table has been successfully completed.",
        execution_log_list,
        filename,
    )
except Exception as e:
    insert_log(run_id,table_name,log_status_failure,synapse_catalog,synapse_schema,adb_synapse_connection_string,e)
    logger(
        logger_level_error,
        f"error occured while writing data into Snowflake table nb_p_pragatilive_bcm_pending : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception(
        "error occured while writing data into Snowflake table nb_p_pragatilive_bcm_pending : ",
        str(e),
    )

# COMMAND ----------

# DBTITLE 1,Insert Log
error = None
insert_log(run_id,table_name,log_status_success,synapse_catalog,synapse_schema,adb_synapse_connection_string,error)

# COMMAND ----------

# Clear Cache to free memory
df.unpersist()