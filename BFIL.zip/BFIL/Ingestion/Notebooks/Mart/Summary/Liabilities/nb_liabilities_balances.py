# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_liabilities_balances.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/LIABILITIES_BALANCES"
    desti_path = "BFIL-MART/REPORTING/LIABILITIES_BALANCES"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """with P_Dailydashboard_Liabilities_Balances AS (
    SELECT
        Hierarchyid,
        AccountConversion,
        AccountOpenDate,
        date_sub(AccountOpenDate, dayofmonth(AccountOpenDate) - 1) AS OpenMonth,
           CASE WHEN AccountOpenDate > date_sub(current_date(), 20) THEN 1 ELSE 0 END AS Is_FTD,
        CASE WHEN LAST_DAY(AccountOpenDate) = LAST_DAY(CURRENT_DATE) THEN 1 ELSE 0 END AS Is_MTD,
        COUNT(1) AS NOA,
        SUM(Balance_FTD) AS Balance
    FROM {mart_catalog}.{mart_schema}.liabilities_accounts
    WHERE AccountOpenDate >= '2024-04-01'
    GROUP BY
        Hierarchyid,
        OpenMonth,
        AccountConversion,
        AccountOpenDate,
        DATE_ADD(AccountOpenDate, 1 - DAY(AccountOpenDate)),
        CASE WHEN AccountOpenDate > CURRENT_DATE - 2 THEN 1 ELSE 0 END,
        CASE WHEN LAST_DAY(AccountOpenDate) = LAST_DAY(CURRENT_DATE) THEN 1 ELSE 0 END
)
SELECT * FROM P_Dailydashboard_Liabilities_Balances;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"liabilities_balances Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on liabilities_balances: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on liabilities_balances : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.liabilities_balances")

    logger(
            logger_level_info,
            f"liabilities_balances writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table liabilities_balances : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table liabilities_balances : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

# DBTITLE 1,Writing to Snowflake
try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "liabilities_balances").mode("overwrite").save()
    logger(
            logger_level_info,
            f"liabilities_balances writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table liabilities_balances : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table liabilities_balances : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)