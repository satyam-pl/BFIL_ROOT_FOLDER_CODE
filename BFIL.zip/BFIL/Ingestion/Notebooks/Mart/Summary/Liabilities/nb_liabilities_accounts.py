# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/nb_mart_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

filename = "nb_liabilities_accounts.dbc"

# COMMAND ----------

# DBTITLE 1,Query
try:
    logger(
        logger_level_info,
        f"Required notebook imports has been successfully completed.",
        execution_log_list,
        filename,
    )
    mart_catalog = dbutils.widgets.get("mart_catalog")
    mart_schema = dbutils.widgets.get("mart_schema")
    source_catalog = dbutils.widgets.get("source_catalog")
    source_schema = dbutils.widgets.get("source_schema")
    mart_layer_abfss_url = dbutils.widgets.get("mart_layer_abfss_path")
    path = mart_layer_abfss_url + "BFIL-MART/REPORTING/LIABILITIES_ACCOUNTS"
    desti_path = "BFIL-MART/REPORTING/LIABILITIES_ACCOUNTS"

    logger(
        logger_level_info,
        f"Fetching required parameters from ADF has been successfully completed.",
        execution_log_list,
        filename,
    )

    query = """WITH MerchantMaster AS (
    SELECT * FROM edp_curated_prod.bfil.`rdsp-merchant_master`),

HRMSStaffdetails AS (
    SELECT * FROM edp_curated_prod.bfil.`azuresource-hrms_staff_wise_details`),

UserMaster AS (
    SELECT UserID, UserName
    FROM edp_curated_prod.bfil.`rlmsbizxtend-usermaster`
    UNION ALL
    SELECT UserID, UserName
    FROM edp_curated_prod.bfil.`ptsmart-usermaster` ),

T_Rav_Liabilities_Accounts AS (
    SELECT
        OperatorID AS AC_Open_SBU1,
        --BranchCode AS AC_Open_BranchID,
        0 as AC_Open_BranchID,
        --BFIL_OperatorID AS SBU,
        0 as SBU,
        --BFIL_HierarchyID AS HierarchyID,
        0 as HierarchyID,
        --BFIL_ClientID AS ClientID,
        0 as ClientID,
        0 as External_CustomerID,
        0 as KYCNumber,
        a.CIFID,
        a.AccountNumber,
        a.AccountType,
        Cast(Null As Varchar(100)) As AgentName,
        --Booking_Amt AS DepAmount,
        0 as DepAmount,
        C.RD_Amount AS DepAmt_PT,
        CAST(a.AccountOpenDate AS Date) AS AccountOpenDate,
        B.MaturityDate,
        B.AccountClosedDate,
        B.Status AS Status,
        0 AS Balance_YTD,
        0 AS Balance_MTD,
        B.Balance AS Balance_FTD,
        B.MaturedAmount,
        AgentID,
        CAST(NULL AS Varchar(20)) AS StaffID,
        CAST(NULL AS Varchar(150)) AS Designation,
        -- CASE 
        --     WHEN Is_StandaloneFD = 0 AND a.AccountType NOT IN ('SB', 'CR') THEN 'RD2FD'
        --     WHEN Is_StandaloneFD = 1 THEN 'FD'
        --     ELSE a.AccountType 
        -- END AS AccountConversion,
        0 as AccountConversion,
           CASE 
        WHEN a.AccountType = 'LM' THEN NULL
        ELSE AC_Open_SBU1 
    END AS AC_Open_SBU,
        --CAST(NULL AS TinyInt) AS Is_DBT,
        0 as Is_DBT,
        --DBT_LatestReqDate AS DBTRegisterDate,
        CAST(NULL AS Date) AS DBTRegisterDate,
        CAST(NULL AS TinyInt) AS Is_UPIRegistered,
        CAST(NULL AS Date) AS UPIRegisterDate,
        CAST(NULL AS TinyInt) AS Is_SocialSecurityScheme,
        CAST(NULL AS TinyInt) AS Is_WhatsappBanking,
        CAST(NULL AS Date) AS WBRegisterDate,
        RD.RDStartDate AS RDActivatedDate,
        1 AS Is_ATS
    FROM edp_bfil_prod.bfil_mart.firewallaccountfacts As A
    left join (select * from edp_bfil_prod.bfil_mart.liablilty_fact_finacle
    union all select * from edp_bfil_prod.bfil_mart.liablilty_fact_finacle) As B On B.AccountNumber = A.AccountNumber
	Left Join edp_bfil_prod.bfil_mart.rd_disbursementbase_fact As C On C.RDAccountNumber = A.AccountNumber
	LEFT JOIN edp_bfil_prod.bfil_mart.liablilty_fact_bfil RD ON RD.RDAccountNumber = A.AccountNumber
    WHERE CAST(a.AccountOpenDate AS Date) >= '2023-03-01' 
),

--select * from T_Rav_Liabilities_Accounts;

Updated_T_Rav_Liabilities_Accounts AS (
    SELECT 
        WBRegisterDate,
        AC_Open_SBU,
        AC_Open_BranchID,
          a.SBU,
         a.HierarchyID,
         a.ClientID,
        A.External_CustomerID,
        A.KYCNumber,
        A.Is_SocialSecurityScheme,
        A.CIFID,
        A.AccountNumber,
        A.AccountType,
        a.AccountConversion,
        a.DepAmount,
        A.DepAmt_PT,
        CAST(A.AccountOpenDate AS DATE) AS AccountOpenDate,
        A.MaturityDate,
        A.AccountClosedDate,
        A.Status,
        A.AgentID,
        DBTRegisterDate,

        -- Update AgentName
        CASE 
            WHEN LEFT(A.AgentID, 3) IN ('I00', 'I0U') THEN 'BMS'
            WHEN LEFT(A.AgentID, 3) = 'I0C' THEN 'LBS'
            WHEN LEFT(A.AgentID, 3) = 'I0E' THEN 'BCS'
            ELSE NULL -- Handle other cases if necessary
        END AS AgentName,

        -- Update StaffID
        CASE 
            WHEN LEFT(A.AgentID, 3) = 'I0E' THEN MM.StaffID
            ELSE A.AgentID
        END AS StaffID,

        -- Update Designation
        CASE 
            WHEN LEFT(A.AgentID, 3) IN ('I00', 'I0U') THEN 'BMS'
            WHEN LEFT(A.AgentID, 3) = 'I0C' THEN 'LBS'
            WHEN LEFT(A.AgentID, 3) = 'I0E' THEN 'BCS'
            ELSE NULL -- Handle other cases if necessary
        END AS Designation,

        -- Update Finacle Values, RD Values, FD Values, and other columns similarly...

        -- Update Is_DBT
        -- CASE 
        --     WHEN FL.Adhar_Seeding_Status = 'Yes' THEN 1
        --     ELSE 0
        -- END AS Is_DBT,
        0 as Is_DBT,
        -- Update Balance columns
        A.Balance_FTD,
        --COALESCE(FL.Balance_MTD, 0) AS Balance_MTD,
        A.Balance_MTD,
        --COALESCE(FL.Balance_YTD, 0) AS Balance_YTD,
        A.Balance_YTD,
        --COALESCE(FL.MaturedAmount, 0) AS MaturedAmount,
        A.MaturedAmount,

        -- Update RD Activated Date
		    A.RDActivatedDate

    FROM 
        T_Rav_Liabilities_Accounts A
        LEFT JOIN edp_curated_prod.bfil.`ptsmart-usermaster` UM ON UM.UserID = A.AgentID AND A.AgentName IS NULL
        LEFT JOIN UserMaster UM2 ON UM2.UserID = A.AgentID AND A.AgentName IS NULL
        LEFT JOIN MerchantMaster MM ON MM.Merchant_ID = A.AgentID
        LEFT JOIN HRMSStaffdetails HD ON HD.StaffID = A.StaffID
        LEFT JOIN edp_curated_prod.bfil.`ptsmart-usermaster` UM3 ON UM3.UserID = A.StaffID
        LEFT JOIN edp_curated_prod.bfil.`pragati-codevalue` CV ON CV.Code = UM3.DesignationID AND A.Designation IS NULL
		LEFT JOIN edp_bfil_prod.bfil_mart.liablilty_fact_finacle FL ON FL.AccountNumber = A.AccountNumber
) ,

--select * from Updated_T_Rav_Liabilities_Accounts;

Updated_T_Rav_Liabilities_Accounts1 AS (
    SELECT 
       A.AC_Open_SBU,
AC_Open_BranchID,
SBU,
HierarchyID,
ClientID,
External_CustomerID,
KYCNumber,
CIFID,
AccountNumber,
AccountType,
AgentName,
DepAmount,
a.DepAmt_PT,
AccountOpenDate,
MaturityDate,
AccountClosedDate,
Status,
Balance_YTD,
Balance_MTD,
Balance_FTD,
MaturedAmount,
AgentID,
StaffID,
Designation,
a.AccountConversion,
Is_DBT,
DBTRegisterDate,
SB.UPIRegisterDate,
WB.DATE_FOR_REGISTRATION,
RDActivatedDate,


        CASE 
            WHEN SB.ForacID IS NOT NULL THEN 1
            ELSE 0
        END AS Is_UPIRegistered,
        

        CASE 
            WHEN WB.Account_Number IS NOT NULL THEN 1
            ELSE 0
        END AS Is_WhatsappBanking,
        WB.Date_For_Registration AS WBRegisterDate,

        CASE 
            WHEN A.Status NOT IN ('Closed', 'C-Closed', 'Closed By CPU', 'PreClose') THEN 0
            ELSE 1
        END AS Is_ATS,

        CASE 
            WHEN SS.ForacID IS NOT NULL THEN 1
            ELSE 0
        END AS Is_SocialSecurityScheme

    FROM 
        Updated_T_Rav_Liabilities_Accounts A
        LEFT JOIN (
            SELECT  ForacID, MIN(CAST(Tran_Date AS DATE)) AS UPIRegisterDate
            FROM edp_bfil_prod.finacle.ibl_transactions
            WHERE TRAN_PARTICULAR_CODE IN ('UPI', 'UPT')
            GROUP BY ForacID
        ) AS SB ON SB.ForacID = A.AccountNumber 
        

        -- Whatsapp Banking Registration Updations
        LEFT JOIN edp_curated_prod.bfil.`liabilities_db-whatsapp_registrations_dump` AS WB ON WB.Account_Number = A.AccountNumber AND WB.Is_CASA_Subscribed = 1 

        -- Social Security Schemes Updations
        LEFT JOIN (
            SELECT  ForacID FROM edp_bfil_prod.finacle.ibl_transactions
            WHERE Tran_Particular LIKE 'PMJJY%' OR Tran_Particular LIKE 'SBY%' OR Tran_Particular LIKE 'APY%'
            GROUP BY ForacID
        ) AS SS ON SS.ForacID = A.AccountNumber
),

--Select * From Updated_T_Rav_Liabilities_Accounts1



Updated_T_Rav_Liabilities_Accounts2 AS (
    SELECT 
       c.AC_Open_SBU,
       C.Is_WhatsappBanking,
       C.WBRegisterDate,
       C.Is_ATS,
       C.Is_SocialSecurityScheme,
c.AC_Open_BranchID,
c.SBU,
c.HierarchyID,
c.ClientID,
c.External_CustomerID,
c.KYCNumber,
c.CIFID,
c.AccountNumber,
c.AccountType,
c.Is_UPIRegistered,

c.AgentName,
c.DepAmt_PT,
c.AccountOpenDate,
AccountClosedDate,

c.Balance_YTD,
c.Balance_MTD,
c.AgentID,
c.StaffID,
c.Designation,
c.AccountConversion,
c.Is_DBT,
c.DBTRegisterDate,
c.UPIRegisterDate,
c.DATE_FOR_REGISTRATION,
c.RDActivatedDate,
MaturityDate,
status,
 Balance_FTD, 

MaturedAmount,
 depamount as DepositAmount
from Updated_T_Rav_Liabilities_Accounts1 c 
--join edp_bfil_prod.bfil_mart.liablilty_fact_finacle a left join T_Rav_Liabilities_Accounts b on  a.FORACID = b.AccountNumber
)
select * from Updated_T_Rav_Liabilities_Accounts2;""".format(
        mart_catalog=mart_catalog,
        mart_schema=mart_schema,
        source_catalog=source_catalog,
        source_schema=source_schema,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error while intializing the parameters and query : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while intializing the parameters and query : ", str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Creating Dataframe
try:
    df = spark.sql(query).repartition(50).cache()
    logger(
        logger_level_info,
        f"liabilities_accounts Query has been successfully completed.{path}",
        execution_log_list,
        filename,
    )

except Exception as e:
    logger(
        logger_level_error,
        f"error while executing query on liabilities_accounts: {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error while executing query on liabilities_accounts : ", str(e))

# COMMAND ----------

# DBTITLE 1,Writing to Delta Table


try :

    df.write.format("delta").mode("overwrite").option("mergeSchema", "true").option("path",path).saveAsTable(f"{mart_catalog}.{mart_schema}.liabilities_accounts")

    logger(
            logger_level_info,
            f"liabilities_accounts writing to delta table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into delta table liabilities_accounts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into delta table liabilities_accounts : ", str(e))


# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Mart/Utils/nb_snowflake_connectivity"

# COMMAND ----------

try :
    # Write DataFrame to Snowflake table
    df.write.format("snowflake").options(**options).option("dbtable", "liabilities_accounts").mode("overwrite").save()
    logger(
            logger_level_info,
            f"liabilities_accounts writing to snowflake table has been successfully completed.",
            execution_log_list,
            filename,
    )
except Exception as e:
    logger(
        logger_level_error,
        f"error occured while writing data into snowflake table liabilities_accounts : {str(e)}",
        execution_log_list,
        filename,
    )
    print(*execution_log_list, sep="\n")
    # Handle the exception or display the error message as needed
    raise Exception("error occured while writing data into snowflake table liabilities_accounts : ", str(e))


# COMMAND ----------

update_logs('NULL', start_timestamp, log_status_success,'NULL','NULL','NULL','NULL','NULL', source_row_count, destination_row_count, log_error_success, desti_path,'NULL', execution_log_list)