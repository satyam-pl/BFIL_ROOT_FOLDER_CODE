# Databricks notebook source
equifax_tables_list = ["equifax_accounthistory","equifax_accountsummary","equifax_addressinfo","equifax_emailaddressinfo","equifax_enquiries","equifax_familydetails","equifax_identityinfo","equifax_incomedetails",
"equifax_inquiryaddresses","equifax_inquirycommonaccountdetails","equifax_inquiryphones","equifax_inquiryrequestinfo","equifax_inquiryresponseheader","equifax_mfiaddress",
"equifax_mfiphone","equifax_microfinance","equifax_phoneinfo","equifax_relationship","equifax_report_data","equifax_retails","equifax_score"]
crif_tables_list=["crif_account_summary","crif_alert","crif_contact","crif_groupdetails","crif_header","crif_ids","crif_inquiryhistory","crif_linked_accounts","crif_loan_details",
"crif_relation","crif_request","crif_response","crif_responselist","crif_score","crif_secondary_matches","crif_securitydetails","crif_statusdetails","crif_variation"]

# COMMAND ----------

try:
    pipeline_runid = dbutils.widgets.get("pipeline_runid")
    etl_exec_log_id = dbutils.widgets.get("etl_exec_log_id")
    curated_layer_schema = dbutils.widgets.get("curated_layer_schema")
    cb_type = dbutils.widgets.get("cb_type")
    print(pipeline_runid, curated_layer_schema, cb_type)
except Exception as e:
    # Handle the exception or display the error message as needed
    raise Exception(f"An error occurred in the passing base parameters to the notebook: {str(e)}")


deleted_tables_count = 0
deleted_tables_list = []
error_status_list = [] 

try:
    if cb_type == "EQUIFAX":
        total_tables_count = len(equifax_tables_list)
        for item in equifax_tables_list:
            try:
                spark.sql(f'''DELETE FROM {curated_layer_schema}.{item} WHERE ETL_AUDIT_ID = '{pipeline_runid}' AND ETL_EXEC_LOG_ID = '{etl_exec_log_id}' ''')
                deleted_tables_count += 1
                deleted_tables_list.append(item)
            except Exception as e:  
                print(f"Failed to delete Delta table : {str(e)}")
                error_status_list.append({"table": item, "status": f"failed to drop: {str(e)}"})
    elif cb_type == "CRIF":
        total_tables_count = len(crif_tables_list)
        for item in crif_tables_list:
            try:
                spark.sql(f'''DELETE FROM {curated_layer_schema}.{item} WHERE ETL_AUDIT_ID = '{pipeline_runid}' AND ETL_EXEC_LOG_ID = '{etl_exec_log_id}' ''')
                deleted_tables_count += 1
                deleted_tables_list.append(item)
            except Exception as e:  
                print(f"Failed to delete Delta table : {str(e)}")
                error_status_list.append({"table": item, "status": f"failed to drop: {str(e)}"})
    elif cb_type == 'INSTANT' :
        total_tables_count = len(crif_tables_list)+len(equifax_tables_list)
        for item in crif_tables_list:
            try:
                spark.sql(f'''DELETE FROM {curated_layer_schema}.{item} WHERE ETL_AUDIT_ID = '{pipeline_runid}' ''')
                deleted_tables_count += 1
                deleted_tables_list.append(item)
            except Exception as e:  
                print(f"Failed to delete Delta table : {str(e)}")
                error_status_list.append({"table": item, "status": f"failed to drop: {str(e)}"})
        for item in equifax_tables_list:
            try:
                spark.sql(f'''DELETE FROM {curated_layer_schema}.{item} WHERE ETL_AUDIT_ID = '{pipeline_runid}' ''')
                deleted_tables_count += 1
                deleted_tables_list.append(item)
            except Exception as e:  
                print(f"Failed to delete Delta table : {str(e)}")
                error_status_list.append({"table": item, "status": f"failed to drop: {str(e)}"})
except Exception as e:
    # Handle the exception or display the error message as needed
    raise Exception(f"An error occurred while executing the SQL delete statements: {str(e)}")
output = {

    "total_tables_count": total_tables_count,
    "deleted_tables_count": deleted_tables_count,
    "deleted_tables_list": deleted_tables_list,
    "error_status_list": error_status_list
}

print("Script execution completed.")
dbutils.notebook.exit(output) # Output the final status
