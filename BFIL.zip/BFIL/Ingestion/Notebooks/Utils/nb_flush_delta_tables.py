# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------


input_list = json.loads(dbutils.widgets.get("input_list"))

curated_schema = dbutils.widgets.get("curated_schema")
datasharing_schema = dbutils.widgets.get("datasharing_schema")
mode = dbutils.widgets.get("mode")
curated_catalog = curated_schema.split(".")[0]

dropped_tables_list = []
deleted_tables_list = []
error_list = []

for i in input_list:
    try:
        # Fetch the values
        db_name = list(i.values())[0].lower()
        table_name = list(i.values())[1].lower()
        dbtable_name = f"{db_name}..{table_name}"
        pipeline_runid = list(i.values())[2]
        load_type = list(i.values())[3]
        dest_save_type = list(i.values())[4]
        
        # Construct table_name names
        curated_fqtn = f"{curated_schema}.`{db_name}-{table_name}`"
        curated_table_name = f"{db_name}-{table_name}"
        
        # Check if the Delta table_name exists
        delta_table_exists = spark.sql(f"""
            SELECT * 
            FROM {curated_catalog}.information_schema.tables 
            WHERE table_schema = 'bfil' AND table_name = '{curated_table_name}'
        """)
        
        if mode == "full_flush":
            if not delta_table_exists.isEmpty():
                # If the table_name exists, delete the table_name and dq report
                try:
                    spark.sql(f"DROP TABLE IF EXISTS {curated_fqtn};")
                    dropped_tables_list.append(dbtable_name)
                except Exception as e:
                    error_list.append({"table_name": curated_table_name, "status": f"failed to drop table_name: {str(e)}"})
                try:
                    spark.sql(f"DELETE FROM {datasharing_schema}.dq_detailed_report WHERE TABLE_NAME = '{table_name.upper()}' AND SOURCE_SYSTEM = '{db_name.upper()}';")
                    dropped_tables_list.append(dbtable_name)
                except Exception as e:
                    error_list.append({"table_name": curated_table_name, "status": f"failed to delete dq report: {str(e)}"})
            else:
                error_list.append({"table_name": curated_table_name, "status": "not found"})
        elif mode == "day_wise_flush":
            if not delta_table_exists.isEmpty():
                if load_type == 'TRANSACTIONAL' and dest_save_type == 'SCD-1':
                    try:
                        spark.sql(f"DELETE FROM {curated_fqtn} WHERE ETL_AUDIT_ID = '{pipeline_runid}';")
                        deleted_tables_list.append(dbtable_name)
                    except Exception as e:
                        error_list.append({"table_name": curated_table_name, "status": f"failed to delete table_name records: {str(e)}"})
                try:
                    spark.sql(f"DELETE FROM {datasharing_schema}.dq_detailed_report WHERE TABLE_NAME = '{table_name.upper()}' AND SOURCE_SYSTEM = '{db_name.upper()}' AND ETL_AUDIT_ID = '{pipeline_runid}';")
                    deleted_tables_list.append(dbtable_name)
                except Exception as e:
                    error_list.append({"table_name": curated_table_name, "status": f"failed to delete records from DQ Report: {str(e)}"})
            else:
                error_list.append({"table_name": curated_table_name, "status": "not found"})
    except Exception as e:
        error_list.append({"table_name": curated_table_name, "status": f"error: {str(e)}"})

# Create a concatenated string from list
dropped_tables_list = [tbl.replace("pragati..", "pragati_s1..") for tbl in dropped_tables_list]
unique_dropped_list = list(set(dropped_tables_list))
dropped_tables_str = ",".join([f"'{tbl}'" for tbl in unique_dropped_list])

deleted_tables_list = [tbl.replace("pragati..", "pragati_s1..") for tbl in deleted_tables_list]
unique_deleted_list = list(set(deleted_tables_list))
deleted_tables_str = ",".join([f"'{tbl}'" for tbl in unique_deleted_list])

total_tables_count = len(input_list)
dropped_tables_count = len(dropped_tables_list)
deleted_tables_count = len(deleted_tables_list)

output = {
    "mode": mode,
    "total_tables_count": total_tables_count,
    "dropped_tables_count": dropped_tables_count,
    "dropped_tables_list": dropped_tables_str,
    "deleted_tables_count": deleted_tables_count,
    "deleted_tables_list": deleted_tables_str,
    "error_list": error_list
}

dbutils.notebook.exit(json.dumps(output))  # Output the final status