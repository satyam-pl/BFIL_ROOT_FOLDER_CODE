# Databricks notebook source
# # Importing required libraries
from pyspark.sql.functions import col, lit, when, count, date_format, concat_ws, collect_list, trim, split, lower, concat, length, array, date_diff, to_date, unix_timestamp, from_unixtime, upper, to_timestamp, explode, explode_outer, regexp_extract, regexp_replace, regexp_extract_all, from_json, create_map, monotonically_increasing_id, first, json_tuple, row_number, sha2
from pyspark.sql.window import Window
import re, json, hashlib, ast, inspect, pytz, time, operator
from datetime import datetime, timedelta
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType, DoubleType, BooleanType, DateType, TimestampType, ArrayType, MapType, ByteType, ShortType, LongType, DecimalType
from delta.tables import DeltaTable
from inspect import currentframe, getframeinfo
from decimal import Decimal
import zipfile
from io import BytesIO
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
import json

input_list = dbutils.widgets.get("input_list")
input_list = json.loads(input_list)
curated_schema = dbutils.widgets.get("curated_schema")
datasharing_schema = dbutils.widgets.get("datasharing_schema")
# input_list = [{"table":"Pragati..KYCMaster","path":"BFIL/CB/PGATI/KYCMASTER"}]
dropped_tables_count = 0  # Initialize the counter for dropped tables
not_found_tables_count = 0  # Initialize the counter for not found tables
dropped_tables = []  # Initialize a list to keep track of dropped table names
status_list = []  # Initialize a list to keep track of status of each table
curated_catalog = curated_schema.split(".")[0]
print(input_list)

for i in input_list:
    try:
        # Fetch the values
        dbtable = list(i.values())[0]
        db_name = dbtable.split("..")[0].lower()
        table_name = dbtable.split("..")[1].lower()
        
        # Construct table and path names
        curated_fqtn = f"{curated_schema}.`{db_name}-{table_name}`"
        curated_table_name = f"{db_name}-{table_name}"
        
        # Check if the Delta table exists
        delta_table_exists = spark.sql(f"""
            SELECT * 
            FROM {curated_catalog}.information_schema.tables 
            WHERE table_schema = 'bfil' AND table_name = '{curated_table_name}' limit 1
        """)
        
        if not delta_table_exists.isEmpty():
            # If the table exists, delete the table and the corresponding path
            print(f"Dropping {curated_table_name}")
            try:
                spark.sql(f"DROP TABLE IF EXISTS {curated_fqtn};")  
                dropped_tables_count += 1  # Increment the counter for dropped tables
                dropped_tables.append(dbtable)  # Append the original table name to the list
                status_list.append({"table": curated_table_name, "status": "dropped"})             
            except Exception as e:
                print(f"Failed to delete Delta table : {str(e)}")
                status_list.append({"table": curated_table_name, "status": f"failed to drop: {str(e)}"})
            try:
                spark.sql(f"DELETE FROM {datasharing_schema}.dq_detailed_report where table_name = '{table_name}' and source_system = '{db_name}';")               
            except Exception as e:
                print(f"Failed to delete Records from DQ Detailed Report : {str(e)}")
        else:
            print(f"Not found {curated_table_name}.")
            not_found_tables_count += 1  # Increment the counter for not found tables
            status_list.append({"table": curated_table_name, "status": "not found"})
    except Exception as e:
        print(f"An error occurred while processing {curated_table_name}: {str(e)}")
        status_list.append({"table": curated_table_name, "status": f"error: {str(e)}"})

print("Script execution completed.")