# Databricks notebook source
def overwriting_schema(curated_catalog, curated_schema, table_name, source_df):
    try :
        #Fetch existing delta table schema with comments & Tags
        schema_df = spark.sql(f"""with comments as (
            SELECT table_catalog,table_schema,table_name,column_name,comment
            FROM {curated_catalog}.information_schema.columns
            WHERE table_schema = '{curated_schema}'
            and table_name = '{table_name}'
            ),
            tags as (
            SELECT catalog_name,schema_name,table_name,column_name,tag_name,tag_value
            FROM {curated_catalog}.information_schema.column_tags
            WHERE schema_name = '{curated_schema}'
            and table_name = '{table_name}'
            )
            select c.table_catalog,c.table_schema,c.table_name,c.column_name,c.comment,t.tag_name,t.tag_value
            from comments c
            full join tags t
            on c.column_name = t.column_name;
            """)
        # # Extract relevant columns (col_name, data_type, comment)
        schema_info = schema_df.select("column_name","comment","tag_name").collect()
        # # Convert the schema information to a dictionary
        schema_dict = {}
        for row in schema_info:
            col_name = row["column_name"]
            comment = row["comment"]
            tag = row["tag_name"]
            schema_dict[col_name] = {"tag": tag, "comment": comment}    
    except Exception as e :
        # Log the error along with the traceback
        filename = 'nb_preserve_comments_tags.dbc'
        logger(logger_level_error, f"An error occurred while reading the schema for the table: {table_name}.", execution_log_list, filename)    
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)
    try :
        for col_name, col_info in schema_dict.items():
            # Update the comments & Tags into the source_df
            source_df = source_df.withColumn(col_name, source_df[col_name].alias(col_name, metadata={"comment": col_info['comment']}))
            # Update tags (if available)
            if col_info['tag']:
                source_df = source_df.withColumn(col_name, source_df[col_name].alias(col_name, metadata={"tags": col_info['tag']}))
        return source_df
    except Exception as e :
        # Log the error along with the traceback
        filename = 'nb_preserve_comments_tags.dbc'
        logger(logger_level_error, f"An error occurred while overwriting the exisint schema to the source df for the table: {table_name}.", execution_log_list, filename)    
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)
