# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

input_list = dbutils.widgets.get("input_list")
input_list = json.loads(input_list)

curated_schema = dbutils.widgets.get("curated_schema")
mode = dbutils.widgets.get("mode")
date = dbutils.widgets.get("date")
curated_catalog = curated_schema.split(".")[0]

total_tables_count = len(input_list)
deleted_tables_count = 0
deleted_tables_list = []
error_status_list = [] 

for i in input_list:
    try:
        # Fetch the values
        dbtable = list(i.values())[0]
        db_name = dbtable.split("..")[0].lower()
        table_name = dbtable.split("..")[1].lower()
        pipeline_runid = list(i.values())[1]
        
        # Construct table and path names
        curated_fqtn = f"{curated_schema}.`{db_name}-{table_name}`"
        curated_table_name = f"{db_name}-{table_name}"
        
        # Check if the Delta table exists
        delta_table_exists = spark.sql(f"""
            SELECT * 
            FROM {curated_catalog}.information_schema.tables 
            WHERE table_schema = 'bfil' AND table_name = '{curated_table_name}'
        """)
        
        if not delta_table_exists.isEmpty():
            # If the table exists, delete the table and dq report
            try:
                spark.sql(f"DELETE FROM {curated_fqtn} WHERE ETL_AUDIT_ID = '{pipeline_runid}';")
                deleted_tables_count += 1
                deleted_tables_list.append(dbtable)
            except Exception as e:
                print(f"Failed to delete Delta table : {str(e)}")
                error_status_list.append({"table": curated_table_name, "status": f"failed to drop: {str(e)}"})
        else:
            print(f"Not found {curated_table_name}.")
            error_status_list.append({"table": curated_table_name, "status": "not found"})
    except Exception as e:
        print(f"An error occurred while processing {curated_table_name}: {str(e)}")
        error_status_list.append({"table": curated_table_name, "status": f"error: {str(e)}"})

# Create a concatenated string of dropped and undropped table names
deleted_tables_list = [tbl.replace("pragati..", "pragati_s1..") for tbl in deleted_tables_list]
dropped_tables_str = ",".join([f"'{tbl}'" for tbl in deleted_tables_list])


output = {
    "mode": mode,
    "date": date,
    "total_tables_count": total_tables_count,
    "deleted_tables_count": deleted_tables_count,
    "deleted_tables_list": dropped_tables_str,
    "error_status_list": error_status_list
}

print("Script execution completed.")
dbutils.notebook.exit(json.dumps(output))  # Output the final status