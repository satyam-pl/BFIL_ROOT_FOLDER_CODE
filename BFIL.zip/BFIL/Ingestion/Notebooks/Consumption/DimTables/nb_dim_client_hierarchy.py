# Databricks notebook source
def dimclienthierarchy(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    prevSKVal,LoadCount = 0,0
    try:
        
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        if df and renameFields and rowCountDF:
            print("Dataframe count from framework", df.count(),rowCountDF)

            if Business == 'MFI':
                dfGROUPIDValues = df.select("GROUPID").distinct()
                GROUPMASTERVal = f"select GROUPID, GROUPID as GRP_GROUPID, GROUPCODE, CENTERID from {SRCSCH}.`pragati-groupmaster` where ETL_IS_ACTIVE = 1 "
                groupMaster_df= spark.sql(GROUPMASTERVal)
                groupMaster_df = groupMaster_df.join(dfGROUPIDValues, groupMaster_df["GROUPID"]==dfGROUPIDValues["GROUPID"], "inner").select(groupMaster_df["*"])

                dfCENTERMASTERValues = groupMaster_df.select("CENTERID").distinct()

                CENTERMASTERVal = f"select CENTERID, CENTERCODE from {SRCSCH}.`pragati-centermaster` where ETL_IS_ACTIVE = 1 "
                centreMaster_df= spark.sql(CENTERMASTERVal)
                centreMaster_df = centreMaster_df.join(dfCENTERMASTERValues, centreMaster_df["CENTERID"]==dfCENTERMASTERValues["CENTERID"], "inner").select(centreMaster_df["*"])

                groupMaster_df = groupMaster_df.join(centreMaster_df,["CENTERID"],"left")

                df = df.join(groupMaster_df, ["GROUPID"], "left")
                df = df.withColumn("GROUPID", lit(col("GRP_GROUPID")))
            else:
                df = df.withColumn('CENTERID',lit(None)).withColumn('GROUPCODE',lit(None)).withColumn('CENTERCODE',lit(None))
            

            if Business == 'BSS':
                branchmasterdfquery = f"select HIERARCHYID, BRANCHCODE from  {SRCSCH}.`rlmsbizxtend-branchmaster`"
                branchmasterdf = spark.sql(branchmasterdfquery)

                df = df.join(branchmasterdf, ["HIERARCHYID"], "left")
            

            if (Business == 'BSS' and Business == 'BMS'):
                df = df.withColumn("GROUPID",lit(None))

            if Business == 'BSS':
                df = df.withColumn("GROUPID", lit(None)).withColumn("GROUPCODE", lit(None)).withColumn("CENTERID", lit(None)).withColumn("CENTERCODE", lit(None))

            df = selectAndRename(df,renameFields)
            print("Dataframe count after rename", df.count(),rowCountDF)

            #Execution method
            withColVar = MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")


            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_client_hierarchy_bfil", "TARGETID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] ],"" ,desti_path,"" ,adb_consumption_dest_url)

        rowCountDF = rowCountDF if rowCountDF else 0
        
        Stats = update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_client_hierarchy_bfil"])


    except Exception as e:
        raise Exception("An error occurred in the dimgroup notebook:", str(e))

