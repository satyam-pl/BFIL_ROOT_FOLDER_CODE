# Databricks notebook source
def dimbranchserviceoffering(TargetTable, Business, stdate,eddate,DBG_FLG):
    LoadCount=0
    prevSKVal = maxsk("DIM_GROUP_SKEY",f"{TRGSCH}.bfil.dim_group_bfil")
    # df = FrameWork(TargetTable, Business)
    df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)

    df = df.withColumn("DIM_GROUP_SKEY", lit(col("SKID").cast("int")+prevSKVal ))

    df = df.withColumn("ResultDescription",
                            when(col("Result").isin('2', '3'), "Success")
                            .when(col("Result") == '1', "Failed")
                            .when((col("Result").isNull()) | (col("Result") == ""), "Not Done")
                            .otherwise(None)
                            )

    print("renameFields", type(renameFields), renameFields )
    df = selectAndRename(df,renameFields)

    #Execution method
    withColVar = MetaDataColumns(MetaColList,"","","User")
    # exec("df"+f'=df{withColVar}')
    df = eval(f"df{withColVar}")

    LoadCount = handle_scd_type_2(df,f"{TRGSCH}.bfil","dim_group_bfil", "GROUPID","User",RunDate.strftime('%Y-%m-%dT%H:%M:%SZ'), [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]]],"" ,"" ,"" ,"",[])

    update_logs("1", datetime.now(pytz.timezone('Asia/Kolkata')), "Completed", "", "", "ConsumptionLayer", "0", "NA", rowCountDF, LoadCount, "", "", "", ["dimGroup"])


