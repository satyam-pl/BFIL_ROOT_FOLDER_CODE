# Databricks notebook source
# DBTITLE 1,Dim Client
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_client"
# MAGIC

# COMMAND ----------

# DBTITLE 1,Dim  Group
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_group"

# COMMAND ----------

# DBTITLE 1,Dim Centre
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_centre"

# COMMAND ----------

# DBTITLE 1,Dim Centre Details
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_centre_details"

# COMMAND ----------

# DBTITLE 1,Dim Contact Address
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_client_contact_address"

# COMMAND ----------

# DBTITLE 1,Dim Contact Phone
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_client_contact_phone"

# COMMAND ----------

# DBTITLE 1,Dim Client Details
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_client_details"

# COMMAND ----------

# DBTITLE 1,Dim Client Hierarchy
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_client_hierarchy"

# COMMAND ----------

# DBTITLE 1,Dim Employee
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_employee"

# COMMAND ----------

# DBTITLE 1,Dim Lead
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_lead"

# COMMAND ----------

# DBTITLE 1,Dim Merchant
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_merchant"

# COMMAND ----------

# DBTITLE 1,Dim Purpose
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_purpose"

# COMMAND ----------

# DBTITLE 1,Dim Product
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_product"

# COMMAND ----------

# DBTITLE 1,Dim Branch
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_branch"

# COMMAND ----------

# DBTITLE 1,Dim Branch Service Offering
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_branch_service_offering"

# COMMAND ----------

# DBTITLE 1,Dim Branch Supervisor Details
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_branch_supervisor_detail"

# COMMAND ----------

# DBTITLE 1,Dim Loan Heirarchy
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_loan_hierarchy"

# COMMAND ----------

# DBTITLE 1,DIM_LOAN_ORIGINATION_APPLICATION
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_loan_origination_application"

# COMMAND ----------

# DBTITLE 1,DIM Loan Account
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_loan_account"

# COMMAND ----------

# DBTITLE 1,DIM KYC
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_client_document_kyc"

# COMMAND ----------

# DBTITLE 1,dim_bfil_ibl_relation
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_bfil_ibl_relation"

# COMMAND ----------

spark.conf.set("spark.sql.session.timeZone", "Asia/Calcutta")