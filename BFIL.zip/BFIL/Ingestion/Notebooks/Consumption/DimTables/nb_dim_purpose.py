# Databricks notebook source
def dimpurpose(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_PURPOSE_REF_SKEY",0

        prevSKVal = maxsk(SKCOL,f"{adb_consumption_catlog_schema}.dim_purpose_ref")
        ConfigDF, CreateConfig,JoinConfigDF,UniqueKeyValues,list_agg_df,mappingdict,JoinConfigDFValue,renameFields = loadconfig(TargetTable,Business,1)

        if DBG_FLG:
            print(f'select {ConfigDF.select("BusinessKey").collect()[0][0]} from {SRCSCH}.`azuresource-dim_masterloanpurposes` where ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ')

        df = spark.sql(f'select {ConfigDF.select("BusinessKey").collect()[0][0]} from  {SRCSCH}.`azuresource-dim_masterloanpurposes` where ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ')
        # df = df.dropDuplicates(["PurposeId"])

        rowCountDF = df.count()
        rowCountDF = rowCountDF if rowCountDF else 0

        print("df count", rowCountDF)

        df = repartitioning_SKID(df)
        dfCount = df.count()

        # df.show()
        df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))

        df = selectAndRename(df,renameFields)
        
        # #Execution method
        withColVar =MetaDataColumns(MetaColList,Business,"","User")
        df = eval(f"df{withColVar}")
        

        LoadCount=handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_purpose_ref","PURPOSE_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate,[elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]]and elem !=SKCOL ],"" ,desti_path,"" ,adb_consumption_dest_url)

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dimpurpose"])

    except Exception as e:
        raise Exception("An error occurred in the dimpurpose notebook:", str(e))

