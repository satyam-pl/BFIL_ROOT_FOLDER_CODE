# Databricks notebook source
def dimclientcontactaddress(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_CLIENT_CONTACT_ADDRESS_SKEY",0
        prevSKVal = maxsk(SKCOL,f"{adb_consumption_catlog_schema}.dim_client_contact_address_bfil")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        
        
        if df and renameFields and rowCountDF:
            

            # if Business == 'BMS':
            #     df_client_values = df.select("CLIENTID").distinct()
            #     df_sa_reg = spark.sql('''select CLIENTID, HOUSENUMBER,STREET,GRAMPANCHAYAT,VILLAGE,LANDMARK,DISTICT,STATE,PIN from edp_curated_dev.bfil.`rdsp-sa_registration` where ETL_IS_ACTIVE = 1''')

            #     df_sa_reg = df_sa_reg.join(df_client_values, ["CLIENTID"],"inner")
            #     df = df.join(df_sa_reg,["CLIENTID"],"left")
            if Business == 'MFI':
                df=spark.sql(f''' select TargetID,CLIENTID,'91' as ADDRESS_COUNTRY_CODE, 'India' as ADDRESS_COUNTRY_NAME from {SRCSCH}.`pragati-clientmaster` where ETL_IS_ACTIVE = 1  and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ''')
                kycmaster_df = spark.sql(f'''
                        WITH Max_SeqID AS (
                            SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                            FROM {SRCSCH}.`pragati-kycmaster`
                            WHERE ClientOrSpouse IN ('M','Y') AND ETL_IS_ACTIVE = '1'   
                            GROUP BY TargetID, KYCType
                        )
                        SELECT A.KYCTYPE,A.AddressLine1,A.AddressLine2,A.TargetId,A.LandMark,A.DistrictName,A.StateName,A.Pincode
                        FROM {SRCSCH}.`pragati-kycmaster` A
                        INNER JOIN Max_SeqID B
                            ON B.TargetID = A.TargetID
                            AND B.KYCType = A.KYCType
                            AND B.MaxSeqID = A.SequenceID
                        WHERE A.ETL_IS_ACTIVE = '1' and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ''')
                df = df.join(kycmaster_df, ["TargetID"], "left")
                df = df.filter(col("KYCTYPE").isNotNull())

            if Business == 'BMS':
                df=spark.sql(f'''select TargetID,CLIENTID,'91' as ADDRESS_COUNTRY_CODE, 'India' as ADDRESS_COUNTRY_NAME from {SRCSCH}.`ptsmart-clientmaster` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ''')
                
                kycmaster_df=spark.sql(f'''WITH Max_SeqID AS (
                        SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                        FROM {SRCSCH}.`ptsmart-kycmaster`
                        WHERE ClientOrSpouse IN ('M', 'Y') AND ETL_IS_ACTIVE = '1'
                        GROUP BY TargetID, KYCType
                    )
                    
                    SELECT A.TargetID,A.KYCNumber,A.KYCTYPE
                    FROM {SRCSCH}.`ptsmart-kycmaster` A
                    INNER JOIN Max_SeqID B
                        ON B.TargetID = A.TargetID
                        AND B.KYCType = A.KYCType
                        AND B.MaxSeqID = A.SequenceID
                    WHERE A.ETL_IS_ACTIVE = '1' and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ''')
                df = df.join(kycmaster_df, ["TargetID"], "left")
                df = df.filter(col("KYCTYPE").isNotNull())


                # df=filter(df["ClientOrSpouse"].isin('M', 'Y'))
                df_client_values = df.select("KYCNUMBER").distinct()
                query = f"select KYCNumber,CLIENTID, HOUSENUMBER,STREET,GRAMPANCHAYAT,VILLAGE,LANDMARK,DISTICT,STATE,PIN from  {SRCSCH}.`rdsp-sa_registration` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY KYCNUMBER ORDER BY Createdatetime DESC) =1"
                df_sa_reg = spark.sql(query)

                df_sa_reg = df_sa_reg.join(df_client_values, ["KYCNUMBER"],"inner").drop("CLIENTID")
                df = df.join(df_sa_reg,["KYCNUMBER"],"left")
            
            if Business == 'BSS':
                #Remove qualify as per client requirement from kycmaster
                dfcustomervalues = df.select("CUSTOMERID").distinct()
                query = f"select CUSTOMERID as CUSTOMERID,KYCTYPE,AddressLine1 ,AddressLine2,LandMark,DistrictName,StateName,Pincode,ClientOrSpouse from {SRCSCH}.`rlmsbizxtend-kycmaster` where ETL_IS_ACTIVE = 1 and ClientOrSpouse IN ('M','Y')  and KYCTYPE is not null "
                df_kyc_master = spark.sql(query)
                df_kyc_master = df_kyc_master.join(dfcustomervalues, ["CUSTOMERID"],"inner")

                df = df.join(df_kyc_master, ["CUSTOMERID"],"left")
                df = df.filter(col("KYCTYPE").isNotNull())

            if Business == 'MERCHANT':
                df = df.filter(length(trim(df['CLIENTID'])) >= 8)
                dfKYCNUMBERvalues = df.select("KYCNUMBER").distinct()
                query = f"select KYCNUMBER,HouseNumber,Street,GramPanchayat, Village,LandMark,Distict,State,PIN from {SRCSCH}.`rdsp-sa_registration` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY KYCNUMBER ORDER BY Createdatetime DESC) =1 "
                df_sa_reg = spark.sql(query)
                df_sa_reg = df_sa_reg.join(dfKYCNUMBERvalues, ["KYCNUMBER"],"inner")

                df = df.join(df_sa_reg, ["KYCNUMBER"],"left")
            

            if Business in ('BMS','MERCHANT'):
                df = df.withColumn("ADDRESS_LINE_1",concat_ws(',',col("HouseNumber"),col("Street"),col("GramPanchayat")))
            else:
                df = df.withColumn("ADDRESS_LINE_1",lit(col("ADDRESSLINE1")))

            if Business =="MERCHANT":
                df = df.withColumn("ADDRESS_SOURCE_PRIMARY_OR_SECONDARY", lit("Primary"))
            elif Business =="BSS":
                df = df.withColumn("ADDRESS_SOURCE_PRIMARY_OR_SECONDARY", when(df["KYCTYPE"] == "IDP1", "Primary").otherwise("Secondary"))
            elif Business !="BSS":
                df = df.withColumn("ADDRESS_SOURCE_PRIMARY_OR_SECONDARY", when(df["KYCTYPE"] == "IDP6", "Primary").otherwise("Secondary"))
            
            if Business=='BMS' or  Business=='MFI':
                df = repartitioning_SKID(df)
                df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            else:
                df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)

            #Execution method
            withColVar = MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")

            df = df.withColumn("ADDRESS_PINCODE", lit(col("ADDRESS_PINCODE").cast("string")))


            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_client_contact_address_bfil", "CLIENTID,ADDRESS_SOURCE",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)


        rowCountDF = rowCountDF if rowCountDF else 0

        Stats = update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_client_contact_address_bfil"])


    except Exception as e:
        raise Exception("An error occurred in the DIM_CLIENT_CONTACT_ADDRESS notebook:", str(e))



