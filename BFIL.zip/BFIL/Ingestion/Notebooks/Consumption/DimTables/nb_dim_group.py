# Databricks notebook source
def dimgroup(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_GROUP_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_group_bfil")
        # df = FrameWork(TargetTable, Business)
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        if df and  renameFields and rowCountDF:
            df = df.withColumn("ResultDescription",
                                    when(col("Result").isin('2', '3'), "Success")
                                    .when(col("Result") == '1', "Failed")
                                    .when((col("Result").isNull()) | (col("Result") == ""), "Not Done")
                                    .otherwise(None)
                                    ).withColumn("Result", col("Result").cast('string'))
            # .withColumn("VILLAGE_NAME", lit(col("TesterId"))).withColumn("GRT_ID", lit(col("GRTID")))

            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            
            df = selectAndRename(df,renameFields)

            #Execution method
            # withColVar = MetaDataColumns(MetaColList,Business,"",spark.sql('select current_user() as user').collect()[0]['user'])
            # df = eval(f"df{withColVar}")
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")

            LoadCount=handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_group_bfil", "GROUPID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)

        rowCountDF = rowCountDF if rowCountDF else 0

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dimGroup"])

        # update_logs("1", start_timestamp, log_status, "", "", "ConsumptionLayer", "0", "NA", rowCountDF, rowCountDF, "", "", "", ["dimGroup"])

        # return CompletetionStatus
    except Exception as e:
        raise Exception("An error occurred in the dimgroup notebook:", str(e))

