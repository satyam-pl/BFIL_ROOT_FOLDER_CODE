# Databricks notebook source
# DBTITLE 1,FrameWork
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/FrameWork/nb_generic_framework"

# COMMAND ----------

# DBTITLE 1,FrameworkConfig
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/FrameWork/nb_consumption_common_config"

# COMMAND ----------

# DBTITLE 1,Logger
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# DBTITLE 1,Logger Constants
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/FrameWork/nb_exec_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

# DBTITLE 1,Dim imports
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Consumption/DimTables/nb_dim_tables_import"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_query_on_synapse"

# COMMAND ----------

# DBTITLE 1,Constants
filename = "Dim_Tables.dbc"

# COMMAND ----------

# # Calling function to fetch all input parameters from ADF

try:
    targetDim = dbutils.widgets.get("DimTable")
    TargetTable = dbutils.widgets.get("TargetTable")
    businessDetails = dbutils.widgets.get("Business")
    startTime = dbutils.widgets.get("CurTS")
    endTime = dbutils.widgets.get("endTS")
    src_object_id = dbutils.widgets.get("src_object_id")
    pipeline_name = dbutils.widgets.get("pipeline_name")
    pipeline_run_id = dbutils.widgets.get("pipeline_run_id")
    pipeline_trigger_name = dbutils.widgets.get("pipeline_trigger_name")
    load_from_date=dbutils.widgets.get("load_from_date")
    load_to_date=dbutils.widgets.get("load_to_date")
    load_type = dbutils.widgets.get("load_type")
    adb_consumption_catlog_schema = dbutils.widgets.get("adb_consumption_catlog_schema")
    adb_synapse_connection_string = dbutils.widgets.get("synapse_jdbc_secret_name")
    adb_consumption_dest_url= dbutils.widgets.get("adb_consumption_dest_url")
    desti_path= dbutils.widgets.get("desti_path")
    adb_curated_schema_name=dbutils.widgets.get("curated_schema_name")
    TRGSCH = adb_consumption_catlog_schema
    SRCSCH=adb_curated_schema_name
    

except Exception as e:
    logger(logger_level_error, f"An error occurred in the get_params_from_adf : {str(e)}", execution_log_list, filename)

#     # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the get_params_from_adf :", str(e))


try:
    # For creating connection between databricks to synapse
    synapse_jdbc_url = create_databricks_to_synapse_connection(adb_secret_scope_name, adb_synapse_connection_string)
    if synapse_jdbc_url is not None :
        # Configure connection between Databricks to Synapse
        logger(logger_level_info, f"The configuration of the connection between Databricks and Synapse has been successfully completed.", execution_log_list, filename)
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_synapse_connectivity notebook: {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_synapse_connectivity notebook:", str(e))



# COMMAND ----------

# DBTITLE 1,Dim Calling
try :
   if targetDim == "DIM_CENTRE":
      CompletetionStatus = dimcentre(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_CENTRE_DETAILS":
      CompletetionStatus = dimcentredetails(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_CLIENT":
      CompletetionStatus = dimclient(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_CLIENT_CONTACT_ADDRESS":
      CompletetionStatus = dimclientcontactaddress(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_CLIENT_CONTACT_PHONE":
      CompletetionStatus = dimclientcontactphone(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_CLIENT_DETAILS":
      CompletetionStatus = dimclientdetails(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_CLIENT_HIERARCHY":
      CompletetionStatus = dimclienthierarchy(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_EMPLOYEE":
      CompletetionStatus =dimemployee(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
      # dimemployee(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema)
   elif targetDim == "DIM_GROUP":
      CompletetionStatus = dimgroup(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_LEAD":
      CompletetionStatus = dimlead(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_MERCHANT":
      CompletetionStatus = dimmerchant(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_PRODUCT":
      CompletetionStatus = dimproduct(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_PURPOSE_REF":
      CompletetionStatus = dimpurpose(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_BRANCH":
      CompletetionStatus = dimbranch(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "dimbranchserviceoffering":
      CompletetionStatus = dimbranchserviceoffering(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_BRANCH_SUPERVISOR_DETAILS":
      CompletetionStatus = dimbranchsupervisordetail(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_LOAN_HIERARCHY":
      CompletetionStatus = dim_loan_hierarchy_driver(targetDim, "MFI,BMS,BSS",'1900-01-01T00:00:00Z','9999-12-31T23:59:59Z',DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_LOAN_ORIGINATION_APPLICATION":
      CompletetionStatus = dimloanoroginationapplication(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_LOAN_ACCOUNT":
      CompletetionStatus = dim_loan_account(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   elif targetDim == "DIM_CLIENT_DOCUMENT_KYC":
      CompletetionStatus = dim_client_document_kyc(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id,SRCSCH)
   elif targetDim == "DIM_BFIL_IBL_RELATION":
      CompletetionStatus = dim_bfil_ibl_relation(targetDim,businessDetails,startTime,endTime,DebugFlag,adb_consumption_catlog_schema,pipeline_run_id)
   else:
      logger(logger_level_info, f"No {targetDim} match", execution_log_list, filename)
except Exception as e:
    logger(logger_level_error, f"An error occurred in the {targetDim} : {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception(f"An error occurred in the {targetDim} notebook:", str(e))


# COMMAND ----------

logger(logger_level_info, f"Execution for {targetDim}", execution_log_list, filename)