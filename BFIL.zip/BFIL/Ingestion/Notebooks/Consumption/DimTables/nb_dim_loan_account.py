# Databricks notebook source
def querystore (Business,Start_date,End_date):
    if Business =='MFI':
        
        query = f'''with cls as (select CreatedBy,ClientId,LoanProposalId,ClientLoanId,DisbursementDate,DisbursementMode,InterestRate,InterestRate as EFFECTIVE_INTEREST_RATE,Tenure,Tenure as TL_DL,RepaymentFrequency,ClientProductSequenceNo,ExpectedPaidupDate ,ExpectedPaidupDate as MATURITY_DATE,LOANCANCELLEDDATE,LOANCANCELLEDDATE as CANCELED_FLAG,DeviationCancelledDate,LoanClosedDate,LoanClosedDate as ACCOUNT_CLOSURE_DATE,ResheduleProcessedDate,IsCoApplicantExists,CoApplicantInsuranceAmount,IsInsuranceApplicable,LoanCancellationType,Remarks,ProductId,HierarchyId,'Fixed' as INTEREST_RATE_TYPE,'1' as PRECLOSURE_ALLOWED,'0' as PRECLOSURE_FEE,ProductType,'P_Loan Facts' as SMA_TYPE ,'Document Master' as DOC_ID from {SRCSCH}.`pragati-clientloansubscription` where ProductType is null and ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\' AND Remarks not like '%duplicateloan%' ),

        clhv as (select CreatedBy as CreatedBy_client_loan,BioAuthDisbConsentDate,LoanProposalID as LoanProposalID_B,HospiCashOption,EKYCSucessDate,SpouseEKYCCaptureDate,CoApplicantEKYCSucessDate,ProposalDate,MainOTPSucessDate,AlternateOTPSucessDate,TEMPDISBURSEMENTDATE,PurposeId,ESignRRNO from {SRCSCH}.`pragati-clientloanproposal_h_view` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        dp as (select derivedproductid, productid from {SRCSCH}.`pragatimain-derivedproductmaster` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        prdm as (select PRODUCTID,ProductCode from {SRCSCH}.`pragati-productmaster` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        atls as (select ValueDate as VALUE_DATE,HIERARCHYID,CLIENTID as CLIENTID_atls,CLIENTLOANID as CLIENTLOANID_E,DebitOrCredit  from {SRCSCH}.`pragati-at_loanschedules` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'
        QUALIFY ROW_NUMBER () OVER (partition by CLIENTLOANID_E order by CreatedDateTime desc, UpdatedDateTime desc )=1),

        p_cls as (select SPT_ID,ClientNewLoanID as clientloanid_pcls,type_new,Writeoff_Pri,Writeoff_Int,Writeoff_date,Writeoff_date as COMPROMISE_DATE,0 as WriteOffIntAmount from {SRCSCH}.`azuresource-p_clstagging` where ETL_IS_ACTIVE = 1 ),

        rloans as (select ClientLoanId as ClientLoanId_g,ClientLoanId as LOANID,RescheduleProcessDate as RescheduleProcessDate_new from {SRCSCH}.`pragati-rescheduleloans` where ETL_IS_ACTIVE = 1),

        d2k as (select CustomerACID, NCIF_NPA_Date, NCIF_NPA_DATE as ASSET_CLASSIFICATION_DATE from {SRCSCH}.`ptsmartnpa-d2k_npadetailsfrommanagedfiles` where  ETL_IS_ACTIVE = 1),
        preapproved as (select LoanProposalId as LoanProposalId_prea , CreatedBy as CreatedBy_preapproved from {SRCSCH}.`pragati-preapprovedproposal` where ETL_IS_ACTIVE = 1),

        prdmaster as (select  Product_Category4,PRODUCT_CATEGORY1 as ProductCategory ,PRODUCT_ID as PRODUCTCODE_J,PRODUCT_ID as productid,Product_Category4 as P_TYPE   from {SRCSCH}.`azuresource-dim_productmaster` where ETL_IS_ACTIVE = 1 and SBU='MFI'),
        all_view as (select LoanProposalId as LoanProposalId_all, LoanProposalId as DLP_SMS_Sent, LoanProposalId as DLP_Status from {SRCSCH}.`azuresource-alldlpdata_view` where ETL_IS_ACTIVE = 1 ),

        

        innerblock as (select * from cls A, clhv B , dp C, prdm D
        , atls E
        where  B.LoanProposalID_B = A.LOANPROPOSALID
        and C.DERIVEDPRODUCTID = A.PRODUCTID
        and D.PRODUCTID = C.PRODUCTID
        and E.HIERARCHYID = A.HIERARCHYID  AND E.CLIENTID_atls = A.CLIENTID  AND E.CLIENTLOANID_E = A.CLIENTLOANID
        )

        select * from innerblock A 
        left join p_cls F on F.clientloanid_pcls = A.CLIENTLOANID
        left join rloans G on G.LOANID = A.CLIENTLOANID
        left join d2k H on H.CUSTOMERACID = A.LOANPROPOSALID 
        left join preapproved I on I.LoanProposalId_prea = A.LOANPROPOSALID
        left join prdmaster J on J.PRODUCTCODE_J = A.PRODUCTCODE
        left join all_view K on K.LoanProposalId_all = A.LOANPROPOSALID '''
    elif Business == 'BMS':
        
        query = f'''with cls as (select CreatedBy,ClientId,LoanProposalId,ClientLoanId,DisbursementDate,DisbursementMode,InterestRate,InterestRate as EFFECTIVE_INTEREST_RATE,Tenure,Tenure as TL_DL,RepaymentFrequency,ClientProductSequenceNo,ExpectedPaidupDate ,ExpectedPaidupDate as MATURITY_DATE,LOANCANCELLEDDATE,LOANCANCELLEDDATE as CANCELED_FLAG,DeviationCancelledDate,LoanClosedDate,LoanClosedDate as ACCOUNT_CLOSURE_DATE,ResheduleProcessedDate,IsCoApplicantExists,CoApplicantInsuranceAmount,IsInsuranceApplicable,LoanCancellationType,Remarks,ProductId ProductId_cls,HierarchyId,'Fixed' as INTEREST_RATE_TYPE,'1' as PRECLOSURE_ALLOWED,ProductType,'P_Loan Facts' as SMA_TYPE,'Document Master' as DOC_ID from {SRCSCH}.`ptsmart-clientloansubscription` where  ProductType is null and ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        clhv as (select CreatedBy as CreatedBy_client_loan,\'\' as BioAuthDisbConsentDate,LoanProposalID as LoanProposalID_B,HospiCashOption,EKYCSucessDate,SpouseEKYCCaptureDate,CoApplicantEKYCSucessDate,ProposalDate,MainOTPSucessDate,AlternateOTPSucessDate,TEMPDISBURSEMENTDATE,PurposeId,ESignRRNO,DisbursementType,SameDayOrNextWeek,CBUpdateID from {SRCSCH}.`ptsmart-clientloanproposal` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        dp as (select derivedproductid, productid from {SRCSCH}.`ptsmart-derivedproductmaster` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        prdm as (select PRODUCTID,ProductCode from {SRCSCH}.`ptsmart-productmaster` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        atlsb as (select HIERARCHYID AS HIERARCHYID_ATLSB,CLIENTID AS CLIENTID_ATLSB,CLIENTLOANID AS CLIENTLOANID_ATLSB,
        MIN(ValueDate) as EMI_START_DATE,MAX(ValueDate) as EMI_END_DATE from {SRCSCH}.`ptsmart-accounttransactions` where ETL_IS_ACTIVE = 1 and DEBITORCREDIT = 'D'   GROUP BY CLIENTLOANID_ATLSB,CLIENTID_ATLSB,HIERARCHYID_ATLSB ),

        -- atls as (select ValueDate as VALUE_DATE,HIERARCHYID,CLIENTID,CLIENTLOANID as CLIENTLOANID_E,DebitOrCredit  from {SRCSCH}.`ptsmart-at_loanschedules` where ETL_IS_ACTIVE = 1
        -- QUALIFY ROW_NUMBER () OVER (partition by CLIENTLOANID_E order by CreatedDateTime desc, UpdatedDateTime desc )=1),

        p_cls as (select SPT_ID,ClientNewLoanID as clientloanid_pcls,type_new,Writeoff_Pri,Writeoff_Int,Writeoff_date,Writeoff_date as COMPROMISE_DATE,0 as WriteOffIntAmount from {SRCSCH}.`azuresource-p_clstagging` where ETL_IS_ACTIVE = 1),

        d2k as (select CustomerACID, NCIF_NPA_Date, NCIF_NPA_DATE as ASSET_CLASSIFICATION_DATE from {SRCSCH}.`ptsmartnpa-d2k_npadetailsfrommanagedfiles` where  ETL_IS_ACTIVE = 1 AND SourceName='PT Smart'),
        
        --prdmaster as (select  Product_Category4,PRODUCT_CATEGORY1 as ProductCategory ,PRODUCT_ID as PRODUCTCODE_J,PRODUCT_ID as --productid ,Product_Category4 as P_TYPE  from {SRCSCH}.`azuresource-dim_productmaster` where ETL_IS_ACTIVE = 1),

        tbl_loandoc as (select CLIENTID as CLIENTID_tbl,ProposalID,ProposalID as DLP_SMS_SENT,ProposalID as DLP_STATUS from {SRCSCH}.`rdsp-tbl_bms_loandocumentdetails` where ETL_IS_ACTIVE = 1 and LoanDocFlag='1' ),

        --bmscbdetails as(select PTClientID, ClientID As BFILNumber from {SRCSCH}.`rdsp_trans-tbl_bmscbdetails` where ETL_IS_ACTIVE = 1 --qualify row_number() over(PARTITION BY PTCLIENTID ORDER BY CreatedDateTime desc) = 1  ),

        BMSRRNNumbers AS (
            SELECT
                B.CreatedDateTime,      
                B.PTClientID,      
                B.ClientID AS BFILNumber,      
                C.ProposalID,      
                C.LoanID,      
                (CASE
                    WHEN (MAX(B.RRNNumber) OVER (PARTITION BY B.PTClientID ORDER BY auto_id DESC ROWS CURRENT ROW)) IS NOT NULL      
                    THEN MAX(B.RRNNumber) OVER (PARTITION BY B.PTClientID ORDER BY auto_id DESC ROWS CURRENT ROW)
                    ELSE C.RRN
                END) AS RRNNumber          
            FROM (Select * from {SRCSCH}.`PTSMART-CLIENTLOANSUBSCRIPTION` Where ETL_IS_ACTIVE = 1  and ProductType Is Null ) A
            JOIN (Select * from {SRCSCH}.`RDSP_Trans-tbl_BMSCBDetails` where ETL_IS_ACTIVE = 1 ) B  
        
                ON B.PTClientID = A.ClientID                                    
            JOIN (Select * from {SRCSCH}.`RDSP-tbl_BMS_LoanDocumentDetails` where ETL_IS_ACTIVE = 1  ) C
        
                ON C.ClientID = B.PTClientID
        ),                                  
        BMSMaxDate AS (
            SELECT ProposalID, MAX(CreatedDateTime) AS CreatedDateTime      
            FROM BMSRRNNumbers      
            GROUP BY ProposalID
        ),  
        BMSOTPBioAuthData AS (
            SELECT
                Distinct B.RRNNumber,
                'with Bio-auth' AS BioAuthStatus,
                B.ProposalID
            FROM BMSRRNNumbers B  
            JOIN BMSMaxDate C
                ON C.ProposalID = B.ProposalID
                AND C.CreatedDateTime = B.CreatedDateTime
        ),
   


        innerblock as (select * from cls A, clhv B , dp C, prdm D
        ---, atlsb E
        where  B.LoanProposalID_B = A.LOANPROPOSALID
        and C.DERIVEDPRODUCTID = A.ProductId_cls
        and D.PRODUCTID = C.PRODUCTID
        --and E.HIERARCHYID_ATLSB = A.HIERARCHYID  AND E.CLIENTID_ATLSB = A.CLIENTID  AND E.CLIENTLOANID_ATLSB = A.CLIENTLOANID
        )
       select * from innerblock A 
        left join p_cls F on F.SPT_ID = A.CLIENTLOANID
        left join d2k G on G.CUSTOMERACID = A.LOANPROPOSALID 
        ----left join prdmaster H on H.PRODUCTCODE_J = A.ProductId_cls
        left join tbl_loandoc I on I.ProposalID = A.LOANPROPOSALID
        ----left join bmscbdetails J on J.PTClientID = A.CLIENTID 
        left join BMSOTPBioAuthData z on z.ProposalID=A.LOANPROPOSALID
        left join atlsb E on  E.HIERARCHYID_ATLSB = A.HIERARCHYID  AND E.CLIENTID_ATLSB = A.CLIENTID  AND E.CLIENTLOANID_ATLSB = A.CLIENTLOANID
        '''
    elif Business == 'BSS':
        

       query = f'''with cls as (SELECT ProductId, CreatedBy, CustomerId, LoanApplicationID, CustomerLoanId, 
       DisbursementDate, DisbursementMode, InterestRate,InterestRate as EFFECTIVE_INTEREST_RATE, Tenure, RepaymentFrequency, 
       CustomerProductSequenceNo, ExpectedPaidupDate, ExpectedPaidupDate AS MATURITY_DATE, LOANCANCELLEDDATE, LoanClosedDate, PreCloseChargesPercent, PreCloseChargesPercent as PRECLOSURE_FEE ,
       IsCoApplicantExists, CoApplicantInsuranceAmount, IsInsuranceApplicable, 
       deviationCancelledDate,HierarchyId,LoanPreClosedDate,'Fixed' as INTEREST_RATE_TYPE,'P_Loan Facts' as SMA_TYPE,'Document Master' as DOC_ID FROM {SRCSCH}.`rlmsbizxtend-customerloandisbursement` where  ProductType is null and ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

       additonaldetails as (SELECT LoanApplicationId as LoanApplicationId_additional, LoanApplicationType,  
                CancelDate, deviationCancelledDate as deviationCancelledDate_add , ESignRRNO, EKYCSucessDate, 
               CancelRemarks as CANELED_DEVIATION_REASON
            FROM {SRCSCH}.`rlmsbizxtend-additionalloanapplicationdetails`  where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        custloanapplication as (SELECT LoanApplicationId as LoanApplicationId_cust,purposeid
            FROM {SRCSCH}.`rlmsbizxtend-customerloanapplication` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        prdmaster as (SELECT ProductCode, ProductId FROM {SRCSCH}.`rlmsbizxtend-productmaster` where ETL_IS_ACTIVE = 1 and ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'),

        pcls as (select Type_New ,Type_New as WRITE_OFF_DATE,Writeoff_Int,Writeoff_Pri,ClientNewLoanID as clientloanid_pcls,SPT_ID  as CustomerLoanId_pcls  FROM {SRCSCH}.`azuresource-p_clstagging` where ETL_IS_ACTIVE = 1 ),

        atlsb as (select ValueDate as VALUE_DATE,DebitOrCredit,HierarchyId as HierarchyId_atlsb,CustomerId as CustomerId_atlsb,CustomerLoanId as CustomerLoanId_atlsb  from {SRCSCH}.`rlmsbizxtend-loantransactions` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER () OVER (partition by HIERARCHYID 
        order by CreatedDateTime desc,UpdatedDateTime
        desc )=1),

        cons as (select id from {SRCSCH}.`rlmsbizxtend-bfil_CONSENTS` where ETL_IS_ACTIVE = 1),

        bfil_consesnt as (select CustomerId as CustomerId_bfilconsens,CONSENTS  from {SRCSCH}.`rlmsbizxtend-BFIL_CONSENTSCONFIRMED` where ETL_IS_ACTIVE = 1 and CONSENTS IN ('60','61') QUALIFY ROW_NUMBER () OVER (partition by CustomerId order by CreatedDateTime desc )=1),

        d2k as (select CustomerACID, NCIF_NPA_Date, NCIF_NPA_DATE as ASSET_CLASSIFICATION_DATE from {SRCSCH}.`ptsmartnpa-d2k_npadetailsfrommanagedfiles` where  ETL_IS_ACTIVE = 1 AND SourceName='PT Smart'),

        dimprdmaster as (select PSL_CATEGORY,PSL_CATEGORY as PSL_FLAG,product_ID as ProductCode_dim from {SRCSCH}.`azuresource-dim_productmaster` where ETL_IS_ACTIVE = 1),

        cgtmselog as (select LeegalityLink,CustomerId as CustomerId_cgtmselog,ProposalId from {SRCSCH}.`rlmsbizxtend-bfil_cgtmselog`
        where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER () OVER (partition by ProposalId 
        order by CreatedDate desc )=1),

        kycmaster as(select KYCNumber,CustomerId as CustomerId_kyc,clientorspouse from {SRCSCH}.`rlmsbizxtend-kycmaster` where KYCType='IDP1' and clientorspouse='M' and ETL_IS_ACTIVE = 1),


        
        innerblock as (select * from cls A, additonaldetails B , custloanapplication C, prdmaster D
        , atlsb E
        where  B.LoanApplicationId_additional = A.LoanApplicationId
        and C.LoanApplicationId_cust = A.LoanApplicationId
        and D.PRODUCTID = A.PRODUCTID
        and E.HierarchyId_atlsb = A.HIERARCHYID  AND E.CustomerId_atlsb = A.CustomerId  AND E.CustomerLoanId_atlsb = A.CustomerLoanId
        )

       select * from innerblock A 
        left join pcls F on F.CustomerLoanId_pcls = A.CustomerLoanId
        left join bfil_consesnt G on G.CustomerId_bfilconsens = A.CustomerId 
        left join cons H on H.id = G.CONSENTS
        left join d2k I on I.CustomerACID = A.LoanApplicationId 
        --left join dimprdmaster J on J.ProductCode_dim = D.ProductCode
        left join cgtmselog k on k.CustomerId_cgtmselog = A.CustomerId and  k.ProposalId = A.LoanApplicationId 
        left join kycmaster l on l.CustomerId_kyc = A.CustomerId  

       '''

#         -- select * from tbl_loandoc
#         %sql
# -- select * from innerblock A 
# --         left join p_cls F on F.clientloanid_pcls = A.CLIENTLOANID
# --         left join d2k G on G.CUSTOMERACID = A.LOANPROPOSALID 
# --         left join prdmaster H on H.PRODUCTCODE_J = A.ProductId_cls
# --         left join tbl_loandoc I on I.ProposalID = A.LOANPROPOSALID
# --         left join bmscbdetails J on J.PTClientID = A.CLIENTID '''

        

    df = spark.sql(query)

    # print(query)
    
    return df



# COMMAND ----------

def dim_loan_account(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_LOANACCOUNT_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_loan_account")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        df = None

        df = querystore (Business,stdate,eddate)
        rowCountDF = df.count()
        print("rowCountDF",rowCountDF)
       
        if df and renameFields and rowCountDF:
            df = df.withColumn("TL_DL", when(col("Tenure").isin(12, 25, 52, 50), "DL").otherwise("TL"))\
                .withColumn("ACCOUNT_CLOSED_FLAG", when(col("LoanClosedDate").isNotNull(), "1").otherwise("0"))\
                .withColumn("NPA_FLAG", when(col("CUSTOMERACID").isNotNull(), "1").otherwise("0"))\
                .withColumn("WRITE_OFF_FLAG", when(col("clientloanid_pcls").isNotNull(), 1).otherwise(0))\
                .withColumn("Deviation_Cancelled_Flag", when(col("DeviationCancelledDate").isNotNull(), 1).otherwise(0))
                
                # .withColumn("INTEREST_RATE_TYPE", lit("Fixed"))

            
            if Business == 'MFI':
                window_spec = Window.orderBy().rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
                df = df.withColumn(
                    "EMI_START_DATE", 
                    min(when(col("DebitOrCredit") == 'D', col("VALUE_DATE"))).over(window_spec)
                ).withColumn(
                    "EMI_END_DATE", 
                    max(when(col("DebitOrCredit") == 'D', col("VALUE_DATE"))).over(window_spec)
                )

                df=df.withColumn("CANELED_DEVIATION_REASON", coalesce(col("LoanCancellationType"), col("Remarks"))).withColumn(
                    "CANCELED_TYPE",
                    when(col("deviationCancelledDate").isNotNull(), "Deviation")
                    .when(col("LoanCancelledDate").isNotNull(), "Cancel")
                    .otherwise(None)
                )
                df=df.withColumn("CANCELED_FLAG", when(col("LoanCancelledDate").isNotNull(), "1").otherwise("0"))
                df=df.withColumn("LOAN_STATUS", when(coalesce(col("LoanCancelledDate"), col("DeviationCancelledDate")).isNotNull(), "Cancel")\
                    .when(coalesce(col("LoanClosedDate"), lit('1900-01-01')) == '1900-01-01', "Open").when(col("LoanClosedDate") < col("ExpectedPaidupDate"), "Pre-Closure").otherwise("Closed"))
                df = df.withColumn("IS_OPTEDHOSPICASH", when(col("HospiCashOption") == 1, 1).otherwise(None)).withColumn("DLP_SMS_Sent", when(col("DLP_SMS_Sent").isNotNull(), "1").otherwise("0")).withColumn("DLP_Status", when(col("DLP_Status").isNotNull(), "Yes").otherwise("No"))
                df=df.withColumn("Product_Category4", when(col("Product_Category4").isin('TWO', 'FUL'), 'Secured').otherwise('Un-Secured'))\
                    .withColumn('RESHEDULE_DATE',when(col('ProductCategory') == 'Suvidha', col('ResheduleProcessedDate')).otherwise(col('RescheduleProcessDate_new')))
                df = df.withColumn("SPT_ID", when(col("SPT_ID").isNotNull(), "1").otherwise("0"))\
                    .withColumn("WriteOffAmount", col("Writeoff_Pri") + col("Writeoff_Int") )
                df = df.withColumn("COMPROMISE_AMOUNT", col("WriteOffAmount") + col("WriteOffIntAmount"))\
                    .withColumn("P_TYPE", when(col("P_TYPE").isin('TWO', 'FUL'), 'Secured').otherwise('Un-Secured'))
                    
                    
                    
                df = df.withColumn(
                    'LOAN_TYPE',
                    when(
                        (col('ProductCategory').isin('FUL', 'Two Wheelers')) & (col('CreatedBy_client_loan').like('%HO%')), 'Preapproved'
                    ).when(
                        col('ProductCategory').isin('FUL', 'Two Wheelers'), 'Instant'
                    ).when(
                        col('ProductCategory').like('%Unnati%'), 'Preapproved'
                    ).when(
                        (col('ProductCategory') == 'MFI') & (col('CreatedBy_preapproved').like('%HO%')), 'Preapproved'
                    ).otherwise('Instant')
                )

                df = df.withColumn(
                    "OTP_BIOAUTH",
                    when(
                        col("ProductCategory") == "Two Wheelers",
                        when(
                            (col("EKYCSucessDate") != '1900-01-01') &
                            (
                                (col("SpouseEKYCCaptureDate") != '1900-01-01') |
                                (col("CoApplicantEKYCSucessDate") != '1900-01-01')
                            ),
                            "with Bio-auth"
                        )
                    ).otherwise(
                        when(
                            col("ProposalDate") == col("EKYCSucessDate"), "with Bio-auth"
                        ).when(
                            col("ProposalDate") == col("MainOTPSucessDate"), "with OTP"
                        ).when(
                            col("ProposalDate") == col("AlternateOTPSucessDate"), "with OTP"
                        ).when(
                            col("TEMPDISBURSEMENTDATE") == col("EKYCSucessDate"), "with Bio-auth"
                        ).when(
                            col("TEMPDISBURSEMENTDATE") == col("MainOTPSucessDate"), "with OTP"
                        ).when(
                            col("TEMPDISBURSEMENTDATE") == col("AlternateOTPSucessDate"), "with OTP"
                        ).otherwise("Without Bio-auth & OTP")
                    )
                )

            elif Business == 'BMS':
                # df=df.withColumn("OTP_BIOAUTH")
                dimproductmasterdf=spark.sql(f'''select  Product_Category4,PRODUCT_CATEGORY1 as ProductCategory ,PRODUCT_ID as PRODUCTCODE_J,PRODUCT_ID as productid ,Product_Category4 as P_TYPE  from {SRCSCH}.`azuresource-dim_productmaster` where ETL_IS_ACTIVE = 1 AND SBU='BMS' ''')
                df = df.join(dimproductmasterdf, df["ProductCode"] == dimproductmasterdf["PRODUCTCODE_J"], 'left')

                df=df.withColumn("LOAN_STATUS", when(coalesce(col("LoanCancelledDate"), col("DeviationCancelledDate")).isNotNull(), "Cancel")\
                    .when(coalesce(col("LoanClosedDate"), lit('1900-01-01')) == '1900-01-01', "Open").when(col("LoanClosedDate") < col("EMI_END_DATE"), "Pre-Closure").otherwise("Closed"))
                df=df.withColumn("CANCELED_FLAG", when(col("LoanCancelledDate").isNotNull(), "1").otherwise("0"))
                df=df.withColumn("CANELED_DEVIATION_REASON", coalesce(col("LoanCancellationType"), col("Remarks"))).withColumn(
                    "CANCELED_TYPE",
                    when(col("deviationCancelledDate").isNotNull(), "Deviation")
                    .when(col("LoanCancelledDate").isNotNull(), "Cancel")
                    .otherwise(None)
                )
                
                df = df.withColumn('LOAN_TYPE',when(
                                (col('DisbursementType') == 'I') & (col('SameDayOrNextWeek') == 'Same Day'), 'Instant'
                            ).when(
                                col('CreatedBy_client_loan') == 'HO', 'Preapproved'
                            ).when(
                                col('CBUpdateID').like('%:P%'), 'Preapproved'
                            ).otherwise('Normal')
                        )\
                    .withColumn("DLP_SMS_SENT", when(col("DLP_SMS_SENT").isNotNull(), "1").otherwise("0"))\
                    .withColumn("DLP_STATUS", when(col("DLP_STATUS").isNotNull(), "Yes").otherwise("No"))\
                    .withColumn("P_TYPE", when(col("P_TYPE").isin('TWO', 'FUL'), 'Secured').otherwise('Un-Secured'))\
                    .withColumn("OTP_BIOAUTH",lit(col("BioAuthStatus")))
                    
            elif Business=='BSS':
                window_spec = Window.orderBy().rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
                df = df.withColumn(
                    "EMI_START_DATE", 
                    min(when(col("DebitOrCredit") == 'D', col("VALUE_DATE"))).over(window_spec)
                ).withColumn(
                    "EMI_END_DATE", 
                    max(when(col("DebitOrCredit") == 'D', col("VALUE_DATE"))).over(window_spec)
                )

                dimproductmasterdf=spark.sql(f'''select PSL_CATEGORY,PSL_CATEGORY as PSL_FLAG,product_ID as ProductCode_dim from {SRCSCH}.`azuresource-dim_productmaster` where ETL_IS_ACTIVE = 1''')
                df = df.join(dimproductmasterdf, df["ProductCode"] == dimproductmasterdf["ProductCode_dim"], 'left')
                df=df.withColumn("CANCELED_FLAG", when(col("CancelDate").isNotNull(), "1").otherwise("0"))\
                    .withColumn(
                        "CANCELED_TYPE",
                        when(col("deviationCancelledDate").isNotNull(), "Deviation")
                        .when(col("CancelDate").isNotNull(), "Cancel")
                        .otherwise(None)
                    )\
                    .withColumn("LOAN_STATUS", when(coalesce(col("LoanCancelledDate"), col("DeviationCancelledDate")).isNotNull(), "Cancel")\
                    .when(coalesce(col("LoanClosedDate"), lit('1900-01-01')) == '1900-01-01', "Open").when(col("LoanPreClosedDate").isNotNull(),"Pre-Closure" ).otherwise("Closed"))\
                    .withColumn(
                    "SECURED_UNSECURED_NOT_PERFECTED_FLAG", 
                    when(col("LeegalityLink").like("%stamp%"), "Un-Secured").otherwise("Secured"))\
                    .withColumn("PRECLOSURE_ALLOWED", when((isnull(col("PreCloseChargesPercent")) | (col("PreCloseChargesPercent") == 0)), lit(0)).otherwise(lit(1)))\
                    .withColumn("BioAuthConsentFlag", when(col("ID").isNotNull(), lit(1)).otherwise(lit(0)))\
                    .withColumn("OTP_BIOAUTH",when(length(col("ESignRRNO")) == 12, "BIOAUTH").when(length(col("ESignRRNO")) > 12, "OTP").otherwise(lit(None)))
                    
            print(renameFields)
            for val in sorted(df.columns):
                print(val)

            for val in df.columns:
                try:
                    df = df.withColumn(val, lit(col(val).cast("string")))
                except:
                    pass

            df = repartitioning_SKID(df)
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)

            # Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")

            print("df count", df.count())

 
            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_loan_account", "LOAN_PROPOSAL_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0
 
        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_loan_account"])
 
    except Exception as e:
        raise Exception("An error occurred in the dim_loan_account notebook:", str(e))

# COMMAND ----------

def dim_loan_account_version(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
       
        SKCOL,LoadCount = "DIM_LOAN_ACCOUNT_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_loan_account")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
       
        if df and renameFields and rowCountDF:
            df=df.filter(col("ProductType").isNull())
 
            if Business == 'MFI':
                df_at_loan_Schedule=spark.sql("select ValueDate as VALUE_DATE,HierarchyId,ClientId,ClientLoanId,DebitOrCredit  from {SRCSCH}.`pragati-at_loanschedules`")
                df = df.join(df_at_loan_Schedule, 
                            (df["HierarchyId"] == df_at_loan_Schedule["HierarchyId"]) & 
                            (df["ClientId"] == df_at_loan_Schedule["ClientId"]) & 
                            (df["ClientLoanId"] == df_at_loan_Schedule["ClientLoanId"]), 
                            'inner').drop(ClientId)
                productmasterdf=spark.sql("select productid,ProductCode from {SRCSCH}.`pragati-productmaster` where ETL_IS_ACTIVE = 1")
                df=df.join(productmasterdf,["productid"],'inner')
                df=df.filter(col("HospiCashOption")==1)
                dimproductmasterdf=spark.sql(f'''select  Product_Category4,PRODUCT_CATEGORY1 as ProductCategory ,PRODUCT_ID as productid  from {SRCSCH}.`azuresource-dim_productmaster` where ETL_IS_ACTIVE = 1''')
                df=df.join(dimproductmasterdf,["productid"],'left')
                df=df.withColumn("Product_Category4", when(col("Product_Category4").isin('TWO', 'FUL'), 'Secured').otherwise('Un-Secured')).withColumn('RESHEDULE_DATE',when(col('ProductCategory') == 'Suvidha', col('ResheduleProcessedDate')).otherwise(col('RescheduleProcessDate_new')))
                df = df.withColumn("TL_DL", when(col("Tenure").isin(12, 25, 52, 50), "DL").otherwise("TL"))\
                    .withColumn("CANCELED_FLAG", when(col("LoanCancelledDate").isNotNull(), "1").otherwise("0"))\
                    .withColumn("ACCOUNT_CLOSED_FLAG", when(col("LoanClosedDate").isNotNull(), "1").otherwise("0"))\
                    .withColumn("NPA_FLAG", when(col("CUSTOMERACID").isNotNull(), "1").otherwise("0"))\
                    .withColumn("SPT_ID", when(col("SPT_ID").isNotNull(), "1").otherwise("0"))\
                    .withColumn("DLP_SMS_Sent", when(col("DLP_SMS_Sent").isNotNull(), "1").otherwise("0"))\
                    .withColumn("DLP_Status", when(col("DLP_Status").isNotNull(), "Yes").otherwise("No"))\
                    .withColumn("WriteOffAmount", col("Writeoff_Pri") + col("Writeoff_Int") ).withColumn(
                        "CANCELED_TYPE",
                        when(col("deviationCancelledDate").isNotNull(), "Deviation")
                        .when(col("LoanCancelledDate").isNotNull(), "Cancel")
                        .otherwise(None)
                    ).withColumn("LOAN_STATUS", when(coalesce(col("LoanCancelledDate"), col("DeviationCancelledDate")).isNotNull(), "Cancel")\
                   .when(coalesce(col("LoanClosedDate"), lit('1900-01-01')) == '1900-01-01', "Open").when(col("LoanClosedDate") < col("ExpectedPaidupDate"), "Pre-Closure").otherwise("Closed"))
                    
                window_spec = Window.orderBy().rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
                df = df.withColumn(
                    "EMI_START_DATE", 
                    min(when(col("DebitOrCredit") == 'D', col("VALUE_DATE"))).over(window_spec)
                ).withColumn(
                    "EMI_END_DATE", 
                    max(when(col("DebitOrCredit") == 'D', col("VALUE_DATE"))).over(window_spec)
                )
                df = df.withColumn(
                    'LOAN_TYPE',
                    when(
                        (col('ProductCategory').isin('FUL', 'Two Wheelers')) & (col('CreatedBy').like('%HO%')), 'Preapproved'
                    ).when(
                        col('ProductCategory').isin('FUL', 'Two Wheelers'), 'Instant'
                    ).when(
                        col('ProductCategory').like('%Unnati%'), 'Preapproved'
                    ).when(
                        (col('ProductCategory') == 'MFI') & (col('CreatedBy').like('%HO%')), 'Preapproved'
                    ).otherwise('Instant')
                )

                df = df.withColumn(
                    "OTP_BIOAUTH",
                    when(
                        col("ProductCategory") == "Two Wheelers",
                        when(
                            (col("EKYCSucessDate") != '1900-01-01') &
                            (
                                (col("SpouseEKYCCaptureDate") != '1900-01-01') |
                                (col("CoApplicantEKYCSucessDate") != '1900-01-01')
                            ),
                            "with Bio-auth"
                        )
                    ).otherwise(
                        when(
                            col("ProposalDate") == col("EKYCSucessDate"), "with Bio-auth"
                        ).when(
                            col("ProposalDate") == col("MainOTPSucessDate"), "with OTP"
                        ).when(
                            col("ProposalDate") == col("AlternateOTPSucessDate"), "with OTP"
                        ).when(
                            col("TEMPDISBURSEMENTDATE") == col("EKYCSucessDate"), "with Bio-auth"
                        ).when(
                            col("TEMPDISBURSEMENTDATE") == col("MainOTPSucessDate"), "with OTP"
                        ).when(
                            col("TEMPDISBURSEMENTDATE") == col("AlternateOTPSucessDate"), "with OTP"
                        ).otherwise("Without Bio-auth & OTP")
                    )
                )
 
            elif Business == 'BMS':
                print("test")
           
            for val in df.columns:
                try:
                    df = df.withColumn(val, lit(col(val).cast("string")))
                except:
                    pass
           
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)
 
            # Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")
 
            LoadCount,handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_loan_account", "LOAN_PROPOSAL_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0
 
        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_loan_account"])
 
    except Exception as e:
        raise Exception("An error occurred in the dim_loan_account notebook:", str(e))