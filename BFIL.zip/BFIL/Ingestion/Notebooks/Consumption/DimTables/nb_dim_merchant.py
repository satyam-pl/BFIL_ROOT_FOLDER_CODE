# Databricks notebook source
def dimmerchant(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_MERCHANT_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_merchant")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        df=spark.sql(f'''select hierarchyid,merchant_id,merchant_name,ClientCode,clientid,branchcode,createdatetime,merchantactivedatetime,merchantdeactivedatetime,merchantaccno,latitude,longitude,imei1,imei2,shopname,merchant_uidai_no from {SRCSCH}.`rdsp-merchant_master` where ETL_IS_ACTIVE = 1 and length(trim(MERCHANT_ID))>= 8''')
        if df and renameFields and rowCountDF:
            # df = df.filter(substring(col("MERCHANT_ID"), 1, 3) == 'I00')
            
            df_client_values = df.select("ClientCode").distinct()
            query = f"select bioid,ClientCode from {SRCSCH}.`rdsp-rdsp_assetmapping` where ETL_IS_ACTIVE = 1"
            rdsp_assetmapping__df = spark.sql(query)
            rdsp_assetmapping__df = rdsp_assetmapping__df.join(df_client_values, ["ClientCode"],"inner")
            df = df.join(rdsp_assetmapping__df,["ClientCode"],"left")

            query = f"select ClientID as ClientCode_map,membertype,recommendationsurvey,usertype,shoptype from {SRCSCH}.`rdsp-map_centers` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY ClientCode_map ORDER BY CreatedDateTime DESC) = 1"

            # df_client_count = df.select("CLIENTCODE").distinct().count()
            map_centers__df = spark.sql(query)
            # map_centers__df = map_centers__df.join(df_client_values, ["ClientCode"],"inner")
            df = df.join(map_centers__df,(df["ClientCode"] == map_centers__df["ClientCode_map"]) & (df["MERCHANT_ID"].substr(1, 3) == 'I00'),"left")
            # df = df.join(map_centers__df,["ClientCode"],"left")

            query = f"select filledby,age,maritalstatus,gender,bankname,spousename,spousedob,relationwith,mothermaidenname,fathername,urbanorrural,ownerphoto,panphoto,voterimage,votername,educationqual,documentid as DOCUMENTID,docdatetime,cbstatus,ekycstatus,isdocvirtualsignaturedone,iibfcertification,iibfcertificationnumber,recommend,rrnnumber,communicationskills,enrollmentnumber,form60,shopname as MERCHANT_SHOPNAME,ownshop,shopphoto,ClientID as ClientCode_sareg from {SRCSCH}.`rdsp-sa_registration` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY ClientCode_sareg ORDER BY Createdatetime DESC) =1"

            df_sa_reg = spark.sql(query)
            # df_sa_reg = df_sa_reg.join(df_client_values, ["ClientCode"],"inner")
            # df = df.join(df_sa_reg,["ClientCode"],"left")
            
            df = df.join(df_sa_reg,(df["CLIENTCODE"] == df_sa_reg["ClientCode_sareg"]) & (df["MERCHANT_ID"].substr(1, 3) == 'I00'),"left")

            dfcount = df.count()
            df_merchantcount = df.select("MERCHANT_ID").distinct().count()


            df = df.withColumn("MERCHANT_CLIENTID", lit(col("CLIENTID")))

            df_merchant=spark.sql(f'''select EffectiveDate,merchant_status,merchant_id as MERCHANT_ID from {SRCSCH}.`rdsp_trans-merchant_master` where ETL_IS_ACTIVE = '1' ''')

            df = df.join(df_merchant, ["MERCHANT_ID"], "left")


            df_login_bmo=spark.sql(f'''select UserID ,UserName as ENROL_STAFF_NAME from {SRCSCH}.`rdsp-rdsp_login_bmo` where ETL_IS_ACTIVE = '1'  ''')

            df = df.join(
                df_login_bmo, 
                df['FILLEDBY'] == df_login_bmo['UserID'], 
                'left'
            ).drop("UserID")

            dfcount = df.count()
            df_merchantcount = df.select("MERCHANT_ID").distinct().count()


            df = df.withColumn(\
                "URBAN_OR_RURAL",
                when(df["urbanorrural"] == 1, "Urban")\
                .when(df["urbanorrural"] == 2, "Rural")\
                .otherwise(None))
            df = df.withColumn(\
                    "MERCHANT_TYPE",
                    when(col("MERCHANT_ID").startswith('I00'), 'BMS')\
                    .when(col("MERCHANT_ID").startswith('I0C'), 'LBS')\
                    .when(col("MERCHANT_ID").startswith('I0E'), 'BCS')\
                    .otherwise(lit(None))
                )

            df = df.withColumn(
                "AGREEMENT_PATH",
                concat(lit(r'\\DCPRFS\Rdsp_images\AggrementDocuments\\'), col("DOCUMENTID"), lit('.pdf'))
            )

            df = df.withColumn(
                "AGREEMENT_EXPIRYDATE",
                when((to_date(col("DocDateTime")) >= '2021-10-13') & (col("IsDocVirtualSignatureDone") == 1), add_months(col("DocDateTime"), 60))
                .when((to_date(col("DocDateTime")) < '2021-10-13') & (col("IsDocVirtualSignatureDone") == 1), add_months(col("DocDateTime"), 24))
                .otherwise(None)
            )

            df = df.withColumn(
            "ESIGN_STATUS",
            when(col("IsDocVirtualSignatureDone") == 0, 'ESign Pending')
            .when(col("IsDocVirtualSignatureDone") == 1, 'ESign Completed')
            .when(col("IsDocVirtualSignatureDone") == 9, 'ESign Blocked/Disabled')
            .otherwise(None)
            )
            df_kycmaster=spark.sql(f'''select KYCNUMBER, CLIENTORSPOUSE,TargetId from {SRCSCH}.`ptsmart-kycmaster` where ETL_IS_ACTIVE = '1' QUALIFY ROW_NUMBER() OVER (PARTITION BY TargetId ORDER BY CreatedDateTime,UpdatedDateTime DESC) = 1  ''')
            df_clintmaster=spark.sql(f'''select TargetId,ClientId as PT_CLIENTID  from {SRCSCH}.`ptsmart-clientmaster` 
            where ETL_IS_ACTIVE = '1' ''')

            df = df.alias("A").join( df_kycmaster.alias("G"), (col("G.KYCNumber") == col("A.MERCHANT_UIDAI_NO")) & (col("G.CLIENTORSPOUSE").isin('M', 'Y')), "left" ).join( df_clintmaster.alias("H"), ["TargetId"], "left" )
                            
            df = repartitioning_SKID(df)
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)
  

            #Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")

            LoadCount= handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_merchant", "MERCHANT_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)

        rowCountDF = rowCountDF if rowCountDF else 0

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dimMerchant"])

    except Exception as e:
        raise Exception("An error occurred in the dimmerchant notebook:", str(e))

