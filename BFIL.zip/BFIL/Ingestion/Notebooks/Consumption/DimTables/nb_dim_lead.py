# Databricks notebook source
def dimlead(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try :
        SKCOL,LoadCount = "DIM_TARGET_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_lead")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        print("Dataframe count from framework", df.count(),rowCountDF)

        if df and renameFields and rowCountDF:

            if Business =="MFI":
                kycmaster_df_idp6 = spark.sql(f'''
                    WITH Max_SeqID AS (
                        SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                        FROM {SRCSCH}.`pragati-kycmaster`
                        WHERE ClientOrSpouse IN ('M') AND ETL_IS_ACTIVE = '1' AND KYCType='IDP6'
                        GROUP BY TargetID, KYCType
                    )
                    SELECT A.KYCTYPE AS KYCType_IDP6, A.ISEKYCSTATUS AS ISEKYCSTATUS_IDP6, A.ClientOrSpouse AS ClientOrSpouse_IDP6, 
                        A.voternamepercentage AS voternamepercentage_IDP6, A.TargetId, A.rrnumber AS rrnumber_IDP6
                    FROM {SRCSCH}.`pragati-kycmaster` A
                    INNER JOIN Max_SeqID B
                        ON B.TargetID = A.TargetID
                        AND B.KYCType = A.KYCType
                        AND B.MaxSeqID = A.SequenceID
                    WHERE A.ETL_IS_ACTIVE = '1'
                    AND ETL_LAST_UPDATED_DATE >= '{stdate}'
                    AND ETL_LAST_UPDATED_DATE <= '{eddate}'
                ''')

                df = df.join(kycmaster_df_idp6, ["TargetID"], "left")

                # Second join for IDP8 KYCType
                kycmaster_df_idp8 = spark.sql(f'''
                    WITH Max_SeqID AS (
                        SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                        FROM {SRCSCH}.`pragati-kycmaster`
                        WHERE ClientOrSpouse IN ('M') AND ETL_IS_ACTIVE = '1' AND KYCType='IDP8'
                        GROUP BY TargetID, KYCType
                    )
                    SELECT A.KYCTYPE AS KYCType_IDP8, A.ISEKYCSTATUS AS ISEKYCSTATUS_IDP8, A.ClientOrSpouse AS ClientOrSpouse_IDP8, 
                        A.voternamepercentage AS voternamepercentage_IDP8, A.TargetId, A.rrnumber AS rrnumber_IDP8
                    FROM {SRCSCH}.`pragati-kycmaster` A
                    INNER JOIN Max_SeqID B
                        ON B.TargetID = A.TargetID
                        AND B.KYCType = A.KYCType
                        AND B.MaxSeqID = A.SequenceID
                    WHERE A.ETL_IS_ACTIVE = '1'
                    AND ETL_LAST_UPDATED_DATE >= '{stdate}'
                    AND ETL_LAST_UPDATED_DATE <= '{eddate}'
                ''')

                df = df.join(kycmaster_df_idp8, ["TargetID"], "left")

                # Now we reference the renamed columns to avoid ambiguity
                df = df.withColumn("isekycstatus", when((col("KYCType_IDP6") == "IDP6") & (col("ClientOrSpouse_IDP6") == "M"), col("ISEKYCSTATUS_IDP6")).otherwise(None))\
                    .withColumn("rrnumber", when((col("KYCType_IDP6") == "IDP6") & (col("ClientOrSpouse_IDP6") == "M"), col("rrnumber_IDP6")).otherwise(None))\
                    .withColumn("voternamepercentage", when((col("KYCType_IDP8") == "IDP8") & (col("ClientOrSpouse_IDP8") == "M"), col("voternamepercentage_IDP8")).otherwise(None))

                # df = df.withColumn("isekycstatus", when((col("KYCType") == "IDP6") & (col("ClientOrSpouse") == "M"), lit(col("isekycstatus"))) .otherwise(None)) .withColumn("rrnumber", when((col("KYCType") == "IDP6") & (col("ClientOrSpouse") == "M"), lit(col("rrnumber"))) .otherwise(None)) .withColumn("voternamepercentage", when((col("KYCType") == "IDP8") & (col("ClientOrSpouse") == "M"), lit(col("voternamepercentage"))) .otherwise(None))
            elif  Business =="BMS":
                kycmaster_df_idp6 = spark.sql(f'''
                    WITH Max_SeqID AS (
                        SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                        FROM {SRCSCH}.`ptsmart-kycmaster`
                        WHERE ClientOrSpouse IN ('M') AND ETL_IS_ACTIVE = '1' AND KYCType='IDP6'
                        GROUP BY TargetID, KYCType
                    )
                    SELECT A.KYCTYPE AS KYCType_IDP6, A.ISEKYCSTATUS AS ISEKYCSTATUS_IDP6, A.ClientOrSpouse AS ClientOrSpouse_IDP6, 
                        A.voternamepercentage AS voternamepercentage_IDP6, A.TargetId, A.rrnumber AS rrnumber_IDP6
                    FROM {SRCSCH}.`ptsmart-kycmaster` A
                    INNER JOIN Max_SeqID B
                        ON B.TargetID = A.TargetID
                        AND B.KYCType = A.KYCType
                        AND B.MaxSeqID = A.SequenceID
                    WHERE A.ETL_IS_ACTIVE = '1'
                    AND ETL_LAST_UPDATED_DATE >= '{stdate}'
                    AND ETL_LAST_UPDATED_DATE <= '{eddate}'
                ''')

                df = df.join(kycmaster_df_idp6, ["TargetID"], "left")

                # Second join for IDP8 KYCType
                kycmaster_df_idp8 = spark.sql(f'''
                    WITH Max_SeqID AS (
                        SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                        FROM {SRCSCH}.`ptsmart-kycmaster`
                        WHERE ClientOrSpouse IN ('M') AND ETL_IS_ACTIVE = '1' AND KYCType='IDP8'
                        GROUP BY TargetID, KYCType
                    )
                    SELECT A.KYCTYPE AS KYCType_IDP8, A.ISEKYCSTATUS AS ISEKYCSTATUS_IDP8, A.ClientOrSpouse AS ClientOrSpouse_IDP8, 
                        A.voternamepercentage AS voternamepercentage_IDP8, A.TargetId, A.rrnumber AS rrnumber_IDP8
                    FROM {SRCSCH}.`ptsmart-kycmaster` A
                    INNER JOIN Max_SeqID B
                        ON B.TargetID = A.TargetID
                        AND B.KYCType = A.KYCType
                        AND B.MaxSeqID = A.SequenceID
                    WHERE A.ETL_IS_ACTIVE = '1'
                    AND ETL_LAST_UPDATED_DATE >= '{stdate}'
                    AND ETL_LAST_UPDATED_DATE <= '{eddate}'
                ''')

                df = df.join(kycmaster_df_idp8, ["TargetID"], "left")

                # Now we reference the renamed columns to avoid ambiguity
                df = df.withColumn("isekycstatus", when((col("KYCType_IDP6") == "IDP6") & (col("ClientOrSpouse_IDP6") == "M"), col("ISEKYCSTATUS_IDP6")).otherwise(None))\
                    .withColumn("rrnumber", when((col("KYCType_IDP6") == "IDP6") & (col("ClientOrSpouse_IDP6") == "M"), col("rrnumber_IDP6")).otherwise(None))\
                    .withColumn("voternamepercentage", when((col("KYCType_IDP8") == "IDP8") & (col("ClientOrSpouse_IDP8") == "M"), col("voternamepercentage_IDP8")).otherwise(None))

            else:
                df = df.withColumn("isekycstatus", lit(None)).withColumn("voternamepercentage", lit(None))
            
            df = df.distinct()
            
            if Business !="BSS":
                df_cb_id = spark.sql(f"""
                    WITH CreditBureauUpdateData AS (
                        SELECT 
                            TargetID,
                            MAX(CreatedDateTime) AS MaxCBDate,
                            MAX(COALESCE(CBSUbmittedDate, CreatedDateTime)) AS MaxCBDate_1,
                            MAX(COALESCE(CBResponseDate, CreatedDateTime)) AS MaxCBDate_2,
                            MAX(sequenceid) AS MaxSequenceID
                        FROM {SRCSCH}.`pragati-creditbureauupdate`
                        WHERE CAST(CreatedDateTime AS DATE) >= '2022-04-01'
                        AND ETL_IS_ACTIVE = 1
                        AND LoanProposalID IS NULL
                        GROUP BY TargetID), joindata AS (
                        SELECT 
                            A.CBResponseID,
                            A.TargetID,
                            A.CBStatus
                        FROM {SRCSCH}.`pragati-creditbureauupdate` A
                        JOIN CreditBureauUpdateData B
                            ON A.TargetID = B.TargetID
                            AND A.CreatedDateTime = B.MaxCBDate
                            AND COALESCE(A.CBSUbmittedDate, A.CreatedDateTime) = B.MaxCBDate_1
                            AND COALESCE(A.CBResponseDate, A.CreatedDateTime) = B.MaxCBDate_2
                            AND A.sequenceid = B.MaxSequenceID
                        WHERE CAST(A.CreatedDateTime AS DATE) >= '2022-04-01'
                        AND A.ETL_IS_ACTIVE = 1
                        AND A.LoanProposalID IS NULL
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY A.TargetID ORDER BY A.TargetID DESC) =1
                    )
                    SELECT *
                    FROM joindata
                    """)

  
                df= df.join(df_cb_id, ["TARGETID"] ,"left")
                
            else:
                df_cb_id=spark.sql(f'''with bfil_cbresponsedata as ( select targetid as CUSTOMERID,  ID from {SRCSCH}.`rlmsbizxtend-bfil_cb_check` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY targetid ORDER BY ApplicationEntryDate DESC) =1 ),dataval as (select A.*,B.id as CBRESPONSEID, B.EligibilityStatus,RID from bfil_cbresponsedata A left join {SRCSCH}.`rlmsbizxtend-bfil_cbresponse` B on A.ID = B.RID where B.ETL_IS_ACTIVE = 1 ) select * from dataval''' )
                df= df.join(df_cb_id, ["CUSTOMERID"] ,"left")

                df_kycmaster = spark.sql(f'''with dataval as (select customerid,'' as rejectedremarks, CAST(Createddatetime AS string) as EKYCCAPTUREDATE from {SRCSCH}.`rlmsbizxtend-kycmaster` where ETL_IS_ACTIVE = 1 and KYCTYPE='IDP6' AND CLIENTORSPOUSE ='M' QUALIFY ROW_NUMBER() OVER (PARTITION BY customerid ORDER BY customerid DESC) =1 ) select * from dataval ''')
                df= df.join(df_kycmaster, ["CUSTOMERID"] ,"left")
                        
            for val in df.columns:
                try:
                    df = df.withColumn(val, lit(col(val).cast("string")))
                except:
                    pass
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)
  
            #Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")
            print("targeid_count",df.select("TARGET_ID").count(),df.select("TARGET_ID").distinct().count())

            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_lead", "TARGET_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)

        rowCountDF = rowCountDF if rowCountDF else 0

        Stats = update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_lead"])

    except Exception as e:
        raise Exception("An error occurred in the dimlead notebook:", str(e))
