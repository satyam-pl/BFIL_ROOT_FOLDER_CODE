# Databricks notebook source
def dim_loan_hierarchy(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL = "DIM_LOAN_HIERARCHY_SKEY"
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        df = df.withColumn(SKCOL,lit(None))
      
        if df and renameFields and rowCountDF:
            SRCDB = ""

            if Business == "MFI" or Business == "BMS" :                
                if Business == "MFI" :
                    SRCDB = "`pragati-clientloansubscription`"
                elif Business == "BMS" :
                    SRCDB ="`ptsmart-clientloansubscription`"

                clientloansubscription_df = spark.sql(f"""select LoanProposalId, ClientLoanID, ClientLoanCode, RDAccountNumber from {SRCSCH}.{SRCDB} where ETL_IS_ACTIVE='1' """)

                df = df.join(clientloansubscription_df, ['LoanProposalId'], 'left')

            if Business == "BSS" :    
                additionalloanapplicationdetails_df = spark.sql(f"""select LoanApplicationId, LoanProposalCode from {SRCSCH}.`rlmsbizxtend-additionalloanapplicationdetails` where ETL_IS_ACTIVE='1' """)
 
                df=df.join(additionalloanapplicationdetails_df, ['LoanApplicationId'], 'left')
 
                customerloandisbursement_df = spark.sql(f"""select LoanApplicationId, CustomerLoanId, CustomerLoanCode, RDAccountNumber from {SRCSCH}.`rlmsbizxtend-customerloandisbursement` where ETL_IS_ACTIVE='1' """)
 
                df=df.join(customerloandisbursement_df, ['LoanApplicationId'], 'left')

            df = selectAndRename(df,renameFields)
           
            #Execution method
            withColVar = MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")
 
        rowCountDF = rowCountDF if rowCountDF else 0
        return df, rowCountDF
 
    except Exception as e:
        raise Exception("An error occurred in the dim_loan_hierarchy notebook:", str(e))

# COMMAND ----------

def dim_loan_hierarchy_driver(
    TargetTable,
    business_values,
    stdate,
    eddate,
    DBG_FLG,
    adb_consumption_catlog_schema,
    pipeline_run_id,
):
    try:
        business_values = business_values.split(",")
        SKCOL = "DIM_LOAN_HIERARCHY_SKEY"
        prevSKVal = maxsk(SKCOL, f"{TRGSCH}.dim_loan_hierarchy")
        MFI_df, MFI_rowcount, BMS_df, BMS_rowcount, BSS_df, BSS_rowcount = (
            None,
            None,
            None,
            None,
            None,
            None,
        )

        # Loop through business values, call FrameWork function and union results
        for business in business_values:
            if business == "MFI":
                MFI_df, MFI_rowcount = dim_loan_hierarchy(
                    TargetTable,
                    business,
                    stdate,
                    eddate,
                    DBG_FLG,
                    adb_consumption_catlog_schema,
                    pipeline_run_id,
                )
            elif business == "BMS":
                BMS_df, BMS_rowcount = dim_loan_hierarchy(
                    TargetTable,
                    business,
                    stdate,
                    eddate,
                    DBG_FLG,
                    adb_consumption_catlog_schema,
                    pipeline_run_id,
                )
            elif business == "BSS":
                BSS_df, BSS_rowcount = dim_loan_hierarchy(
                    TargetTable,
                    business,
                    stdate,
                    eddate,
                    DBG_FLG,
                    adb_consumption_catlog_schema,
                    pipeline_run_id,
                )

        if MFI_df and BMS_df and BSS_df:
            df = MFI_df.union(BMS_df).union(BSS_df)
            # rowcount = MFI_rowcount + BMS_rowcount + BSS_rowcount
        elif MFI_df and BMS_df:
            df = MFI_df.union(BMS_df)
            # rowcount = MFI_rowcount + BMS_rowcount
        elif BSS_df and MFI_df:
            df = BSS_df.union(MFI_df)
            # rowcount = BSS_rowcount + MFI_rowcount
        elif BSS_df and BMS_df:
            df = BSS_df.union(BMS_df)
            # rowcount = BSS_rowcount + BMS_rowcount
        elif BSS_df:
            df = BSS_df
            # rowcount = BSS_rowcount
        elif BMS_df:
            df = BMS_df
            # rowcount = BMS_rowcount
        elif MFI_df:
            df = MFI_df
            # rowcount = MFI_rowcount
        else:
            df = None

        df = repartitioning_SKID(df)
        df = df.withColumn(SKCOL, lit(col("SKID").cast("int") + prevSKVal))

        rowcount = df.count()

        # For type truncate and load
        max_retries = 10  # Maximum number of retries
        retry_delay = 50  # Delay between retries in seconds

        retry_count = 0
        success = False
        object_name = "dim_loan_hierarchy"

        while retry_count < max_retries and not success:
            try:
                # If Delta table is exist, overwrite Delta table and write the source data
                df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{adb_consumption_catlog_schema}.{object_name}")

                logger(logger_level_info, f"Delta table has been successfully overwrite for table {object_name}.", execution_log_list, filename)
                success = True
            except Exception as e:
                retry_count += 1
                logger(logger_level_error, f"An error occurred. Retrying in {retry_delay} seconds...in {object_name}", execution_log_list, filename)
                time.sleep(retry_delay)

        if not success:
            logger(logger_level_error, f"Failed to execute the command after maximum retries is {max_retries} in {object_name}", execution_log_list, filename)
            raise Exception(f"Failed to execute the command after maximum retries is {max_retries} in {object_name}")

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowcount, rowcount, log_error_success, "", load_type, ["dim_loan_hierarchy"])
    except Exception as e:
        raise Exception("An error occurred in the dim_loan_hierarchy_driver notebook:", str(e))