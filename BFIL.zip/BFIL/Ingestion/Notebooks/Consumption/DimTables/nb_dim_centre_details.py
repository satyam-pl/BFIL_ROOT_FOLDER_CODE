# Databricks notebook source
def dimcentredetails(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_CENTRE_DETAILS_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_centre_details")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        
 
        if df and renameFields and rowCountDF:
            df_CenterCategory=spark.sql(
                                f"""WITH MAXCNTR AS(
                                Select CenterID ,Max(CreatedDateTime) As MAxCreatedDate, Max(coalesce(UpdatedDatetime,CreatedDateTime)) as MaxUpdatedDate
                                From {SRCSCH}.`pragati-centercategory` WHERE ETL_IS_ACTIVE = 1
                                Group By CenterID)
                                Select A.CenterID,A.CenterCategory as CenterCategory_temp
                                From {SRCSCH}.`pragati-centercategory` A
                                Join MAXCNTR B On B.CenterID = A.CenterID and B.MAxCreatedDate = A.CreatedDateTime and B.MaxUpdatedDate = A.UpdatedDatetime WHERE ETL_IS_ACTIVE = 1;""")
 
            df = df.join(df_CenterCategory, ['CENTERID'], 'left')
           
            df_CenterMeetingShiftLog=spark.sql(
                                f"""With ShiftCM AS(
                                    Select CenterID,Max(CreatedDateTime) AS Max_CMCreateDate, Max(coalesce(ShiftedFromDate,CreatedDateTime)) AS ShiftedFromDate, Max(coalesce(ShiftedToDate,CreatedDateTime)) AS ShiftedToDate
                                    From {SRCSCH}.`pragati-centermeetingshiftlog` WHERE ETL_IS_ACTIVE = 1
                                    Group By CenterID)
                                    Select  C.CenterID, C.ShiftedCenterMeetingDay AS ShiftedCenterMeetingDay_temp, C.ShiftedFromDate AS ShiftedFromDate_temp, C.ShiftedToDate AS ShiftedToDate_temp
                                    From {SRCSCH}.`pragati-centermASter` A
                                    Left Join ShiftCM B On B.CenterID = A.CenterID
                                    Left Join {SRCSCH}.`pragati-centermeetingshiftlog` C On C.CenterID = B.CenterID AND C.CreatedDateTime = B.Max_CMCreateDate AND coalesce(C.ShiftedFromDate,C.CreatedDateTime) = B.ShiftedFromDate AND coalesce(C.ShiftedToDate,C.CreatedDateTime) = B.ShiftedToDate WHERE A.ETL_IS_ACTIVE = 1 AND C.ETL_IS_ACTIVE = 1;""")
 
 
            df = df.join(df_CenterMeetingShiftLog , ['CENTERID'], 'left')
 
 
            df = df.withColumn("CenterCategory", lit(col("CenterCategory_temp"))).withColumn("ShiftedCenterMeetingDay", lit(col("ShiftedCenterMeetingDay_temp"))).withColumn("ShiftedFromDate", lit(col("ShiftedFromDate_temp"))).withColumn("ShiftedToDate", lit(col("ShiftedToDate_temp")))
 
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal))
            df = selectAndRename(df,renameFields)
 
            #Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")
   
            LoadCount=handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_centre_details", "CENTERID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0
 
        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_centre_details"])
 
    except Exception as e:
        raise Exception("An error occurred in the dim_centre_details notebook:", str(e))

 