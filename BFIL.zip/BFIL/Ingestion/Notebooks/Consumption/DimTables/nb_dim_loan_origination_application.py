# Databricks notebook source
def dimloanoroginationapplication(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        
        SKCOL,LoadCount = "DIM_LOAN_ORIGINATION_APPLICATION_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_loan_origination_application")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        
        if df and renameFields and rowCountDF:
            if Business=='MFI':
                clientloansubscription__df = spark.sql(f'''
                    SELECT clientloanid, loanproposalid 
                    FROM {SRCSCH}.`pragati-clientloansubscription` 
                    WHERE ETL_IS_ACTIVE = 1 
                    AND ProductType IS NULL 
                    AND Remarks not like '%duplicateloan%'
                     and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' 
                ''')

                # Joining the DataFrames
                df = df.join(clientloansubscription__df, ['loanproposalid'], "left")
                table= '`pragati-productmaster`'
                product_df=spark.sql(f'''select ProductId as productidnew,PRODUCTCODE from {SRCSCH}.{table} where ETL_IS_ACTIVE=1 QUALIFY ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY ProductId DESC) =1''')
                df= df.join(product_df, ['productidnew'], 'left' ).drop("ProductId")
            elif Business=='BMS':
                table= '`ptsmart-productmaster`'
                product_df=spark.sql(f'''select ProductId as productidnew,PRODUCTCODE from {SRCSCH}.{table} where ETL_IS_ACTIVE=1 QUALIFY ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY ProductId DESC) =1''')
                df= df.join(product_df, ['productidnew'], 'left' ).drop("ProductId")
            
            join_df=spark.sql(f'''select PRODUCT_ID as PRODUCTCODE,PSL_CATEGORY AS PSL_FLAG ,PSL_CATEGORY from {SRCSCH}.`azuresource-dim_productmaster` where ETL_IS_ACTIVE=1 QUALIFY ROW_NUMBER() OVER (PARTITION BY PRODUCT_ID ORDER BY ETL_LAST_UPDATED_DATE DESC) =1''')
            df=df.join(join_df, ['PRODUCTCODE'], 'left' )
            for val in df.columns:
                try:
                    df = df.withColumn(val, lit(col(val).cast("string")))
                except:
                    pass
            
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)

            #Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")


            LoadCount =handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_loan_origination_application", "LOAN_PROPOSAL_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_loan_origination_application"])

    except Exception as e:
        raise Exception("An error occurred in the dim_loan_origination_application notebook:", str(e))

