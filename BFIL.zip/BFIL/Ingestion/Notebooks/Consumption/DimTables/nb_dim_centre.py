# Databricks notebook source
def dimcentre(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_CENTRE_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_centre")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
 
        if df and renameFields and rowCountDF:
   
            df_state=spark.sql(f'''select StateName as STATE_NAME, StateId as STATEID from {SRCSCH}.`pragati-statemaster` where ETL_IS_ACTIVE='1' ''')
 
            df= df.join(df_state, ['STATEID'], 'left' )
 
            spark.conf.set("spark.sql.session.timeZone", "UTC")
            # df = df.withColumn('CENTERMEETINGTIME', from_utc_timestamp(col('CENTERMEETINGTIME'), 'Etc/UTC'))
            df = df.withColumn("CENTERMEETINGTIME", F.date_format("CENTERMEETINGTIME", "HH:mm:ss")).withColumn("STREET_NAME", concat_ws(',', col("street1"), col("street2")))
           
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
           
            df = selectAndRename(df,renameFields)
           
            #Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")
 
            LoadCount=handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_centre", "CENTERID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0
 
        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dimcentre"])
 
    except Exception as e:
        raise Exception("An error occurred in the dimcentre notebook:", str(e))