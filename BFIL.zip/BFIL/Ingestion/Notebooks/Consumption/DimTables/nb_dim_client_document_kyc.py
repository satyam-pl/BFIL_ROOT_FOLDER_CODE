# Databricks notebook source
def get_source_df_kyc(stdate, eddate, SRCSCH):
    query = f"""WITH kycfacts AS (
    SELECT 
        cast(CURRENT_DATE() - 1 AS DATE) AS RPT_DATE,
        'SMPT' AS BRANCH_TYPE,
        HierarchyId,
        ClientId,
        TargetId,
        CAST(NULL AS VARCHAR(255)) AS CreatedBy,
        CAST(NULL AS TIMESTAMP) AS CreatedDateTime,
        CAST(NULL AS VARCHAR(255)) AS UpdatedBy,
        CAST(NULL AS TIMESTAMP) AS UpdatedDateTime,
        CAST(NULL AS VARCHAR(255)) AS KYCType,
        CAST(NULL AS VARCHAR(255)) AS ID,
        CAST(NULL AS CHAR(1)) AS ClientOrSpouse,
        CAST(NULL AS VARCHAR(255)) AS Name,
        CAST(NULL AS TIMESTAMP) AS DateOfBirth,
        CAST(NULL AS TIMESTAMP) AS KYCIssueDate,
        CAST(NULL AS TIMESTAMP) AS CaptureDate,
        'BFIL-MFI' as SOURCE_SYSTEM_ID
    FROM {SRCSCH}.`pragati-clientmaster`   
    where  --hierarchyid ='115203' and
     ETL_IS_ACTIVE=1 AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')
-----    WHERE CAST(UpdatedDateTime AS DATE) = CAST(CURRENT_DATE() - 1 AS DATE) --
    
    UNION ALL 
    
    SELECT 
        cast(CURRENT_DATE() - 1 AS DATE) AS RPT_DATE,
        'RLMS' AS BRANCH_TYPE,
        HierarchyId,
        customerid AS ClientId,
        baselinecustomerid AS TARGETID,
        CAST(NULL AS VARCHAR(255)) AS CreatedBy,
        CAST(NULL AS TIMESTAMP) AS CreatedDateTime,
        CAST(NULL AS VARCHAR(255)) AS UpdatedBy,
        CAST(NULL AS TIMESTAMP) AS UpdatedDateTime,
        CAST(NULL AS VARCHAR(255)) AS KYCType,
        CAST(NULL AS VARCHAR(255)) AS ID,
        CAST(NULL AS CHAR(1)) AS ClientOrSpouse,
        CAST(NULL AS VARCHAR(255)) AS Name,
        CAST(NULL AS TIMESTAMP) AS DateOfBirth,
        CAST(NULL AS TIMESTAMP) AS KYCIssueDate,
        CAST(NULL AS TIMESTAMP) AS CaptureDate,
        'BFIL-BSS' as SOURCE_SYSTEM_ID
    FROM {SRCSCH}.`rlmsbizxtend-customermaster`    WHERE -- HIERARCHYID='115269'  and 
    ETL_IS_ACTIVE=1 AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')
 -----   WHERE CAST(UpdatedDateTime AS DATE) = CAST(CURRENT_DATE() - 1 AS DATE)
    
    UNION ALL
    
    SELECT 
        cast(CURRENT_DATE() - 1 AS DATE) AS RPT_DATE,
        'RDSP' AS BRANCH_TYPE,
        HierarchyId,
        ClientId,
        TargetId,
        CAST(NULL AS VARCHAR(255)) AS CreatedBy,
        CAST(NULL AS TIMESTAMP) AS CreatedDateTime,
        CAST(NULL AS VARCHAR(255)) AS UpdatedBy,
        CAST(NULL AS TIMESTAMP) AS UpdatedDateTime,
        CAST(NULL AS VARCHAR(255)) AS KYCType,
        CAST(NULL AS VARCHAR(255)) AS ID,
        CAST(NULL AS CHAR(1)) AS ClientOrSpouse,
        CAST(NULL AS VARCHAR(255)) AS Name,
        CAST(NULL AS TIMESTAMP) AS DateOfBirth,
        CAST(NULL AS TIMESTAMP) AS KYCIssueDate,
        CAST(NULL AS TIMESTAMP) AS CaptureDate,
        'BFIL-BMS' as SOURCE_SYSTEM_ID
    FROM {SRCSCH}.`ptsmart-clientmaster`
    WHERE HierarchyId IN ('114451', '114910') AND ETL_IS_ACTIVE=1 AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')
  -----  AND CAST(UpdatedDateTime AS DATE) = CAST(CURRENT_DATE() - 1 AS DATE)
)   ,---select  branch_type,count(3)  from kycfacts   group by branch_type

KYCFacts_Consolidated AS
(
  ----MFI
  SELECT A.RPT_DATE,BRANCH_TYPE, A.HierarchyId, A.ClientId, A.TargetId, A.CaptureDate, 
(CASE WHEN  COALESCE(B.KYCNumber,'')<>'' THEN B.CreatedBy ELSE A.CreatedBy END) AS CreatedBy,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.CreatedDateTime ELSE A.CreatedDateTime END) AS CreatedDateTime,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.UpdatedBy ELSE A.UpdatedBy END) AS UpdatedBy,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.UpdatedDateTime ELSE A.UpdatedDateTime END) AS UpdatedDateTime,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>'' THEN B.KYCType ELSE A.KYCType END) AS KYCType,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.KYCNUMBER ELSE A.ID END) AS ID,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.ClientOrSpouse ELSE A.ClientOrSpouse END) AS ClientOrSpouse,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.NameInKYC ELSE A.Name END) AS Name,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.DateOfBirth ELSE A.DateOfBirth END) AS DateOfBirth,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.KYCIssueDate ELSE A.KYCIssueDate END) AS KYCIssueDate,
A.SOURCE_SYSTEM_ID,
B.SequenceId
FROM KYCFacts A    JOIN {SRCSCH}.`pragati-kycmaster` B ON A.TargetId=B.TargetId 
where b.ETL_IS_ACTIVE=1 and 
 branch_type='SMPT' AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')
UNION ALL

----BSS

  SELECT A.RPT_DATE,BRANCH_TYPE ,A.HierarchyId, A.ClientId, A.TargetId, A.CaptureDate, 
(CASE WHEN  COALESCE(B.KYCNumber,'')<>'' THEN B.CreatedBy ELSE A.CreatedBy END) AS CreatedBy,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.CreatedDateTime ELSE A.CreatedDateTime END) AS CreatedDateTime,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.UpdatedBy ELSE A.UpdatedBy END) AS UpdatedBy,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.UpdatedDateTime ELSE A.UpdatedDateTime END) AS UpdatedDateTime,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>'' THEN B.KYCType ELSE A.KYCType END) AS KYCType,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.KYCNUMBER ELSE A.ID END) AS ID,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.ClientOrSpouse ELSE A.ClientOrSpouse END) AS ClientOrSpouse,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.NameInKYC ELSE A.Name END) AS Name,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.DateOfBirth ELSE A.DateOfBirth END) AS DateOfBirth,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.KYCIssueDate ELSE A.KYCIssueDate END) AS KYCIssueDate,
A.SOURCE_SYSTEM_ID,
B.SequenceId
FROM KYCFacts A   JOIN {SRCSCH}.`rlmsbizxtend-kycmaster` B ON A.TargetId=B.CUSTOMERID 
where 
b.ETL_IS_ACTIVE=1 and  
branch_type='RLMS' AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')

---BMS
UNION ALL
  SELECT A.RPT_DATE,BRANCH_TYPE, A.HierarchyId, A.ClientId, A.TargetId, A.CaptureDate, 
(CASE WHEN  COALESCE(B.KYCNumber,'')<>'' THEN B.CreatedBy ELSE A.CreatedBy END) AS CreatedBy,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.CreatedDateTime ELSE A.CreatedDateTime END) AS CreatedDateTime,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.UpdatedBy ELSE A.UpdatedBy END) AS UpdatedBy,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.UpdatedDateTime ELSE A.UpdatedDateTime END) AS UpdatedDateTime,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>'' THEN B.KYCType ELSE A.KYCType END) AS KYCType,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.KYCNUMBER ELSE A.ID END) AS ID,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.ClientOrSpouse ELSE A.ClientOrSpouse END) AS ClientOrSpouse,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.NameInKYC ELSE A.Name END) AS Name,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.DateOfBirth ELSE A.DateOfBirth END) AS DateOfBirth,
(CASE WHEN  COALESCE(B.KYCNumber,'')<>''  THEN B.KYCIssueDate ELSE A.KYCIssueDate END) AS KYCIssueDate ,
A.SOURCE_SYSTEM_ID,
B.SequenceId
FROM KYCFacts A    JOIN {SRCSCH}.`PTSMART-kycmaster` B ON A.TargetId=B.TargetId 
WHERE  A.HierarchyId IN ('114451','114910') 
and  b.ETL_IS_ACTIVE=1 
and  branch_type='RDSP' AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')

UNION ALL

--CKYC
-----CKYC
SELECT A.RPT_DATE,BRANCH_TYPE, A.HierarchyId, A.ClientId, A.TargetId, A.CaptureDate, 
 E.CreatedBy AS CreatedBy,
 E.CreatedDateTime   AS CreatedDateTime,
 E.UpdatedBy   AS UpdatedBy,
 E.UpdatedDateTime   AS UpdatedDateTime,
 'CKYC'   AS KYCType,
 E.CKYCID  AS ID,
 'M'  AS ClientOrSpouse,
A.Name, A.DateOfBirth, A.KYCIssueDate,
A.SOURCE_SYSTEM_ID,
CAST(NULL AS BIGINT) AS SequenceId
FROM KYCFacts A  JOIN {SRCSCH}.`azuresource-tbl_BFILCKYCMIS_ClientWise` E ON A.ClientId=E.ClientId 
-- WHERE CAST(E.UpdatedDateTime AS DATE)=CAST(CURRENT_DATE()-1 AS DATE)
where   E.ETL_IS_ACTIVE=1 AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')

UNION ALL
----UCIC
SELECT distinct A.RPT_DATE,BRANCH_TYPE, A.HierarchyId, A.ClientId, A.TargetId, A.CaptureDate, A.CreatedBy, 
F.PDATE  AS CreatedDateTime, 
A.UpdatedBy,
F.mdate  AS UpdatedDateTime, 
'UCIC' AS KYCType, 
F.UCICID  AS ID, 
'M'  AS ClientOrSpouse, 
A.Name, A.DateOfBirth, A.KYCIssueDate,
A.SOURCE_SYSTEM_ID,
CAST(NULL AS BIGINT) AS SequenceId
FROM KYCFacts A JOIN {SRCSCH}.`ptsmartserver-p_ucic` F ON A.ClientId=F.ClientId 
where F.ETL_IS_ACTIVE=1 AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}')
) ,
-- Select BRANCH_TYPE,count(distinct clientid)  from KYCFacts_Consolidated
-- group by BRANCH_TYPE
Ekyc AS
(SELECT HierarchyId,AadharNumber , max(SequenceId) SequenceId from {SRCSCH}.`pragati-ekyclog` 
where  ETL_IS_ACTIVE=1 and EKYCStatus = 'Success' AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}') --and  hierarchyid ='115203'  -----or cast(UpdatedDateTime as date)=CAST(CURRENT_DATE()-1 AS date)
group by HierarchyId,AadharNumber),

CTE_EKYC AS
(SELECT  CreatedBy,CreatedDateTime,UpdatedBy,UpdatedDateTime, A.HierarchyId, A.AadharNumber,A.CaptureDate
FROM {SRCSCH}.`pragati-ekyclog` A JOIN Ekyc  B  
ON A.HierarchyId = B.HierarchyId AND A.AadharNumber=B.AadharNumber and  A.SequenceId = B.SequenceId
WHERE A.ETL_IS_ACTIVE=1 AND (ETL_LAST_UPDATED_DATE >= '{stdate}' AND ETL_LAST_UPDATED_DATE <= '{eddate}') --and  b.hierarchyid ='115203'
)
,
EKYCFacts_Consolidated AS --CHECK
(SELECT  DISTINCT A.RPT_DATE,BRANCH_TYPE, A.HierarchyId, A.ClientId, A.TargetId, A.CaptureDate, 
(CASE WHEN B.AadharNumber IS NOT NULL THEN B.CreatedBy ELSE A.CreatedBy END) AS CreatedBy,
(CASE WHEN B.AadharNumber IS NOT NULL THEN B.CreatedDateTime ELSE A.CreatedDateTime END) AS CreatedDateTime,
(CASE WHEN B.AadharNumber IS NOT NULL THEN B.UpdatedBy ELSE A.UpdatedBy END) AS UpdatedBy,
(CASE WHEN B.AadharNumber IS NOT NULL THEN B.UpdatedDateTime ELSE A.UpdatedDateTime END) AS UpdatedDateTime,
(CASE WHEN B.AadharNumber IS NOT NULL THEN 'EKYC' ELSE A.KYCType END) AS KYCType,
A.ID,
(CASE WHEN B.AadharNumber IS NOT NULL THEN 'M' ELSE A.ClientOrSpouse END) AS ClientOrSpouse,
A.Name,A.DateOfBirth, A.KYCIssueDate,A.SOURCE_SYSTEM_ID,A.SequenceId FROM KYCFacts_Consolidated A 
 left JOIN CTE_EKYC  B  ON A.ID=B.AadharNumber  and A.HierarchyId=B.HierarchyId AND  A.KYCTYPE='IDP6' AND  a.clientorspouse='M'
where  BRANCH_TYPE ='SMPT'


),

TransformedKYCFacts AS (
    SELECT RPT_DATE,BRANCH_TYPE,HierarchyId,ClientId,TargetId,ID,Name,DateOfBirth,KYCIssueDate,CreatedBy,CreatedDateTime,UpdatedBy,ClientOrSpouse,CAPTUREDATE ,
           CASE 
               WHEN KYCType = 'Pan Card' THEN 'IDP14'
               WHEN KYCType  in ('Aadhar Car', 'Aadhar Card') THEN 'IDP6'
               WHEN KYCType IN ('Voter', 'Votet ID', 'idp8','Voting card') THEN 'IDP8'
               ELSE KYCType
           END AS KYCType,
           SOURCE_SYSTEM_ID,
           SequenceId
    FROM EKYCFacts_Consolidated
    WHERE KYCType != 'admin' AND ID != 'head office' and BRANCH_TYPE='SMPT'
    UNION  ALL
    SELECT RPT_DATE,BRANCH_TYPE,HierarchyId,ClientId,TargetId,ID,Name,DateOfBirth,KYCIssueDate,CreatedBy,CreatedDateTime,UpdatedBy,ClientOrSpouse,CAPTUREDATE ,
           CASE 
               WHEN KYCType = 'Pan Card' THEN 'IDP14'
               WHEN KYCType  in ('Aadhar Car', 'Aadhar Card') THEN 'IDP6'
               WHEN KYCType IN ('Voter', 'Votet ID', 'Voting card') THEN 'IDP8'
               ELSE KYCType
           END AS KYCType,
        SOURCE_SYSTEM_ID,
        SequenceId
    FROM KYCFacts_Consolidated 
    WHERE   BRANCH_TYPE IN ('RLMS','RDSP') AND KYCType != 'admin' AND ID != 'head office'
),
RankedKYCFacts AS (
    SELECT *, 
           ROW_NUMBER() OVER (PARTITION BY KYCType, ID, ClientId,ClientOrSpouse ORDER BY SequenceId DESC) AS rn
    FROM TransformedKYCFacts
)

SELECT RPT_DATE, BRANCH_TYPE, HierarchyId, ClientId, TargetId, ID, Name, DateOfBirth, KYCIssueDate, CreatedBy, CreatedDateTime, UpdatedBy, ClientOrSpouse, CAPTUREDATE, KYCType,SOURCE_SYSTEM_ID
FROM RankedKYCFacts
WHERE rn = 1;"""
    try:
        source_data_df = spark.sql(query)
        return source_data_df
    except Exception as e:
        # Log the error
        logger(
            logger_level_error,
            f"Error while executing query on loan_collection_fact: {str(e)}",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        # Raise a new exception with a message
        print("completed")
        raise RuntimeError(
            f"Error while executing query on loan_collection_fact: {str(e)}"
        ) from e

# COMMAND ----------

def dim_client_document_kyc(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id,SRCSCH):
    try:
        SKCOL = "DIM_CLIENT_DOCUMENT_KYC_SKEY"
        prevSKVal = maxsk(SKCOL,f"{adb_consumption_catlog_schema}.dim_client_document_kyc")
        ConfigDF, CreateConfig,JoinConfigDF,UniqueKeyValues,list_agg_df,mappingdict,JoinConfigDFValue,renameFields = loadconfig(TargetTable,Business,1)
        df = get_source_df_kyc(stdate,eddate,SRCSCH)
        df = repartitioning_SKID(df)

        df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
        df = selectAndRename(df,renameFields)
        MetaColList_updated =["EFFECTIVEFROMDATE", "EFFECTIVETODATE", "CURRENT_FLAG", "ETL_BATCH_ID", "ETL_INSERTED_DATE", "ETL_INSERTED_BY", "ETL_UPDATED_DATE", "ETL_UPDATED_BY"]
        
        withColVar = MetaDataColumns(MetaColList_updated,Business,"","User")

        df = eval(f"df{withColVar}")
        
        LoadCount = handle_scd_type_2_fact(df,adb_consumption_catlog_schema,"dim_client_document_kyc","ID,CLIENTID,KYCTYPE,CLIENTORSPOUSE",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL and elem != "RPT_DATE"],"" ,desti_path,"" ,adb_consumption_dest_url)

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, LoadCount, LoadCount, log_error_success, "", load_type, ["dim_client_document_kyc"])

    except Exception as e:
        logger(logger_level_error, f"An error occurred in the dim_client_document_kyc notebook: {str(e)}", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        #Handle the exception or display the error message as needed
        raise Exception("An error occurred in the dim_client_document_kyc notebook:", str(e))