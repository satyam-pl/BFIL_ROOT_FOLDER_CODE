# Databricks notebook source
def dimclient(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_CLIENT_SKEY",0
        prevSKVal = maxsk(SKCOL,f"{adb_consumption_catlog_schema}.dim_client_bfil")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        if df and renameFields and rowCountDF:
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))

            
            if Business == 'MFI':
                coapplicant_df=spark.sql(f''' select CoApplicantName,CLIENTID,DateOfBirth as coapplicantdetails_DateOfBirth  from {SRCSCH}.`pragati-coapplicantdetails` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY ClientId ORDER BY CreatedDateTime DESC, UpdatedDateTime DESC) = 1''')
                df = df.join(coapplicant_df, ["CLIENTID"], "left")
                kycmaster_df = spark.sql(f'''
                   
                        WITH Max_SeqID AS (
                            SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                            FROM {SRCSCH}.`pragati-kycmaster`
                            WHERE ClientOrSpouse IN ('M','Y','S') AND ETL_IS_ACTIVE = '1'   
                            GROUP BY TargetID, KYCType
                        )
                        SELECT A.KYCTYPE,A.ISEKYCSTATUS,A.ClientOrSpouse,'1' as Age,A.TargetId,A.DateOfBirth
                        FROM {SRCSCH}.`pragati-kycmaster` A
                        INNER JOIN Max_SeqID B
                            ON B.TargetID = A.TargetID
                            AND B.KYCType = A.KYCType
                            AND B.MaxSeqID = A.SequenceID
                        WHERE A.ETL_IS_ACTIVE = '1' and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\'
                    
                ''')
                df = df.join(kycmaster_df, ["TargetID"], "inner")
                df=df.filter((col("KYCTYPE") == 'IDP6'))
                df = df.withColumn("DOB", when((col("ClientOrSpouse") == "M") | (col("ClientOrSpouse") == "Y"), lit(col("DateOfBirth"))).otherwise(None)).withColumn("SpouseDOB", when((col("ClientOrSpouse") == "S"), lit(col("DateOfBirth"))).otherwise(None))
            elif Business == 'BMS':
                df = df.withColumn("DOB", lit(None))
                # .withColumn("SpouseDOB", lit(None))

            # print("Framework",  df.count(), df.select("CUSTOMERID").distinct().count())
                
            if Business == 'BMS':

                kycmaster_df=spark.sql(f'''WITH Max_SeqID AS (
                    SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                    FROM {SRCSCH}.`ptsmart-kycmaster`
                    WHERE ClientOrSpouse IN ('M', 'Y') AND ETL_IS_ACTIVE = '1' AND KYCType='IDP6' 
                    GROUP BY TargetID, KYCType
                )
                SELECT A.TargetID,A.KYCNumber
                FROM {SRCSCH}.`ptsmart-kycmaster` A
                INNER JOIN Max_SeqID B
                    ON B.TargetID = A.TargetID
                    AND B.KYCType = A.KYCType
                    AND B.MaxSeqID = A.SequenceID
                WHERE A.ETL_IS_ACTIVE = '1' and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ''')
                df = df.join(kycmaster_df, ["TargetID"], "inner")
                # df=df.filter((col("KYCTYPE") == 'IDP6'))
                df_KYCNUMBER = df.select("KYCNUMBER").distinct()
                kycquery = f"select KYCNUMBER,KYCNUMBER as KYCNUMBEROutcome,MARITALSTATUS,AGE,CASTE,RELIGION,NATURE,EDUCATIONQUAL,EMAILID,FATHERNAME,MOTHERMAIDENNAME,SPOUSENAME,SPOUSEDOB,SPOUSEAGE from {SRCSCH}.`rdsp-sa_registration` where ETL_IS_ACTIVE = '1' QUALIFY ROW_NUMBER() OVER (PARTITION BY KYCNUMBER ORDER BY Createdatetime,UpdatedDateTime DESC) =1"
                df_sa_reg = spark.sql(kycquery)
                df_sa_reg = df_sa_reg.join(df_KYCNUMBER, ["KYCNUMBER"], "inner")
                df = df.join(df_sa_reg, ["KYCNUMBER"],"left")
                df = df.withColumn("KYCNUMBER", lit(col("KYCNUMBEROutcome")))

            # print("sa_registration", df.count(), df.select("CUSTOMERID").distinct().count())

            #Break at this Point

            if Business in ("MFI"):
                df = dateadd(df,"HHI_Expiry_Date","CreatedDateTime",365)
            # df = isinvalue(df,"ClientOrSpouse", ['M','Y','S'])
            # df = isinvalue(df,"KYCTYPE", ['IDP6','IDP8'])
            df = datediff_func(df, "JoinDate","DateOfBirth", "Age_when_joined")
            df = df.withColumn("Age_As_On_today",  datediff( expr("current_date()"), "DateOfBirth") / 365.25).withColumn("AgeingDays",datediff(when(col("DropOutDate").isNull(), expr("current_date() - 1")).otherwise(col("DropOutDate")), col("JoinDate")))

            if Business =='BSS':
                df = df.withColumn("ClientID", lit(col("CUSTOMERID"))).withColumn("DropOutReasonID", lit(None)).withColumn("DeathCertificateReceivedDate", lit(None))

            dfClientIDValues = df.select("ClientID").distinct()
            dfDropOutReasonIDValues =df.select("DropOutReasonID").distinct()
                

            if Business in ("MFI"):
                tablename = "`pragati-clientloansubscription`"
                CodeValuetable = "`pragati-codevalue`"
            if Business in ("BMS"):
                tablename = "`ptsmart-clientloansubscription`"
                CodeValuetable = "`pragati-codevalue`"
            elif Business in ("BSS"):
                tablename = "`RLMSBIZXTEND-clientloansubscription`"
                CodeValuetable = "`RLMSBIZXTEND-codevalue`"


            dfCustDormancyType = f"select ClientID, ClientID as dfCustDormancyType_df_ClientID, ClientLoanID,LoanClosedDate,LoanCancelledDate,DeviationCancelledDate,ProductType from {SRCSCH}.{tablename} where ETL_IS_ACTIVE = 1 and ProductType is null QUALIFY ROW_NUMBER() OVER (PARTITION BY ClientID ORDER BY CreatedDateTime,UpdatedDateTime DESC) =1"

            dfMaxLoanClose = f"Select ClientID, ClientID as MaxLoanClose_ClientID, Count(ClientLoanID) As NoOfLoans, Sum(Case When LoanClosedDate Is Not Null Then 1 Else 0 End) As NoOfClosedLoans, Max(LoanClosedDate) As Max_LoanClosedDate From {SRCSCH}.{tablename} Where LoanCancelledDate Is Null and DeviationCancelledDate Is Null and ETL_IS_ACTIVE = 1 and ProductType Is Null Group By ClientID "
            CodeValue = f"Select Code, Value From {SRCSCH}.{CodeValuetable} Where ETL_IS_ACTIVE = 1"


            try:
                CodeValue_df= spark.sql(CodeValue)
            except:
                CodeValue_df= spark.sql('''"Select \'\' as Code, \'\' as Value" ''')

            if Business !='BMS':
                dfReligionValues =df.select("RELIGION").distinct()
                CodeValue_TargetID_df = CodeValue_df
                CodeValue_TargetID_df = CodeValue_TargetID_df.withColumnRenamed("Code", "RELIGION").withColumnRenamed("Value", "Religion_data")
                CodeValue_targetIDdf = CodeValue_TargetID_df.join(dfReligionValues, ["RELIGION"], "inner").select(CodeValue_TargetID_df["*"])
                

            try:
                MaxLoanClose_df = spark.sql(dfMaxLoanClose)
            except:
                MaxLoanClose_df = spark.sql('''select \'\' as ClientID, \'\' as MaxLoanClose_ClientID, \'\' as NoOfLoans, \'\' as  NoOfClosedLoans, \'\' as Max_LoanClosedDate ''')


            try:
                CustDormancyType_df =spark.sql(dfCustDormancyType)
            except:
                CustDormancyType_df  = spark.sql('''select \'\' as ClientID, \'\' as dfCustDormancyType_df_ClientID, \'\' as ClientLoanID,\'\' as LoanClosedDate,\'\' as LoanCancelledDate,\'\' as DeviationCancelledDate, \'\' as ProductType ''')

            CustDormancyType_df = CustDormancyType_df.join(dfClientIDValues, ["ClientID"], "inner").select(CustDormancyType_df["*"])

            # print("CustDormancyType_df", df.count(), dfClientIDValues.count(), CustDormancyType_df.count(), CustDormancyType_df.select("ClientID").distinct().count())

            MaxLoanClose_df = MaxLoanClose_df.join(dfClientIDValues, ["ClientID"], "inner").select(MaxLoanClose_df["*"])

            # print("MaxLoanClose_df", df.count(), dfClientIDValues.count(), CustDormancyType_df.count(), CustDormancyType_df.select("ClientID").distinct().count())

            CodeValue_df = CodeValue_df.join(dfDropOutReasonIDValues, CodeValue_df["Code"] == dfDropOutReasonIDValues["DropOutReasonID"], "inner").select(CodeValue_df["*"])

            # print("CodeValue_df", df.count(), dfClientIDValues.count(), CustDormancyType_df.count(), CustDormancyType_df.select("ClientID").distinct().count())


            df = df.join(CustDormancyType_df, "ClientID", "left")
            # print("CustDormancyType_df join",  df.count(), df.select("ClientID").distinct().count())


            df = df.join(MaxLoanClose_df, "ClientID", "left")
            # print("MaxLoanClose_df join",  df.count(), df.select("ClientID").distinct().count())

            df = df.join(CodeValue_df, df["DropOutReasonID"] == CodeValue_df["Code"], "left")
            # print("CodeValue_df join",  df.count(), df.select("ClientID").distinct().count())

            if Business !='BMS':
                df = df.join(CodeValue_targetIDdf, "RELIGION", "left").withColumn("RELIGION", lit(col("Religion_data"))).drop("Religion_data")



            if Business =='MFI':
                CUSTOMERCLOSINGREASONTable = "`pragati-codevalue`"
            elif Business =='BSS':
                CUSTOMERCLOSINGREASONTable = "`RLMSBizXtend-codevalue`"
            elif Business =='BMS':
                CUSTOMERCLOSINGREASONTable = "`pragati-codevalue`"


            CodeValue_CUSTOMERCLOSINGREASON = f"Select Code, Value,Value as CUSTOMER_CLOSING_REASON From {SRCSCH}.{CUSTOMERCLOSINGREASONTable} Where ETL_IS_ACTIVE = 1"

            CodeValue_CCR = f"Select Code, Value From {SRCSCH}.{CUSTOMERCLOSINGREASONTable} Where ETL_IS_ACTIVE = 1"
            CodeValue_dfCCR= spark.sql(CodeValue_CCR)

            dfDropOutReasonIDValues =df.select("DropOutReasonID").distinct()
            CodeValue_CCRdf = CodeValue_dfCCR.withColumnRenamed("Code", "DropOutReasonID").withColumnRenamed("Value", "CUSTOMER_CLOSING_REASON")

            CodeValue_CCRdf = CodeValue_CCRdf.join(dfDropOutReasonIDValues, ["DropOutReasonID"], "inner").select(CodeValue_CCRdf["*"])

            df = df.join(CodeValue_CCRdf, ["DropOutReasonID"], "left")


            df = df.withColumn("CUSTOMER DORMANCY/INACTIVE DATE",
                                when((col("dfCustDormancyType_df_ClientID").isNull()) & (col("DropOutDate").isNull()),
                                    when(datediff(expr("current_date()"), col("JoinDate")) >= 84,
                                            expr("date_add(JoinDate, 85)")).otherwise(col("JoinDate"))
                                        )
                                        ) \
                            .withColumn("CUSTOMER DORMANCY TYPE",
                                        when((col("dfCustDormancyType_df_ClientID").isNull()) & (col("DropOutDate").isNull()),
                                            when(datediff(expr("current_date()"), col("JoinDate")) >= 84,
                                                "Dormant Without Loan").otherwise("In-Active")
                                        )
                                    ) \
                            .withColumn("NO_OF_DAYS_IN_DORMANCY",
                                        when((col("dfCustDormancyType_df_ClientID").isNull()) & (col("DropOutDate").isNull()),
                                            datediff( expr("current_date()"),
                                                when(datediff(expr("current_date()"), col("JoinDate")) >= 84,
                                                    expr("date_add(JoinDate, 85)")).otherwise(col("JoinDate"))
                                                
                                            )
                                        )
                                    )

            if Business == "MFI":
                df = df.withColumn("DEATH_STATUS",when( col("DeathofMemberOrSpouse")=='M', when(col("DeathCertificateReceivedDate").isNull(), "No").otherwise("Yes") ).otherwise("No") )
            else:
                df = df.withColumn("DEATH_STATUS",when(col("DeathCertificateReceivedDate").isNull(), "No").otherwise("Yes") )

            # df = IFF(df,"DEATH_STATUS","DeathCertificateReceivedDate","." + "isNull()","No","Yes")
            # if Business == "MFI":
            #     df = IFF(df,"RE KYC Flag","ISEKYCSTATUS","== 0","1","0")

            df = df.withColumn("CUSTOMER STATUS",when(col("DropOutDate").isNotNull(), "DropOut").when(col("CUSTOMER DORMANCY TYPE") == "In-Active", "In-Active").when(col("CUSTOMER DORMANCY TYPE").isNotNull(), "Dormant").otherwise("Active")).withColumn("AgeDays", floor(datediff(expr("current_date()"), "DateOfBirth")/ 365.25 ) )

            df = df.withColumnRenamed("CUSTOMER DORMANCY/INACTIVE DATE", "CUSTOMER_DORMANCY_INACTIVE_DATE")\
                .withColumnRenamed("CUSTOMER DORMANCY TYPE", "CUSTOMER_DORMANCY_TYPE")\
                    .withColumnRenamed("CUSTOMER STATUS", "CUSTOMER_STATUS")
            df = df.withColumn("CLIENTID_D", col("CLIENTID")).withColumn("DATEOFBIRTH_D", col("DATEOFBIRTH")).withColumn("NO_OF_DAYS_IN_DORMANCY", col("NO_OF_DAYS_IN_DORMANCY"))

            # if Business != 'BMS':
            #     df = df.withColumn("RELIGION", lit(col("value")))

            try:
                df = df.withColumn("CUSTOMER_ID", lit(col("CLIENTID")))
            except:
                pass


            df = selectAndRename(df,renameFields)

            try:
                df = df.withColumn("AGE_AS_ON_TODAY", round(col("AGE_AS_ON_TODAY"),0))
            except:
                pass

            #Execution method
            withColVar = MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")

            CastCols = ["SPOUSE_AGE","SPOUSE_DOB","AGE_AS_ON_TODAY","AGE_WHEN_JOINED","AGEING_DAYS","CUSTOMER_JOINING_DATE","NO_OF_DAYS_IN_DORMANCY"]

            for colname in CastCols:
                try:
                    df = df.withColumn(colname, col(colname).cast("string"))   
                except Exception as e:
                    pass


            LoadCount = handle_scd_type_2_fact(df,adb_consumption_catlog_schema,"dim_client_bfil", "CUSTOMER_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)

        rowCountDF = rowCountDF if rowCountDF else 0

        Stats = update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dimClient"])
        


    except Exception as e:
        raise Exception("An error occurred in the dimclient notebook:", str(e))



