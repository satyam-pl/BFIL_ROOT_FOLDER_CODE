# Databricks notebook source
def dimclientdetails(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        
        SKCOL,LoadCount = "DIM_CLIENT_DETAILS_SKEY",0
        prevSKVal = maxsk(SKCOL,f"{adb_consumption_catlog_schema}.dim_client_details_bfil")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        if df and renameFields and rowCountDF:

            if Business =='MFI':
                kycmaster_df = spark.sql(f'''
                    WITH Max_SeqID AS (
                        SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                        FROM {SRCSCH}.`pragati-kycmaster`
                        WHERE ClientOrSpouse IN ('M','Y') AND ETL_IS_ACTIVE = '1'   
                        GROUP BY TargetID, KYCType
                    )
                    SELECT A.KYCTYPE,A.ISEKYCSTATUS,A.CLIENTORSPOUSE,A.TargetId
                    FROM {SRCSCH}.`pragati-kycmaster` A
                    INNER JOIN Max_SeqID B
                        ON B.TargetID = A.TargetID
                        AND B.KYCType = A.KYCType
                        AND B.MaxSeqID = A.SequenceID
                    WHERE A.ETL_IS_ACTIVE = '1' and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\'  ''')
                df = df.join(kycmaster_df, ["TargetID"], "inner")
                df=df.filter((col("KYCTYPE") == 'IDP6') & (col("ClientOrSpouse") == "M"))
                benny_df=spark.sql(f'''WITH MaxBenny AS ( SELECT ClientID, MAX(CreatedDateTime) AS MaxDate FROM {SRCSCH}.`pragati-bcm_bennyclientdeatils_h_view` WHERE ETL_IS_ACTIVE = '1' GROUP BY ClientID )SELECT A.ClientID, A.BeneName_Matching_per, A.BeneStatus FROM {SRCSCH}.`pragati-bcm_bennyclientdeatils_h_view` A JOIN MaxBenny B ON B.ClientID = A.ClientID AND B.MaxDate = A.CreatedDateTime WHERE A.ETL_IS_ACTIVE = '1';''')
                                
                df= df.join(benny_df, ["ClientID"] ,"left")

                mfi_household_df=spark.sql(f"SELECT Annual_HHI,CreatedDateTime,CreatedDateTime as HHI_Expiry_Date,CLientId from {SRCSCH}.`rdsp_trans-mfi_household_details` where ETL_IS_ACTIVE=1 QUALIFY ROW_NUMBER() OVER (PARTITION BY ClientId ORDER BY CreatedDateTime DESC) =1")

                df= df.join(mfi_household_df, ["CLientId"] ,"left")
                cb_updatedf = spark.sql(f'''WITH CBUpdate AS ( SELECT B.CBResponseID, B.CBStatus, A.TargetID, MAX(B.CreatedDateTime) AS MaxCBDate FROM (SELECT * FROM {SRCSCH}.`pragati-clientmaster` WHERE ETL_IS_ACTIVE = '1') A JOIN (SELECT * FROM {SRCSCH}.`pragati-creditbureauupdate` WHERE ETL_IS_ACTIVE = '1' QUALIFY ROW_NUMBER() OVER (PARTITION BY TargetId ORDER BY TargetId DESC) = 1) B ON B.TargetID = A.TargetID AND B.LoanProposalID IS NULL GROUP BY A.TargetID, B.CBResponseID, B.CBStatus )SELECT * FROM CBUpdate''')

                print(df.columns)
                print(cb_updatedf.columns)

                df= df.join( cb_updatedf, ["TARGETID"] ,"left" )
            elif Business == 'BMS':
                kycmaster_df=spark.sql(f'''WITH Max_SeqID AS (
                        SELECT TargetID, KYCType, MAX(SequenceID) AS MaxSeqID
                        FROM {SRCSCH}.`ptsmart-kycmaster`
                        WHERE ClientOrSpouse IN ('M', 'Y') AND ETL_IS_ACTIVE = '1'and KYCType='IDP6'  
                        GROUP BY TargetID, KYCType
                    )

                    SELECT A.TargetID,A.KYCNumber,A.ISEKYCSTATUS,A.CLIENTORSPOUSE,A.KYCTYPE
                    FROM {SRCSCH}.`ptsmart-kycmaster` A
                    INNER JOIN Max_SeqID B
                        ON B.TargetID = A.TargetID
                        AND B.KYCType = A.KYCType
                        AND B.MaxSeqID = A.SequenceID
                    WHERE A.ETL_IS_ACTIVE = '1' and ETL_LAST_UPDATED_DATE >= \'{stdate}\' and ETL_LAST_UPDATED_DATE <= \'{eddate}\' ''')
                df = df.join(kycmaster_df, ["TargetID"], "inner")


                df_KYCNUMBER = df.select("KYCNUMBER").distinct()
                sa_registration_query = f"select KYCNUMBER,AnnualHouseholdIncome,AnnualHouseholdIncome as HHI_AMOUNT,ShopNumber ,OwnShop,Nature,PIN,shopsize,DailysalesFig,YearofOperations,AccountNo,BankName from {SRCSCH}.`rdsp-sa_registration` where ETL_IS_ACTIVE = '1' QUALIFY ROW_NUMBER() OVER (PARTITION BY KYCNUMBER ORDER BY Createdatetime,UpdatedDateTime DESC) =1"

                df_sa_reg = spark.sql(sa_registration_query)
                df_sa_reg = df_sa_reg.join(df_KYCNUMBER, ["KYCNUMBER"], "inner")
                df = df.join(df_sa_reg, ["KYCNUMBER"],"left")

                merchant_master = f"select MERCHANT_UIDAI_NO as KYCNUMBER, ShopName,Address,latitude,Longitude from {SRCSCH}.`rdsp-merchant_master` where ETL_IS_ACTIVE = '1' QUALIFY ROW_NUMBER() OVER (PARTITION BY KYCNUMBER ORDER BY Createdatetime DESC) =1"

                df_merchant_master = spark.sql(merchant_master)
                df_merchant_master = df_merchant_master.join(df_KYCNUMBER, ["KYCNUMBER"], "inner")
                df = df.join(df_merchant_master, ["KYCNUMBER"],"left")

                dfClientIDValues = df.select("ClientID").distinct()
                df = df.withColumn("ANNUAL_TURNOVER", lit(col("DailysalesFig")*365))                

            elif Business =='BSS':
                tbl_BFILCKYCMIS_ClientWise__df = spark.sql(f'''select ClientId as CUSTOMERID,CKYCID from {SRCSCH}.`azuresource-tbl_BFILCKYCMIS_ClientWise` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY CUSTOMERID ORDER BY UpdatedDateTime DESC) =1''')

                bankrelationdetails_h_view__df = spark.sql(f'''select CUSTOMERID,SBACCOUNTNUMBER from {SRCSCH}.`RLMSBIZXTEND-bankrelationdetails_h_view` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY CUSTOMERID ORDER BY UpdatedDateTime DESC) =1''')

                KYCMaster__df  = spark.sql(f'''select CUSTOMERID,CREATEDDATETIME,ISEKYCSTATUS,CLIENTORSPOUSE, KYCTYPE from {SRCSCH}.`RLMSBIZXTEND-KYCMaster` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY CUSTOMERID ORDER BY UpdatedDateTime DESC) =1''')

                CUSTOMERBANKDETAILS__df  = spark.sql(f'''select CUSTOMERID,BANKNAME ,BANKBRANCHNAME ,IFSCCODE from {SRCSCH}.`RLMSBIZXTEND-CUSTOMERBANKDETAILS` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY CUSTOMERID ORDER BY UpdatedDateTime DESC) =1''')

                CustomerShopDetails__df  = spark.sql(f'''select CUSTOMERID,SHOPID, SHOPNAME, SHOPTYPE, NATUREOFBUSINESS, SHOPADDRESS, PINCODE, AREAOFSHOPINSFT, AVERAGEDAILYSALES, AVERAGEDAILYSALES*365 as ANNUAL_TURNOVER, SHOPCONSTRUCTIONQUALITY, LATITUDE, LONGITUDE, SHOPVINTAGEYEARS from {SRCSCH}.`RLMSBIZXTEND-CustomerShopDetails` where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY CUSTOMERID ORDER BY UpdatedDateTime DESC) =1''')

                CBRESPDATA__df = spark.sql(f''' select A.ClientID as CUSTOMERID, B.ID as ID,B.EligibilityStatus from {SRCSCH}.`rlmsbizxtend-bfil_cb_check` A  left join {SRCSCH}.`rlmsbizxtend-bfil_cbresponse` B on  A.ID = B.RID where A.ETL_IS_ACTIVE = 1 and B.ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY CUSTOMERID ORDER BY A.CreateDatetime DESC) =1''')

                df = df.join(tbl_BFILCKYCMIS_ClientWise__df, ['CUSTOMERID'], "left").join(bankrelationdetails_h_view__df, ['CUSTOMERID'], "left").join(KYCMaster__df, ['CUSTOMERID'], "left").join(CUSTOMERBANKDETAILS__df, ['CUSTOMERID'], "left").join(CustomerShopDetails__df, ['CUSTOMERID'], "left").join(CBRESPDATA__df, ['CUSTOMERID'], "left")

                df.filter(col("CUSTOMERID")=='1114281000420507').select("AVERAGEDAILYSALES", "ANNUAL_TURNOVER").show()


            df = df.withColumn( "RE_KYC_Flag",  when( (col("ISEKYCSTATUS") == False) & (col("CLIENTORSPOUSE") == "M") & (col("KYCTYPE") == "IDP6"), 1).when( (col("ISEKYCSTATUS") == True) & (col("CLIENTORSPOUSE") == "M") & (col("KYCTYPE") == "IDP6"), 0).otherwise(None) )


            if Business in ('MFI'):
                df = dateadd(df,"HHI_Expiry_Date","CreatedDateTime",365)

            df = df.withColumn("CUSTOMER_ID",lit(col("CLIENTID")))

            df =df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))

            df = selectAndRename(df,renameFields)

            CASTCOLUMNS = ["HHI_DATE", "HHI_EXPIRY_DATE" ,"HHI_AMOUNT", "ANNUAL_TURNOVER","FAMILY_INCOME", "LAST_EKYC_DATE", "NATURE_OF_BUSINESS", "RE_KYC_FLAG"]

            for colvalue in CASTCOLUMNS:
                try:
                    df = df.withColumn(colvalue, col(colvalue).cast( "string"))
                except:
                    pass

            #Execution method
            withColVar = MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")



            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_client_details_bfil", "CUSTOMER_ID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)


        rowCountDF = rowCountDF if rowCountDF else 0

        Stats = update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_client_details_bfil"])


    except Exception as e:
        raise Exception("An error occurred in the dim_client_details_bfil notebook:", str(e))



