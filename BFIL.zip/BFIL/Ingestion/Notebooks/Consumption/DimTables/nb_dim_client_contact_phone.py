# Databricks notebook source
def dimclientcontactphone(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_CLIENT_CONTACT_PHONE_SKEY",0
        prevSKVal = maxsk(SKCOL,f"{adb_consumption_catlog_schema}.dim_client_contact_phone_bfil")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)        
        if df and renameFields and rowCountDF:
            query =  ""
            if Business in ('MFI', 'BMS'):
                if Business == 'MFI':
                    Table = "`pragati-kycdetails`"
                
                if Business == 'BMS':
                    Table = "`ptsmart-kycdetails`"
                query = f"select TargetId,LoanProposalId,MobileNumber,PhoneNumber from {SRCSCH}.{Table}where ETL_IS_ACTIVE = 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY TargetId ORDER BY CreatedDateTime DESC) =1"

                print(query)
                    
                dftargetid = df.select("TARGETID").distinct()
                df_kycdetails = spark.sql(query)
                df_kycdetails = df_kycdetails.join(dftargetid,["TargetId"],"inner")
                df = df.join(df_kycdetails,["TargetId"],"left").withColumn("PHONE_TYPE", when(col("MobileNumber").isNotNull() & (col("MobileNumber") != ""), "Primary").otherwise(None))
                

            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))\
                .withColumn("OTP_VERFIED_FLAG",lit(None))\
                .withColumn("OTP_VERFICATION_DATE",lit(None))\
                .withColumn("SOURCE_CUSTOMER_ID",lit(None))\
                .withColumn("ACTIVE_FLAG",lit(None))\
                .withColumn("EFFECTIVE_START_DATE",lit(None))\
                .withColumn("EFFECTIVE_END_DATE",lit(None))\
                .withColumn("CONSENT",lit(None))
                
            
            

            if Business == 'BSS':
                df = df.withColumn("PHONENUMBER",lit(None))

            if Business == 'BSS':
                df = df.withColumn("TYPE", lit('Client'))
            elif Business == 'MERCHANTMASTER':
                df = df.filter(length(trim(df['CLIENTID'])) >= 8)
                df = df.withColumn("TYPE", lit('Merchant'))
            else:
                df = df.withColumn("TYPE", when(col("LoanProposalId").isNull(), "Client").otherwise("Loan"))

            if (Business == 'BSS' or Business == 'MERCHANTMASTER'): 
                df = df.withColumn("LOANPROPOSALID", lit(None)).withColumn("MOBILENUMBER2", lit(None))
            else:
                df = df.withColumn("MOBILENUMBER2", lit(col("PHONENUMBER"))).withColumn("LOANPROPOSALID", lit(col("LOANPROPOSALID")))
                
                

            df = selectAndRename(df,renameFields)

            #Execution method
            withColVar = MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")


            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_client_contact_phone_bfil", "CLIENTID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)


        rowCountDF = rowCountDF if rowCountDF else 0

        Stats = update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_client_contact_phone_bfil"])


    except Exception as e:
        raise Exception("An error occurred in the dimgroup notebook:", str(e))



