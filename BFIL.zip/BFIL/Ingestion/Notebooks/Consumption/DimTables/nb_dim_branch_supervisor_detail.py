# Databricks notebook source
def dimbranchsupervisordetail(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_BRANCH_DETAILS_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_branch_supervisor_details")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        
        if df and renameFields and rowCountDF:
            df_hiearchyid = spark.sql(f'''
            SELECT A.BrID AS BRID, COALESCE(B.HierarchyID, D.HierarchyID) AS HierarchyID
            FROM 
            (
                SELECT BrID 
                FROM {SRCSCH}.`azuresource-mastersopdata` 
                WHERE ETL_IS_ACTIVE = 1
            ) AS A
            LEFT JOIN 
            (
                SELECT BranchCode, HierarchyID 
                FROM {SRCSCH}.`pragati-branchmaster` 
                WHERE ETL_IS_ACTIVE = 1
            ) AS B 
            ON B.BranchCode = A.BrID
            LEFT JOIN 
            (
                SELECT BranchCode, HierarchyID 
                FROM {SRCSCH}.`RLMSBizxtend-branchmaster` 
                WHERE ETL_IS_ACTIVE = 1
            ) AS D 
            ON D.BranchCode = A.BrID''')  
            df= df.join(df_hiearchyid, ['BRID'], 'left' ).drop("BRID")
            df = df.filter(df["HierarchyID"].isNotNull())
            
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)

            #Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")

            LoadCount= handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_branch_supervisor_details", "HIERARCHYID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_branch_supervisor_details"])

    except Exception as e:
        raise Exception("An error occurred in the dim_branch_supervisor_details notebook:", str(e))

