# Databricks notebook source
def dimbranch(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_BRANCH_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_branch")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        
        if df and renameFields and rowCountDF:
            df = df.withColumn("BRANCH_CLOSED_FLAG", when(col("BRANCH_CLOSED_FLAG").isNotNull(), 1).otherwise(0))
            df=df.withColumn("BRANCH_EMAIL_ID", lit("Branchcode@bfil.co.in"))
            df_BRID = df.select("BRID").distinct()

            df_mfi_bms = spark.sql(f'''with dataval as (select BRANCHCODE as BRID,BRANCHCODE as BRID_output, HIERARCHYID,LATITUDE,LONGITUDE,'MFI' as Source from {SRCSCH}.`pragati-branchmaster` where ETL_IS_ACTIVE =1 union select BRANCHCODE as BRID,BRANCHCODE as BRID_output,HIERARCHYID,LATITUDE,LONGITUDE,'BSS' as Source from {SRCSCH}.`rlmsbizxtend-branchmaster` where ETL_IS_ACTIVE =1) 
            select * from dataval QUALIFY ROW_NUMBER() OVER (PARTITION BY BRID ORDER BY BRID DESC) =1''')
            
            df_mfi_bms = df_mfi_bms.join(df_BRID, ["BRID"], "inner")
            df = df.join(df_mfi_bms, ['BRID'], "left")
            # df=df.select("BRID").distinct()
            df=df.dropDuplicates(["BRID"])

            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)
            #Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")
            

            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_branch", "BRANCH_CODE",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0

        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_branch"])

    except Exception as e:
        raise Exception("An error occurred in the dim_branch notebook:", str(e))

