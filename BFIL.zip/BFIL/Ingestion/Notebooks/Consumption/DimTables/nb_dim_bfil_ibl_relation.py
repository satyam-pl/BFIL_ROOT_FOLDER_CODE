# Databricks notebook source
def querystore_ibl_relation (Business,Start_date,End_date):
    if Business =='ALL':
        
        query_data_bfil = f'''WITH UniqueData AS (SELECT A.CIF_ID
        FROM edp_bfil_prod.finacle.gam_vw  AS A
        LEFT JOIN {SRCSCH}.`azuresource-dim_bfil_ibl_idrelationship` AS B ON B.CIFID = A.CIF_ID  -- Inventory Table
        JOIN edp_bfil_prod.finacle.dim_bfil_schmcode AS C 
            ON C.SCHM_Code = A.SCHM_Code 
            AND C.SCHM_Code <> 'IBFIL'
        WHERE B.CIFID IS NULL And B.ETL_IS_ACTIVE=1  and B.ETL_LAST_UPDATED_DATE >= '{Start_date}' and B.ETL_LAST_UPDATED_DATE <= '{End_date}'
        GROUP BY A.CIF_ID

        UNION 
        SELECT A.CIFID
            FROM {SRCSCH}.`firewall_prod-accountidmapping` AS A
            LEFT JOIN {SRCSCH}.`azuresource-dim_bfil_ibl_idrelationship` AS C 
                ON C.CIFID = A.CIFID --- Inventory Table
            WHERE C.CIFID IS NULL  and   A.ETL_IS_ACTIVE=1
                AND CAST(A.CreatedDateTime AS DATE) >= CAST(DATEADD(DAY, -2, GETDATE()) AS DATE)

        ),

        BFIL_IBL_AccountsRelation(
        Select	A.CIFID,
                    A.Ext_CustID,
                    (Case When Len(A.Ext_CustID)>12 Then A.Ext_CustID Else Null End) As ClientID,
                    (Case When Len(A.Ext_CustID)>12 Then Null Else A.Ext_CustID End) As KYCNumber,
                    B.merchant_ID As MerchantID
        -- Into #BFIL_IBL_AccountsRelation
        From UniqueData as Base
        Join {SRCSCH}.`firewall_prod-accountidmapping`  As A On A.CIFID = Base.CIF_ID
        Left Join {SRCSCH}.`rdsp-merchant_master` As B  On B.Merchant_UIDAI_No = A.Ext_CustID  where A.ETL_IS_ACTIVE=1  ),

        B1 AS (
            SELECT KYCNumber AS kycpt, ClientOrSpouse, TargetID  
            FROM {SRCSCH}.`ptsmart-kycmaster`
            WHERE ClientOrSpouse IN ('M', 'Y') 
        ),
        C1 AS (
            SELECT TargetID, DropOutDate 
            FROM {SRCSCH}.`ptsmart-clientmaster`
            WHERE DropOutDate IS NULL OR DropOutDate = '1900-01-01'  
        ),
        B2 AS (
            SELECT KYCNumber AS kycpt, ClientOrSpouse, TargetID  
            FROM {SRCSCH}.`pragati-kycmaster`
            WHERE ClientOrSpouse IN ('M', 'Y')   
        ),
        C2 AS (
            SELECT TargetID, DropOutDate 
            FROM {SRCSCH}.`pragati-clientmaster`
            WHERE DropOutDate IS NULL OR DropOutDate <> '1900-01-01'  
        )


        SELECT 
            A.*, 
            B1.kycpt AS KYCNumber_ptsmart,
            B1.ClientOrSpouse AS ClientOrSpouse_ptsmart,
            B1.TargetID AS TargetID_ptsmart,
            C1.DropOutDate AS DropOutDate_ptsmart,
            B2.kycpt AS KYCNumber_pragati,
            B2.ClientOrSpouse AS ClientOrSpouse_pragati,
            B2.TargetID AS TargetID_pragati,
            C2.DropOutDate AS DropOutDate_pragati
        FROM 
            BFIL_IBL_AccountsRelation A
        LEFT JOIN 
            B1 ON A.KYCNumber = B1.kycpt
        LEFT JOIN 
            C1 ON B1.TargetID = C1.TargetID
        LEFT JOIN 
            B2 ON A.KYCNumber = B2.kycpt
        LEFT JOIN 
            C2 ON B2.TargetID = C2.TargetID
        WHERE 
            A.ClientID IS NULL  

            
            

   
       '''

#         -- select * from tbl_loandoc
#         %sql
# -- select * from innerblock A 
# --         left join p_cls F on F.clientloanid_pcls = A.CLIENTLOANID
# --         left join d2k G on G.CUSTOMERACID = A.LOANPROPOSALID 
# --         left join prdmaster H on H.PRODUCTCODE_J = A.ProductId_cls
# --         left join tbl_loandoc I on I.ProposalID = A.LOANPROPOSALID
# --         left join bmscbdetails J on J.PTClientID = A.CLIENTID '''

        

    df = spark.sql(query_data_bfil)

    # print(query)
    
    return df



# COMMAND ----------

def dim_bfil_ibl_relation(TargetTable, Business, stdate,eddate,DBG_FLG,adb_consumption_catlog_schema,pipeline_run_id):
    try:
        SKCOL,LoadCount = "DIM_BFIL_IBL_RELATION_SKEY",0
        start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))
        prevSKVal = maxsk(SKCOL,f"{TRGSCH}.dim_bfil_ibl_relation")
        df,renameFields,rowCountDF = FrameWork(TargetTable, Business, stdate,eddate,DBG_FLG)
        df = None

        df = querystore_ibl_relation (Business,stdate,eddate)
        rowCountDF = df.count()
        print("rowCountDF",rowCountDF)
       
        if df and renameFields and rowCountDF:
            df=df.dropDuplicates(["CIFID"])

                # .withColumn("INTEREST_RATE_TYPE", lit("Fixed"))

            
            print(renameFields)
            for val in sorted(df.columns):
                print(val)

            for val in df.columns:
                try:
                    df = df.withColumn(val, lit(col(val).cast("string")))
                except:
                    pass

            df = repartitioning_SKID(df)
            df = df.withColumn(SKCOL, lit(col("SKID").cast("int")+prevSKVal ))
            df = selectAndRename(df,renameFields)

            # Execution method
            withColVar =MetaDataColumns(MetaColList,Business,"","User")
            df = eval(f"df{withColVar}")

            print("df count", df.count())

 
            LoadCount = handle_scd_type_2(df,adb_consumption_catlog_schema,"dim_bfil_ibl_relation", "CIFID",spark.sql('select current_user() as user').collect()[0]['user'],stdate, [elem for elem in df.columns if elem not in [item for item in MetaColList if item not in ["ETL_CREATED_DATE", "ETL_CHANGE_FLAG"]] and elem !=SKCOL],"" ,desti_path,"" ,adb_consumption_dest_url)
        rowCountDF = rowCountDF if rowCountDF else 0
 
        update_logs(src_object_id,start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, rowCountDF, LoadCount, log_error_success, "", load_type, ["dim_bfil_ibl_relation"])
 
    except Exception as e:
        raise Exception("An error occurred in the dim_bfil_ibl_relation notebook:", str(e))