# Databricks notebook source
def get_incremental_dataframe_disbursement(stdate, eddate, SRCSCH):
    query = f"""With CTE_ClientLoanProposal As(
/* MFI Proposals - Disbursements */ 
SELECT 'MFI' AS SBU,
       Clp.HierarchyID,
       /* Client Loan Proposal Details */
       Clp.ClientID,
       Clp.LoanProposalID,
       Clp.CreatedDateTime AS ProposalEntryDate,
       Clp.FieldStaffId AS StaffID,
       CAST(Clp.ProposalDate AS DATE) AS ProposalDate,
       Clp.LoanAmountRequested AS RequestedAmount,
       Clp.LoanAmountApproved AS ApprovedAmount,
       CAST(Clp.ApprovedDate AS DATE) AS ApprovedDate,
       Clp.ApprovalRemarks,
       CAST(Clp.TEMPDISBURSEMENTDATE AS DATE) AS TempDisbursementDate,
       Clp.PurposeID,
       LP.PurposeName,
       PM.ProductCode,
       PM.ProductName,
       (CASE 
            WHEN UPPER(SPAP.CreatedBy) IN ('UNNATI', 'UNNATIT') AND PM.ProductCode = '800' THEN 'Unnati'
            WHEN UPPER(SPAP.CreatedBy) IN ('UNNATIPLS', 'UNNATI PLUS') AND PM.ProductCode = '800' THEN 'UnnatiPls'
            WHEN SPAP.SLPlus = 1 AND SPAP.SLCancelDate IS NULL AND UPPER(Clp.DisbursementMode) = 'DM1' AND PM.ProductCode = '800' THEN 'SurakshaPls'
            WHEN UPPER(DIM_PM.PRODUCT_CATEGORY1) = 'RDSP' AND DIM_PM.PRODUCT_ID = '1042' THEN 'RDSP'
            ELSE DIM_PM.PRODUCT_CATEGORY1
        END) AS ProductCategory,
       Clp.DisbursementMode,
       (CASE 
            WHEN UPPER(DIM_PM.PRODUCT_CATEGORY1) IN ('FUL', 'TWO WHEELERS') AND UPPER(Clp.CreatedBy) LIKE '%HO%' THEN 'Preapproved'
            WHEN UPPER(DIM_PM.PRODUCT_CATEGORY1) IN ('FUL', 'TWO WHEELERS') THEN 'Instant'
            WHEN UPPER(DIM_PM.PRODUCT_CATEGORY1) LIKE '%UNNATI%' THEN 'Preapproved'
            WHEN UPPER(DIM_PM.PRODUCT_CATEGORY1) = 'MFI' AND UPPER(PAP.CreatedBy) LIKE '%HO%' THEN 'Preapproved'
            ELSE 'Instant'
        END) AS DisbursementType,
       CAST(Clp.LoanDisbursementDate AS DATE) AS LoanDisbursementDate,
       CAST(Clp.ActualDisbursementDate AS DATE) AS ActualDisbursementDate,
       Clp.ActualDisbursedAmount,
       Clp.ClientProductSequenceNo AS Proposal_SeqNo,
       CAST(Clp.InterestRate AS DECIMAL(10, 2)) AS ROI,
       Clp.Tenure,
       IF(Clp.Tenure IN (12, 25, 52, 50), 'DL', 'TL') AS LoanType,
       Clp.RepaymentFrequency,
       Clp.CBUpdateID,
       Clp.IsBCMTrackerFlag,
       Clp.IsBCMApproved,
       Clp.EKYCStatus,
       CAST(Clp.EKYCSucessDate AS DATE) AS EKYCSucessDate,
       CAST(COALESCE(Clp.MainOTPSucessDate, Clp.AlternateOTPSucessDate) AS DATE) AS OTPDate,
       (CASE 
            WHEN UPPER(DIM_PM.PRODUCT_CATEGORY1) IN ('TWO WHEELERS') THEN
                 (CASE 
                      WHEN CAST(Clp.EKYCSucessDate AS DATE) IS NOT NULL
                           AND (CAST(Clp.SpouseEKYCCaptureDate AS DATE) IS NOT NULL OR CAST(Clp.CoApplicantEKYCSucessDate AS DATE) IS NOT NULL) THEN 'with Bio-auth'
                 END)
            ELSE 
                 (CASE  
                      WHEN CAST(Clp.ProposalDate AS DATE) = CAST(Clp.EKYCSucessDate AS DATE) THEN 'with Bio-auth'
                      WHEN CAST(Clp.ProposalDate AS DATE) = CAST(Clp.MainOTPSucessDate AS DATE) THEN 'with OTP'
                      WHEN CAST(Clp.ProposalDate AS DATE) = CAST(Clp.AlternateOTPSucessDate AS DATE) THEN 'with OTP'
                      WHEN CAST(Clp.TEMPDISBURSEMENTDATE AS DATE) = CAST(Clp.EKYCSucessDate AS DATE) THEN 'with Bio-auth'
                      WHEN CAST(Clp.TEMPDISBURSEMENTDATE AS DATE) = CAST(Clp.MainOTPSucessDate AS DATE) THEN 'with OTP'
                      WHEN CAST(Clp.TEMPDISBURSEMENTDATE AS DATE) = CAST(Clp.AlternateOTPSucessDate AS DATE) THEN 'with OTP'
                      ELSE 'Without Bio-auth & OTP'
                 END)
       END) AS BioAuthStatus,
       IF(CAST(Cls.DisbursementDate AS DATE) >= '2023-08-07', Clp.BioAuthDisbConsentFlag, NULL) AS BioAuthDisbConsentFlag,
       Clp.ESignRRNO,
       Clp.WorkFlowStatus,
       Clp.ProposalStatus,
       CAST(Clp.CancelDate AS DATE) AS Proposal_CancelDate,
       CAST(Clp.LOANCANCELLEDDATE AS DATE) AS Proposal_LoanCancelDate,
       CAST(Clp.BCMLoanCancelledDate AS DATE) AS Proposal_BCMCancelDate,
       CAST(Clp.DeviationCancelledDate AS DATE) AS Proposal_DeviationCancelDate,
       Clp.CancelRemarks,
       (CASE 
            WHEN Clp.IsProposalAfterCenterConfirm = 0 THEN 'With CM'
            WHEN Clp.IsProposalAfterCenterConfirm = 1 THEN 'OutSide CM'
            ELSE 'Error'
        END) AS Proposal_CenterConfirm,
       CAST(Clp.ClientDOBAtDisbursement AS DATE) AS ClientDOBAtDisbursement,
       CAST(Clp.SpouseDOBAtDisbursement AS DATE) AS SpouseDOBAtDisbursement,

       /* Client Loan Subscription Details */
       Cls.CreatedBy AS Disbursement_StaffID,
       Cls.ClientLoanID,
       Cls.ClientProductSequenceNo AS Loan_SeqNo,
       CAST(Cls.DisbursementDate AS DATE) AS DisbursementDate,
       Cls.LoanAmountDisbursed,
       Cls.IsLoanCancelled,
       CAST(COALESCE(Cls.LoanCancelledDate, Cls.DeviationCancelledDate) AS DATE) AS LoanCancel_DeviationDate,
       COALESCE(Cls.LoanCancellationType, Cls.Remarks) AS Cancel_ClosedRemarks,
       CAST(Cls.LoanClosedDate AS DATE) AS LoanClosedDate,
       CAST(Cls.ExpectedPaidUpDate AS DATE) AS ExpectedPaidUpDate,
       (CASE 
            WHEN Cls.ClientLoanID IS NOT NULL THEN 
                 (CASE 
                      WHEN COALESCE(Cls.LoanCancelledDate, Cls.DeviationCancelledDate) IS NOT NULL THEN 'Cancel'
                      WHEN Cls.LoanClosedDate IS NULL THEN 'Open'
                      WHEN Cls.LoanClosedDate < Cls.ExpectedPaidUpDate THEN 'Pre-Closure'
                      ELSE 'Closed'
                 END)
            ELSE NULL
        END) AS LoanStatus,
       INITCAP(DLP.DLPStatus) AS DLPStatus,
       IF(UPPER(DLP.DLPStatus) = 'YES', 1, 0) AS DLPSMSSent,
       'BFIL-MFI' AS SOURCE_SYSTEM_ID 
FROM edp_curated_prod.bfil.`pragati-clientloanproposal_h_view` AS Clp
LEFT JOIN edp_curated_prod.bfil.`pragati-clientloansubscription` AS Cls 
       ON Cls.LoanProposalID = Clp.LoanProposalID 
       AND Cls.ETL_IS_ACTIVE = 1
LEFT JOIN edp_curated_prod.bfil.`pragatimain-derivedproductmaster` AS DPM 
       ON DPM.DerivedProductID = Clp.ProductID 
       AND DPM.ETL_IS_ACTIVE = 1
LEFT JOIN edp_curated_prod.bfil.`pragati-productmaster` AS PM 
       ON PM.ProductID = DPM.ProductID 
       AND PM.ETL_IS_ACTIVE = 1
LEFT JOIN edp_curated_prod.bfil.`pragati-loanpurposes` AS LP 
       ON LP.PurposeID = Clp.PurposeID 
       AND LP.ETL_IS_ACTIVE = 1
LEFT JOIN edp_curated_prod.bfil.`azuresource-dim_productmaster` AS DIM_PM 
       ON DIM_PM.PRODUCT_ID = PM.ProductCode 
       AND DIM_PM.SBU = 'MFI' 
       AND DIM_PM.ETL_IS_ACTIVE = 1
LEFT JOIN edp_curated_prod.bfil.`pragati-preapprovedproposal` AS PAP 
       ON PAP.LoanProposalID = Clp.LoanProposalID 
       AND PAP.ETL_IS_ACTIVE = 1
LEFT JOIN edp_curated_prod.bfil.`pragati-surakshapreapprovedproposal` AS SPAP 
       ON SPAP.LoanProposalID = Clp.LoanProposalID 
       AND SPAP.ETL_IS_ACTIVE = 1
LEFT JOIN edp_curated_prod.bfil.`azuresource-alldlpdata_view` AS DLP 
       ON DLP.LoanProposalID = Clp.LoanProposalID 
       AND DLP.ETL_IS_ACTIVE = 1

WHERE Clp.ProductType IS NULL 
AND Clp.ETL_IS_ACTIVE = 1
AND (
       CAST(Clp.ProposalDate AS DATE) BETWEEN '{stdate}' AND '{eddate}'
       OR 
       CAST(Cls.DisbursementDate AS DATE) BETWEEN '{stdate}' AND '{eddate}'
    )
OR (
    (CAST(Clp.UpdatedDateTime AS DATE) >= CAST(FROM_UTC_TIMESTAMP(CURRENT_DATE(), 'Asia/Kolkata') AS DATE) - 2)
    OR 
    (CAST(Cls.UpdatedDateTime AS DATE) >= CAST(FROM_UTC_TIMESTAMP(CURRENT_DATE(), 'Asia/Kolkata') AS DATE) - 2)
)


Union

/* BSS Proposals - Disbursements */ 
Select  'BSS' As SBU,
        Clp.HierarchyID, 
        /* Client Loan Application Details */
        Clp.CustomerID As ClientID,
        Clp.LoanApplicationID As LoanProposalID,
        Clp.Createddatetime As ProposalEntryDate,
        BM.UserID As StaffID,
        Cast(Clp.LoanApplicationDate As Date) As ProposalDate,
        Clp.LoanAmountRequested As RequestedAmount,
        Clp.LoanAmountApproved As ApprovedAmount,
        Cast(Clp.Approveddate As Date) As ApprovedDate,
        Clp.ApprovalRemarks,
        Cast(Alp.TEMPDISBURSEMENTDATE As Date) As TempDisbursementDate,
        Clp.PurposeID,
        LP.PurposeName,
        PM.ProductCode,
        PM.ProductName,
        DIM_PM.PRODUCT_CATEGORY1 As ProductCategory,
        Clp.DisbursementMode,
        (Case When DT.LoanApplicationID Is Not Null and PM.ProductCode In ('P398','M604') and Cls.CustomerProductSequenceNo = 2 Then 'Regular'
              When DT.LoanApplicationID Is Not Null Then 'Instant' 
        Else 'Regular' End) As DisbursementType,
        Cast(Clp.LoanDisbursementDate As Date) As LoanDisbursementDate,
        Null As ActualDisbursementDate,
        Null As ActualDisbursedAmount,
        Alp.CustomerProductSequenceNo As Proposal_SeqNo,
        cast(clp.InterestRate As Decimal(10,2)) As ROI,
        Clp.Tenure,
        IFF(Clp.Tenure In(12,25,52,50),'DL','TL') As LoanType,   
        Clp.RepaymentFrequency,
        Alp.CBUpdateID,
        Alp.IsBCMTrackerFlag,
        Alp.IsBCMApproved, 
        Alp.EKYCStatus,
        Cast(Alp.EKYCSucessDate As Date) As EKYCSucessDate,
        Cast((Case When Upper(Alp.LoanApplicationType) ='SMS' Then Alp.CustomerRRNoDateTime Else Null End) As Date) As OTPDate,
        (Case When Upper(Alp.LoanApplicationType) ='SMS' Then 'With OTP'     
              When Upper(Alp.LoanApplicationType) = Upper('Regular') Then 'With Bio-Auth' End) As BioAuthStatus,
        Cast(IFF(CC.CustomerID Is Not Null,'True','False') As Boolean) As BioAuthDisbConsentFlag,
        Alp.ESignRRNO,
        Alp.WorkFlowStatus,
        Clp.LoanApplicationStatus As ProposalStatus,
        Cast(Coalesce(Alp.CancelDate,Clp.RejectedDate) As Date) As Proposal_CancelDate,
        Cast(Alp.LOANCANCELLEDDATE As Date) As Proposal_LoanCancelDate,
        Cast(Alp.BCMLoanCancelledDate As Date) As Proposal_BCMCancelDate,
        Cast(Alp.DeviationCancelledDate As Date) As Proposal_DeviationCancelDate,
        Clp.Remarks As CancelRemarks,
        Null As Proposal_CenterConfirm,
        Cast(Alp.ClientDOBAtDisbursement As Date) As ClientDOBAtDisbursement,
        Cast(Alp.SpouseDOBAtDisbursement As Date) As SpouseDOBAtDisbursement,

        /* Client Loan SubScription Details */
        Cls.CreatedBy As Disbursement_StaffID,
        Cls.CustomerLoanId AS ClientLoanID,
        Cls.CustomerProductSequenceNo As Loan_SeqNo,
        Cast(Cls.DisbursementDate As Date) As DisbursementDate,
        Cls.LoanAmountDisbursed,
        Cls.IsLoanCancelled,
        cast(Coalesce(coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) As Date) As LoanCancel_DeviationDate,
        Coalesce(cls.LoanCancellationType,Cls.Remarks) As Cancel_ClosedRemarks,
        cast(Cls.LoanClosedDate as date) As LoanClosedDate,
        cast(Cls.ExpectedPaidupDate as date) As ExpectedPaidUpDate,
        (Case When Cls.CustomerLoanID Is Not Null Then 
              (Case When Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,
                    Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) Is Not Null Then 'Cancel'            
                    When Cls.LoanClosedDate Is Null Then 'Open'             
                    When Cls.LoanClosedDate < Cls.ExpectedPaidUpdate Then 'Pre-Closure'            
                    Else 'Closed' End)
        Else Null End) As LoanStatus,
        IFF(Tiny.ClientLoanID Is Not Null,'Yes',Null) As DLPStatus,
        IFF(IFNull(Msg.MsgPath,Msg1.MsgPath) Is Not Null,1,0) As DLPSMSSent,
    'BFIL-BSS' as SOURCE_SYSTEM_ID

From  edp_curated_prod.bfil.`rlmsbizxtend-customerloanapplication` AS Clp
Left Join edp_curated_prod.bfil.`rlmsbizxtend-additionalloanapplicationdetails` Alp on Clp.LoanApplicationID=Alp.LoanApplicationID and Alp.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`rlmsbizxtend-customerloandisbursement` AS Cls on Clp.LoanApplicationID=Cls.LoanApplicationID and Cls.ETL_IS_ACTIVE = 1 
Left Join edp_curated_prod.bfil.`rlmsbizxtend-productmaster` AS PM on Cls.ProductID=PM.ProductID and PM.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`rlmsbizxtend-loanpurposemaster` as LP on Clp.PurposeID=LP.PurposeID and LP.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`azuresource-dim_productmaster` As DIM_PM On DIM_PM.PRODUCT_ID = PM.ProductCode and DIM_PM.SBU ='BSS' and DIM_PM.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`rlmsbizxtend-batchmaster` As BM On BM.BatchID = Clp.BatchID and BM.ETL_IS_ACTIVE = 1
/* Disbursement Type */
Left Join ( Select A.LoanApplicationID           
            From edp_curated_prod.bfil.`rlmsbizxtend-additionalloanapplicationdetails` A
            Join edp_curated_prod.bfil.`rlmsbizxtend-bfil_cbresponse_h` B On B.ReportID = A.CBUpdateID and B.ETL_IS_ACTIVE = 1
            Where (History12Months=1 Or History6Months=1) and B.ETL_Is_Active = 1
            Union
            Select A.LoanApplicationID
            From edp_curated_prod.bfil.`rlmsbizxtend-customerloanapplication` A
            Join edp_curated_prod.bfil.`rlmsbizxtend-bfil_bankstatements_sent` B On B.CustomerID = A.CustomerID and B.ETL_IS_ACTIVE = 1
            Where TicketSize >0 and InstantFlag=1  and A.ETL_IS_ACTIVE = 1) As DT On DT.LoanApplicationID = Clp.LoanApplicationID
/* Bio Auth Authorization */
Left Join ( Select CC.CustomerID,row_number() OVER (PARTITION BY CC.CustomerID Order By CC.CreatedDateTime Desc) As RowNumber
            From edp_curated_prod.bfil.`rlmsbizxtend-bfil_consentsconfirmed` As CC  
            Join edp_curated_prod.bfil.`rlmsbizxtend-bfil_consents` As CS On CS.ID = CC.Consents and CS.ETL_IS_ACTIVE = 1
            Where CC.Consents In ('60','61') and CC.ETL_IS_ACTIVE = 1) As CC On CC.CustomerID = Clp.CustomerID and RowNumber = 1
/* DLP Status */
Left Join ( Select  Left(Replace(A.c4,'https://dlp.bfil.it/BSSLoanApplication',''),16) As ClientLoanID,B.c3 As MsgFilePath
            From (  Select json_tuple(Req,'Mobile','AccountNumber','ClientID','BfilRefNum','DocPath','sourceSystem','Purpose'),CreateDate
                    From edp_curated_prod.bfil.`rlmsbizxtend-bfil_tiny`
                    Where ETL_IS_ACTIVE = 1) As A
            Left Join (Select json_tuple(Res,'responseCode','responseMsg','BfilRefNum','msgFilePath'),CreateDate
                        From edp_curated_prod.bfil.`rlmsbizxtend-bfil_tiny`
                        Where ETL_IS_ACTIVE = 1) As B On B.C2 = A.C3 and B.CreateDate= A.CreateDate
            Where Upper(A.c6) ='LD') As Tiny On Tiny.ClientLoanID = Cls.CustomerLoanID and Tiny.MsgFilePath Is Not Null
/* DLP SMS Sent */
Left Join ( Select Replace(Left(SMSText,CHARINDEX('to view',SMStext)-2),'Greetings! Click here ','') As MsgPath
            From edp_curated_prod.bfil.`rlmsbizxtend-BFIL_SMSData` 
            Where Upper(Purpose) = Upper('Customer Loan Application') and ETL_IS_ACTIVE = 1) As Msg On Msg.MsgPath = Tiny.MsgFilePath
Left Join ( Select Replace(Left(SMSText,CHARINDEX('to view',SMStext)-2),'Greetings! Click here https://rlms.bfil.it/','') As MsgPath
            From edp_curated_prod.bfil.`rlmsbizxtend-BFIL_SMSData` 
            Where Upper(Purpose) = Upper('Customer Loan Application') and ETL_IS_ACTIVE = 1) As Msg1 On Msg1.MsgPath = Tiny.MsgFilePath

Where Clp.ProductType Is Null
  and (
        Cast(Clp.LoanApplicationDate As Date) Between '{stdate}' And '{eddate}'
        Or 
        Cast(Cls.DisbursementDate As Date) Between '{stdate}' And '{eddate}'
  )
 OR (
    (CAST(Clp.UpdatedDateTime AS DATE) >= CAST(FROM_UTC_TIMESTAMP(CURRENT_DATE(), 'Asia/Kolkata') AS DATE) - 2)
    OR 
    (CAST(Cls.UpdatedDateTime AS DATE) >= CAST(FROM_UTC_TIMESTAMP(CURRENT_DATE(), 'Asia/Kolkata') AS DATE) - 2)
)
Union

/* BMS Proposals - Disbursements */ 
Select 'BMS' as SBU,
        CLP.HierarchyID,
        /* Client Loan Application Details */
        Clp.ClientID,
        Clp.LoanProposalID,
        Clp.CreatedDateTime As ProposalEntryDate,
        Clp.FieldStaffId As StaffID,
        Cast(Clp.ProposalDate As Date) As ProposalDate,
        Clp.LoanAmountRequested As RequestedAmount,
        Clp.LoanAmountApproved As ApprovedAmount,
        Cast(Clp.ApprovedDate As Date) As ApprovedDate,
        Clp.ApprovalRemarks,
        Cast(Clp.TEMPDISBURSEMENTDATE As Date) As TempDisbursementDate,
        Clp.PurposeID,
        LP.PurposeName,
        PM.ProductCode,
        PM.ProductName,
        DIM_PM.PRODUCT_CATEGORY1 As ProductCategory,
        Clp.DisbursementMode,
        (Case When (Upper(Clp.DisbursementType) = 'I' and Upper(CLp.SameDayOrNextWeek) = 'SAME DAY') Then 'Instant'        
              When Upper(Clp.Createdby) ='HO' Then 'Preapproved'         
              When Upper(Clp.CBUpdateID) Like '%:P%' Then 'Preapproved'        
        Else 'Normal' End) As DisbursementType,  
        Cast(Clp.LoanDisbursementDate As Date) As LoanDisbursementDate,
        Null As ActualDisbursementDate,
        Clp.ActualDisbursedAmount,
        Clp.ClientProductSequenceNo As Proposal_SeqNo,
        Cast(Clp.InterestRate As Decimal(10,2)) As ROI,  
        Clp.Tenure,        
        IFF(Clp.Tenure In (12,25,52,50),'DL','TL') As LoanType,
        Clp.RepaymentFrequency,  
        Clp.CBUpdateID,
        Clp.IsBCMTrackerFlag,    
        Clp.IsBCMApproved,    
        Clp.EKYCStatus,
        Cast(Clp.EKYCSucessDate As Date) As EKYCSucessDate,
        Cast(Coalesce(Clp.MainOTPSucessDate,Clp.AlternateOTPSucessDate) As Date) As OTPDate,
        'with Bio-auth' As BioAuthStatus,
        Cast(Null As Boolean) As BioAuthDisbConsentFlag,
        LD.RRN As ESignRRNO,
        Clp.WorkFlowStatus,
        Clp.ProposalStatus,
        Cast(Clp.CancelDate As Date) As Proposal_CancelDate,    
        Cast(Clp.LOANCANCELLEDDATE As Date) As Proposal_LoanCancelDate,    
        Cast(CLp.BCMLoanCancelledDate As Date) As Proposal_BCMCancelDate,    
        Cast(Clp.DeviationCancelledDate As Date) As Proposal_DeviationCancelDate,
        Clp.CancelRemarks,
        (Case When Clp.IsProposalAfterCenterConfirm=0 Then 'With CM'      
              When Clp.IsProposalAfterCenterConfirm=1 Then 'OutSide CM' 
        Else 'Error' End) As Proposal_CenterConfirm,
        Cast(Clp.ClientDOBAtDisbursement As Date) As ClientDOBAtDisbursement,
        Cast(Clp.SpouseDOBAtDisbursement As Date) As SpouseDOBAtDisbursement,

        /* Client Loan SubScription Details */
        Cls.CreatedBy As Disbursement_StaffID,        
        Cls.ClientLoanID, 
        Cls.ClientProductSequenceNo As Loan_SeqNo,  
        Cast(Cls.DisbursementDate As Date) As DisbursementDate,          
        Cls.LoanAmountDisbursed,                  
        Cls.IsLoanCancelled,            
        Cast(Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) As Date) As LoanCancel_DeviationDate,     
        Coalesce(Cls.LoanCancellationType,Cls.Remarks) As Cancel_ClosedRemarks,            
        Cast(Cls.LoanClosedDate As Date) As LoanClosedDate,        
        Cast(Cls.ExpectedPaidUpDate As Date) As ExpectedPaidUpDate,        
        (Case When Cls.ClientLoanID Is Not Null Then 
              (Case When Coalesce(Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate),Null,
                    Coalesce(Cls.LoanCancelledDate,Cls.DeviationCancelledDate)) Is Not Null Then 'Cancel'            
                    When Cls.LoanClosedDate Is Null Then 'Open'             
                    When Cls.LoanClosedDate < Cls.ExpectedPaidUpdate Then 'Pre-Closure'            
                    Else 'Closed' End)
        Else Null End) As LoanStatus,
        IFF(LD.LoanDocFlag ='1','Yes','No') As DLPStatus,
        IFF(LD.LoanDocFlag ='1',1,0) As DLPSMSSent,
                'BFIL-BMS' as SOURCE_SYSTEM_ID

From edp_curated_prod.bfil.`ptsmart-clientloanproposal` AS Clp 
Left Join edp_curated_prod.bfil.`ptsmart-clientloansubscription` As Cls On Cls.LoanProposalID = Clp.LoanProposalID and Cls.ETL_IS_ACTIVE = 1
Left join edp_curated_prod.bfil.`ptsmart-derivedproductmaster`  As DPM On DPM.DerivedProductID = Clp.ProductID and DPM.ETL_IS_ACTIVE = 1
Left join edp_curated_prod.bfil.`ptsmart-productmaster`  As PM On PM.ProductID = DPM.ProductID and PM.ETL_IS_ACTIVE = 1
left join edp_curated_prod.bfil.`ptsmart-loanpurposes` As LP On LP.PurposeID = Clp.PurposeID and LP.ETL_IS_ACTIVE = 1
left join edp_curated_prod.bfil.`azuresource-dim_productmaster`As DIM_PM On DIM_PM.PRODUCT_ID = PM.ProductCode and DIM_PM.SBU ='BMS' and DIM_PM.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`rdsp-tbl_bms_loandocumentdetails` As LD On LD.ProposalID = Clp.LoanProposalID and LD.ETL_IS_ACTIVE = 1
where Clp.ProductType Is Null
-- and Clp.LoanProposalId='5114451000186803'
  and (
        Cast(Clp.ProposalDate As Date) Between '{stdate}' And '{eddate}'
        Or 
        Cast(Cls.DisbursementDate As Date) Between '{stdate}' And '{eddate}'
  )
OR (
    (CAST(Clp.UpdatedDateTime AS DATE) >= CAST(FROM_UTC_TIMESTAMP(CURRENT_DATE(), 'Asia/Kolkata') AS DATE) - 2)
    OR 
    (CAST(Cls.UpdatedDateTime AS DATE) >= CAST(FROM_UTC_TIMESTAMP(CURRENT_DATE(), 'Asia/Kolkata') AS DATE) - 2)
)),

/* Loan Ledger Like LPF,CSIP,etc. */
CTE_AccountTransactions As (
/* MFI Loan Transactions */
Select A.LoanProposalID,
        Coalesce(Sum(Case When Upper(TransactionType) = 'F' Then Amount Else 0 End),0) As LPF,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'I' Then Amount Else 0 End),0) As CSIP_Member,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'H' Then Amount Else 0 End),0) As CSIP_Spouse,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'L' Then Amount Else 0 End),0) As CSIP_CoApplicant,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'O' Then Amount Else 0 End),0) As Document_Charges,    
        Coalesce(Sum(Case When Upper(TransactionType) = 'D' Then Amount Else 0 End),0) As DownPayment_Charges  
From CTE_ClientLoanProposal As A
Join edp_curated_prod.bfil.`pragati-at_loantransactions` As B On B.HierarchyID = A.HierarchyID and B.ClientID = A.ClientID and B.ClientLoanProposalID = A.LoanProposalID
Where Upper(B.DebitOrCredit) ='C' and Upper(A.SBU) ='MFI' and B.ETL_IS_ACTIVE = 1
Group By A.LoanProposalID

Union All

/* BSS Loan Transactions */
Select  A.LoanproposalID,
        Coalesce(Sum(Case When Upper(TransactionType) = 'F' Then Amount Else 0 End),0) As LPF,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'I' Then Amount Else 0 End),0) As CSIP_Member,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'H' Then Amount Else 0 End),0) As CSIP_spouse,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'L' Then Amount Else 0 End),0) As CSIP_CoApplicant,
        Coalesce(Sum(Case When Upper(TransactionType) = 'D' Then Amount Else 0 End),0) As Document_Charges,
        0 As DownPayment_Charges       
From CTE_ClientLoanProposal A
JOIN edp_curated_prod.bfil.`rlmsbizxtend-loantransactions` B On B.HierarchyID = A.HierarchyID and B.CustomerID = A.ClientID and B.LoanApplicationID = A.LoanProposalID
Where Upper(B.DebitOrCredit) ='C' and Upper(A.SBU) ='BSS' and B.ETL_IS_ACTIVE = 1
Group By A.LoanProposalID

Union All

/* BMS Loan Transactions */
Select A.LoanProposalID,
        Coalesce(Sum(Case When Upper(TransactionType) = 'F' Then Amount Else 0 End),0) As LPF,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'I' Then Amount Else 0 End),0) As CSIP_Member,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'H' Then Amount Else 0 End),0) As CSIP_Spouse,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'L' Then Amount Else 0 End),0) As CSIP_CoApplicant,                        
        Coalesce(Sum(Case When Upper(TransactionType) = 'O' Then Amount Else 0 End),0) As Document_Charges,    
        Coalesce(Sum(Case When Upper(TransactionType) = 'D' Then Amount Else 0 End),0) As DownPayment_Charges  
From CTE_ClientLoanProposal As A
Join edp_curated_prod.bfil.`ptsmart-accounttransactions` As B On B.HierarchyID = A.HierarchyID and B.ClientID = A.ClientID and B.ClientLoanProposalID = A.LoanProposalID
Where Upper(B.DebitOrCredit) = 'C' and Upper(A.SBU) ='BMS' and B.ETL_IS_ACTIVE = 1
Group By A.LoanProposalID),

/* Final Table */
CTE_Proposal_Disbursements_BSP As(
Select  A.*,
        B.LPF,
        B.CSIP_Member,
        B.CSIP_Spouse,
        B.CSIP_CoApplicant,
        B.Document_Charges,
        B.DownPayment_Charges,
        IFF(Upper(A.DisbursementMode) In ('DM1','DM4'),A.LoanAmountDisbursed,
        A.LoanAmountDisbursed - (coalesce(B.LPF,0)+coalesce(B.CSIP_Member,0)+coalesce(B.CSIP_Spouse,0)+coalesce(B.CSIP_CoApplicant,0)+coalesce(B.Document_Charges,0)+coalesce(B.DownPayment_Charges,0))) As SMPT_NetAmount,
        BSP.LoanAmountDisbursed As BSP_NetAmount,
        BSP.ACC_Download,
        BSP.ACC_DownloadDate,
        BSP.UTR_NO,
        BSP.UTR_PaymentDate,
        BSP.BankType,
        BSP.BankAccountNumber,
        BSP.BankIFSCCode,
        BSP.BankName,
        BSP.BankBranch,
        BSP.ClientNameASPerBank,
        BSP.IBLRefNo,
        IFF(Coalesce(C.LoanProposalID,D.LoanProposalID) Is Not Null,'Yes',Null) As IsDedupe
From CTE_ClientLoanProposal A
Left Join CTE_AccountTransactions As B On B.LoanProposalID = A.LoanProposalID
Left Join edp_curated_prod.bfil.`cashlessdisburs-Azure_BSP_CashlessDisburs_Data` As BSP On BSP.LoanProposalID = A.LoanProposalID and BSP.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`cashlessdisburs-cl_dedupe_loanandclientdetails` As C On C.LoanProposalID = A.LoanProposalID and C.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`cashlessdisburs-cl_mfi_household` As D On D.LoanProposalID = A.LoanProposalID and D.IsCancel = 2 and D.ETL_IS_ACTIVE = 1),

/* Proposal Against Final Remarks */
CTE_Proposal_FinalRemarks As 
(Select A.LoanProposalID,
        IFF(A.ACC_DownloadDate Is Null and A.LoanCancel_DeviationDate Is Not Null and A.IsDedupe Is Null,'Yes',Null) As Direct_PTCancellation, 
        IFF(IFF(A.ACC_DownloadDate Is Null and A.LoanCancel_DeviationDate Is Not Null and A.IsDedupe Is Null,'Yes',Null)='Yes',SMPT_NetAmount,0) As Direct_PTCancellationAmount,
        (Case When Upper(A.UTR_No) Not Like Upper('%Reject%') and A.UTR_No Is Not Null Then 'Payment Done'
              When Upper(A.UTR_No) Like Upper('%Reject%') Then 'Payment Rejected'
              When A.UTR_No Is Null and A.LoanCancel_DeviationDate Is Not Null Then 'Loan Cancel'
              When A.Acc_Download = 1 and coalesce(A.UTR_No,0) = 0 Then 'Processed But UTR Pending'
              When A.Acc_Download = 0 And A.LoanCancel_DeviationDate Is Null and A.ClientLoanID Is Not Null Then 'Payment Pending'
              When A.ClientLoanID Is Not Null and Upper(A.DisbursementMode) In ('DM1','DM4') Then 'Cash Payment'
              When A.Proposal_CancelDate Is Not Null Or A.Proposal_LoanCancelDate Is Not Null Or A.Proposal_DeviationCancelDate Is Not Null Then 'Proposal Cancel'
              When A.Proposal_BCMCancelDate Is Not Null Then 'BCM Cancel'
              When Upper(A.CancelRemarks) = Upper('System Cancelled due to disbursed not done on same day') Then 'System Cancelled due to disbursed not done on same day'
              When Upper(A.CancelRemarks) = Upper('System Cancelled while tab sync process, due to disbursed not done on same day') Then 'System Cancelled while tab sync process, due to disbursed not done on same day'
              When Upper(A.CancelRemarks) Like Upper('%Previous day disbursement confirmation Pending%') Then 'Previous day disbursement confirmation Pending'
              When Upper(A.CancelRemarks) Like Upper('%Instant CB validity expired%') Then 'Instant CB validity expired'
              When B.LoanProposalID Is Not Null Then 'BSP - WD Blocked'
              When C.LoanProposalID Is Not Null Then 'BSP - Bank A/C Restrict'
              When D.LoanProposalID Is Not Null Then 'BSP - Diversion Disbursement Amount'
              When E.LoanProposalID Is Not Null Then 'BSP - Diversion Disbursement Amount'
              When F.LoanProposalID Is Not Null Then 'BSP - Dedupe'
              When G.LoanProposalID Is Not Null Then 'BSP - HouseHold Reject'
              -- When Upper(A.ProductCategory) = 'FUL' and A.TempDisbursementDate Is Not Null Then 'Disbursement Pending'
              When Upper(A.DisbursementMode) In ('DM1','DM4') and A.TempDisbursementDate Is Not Null Then 'Disbursement Pending'
              When Upper(A.WorkFlowStatus) = 'A' Then 'BCM Pending'
              When Upper(A.WorkFlowStatus) = 'R' and Upper(A.ApprovalRemarks) = Upper('Instantly Rejected') Then 'Instantly Rejected'
              When Upper(A.WorkFlowStatus) = 'N' Or Coalesce(A.WorkFlowStatus,'') ='' Then 'Proposal Cancel'
        Else A.CancelRemarks End) As FinalRemarks
FROM CTE_Proposal_Disbursements_BSP As A
Left Join edp_curated_prod.bfil.`cashlessdisburs-wd_blocked_proposals` As B On B.LoanProposalID = A.LoanProposalID and B.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`cashlessdisburs-cl_restrict_bankaccount` As C On C.LoanProposalID = A.LoanProposalID and C.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`cashlessdisburs-cl_diversiondisbursedamount_H` As D On D.LoanProposalID = A.LoanProposalID and D.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`cashlessdisburs-cl_diversiondisbursedamount_csip_H` As E On E.LoanProposalID = A.LoanProposalID and E.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`cashlessdisburs-cl_dedupe_loanandclientdetails` As F On F.LoanProposalID = A.LoanProposalID and F.ETL_IS_ACTIVE = 1
Left Join edp_curated_prod.bfil.`cashlessdisburs-cl_mfi_household` As G On G.LoanProposalID = A.LoanProposalID and G.IsCancel= 0 and G.ETL_IS_ACTIVE = 1),

/* Final Query with Payment Status */
CTE_Proposal_DisbursementFacts As(
Select  A.*,
        B.FinalRemarks,
        (Case   When Upper(B.FinalRemarks) Like 'BSP%' Then 'BSP Validation Failed'
                When B.FinalRemarks Not In ('Payment Done','Payment Rejected','Loan Cancel','Processed But UTR Pending','Payment Pending','Cash Payment',
                'Proposal Cancel','BCM Cancel','Instant CB validity expired','BCM Pending','Disbursement Pending','Instantly Rejected') Then 'Proposal Cancel'
        Else B.FinalRemarks End) As PaymentStatus
From CTE_Proposal_Disbursements_BSP A
Left Join CTE_Proposal_FinalRemarks As B On B.LoanProposalID = A.LoanProposalID )

/* Final Table */
Select * From CTE_Proposal_DisbursementFacts
    """
    try:
        source_data_df = spark.sql(query)
        return source_data_df
    except Exception as e:
        # print(e)
        # Log the error
        logger(
            logger_level_error,
            f"Error while executing query on loan_collection_fact: {str(e)}",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        # Raise a new exception with a message
        print('completed')
        raise RuntimeError(
            f"Error while executing query on loan_collection_fact: {str(e)}"
        ) from e

# COMMAND ----------

def dim_disbursement_facts(TargetTable, Business, stdate, eddate, DBG_FLG, adb_consumption_catlog_schema, pipeline_run_id, SRCSCH,TRGSCH):
    try:
        SKCOL = "DISBURSEMENT_FACTS_SKEY"
        prevSKVal = maxsk(SKCOL, f"{adb_consumption_catlog_schema}.disbursement_facts")
        
        #FOR CONSUMPTION LAYER
        ConfigDF, CreateConfig, JoinConfigDF, UniqueKeyValues, list_agg_df, mappingdict, JoinConfigDFValue, renameFields = loadconfig(TargetTable, Business, 1)
        df = get_incremental_dataframe_disbursement(stdate, eddate, SRCSCH)
        df.printSchema()
        rowCountDF = df.count() if df else 0
        print(rowCountDF)
        
        df = repartitioning_SKID(df)
        df = df.withColumn(SKCOL, lit(col("SKID").cast("int") + prevSKVal))
        print(renameFields)
        df = selectAndRename(df, renameFields)
        print("print schema before adding metadata columns")
        df.printSchema()
        MetaColList_updated =["EFFECTIVEFROMDATE", "EFFECTIVETODATE", "CURRENT_FLAG", "ETL_BATCH_ID", "ETL_INSERTED_DATE", "ETL_INSERTED_BY", "ETL_UPDATED_DATE", "ETL_UPDATED_BY"]
        
        withColVar = MetaDataColumns(MetaColList_updated, Business, "", "User")
        df = eval(f"df{withColVar}")
        print("print schema before appending to table")
        df.printSchema()

        df.write.format("delta").mode("append").option(
        "mergeSchema", "true"
        ).saveAsTable(f"{TRGSCH}.disbursement_facts")

        update_logs(src_object_id,start_timestamp,log_status_success,load_from_date,load_to_date,pipeline_name,pipeline_run_id,pipeline_trigger_name,rowCountDF,rowCountDF,log_error_success,
            "",
            load_type,
            ["disbursement_facts"]
        )

    except Exception as e:
        logger(logger_level_error, f"An error occurred in the disbursement_facts notebook: {str(e)}", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception("An error occurred in the disbursement_facts notebook:", str(e))
