# Databricks notebook source
def get_incremental_dataframe_cdf(stdate, eddate, SRCSCH):
    query = f"""WITH CTE_Proposals AS (
        SELECT DISTINCT  
            CLP.HierarchyId,
            CLP.LoanProposalId,
            CLP.ClientId,
            CL.ClientName,
            CLP.CreatedBy AS Proposal_Picked_StaffID,
            CLP.UpdatedBy AS Proposal_Updated_Picked_StaffID,
            CLP.ProposalDate,
            CLP.TEMPDISBURSEMENTDATE,            
            CLP.LoanAmountRequested,
            CLP.LoanAmountApproved,
            CLP.WorkFlowStatus AS BM_ProposalApprovalStatus,            
            CLP.ProposalStatus AS CB_Status,
            CLP.CBUpdateId,  
            --SUBSTRING(CLP.CBUpdateId, 8, 1) AS Proposal_Identifier,
            CASE 
                WHEN SUBSTRING(CLP.CBUpdateId, 8, 1) = 'I' THEN 'Instant'
                WHEN SUBSTRING(CLP.CBUpdateId, 8, 1) = 'P' THEN 'Pre-Approved'
            END AS Proposal_Identifier,            
            CASE 
                WHEN CLP.CreatedBy = 'HO' THEN 'Pre-Approved' 
                WHEN CLP.DisbursementType = 'I' AND CLP.SameDayOrNextWeek = 'Same Day' THEN 'Instant' 
            END AS Proposal_Status,            
            CLP.DownPaymentAmount,
            CLP.ProcessingFeeAmount,
            CLP.OtherFeeAmount,
            CLP.MemberInsuranceAmount,            
            CLP.SpouseInsuranceAmount,
            CLP.CoApplicantInsuranceAmount,            
            CLP.ApprovedDate,
            CLP.CancelDate,
            CLP.CancelRemarks,
            CLP.BCMLoanCancelledDate,
            CLP.DeviationCancelledDate,            
            CLP.ESignRRNO,
            CLP.EKYCSucessDate,
            CLP.MobileNumber,
            CLP.EKYCCaptureDate,
            PM.ProductCode,
            O.PRODUCT_CATEGORY2 as ProductDescription,O.PRODUCT_NAME as Prd_BroadCategory,
            CM.CenterID
FROM {SRCSCH}.`pragati-clientloanproposal_h_view`AS CLP            
INNER JOIN {SRCSCH}.`pragatimain-derivedproductmaster` DPM on CLP.ProductId = DPM.DerivedProductId            
INNER JOIN {SRCSCH}.`pragati-productmaster` PM on PM.ProductId = DPM.ProductId            
INNER JOIN {SRCSCH}.`pragati-clientmaster`AS CL   ON CLP.ClientId = CL.ClientId  
INNER JOIN {SRCSCH}.`pragati-groupmaster` AS E   ON CL.GroupId = E.GroupId            
INNER JOIN {SRCSCH}.`pragati-centermaster`AS CM   ON E.CenterId = CM.CenterId            
left join {SRCSCH}.`azuresource-dim_productmaster` O on PM.ProductCode = O.PRODUCT_ID                      
WHERE O.PRODUCT_CATEGORY3 = 'CrossSale' 
AND (CLP.ETL_LAST_UPDATED_DATE >= '{stdate}' AND CLP.ETL_LAST_UPDATED_DATE <= '{eddate}')
AND clp.ETL_IS_ACTIVE = 1 and dpm.ETL_IS_ACTIVE = 1 and pm.ETL_IS_ACTIVE = 1 and CL.ETL_IS_ACTIVE = 1 and E.ETL_IS_ACTIVE = 1 and CM.ETL_IS_ACTIVE = 1 and o.ETL_IS_ACTIVE = 1
    ),
   -- select * from CTE_Proposals;
	
CTE_UserMaster as
(

Select distinct  p.LoanProposalId,s.branchid as Branch_ID,s.BranchName,s.DISTRICT,s.Area,s.Region,s.STATE,s.Zone
---u.UserName as Proposal_Picked_StaffName,ux.UserName as Proposal_Updated_Picked_StaffName,
----UM.UserName as CenterHndled_Staff_Name
FROM CTE_Proposals AS p 
---LEFT JOIN {SRCSCH}.`pragatimain-usermaster` u on p.Proposal_Picked_StaffID=u.UserId            
---LEFT JOIN {SRCSCH}.`pragatimain-usermaster` um on p.CenterHndled_Staff_ID=um.UserId            
---LEFT JOIN {SRCSCH}.`pragatimain-usermaster`ux on p.Proposal_Updated_Picked_StaffID=ux.UserId            
LEFT JOIN edp_bfil_prod.bfil_mart.p_hierarchy_sop s on p.HierarchyId=s.HierarchyId            
--LEFT JOIN edp_bfil_prod.bfil_mart.p_hierarchy_sop Z  on s.HierarchyId=Z.hierarchyid            
----left join {SRCSCH}.`azuresource-dim_productmaster` O on p.ProductCode = O.ProductCode            
 ),
 --select * from CTE_UserMaster,
    CTE_UserMaster1 AS (
        SELECT DISTINCT a.*
        FROM CTE_Proposals AS a
        JOIN CTE_UserMaster AS b ON a.LoanProposalId = b.LoanProposalId
    ),
    CTE_MFI_HouseHold_Details AS (
        SELECT d.*, CAST(e.CreatedDateTime AS DATE) AS HHI_Date, e.Annual_HHI, e.Annual_HHE   
        FROM CTE_UserMaster1 AS d
        LEFT JOIN {SRCSCH}.`rdsp_trans-mfi_household_details` e ON d.clientid = e.clientid and e.ETL_IS_ACTIVE = 1
    ),
    CTE_Creditberu AS (
        SELECT cb.*, b.CBSubmittedDate, b.CBResponseDate, b.CBAmount, b.CBResponseId 
        FROM CTE_MFI_HouseHold_Details AS cb 
        LEFT JOIN {SRCSCH}.`pragati-creditbureauupdate` b ON cb.LoanProposalid = b.LoanProposalid            
        AND cb.CBUpdateId = b.CBUpdateId AND b.ETL_IS_ACTIVE = 1            
    ),
    CTE_Subscription AS (
        SELECT cs.*,
            CLS.CreatedBy AS Disbursed_Staff_ID,
            x.UserName AS Disbursed_Staff_Name,            
            Cls.ClientLoanId,
            CLS.ClientLoanCode,            
            CLS.DisbursementDate,
            CLS.LoanAmountDisbursed,
            CLS.ExpectedPaidupDate,
            CLS.Tenure,
            CLS.LOANCANCELLEDDATE
        FROM CTE_Creditberu AS cs
        LEFT JOIN {SRCSCH}.`pragati-clientloansubscription` AS CLS ON cs.LoanProposalID = CLS.LoanProposalID            
        LEFT JOIN {SRCSCH}.`pragatimain-usermaster` x ON CLS.CreatedBy = x.UserId 
        WHERE CLS.ETL_IS_ACTIVE = 1 and x.ETL_IS_ACTIVE = 1
    ),
    --select * from CTE_Subscription
    
   CTE_Refund as ( 

select  distinct f.*,
ca.DownPayment as DownPayment_Ref ,f.ProcessingFeeAmount as ProcessingFeeAmount_Ref,            
ca.OtherFee as OtherFee_Ref,ca.SpouseInsurance as SpouseInsurance_Ref,ca.MemberInsurance as MemberInsurance_Ref,            
ca.CoApplicantInsuranceAmount as CoApplicantInsuranceAmount_Ref,Ca.DeviationBCMStatus as DeviationBCMStatus_DeVi,lr.LoanReturnedAt as LoanReturnedAt_LR,            
lrho.loanReturnedAt as loanReturnedAt_HO,CA.transactionDate as transactionDate_DeVi,            
--Ca.DownPayment as DownPayment_Ref,
--Ca.SpouseInsurance as SpouseInsurance_Ref,Ca.MemberInsurance as MemberInsurance_Ref,            
(case when   coalesce(f.BCMLoanCancelledDate,'')='' then  ca.loancancellationtype else 'BLR' end ) as loancancellationtype,            
case when ca.DeviationBCMStatus='S' then 'Adjustment' when ca.DeviationBCMStatus='A' or lr.LoanReturnedAt ='B' then 'YES' else 'NO'end as FeereturnedconfirmedbyBCM,            
case when ca.DeviationBCMStatus<>'F' and  (lr.LoanReturnedAt='H' or lrho.LoanReturnedAt='H') then 'NEFT' when lr.LoanReturnedAt ='B' then 'Cash'             
when ca.DeviationBCMStatus='F' then 'NEFT Fail Available For Cash Payment In Branch' end as Fee_returned_confirmed,                        
case when coalesce(ca.ProcessingFee,0)>0 then 'LPF updated in SMPT' else 'LPF not updated in SMPT' end as LPF_Return_status,                  
lrho.UTRNO as UTRNO_Ref,
cast(lrho.UTRPaymentDate as date) UTRPaymentDate_Ref ,mb.AlternateMobileNumber as MobileNumber_Virtual,
mb.AlternateMobileNumber as AlternateMobileNumber_Virtual,
'BFIL-MFI' as SOURCE_SYSTEM_ID 
 from  CTE_Subscription as f
Inner join {SRCSCH}.`pragati-cashlessdisbursementsdeviations` ca on f.LoanProposalId=ca.LoanProposalId            
---inner join {SRCSCH}.`pragati-clientloanproposal_h_view` clp on clp.LoanProposalId=ca.LoanProposalId            
inner join {SRCSCH}.`pragati-clientmaster` cm on cm.ClientId=f.ClientId            
left join {SRCSCH}.`pragati-loancancellationandreturnstatus` lr on f.LoanProposalId=lr.LoanProposalId            
left join {SRCSCH}.`pragati-loancancellationandreturnstatusho` lrho on f.LoanProposalId=lrho.LoanProposalId
left join {SRCSCH}.`consumerloan-tbl_virtualmobileno` mb on f.LoanProposalId=mb.LoanProposalId
where ca.ETL_IS_ACTIVE = 1 AND cm.ETL_IS_ACTIVE = 1 AND lr.ETL_IS_ACTIVE = 1 AND mb.ETL_IS_ACTIVE = 1 AND lrho.ETL_IS_ACTIVE = 1
 )
 select * from CTE_Refund
    """
    try:
        source_data_df = spark.sql(query)
        return source_data_df
    except Exception as e:
        # Log the error
        logger(
            logger_level_error,
            f"Error while executing query on loan_collection_fact: {str(e)}",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        # Raise a new exception with a message
        print('completed')
        raise RuntimeError(
            f"Error while executing query on loan_collection_fact: {str(e)}"
        ) from e

# COMMAND ----------

def cdf_facts(TargetTable, Business, stdate, eddate, DBG_FLG, adb_consumption_catlog_schema, pipeline_run_id, SRCSCH,TRGSCH):
    try:
        SKCOL = "CDF_FACTS_SKEY"
        prevSKVal = maxsk(SKCOL, f"{adb_consumption_catlog_schema}.cdf_facts")
        
        #FOR CONSUMPTION LAYER
        ConfigDF, CreateConfig, JoinConfigDF, UniqueKeyValues, list_agg_df, mappingdict, JoinConfigDFValue, renameFields = loadconfig(TargetTable, Business, 1)
        df = get_incremental_dataframe_cdf(stdate, eddate, SRCSCH)
        rowCountDF = df.count() if df else 0
        df = repartitioning_SKID(df)
        df = df.withColumn(SKCOL, lit(col("SKID").cast("int") + prevSKVal))
        df = selectAndRename(df, renameFields)
        MetaColList_updated =["EFFECTIVEFROMDATE", "EFFECTIVETODATE", "CURRENT_FLAG", "ETL_BATCH_ID", "ETL_INSERTED_DATE", "ETL_INSERTED_BY", "ETL_UPDATED_DATE", "ETL_UPDATED_BY"]
        
        withColVar = MetaDataColumns(MetaColList_updated, Business, "", "User")
        df = eval(f"df{withColVar}")

        df.write.format("delta").mode("append").option(
        "mergeSchema", "true"
        ).saveAsTable(f"{TRGSCH}.cdf_facts")

        update_logs(src_object_id,start_timestamp,log_status_success,load_from_date,load_to_date,pipeline_name,pipeline_run_id,pipeline_trigger_name,rowCountDF,rowCountDF,log_error_success,
            "",
            load_type,
            ["cdf_facts"]
        )

    except Exception as e:
        logger(logger_level_error, f"An error occurred in the cdf_facts notebook: {str(e)}", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception("An error occurred in the cdf_facts notebook:", str(e))