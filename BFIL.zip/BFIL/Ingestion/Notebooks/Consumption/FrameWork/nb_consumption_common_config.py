# Databricks notebook source
filename='nb_consumption_common_config.dbc'

# COMMAND ----------

##---------- IMPORTS-------------#

import pytz,inspect,traceback
from pyspark.sql.types import DecimalType
from pyspark.sql.functions import lit,col,max,min,upper, collect_list,struct,from_json,datediff, round,expr,floor,when,hash,crc32,concat ,current_timestamp, concat_ws,monotonically_increasing_id,sha2,to_timestamp,row_number,to_date,from_utc_timestamp,date_format,add_months,ceil,substring,length,coalesce,isnull,trim
from pyspark.sql import Window
from pyspark.sql.types import StructField,StructType,StringType
from datetime import datetime, timedelta
from inspect import currentframe, getframeinfo
from delta.tables import DeltaTable
from pytz import timezone
from pyspark.sql import functions as F



##---------- IMPORTS-------------#

##---------- CONSTANTS-------------#
date_format = "%Y-%m-%dT%H:%M:%SZ"
UKNVAL= "'UKNVALUE'"

Configcolumns = ["Business","DBName","TableName","UniqueKeys","JoinType","JoinID"]
createconfigcols = ["Business","DBName","TableName","UniqueKeys"]
joindfcols = ["TableName","JoinType","JoinID"]

MetaColList =["EFFECTIVEFROMDATE", "EFFECTIVETODATE", "CURRENT_FLAG", "SOURCE_SYSTEM_ID", "ETL_BATCH_ID", "ETL_INSERTED_DATE", "ETL_INSERTED_BY", "ETL_UPDATED_DATE", "ETL_UPDATED_BY"]

##---------- CONSTANTS-------------#


##---------- Common Functions -------------#
def joinStr(m1, m2, col, join):
    return f"{m1}.join({m2}, {col}, \"{join}\")"    

def Unionstr(m1, m2):
    return f"{m1}.union({m2})"

def RenameCols(df, Org=None):
    if Org:
        return df.withColumnRenamed(Org, Org.upper())
    else:
        for val in df.columns:
            df = df.withColumnRenamed(val,val.upper())
    # df.show()
    return df

def upperCaseValue(df, Colname):
    return df.withColumn(Colname, upper(col(Colname)))

def ctequery(ctename, ctestring):
    return f"{ctename} as ({ctestring})"

def ctejoinStr(m1, m2, col, join):
    return f"{m1} {join} join {m2} on {col}"    

def masterdValue(df):
    return "__".join([df.filter(((col("JoinType")=='') & (col("JoinID")=='')) | ((col("JoinType").isNull()) & (col("JoinID").isNull()))).collect()[0][0], "df"])


def isinvalue(df, filtercol,values):
    return df.filter(col(filtercol).isin(values))

def datediff_func(df, col1, col2, newcolName):
	return df.withColumn(newcolName, (datediff(col(col1), col(col2))/365.25).cast("int"))
	
def IFF(df, newcolName, colName, filtercondition, truestatement, falsestatement):
    # return df.withColumn(newcolName,when(col(colName)(eval(filtercondition)), truestatement).otherwise(falsestatement))
    return df.withColumn(newcolName,when(eval(f"col(\"{colName}\"){filtercondition}"), truestatement).otherwise(falsestatement))
	
def dateadd(df,NewCol, dateCol, daystoadd):
	return df.withColumn(NewCol,expr(f"date_add(to_date({dateCol}), {daystoadd})"))

def selectAndRename(df,dictmapping):
    listval = [ f"{column} as {dictmapping[column]}" for column in dictmapping.keys()]
    try:        
        df = df.selectExpr(listval)
    except Exception as e:
        print(df.columns )
        print(listval)
        raise Exception("An error occurred in selectAndRename:", str(e))
    return df


def MetaDataColumns(ColNames, SOURCE_SYSTEM_ID,etl_user_id=None, ETLCHANGEFLAG=None , exec_log_id=None,pipeline_run_id=None ):
    current_timestamp = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')
    userval = spark.sql('select current_user() as user').collect()[0]['user']
    current_timestamp_tmp = to_timestamp(lit(current_timestamp), "yyyy-MM-dd'T'HH:mm:ss'Z'")
    gendict = {
        "ETL_CHANGE_FLAG": f"lit('{ETLCHANGEFLAG}')",
        "ETL_IS_ACTIVE": "lit('1')",
        "ETL_DQ_FINAL_STATUS": "lit('1')",
        "ETL_DQ_ERROR": "lit(None)",
        "ETL_EXEC_LOG_ID": f"lit(str({exec_log_id}))",
        "ETL_CREATED_BY": f'lit("{userval}")',
        "ETL_INSERTED_BY": f'lit("{userval}")',
        "ETL_INSERTED_DATE": f"lit('{current_timestamp}').cast('timestamp')",
        "ETL_INSERTED_DATE": f"lit('{current_timestamp}').cast('timestamp')",
        "ETL_CREATED_DATE": f"lit('{current_timestamp}').cast('timestamp')",
        "ETL_LAST_UPDATED_BY": f'lit("{userval}")',
        "ETL_UPDATED_BY": f'lit("{userval}")',
        "ETL_UPDATED_DATE": f"lit('{current_timestamp}').cast('timestamp')",
        "ETL_LAST_UPDATED_DATE":f"lit('{current_timestamp}').cast('timestamp')",
        "ETL_AUDIT_ID": f"lit(str({pipeline_run_id}))",
        "ETL_EFFECTIVE_FROM_DATE": f"lit('{current_timestamp}').cast('timestamp')",
        "EFFECTIVEFROMDATE": f"lit('{current_timestamp}').cast('timestamp')",
        "ETL_EFFECTIVE_TO_DATE": "lit('9999-12-31T23:59:59Z').cast('timestamp')",
        "EFFECTIVETODATE": "lit('9999-12-31T23:59:59Z').cast('timestamp')",
        "CURRENT_FLAG": "lit(1)",
        "SOURCE_SYSTEM_ID": f"lit('BFIL-{SOURCE_SYSTEM_ID}')",
        "ETL_BATCH_ID": "lit(None)"
    }

    StringList = []
 
    for ColumnName in ColNames:
        StringList.append(str(f".withColumn(\"{ColumnName}\", {gendict[ColumnName]})"))
 
    withColString = "".join(StringList)
    return withColString


def fillwithNone(df):
    for c in df.columns:
        df = df.withColumn(c, when((col(c) == "NULL") | (col(c) == 'Null') | (col(c).isNull()), '').otherwise(col(c)))
    return df


def maxsk(INPCOL,INPTABLE):
    try:
        queryres = spark.sql(f"select max({INPCOL}) from {INPTABLE}").collect()[0][0]
        MaxVal = 0 if queryres == None or queryres == 0 else queryres
    except:
        print("Failed to get SK")
        MaxVal=0
    print("MaxVal", MaxVal)
    return MaxVal

def repartitioning_SKID(df):
    try:
        num_partitions = df.rdd.getNumPartitions()
        num_partitions = 1 if num_partitions==0 else num_partitions
        df = df.repartition(1).withColumn("SKID",row_number().over(Window.orderBy(monotonically_increasing_id())))
        df = df.repartition(num_partitions)
    except Exception as e:
        print("Exception Occured",e)
        print(f"Detailed traceback:\n{traceback.format_exc()}")
        df = None
        raise Exception(f"Exception Occured in framework while repartitioning", str(e))
    return df

def createemptyPysparkDF():

  # Create empty schema
  columns = StructType([])

  # Create an empty RDD with empty schema
  return spark.createDataFrame(data = [],
                              schema = columns)

##---------- Common Functions -------------#



# COMMAND ----------

# DBTITLE 1,Load Config

##---------- CONFIG DF -------------#

def loadconfig(TargetTable,Business,DBG_FLG):
    SBU,result,UniqueKeyValues,mappingdict = "MFI","",[],{}
    jsonschema = StructType([
    StructField("BusinessKey", StringType(), True),
    StructField("UniqueKeys", StringType(), True),
    StructField("JoinType", StringType(), True),
    StructField("JoinID", StringType(), True),
    StructField("UniqueKeysAlias", StringType(), True)    
    ])

    try:
        ConfigDF = fillwithNone(spark.read.format("com.databricks.spark.sqldw").option("url", synapse_jdbc_url).option("dbtable", f"bfil_meta.pl_src_sys_detail").load().distinct()).coalesce(1).cache()
    except:
        print("Exception in loading config")
        pass

    # ConfigDF = testDF
    # ConfigDF.show()
    
    # ConfigDF = ConfigDF.filter((col('src_type') =='datawarehouse') & (col('is_active').cast("string") =="1"))
    ConfigDF = ConfigDF.filter((col('src_type') =='datawarehouse') &  ((col('is_active').cast("string") =="-1") | (col('is_active').cast("string") =="1")))

    if DBG_FLG:
        print("DBG_FLG in config", DBG_FLG,Business,TargetTable)
        # ConfigDF.filter((col("src_name") == Business) & (col("object_source") == TargetTable)).display()
    else:
        print("DBG_FLG in config", DBG_FLG,Business,TargetTable)

    try:
        ConfigDF = ConfigDF.selectExpr("target_object_name as TargetTable","src_name as Business", "object_name as DBName","other_info_01 as TableName","business_key as JsonMapping", "script as JsonMappingRenameCols", "src_type")
        ConfigDF = ConfigDF.withColumn("parsed_json", from_json('JsonMapping', jsonschema)).select("*","parsed_json.*").drop(*["parsed_json","JsonMapping"])

        ConfigDF = ConfigDF.filter((col("Business") == Business) & (col("TargetTable") == TargetTable))
        # ConfigDF.display()
        ConfigDF = upperCaseValue(ConfigDF,"UniqueKeys")

        CreateConfig = ConfigDF.select(createconfigcols)
        JoinConfigDF = ConfigDF.select(joindfcols)

        JoinConfigDF = upperCaseValue(JoinConfigDF, "JoinID")
        masterdval=masterdValue(JoinConfigDF)

        masterdval_replacement = masterdval.replace("__df", "")

        JoinConfigDFValue = JoinConfigDF.filter(
            ((col("TableName") != masterdval_replacement) | ~(((col("JoinType")=='') & (col("JoinID")=='')) | ((col("JoinType").isNull()) & (col("JoinID").isNull()))))).collect()
        
        renameFields = ConfigDF.filter((col("TableName") == masterdval.replace("__df","")) & ( (col("JsonMappingRenameCols").isNotNull()) & (col("JsonMappingRenameCols")!= "") & (col("JsonMappingRenameCols")!= '')  )).select("JsonMappingRenameCols").collect()[0][0]

        renameFields = eval(renameFields)
        
        # upperCaseValue(CreateConfig,"UniqueKeys")
        for unqval in CreateConfig.select("UniqueKeys").distinct().collect():
            UniqueKeyValues.append(unqval[0])

        list_agg_df = ConfigDF.selectExpr("Business","TableName","BusinessKey as OrgField","DBName").collect()

        mappingdict={}

        for datavalue in list_agg_df:
            mappingdict[datavalue[1].upper()+ "," + datavalue[3]]=[]
            tmpdict = {"ORG": datavalue[2]}
            mappingdict[datavalue[1].upper()+ "," + datavalue[3]].append(tmpdict)
            tmpdict = {"RENM": datavalue[2]}
            mappingdict[datavalue[1].upper()+ "," + datavalue[3]].append(tmpdict)

        # ConfigDF = ConfigDF.filter((col("Business") == Business) & (col("TargetTable") == TargetTable))
    except Exception as e:
        print("Config Failed to Load", f"loadconfig({TargetTable},{Business})")
        print(f"Detailed traceback:\n{traceback.format_exc()}")
        raise Exception(f"Config Failed to Load", str(e))
    


    return ConfigDF, CreateConfig,JoinConfigDF,UniqueKeyValues,list_agg_df,mappingdict,JoinConfigDFValue,renameFields
    ##---------- CONFIG DF -------------#

# COMMAND ----------

# DBTITLE 1,SCD type 2 Function new
"""
    This function handles Slowly Changing Dimension (SCD) Type 2 operations.
    Args:
    source_df (DataFrame): The source incremental data.
    table_name (str): The name of full snapshot table.
    Returns:
    str: A message indicating whether the operation was successful.
"""

def handle_scd_type_2(source_df, adb_consumption_catlog_schema, object_name, business_key, updated_by, load_to_date, crcColList, src_type, desti_path, object_source, adb_consumption_dest_url):
    try:
        LoadCount = 0
        source_df_filtered_count=0
        # Update effective_from_date minus 1 day of load_to_date
        new_time = datetime.now(timezone("Asia/Kolkata")).strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=0)
        load_to_date_minus_one_day = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

        print(f"{adb_consumption_catlog_schema}.`{object_name}`")

        adb_curated_catalog = adb_consumption_catlog_schema.split(".")[0]
        table_schema = adb_consumption_catlog_schema.split(".")[1]

        # Construct the Delta table path
        delta_table_path = f"{adb_consumption_dest_url}/{desti_path}"

        # Convert the table to DeltaTable
        delta_table_exists = spark.sql(f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_name}"')

        print(delta_table_exists,f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_name}"')

        # Get all columns except those specified in column_to_exclude_frm_scd
        selected_columns = [col_name for col_name in source_df.columns if col_name not in MetaColList]

        # sha2(concatenated_string_column, 256)
        load_to_date_for_new_data = load_to_date[:11] + "00:00:00Z"
        source_df = source_df.withColumn("ETL_HASH_COL", sha2(concat_ws("",*[col(val) for val in [ elem for elem in sorted(crcColList) if elem not in ["CURRENT_FLAG","EFFECTIVEFROMDATE","EFFECTIVETODATE"] ]]),256).cast('string')).cache()
        source_df.printSchema()

        # if not (delta_table_exists.isEmpty()) :
        #     join_condition = " AND ".join([f"target.{key} = source.{key}" for key in business_key.split(',')]) 

        #     source_df.createOrReplaceTempView("source_df_view")
        #     source_df_Count = source_df.count()
        #     print("source_df Columns", source_df.columns,"source_df Recs for upsert/insert into table", source_df_Count)

        #     # Enable automatic schema evolution
        #     spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

        #     output_df = spark.sql(f"""MERGE INTO {adb_consumption_catlog_schema}.`{object_name}` AS target
        #                             USING (with source_data as (select * from source_df_view) 
        #                             select * from source_data) source
        #                             ON {join_condition}
        #                             WHEN MATCHED and target.ETL_HASH_COL <> source.ETL_HASH_COL and target.CURRENT_FLAG == '1' THEN
        #                             UPDATE SET
        #                                 target.ETL_UPDATED_BY = '{updated_by}'    
        #                                 ,target.ETL_UPDATED_DATE = source.ETL_INSERTED_DATE 
        #                                 ,target.CURRENT_FLAG = '0'
        #                                 ,target.EFFECTIVETODATE = '{load_to_date_minus_one_day}'
        #                                 WHEN NOT MATCHED THEN
        #                                 INSERT *
        #                             """)
        #     # Reading existing delta table data to insert new data of updates
        #     delta_table = DeltaTable.convertToDelta(spark, f"{adb_consumption_catlog_schema}.{object_name}").toDF().select("ETL_HASH_COL")
           
        #     # Perform a left anti-join to filter out records from source_df present in delta_table
        #     source_df_filtered = source_df.alias("updates").join(
        #         delta_table.alias("existing"),
        #         (col("updates.ETL_HASH_COL") == col("existing.ETL_HASH_COL")) ,
        #         "left_anti"
        #     )

        #     source_df_filtered_count = source_df_filtered.count()
        #     print("Delta table count", delta_table.count(), "New inserts count", source_df_filtered_count)

        #     # Insert new historical data only
        #     source_df_filtered.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{adb_consumption_catlog_schema}.{object_name}")
           
        #     print(f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}")
        #     logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
        #     return source_df_Count + source_df_filtered_count
        if not (delta_table_exists.isEmpty()) :
            # join_condition = " AND ".join([f"source.{key} = target.{key} " for key in business_key.split(',')]) 
            join_condition = " AND ".join([f"source.merge_key_{index} = target.{key} " for index, key in enumerate(business_key.split(','))]) 
            innerjoin_condition = " AND ".join([f"raw_inner.{key} = d.{key}" for key in business_key.split(',')]) 
            mergekey_values = " , ".join([f"{key} as merge_key_{index}" for index, key in enumerate(business_key.split(','))])
            nulljoinkey = " , ".join([f"null as merge_key_{index}" for index, key in enumerate(business_key.split(','))])

            print("join_condition", join_condition)

            source_df.createOrReplaceTempView("source_df_view")
            source_df_Count = source_df.count()
           
            print("source_df Columns", source_df.columns,"source_df Recs for upsert/insert into table", source_df_Count)

            # Enable automatic schema evolution
            spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

            dataloadquery = f"""
                        MERGE INTO {adb_consumption_catlog_schema}.`{object_name}` target
                        USING
                            (with raw_data
                                AS(select * from source_df_view)
                                select {mergekey_values}, *
                                FROM raw_data
                                union all select {nulljoinkey},raw_inner.*
                                FROM raw_data raw_inner
                                join {adb_consumption_catlog_schema}.`{object_name}` d
                                    on {innerjoin_condition}
                                    AND d.CURRENT_FLAG = '1'
                                    AND raw_inner.ETL_HASH_COL<> d.ETL_HASH_COL
                                ) source
                                ON {join_condition}
                                WHEN MATCHED AND target.CURRENT_FLAG = '1' AND source.ETL_HASH_COL<>target.ETL_HASH_COL
                       
                                THEN UPDATE SET
                                        target.ETL_UPDATED_BY = '{updated_by}'    
                                        ,target.ETL_UPDATED_DATE = source.ETL_INSERTED_DATE 
                                        ,target.CURRENT_FLAG = '0'
                                        ,target.EFFECTIVETODATE = '{load_to_date_minus_one_day}'
                                WHEN NOT MATCHED THEN INSERT ({",".join([f"{key}" for index, key in enumerate(source_df.columns)])}) VALUES ({",".join([f"source.{key}" for index, key in enumerate(source_df.columns)])}) 
       
                                
                                 """
            print(dataloadquery)
            output_df = spark.sql(dataloadquery)
            # output_df = spark.sql("select ")
            
           
            print(f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}")
            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
            return source_df_Count + source_df_filtered_count
        else:
            # If Delta table does not exist, create a new Delta table and write the source data
            print("source_df Columns", source_df.columns,"source_df Recs for upsert/insert into table", source_df.count())

            source_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{adb_consumption_catlog_schema}.{object_name}")
            # .option("path", delta_table_path)
            
            print(f"In SCD Type 2, the curated delta table has been successfully loaded for {adb_consumption_catlog_schema}.{object_name}")
            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully loaded for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
            return source_df.count()
    except Exception as e:
        logger(logger_level_error, f"An error occurred in the handle_scd-2 function of nb_consumption_common_config  notebook: {str(e)}", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        # Handle the exception or display the error message as needed
        raise Exception("An error occurred in the handle_scd-2 function of nb_consumption_common_config  notebook:", str(e))
        return LoadCount

# COMMAND ----------

# DBTITLE 1,SCD type 2 Function old
# """
#     This function handles Slowly Changing Dimension (SCD) Type 2 operations.
#     Args:
#     source_df (DataFrame): The source incremental data.
#     table_name (str): The name of full snapshot table.
#     Returns:
#     str: A message indicating whether the operation was successful.
# """

# def handle_scd_type_2(source_df, adb_consumption_catlog_schema, object_name, business_key, updated_by, load_to_date, crcColList, src_type, desti_path, object_source, adb_consumption_dest_url):
#     try:
#         LoadCount = 0
#         source_df_filtered_count=0
#         # Update effective_from_date minus 1 day of load_to_date
#         new_time = datetime.now(timezone("Asia/Kolkata")).strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=0)
#         load_to_date_minus_one_day = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

#         print(f"{adb_consumption_catlog_schema}.`{object_name}`")

#         adb_curated_catalog = adb_consumption_catlog_schema.split(".")[0]
#         table_schema = adb_consumption_catlog_schema.split(".")[1]

#         # Construct the Delta table path
#         delta_table_path = f"{adb_consumption_dest_url}/{desti_path}"

#         # Convert the table to DeltaTable
#         delta_table_exists = spark.sql(f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_name}"')

#         print(delta_table_exists,f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_name}"')

#         # Get all columns except those specified in column_to_exclude_frm_scd
#         selected_columns = [col_name for col_name in source_df.columns if col_name not in MetaColList]

#         # sha2(concatenated_string_column, 256)
#         load_to_date_for_new_data = load_to_date[:11] + "00:00:00Z"
#         source_df = source_df.withColumn("ETL_HASH_COL", sha2(concat_ws("",*[col(val) for val in [ elem for elem in crcColList if elem not in ["CURRENT_FLAG","EFFECTIVEFROMDATE","EFFECTIVETODATE"] ]]),256).cast('string')).cache()

#         # if not (delta_table_exists.isEmpty()) :
#         #     join_condition = " AND ".join([f"target.{key} = source.{key}" for key in business_key.split(',')]) 

#         #     source_df.createOrReplaceTempView("source_df_view")
#         #     source_df_Count = source_df.count()
#         #     print("source_df Columns", source_df.columns,"source_df Recs for upsert/insert into table", source_df_Count)

#         #     # Enable automatic schema evolution
#         #     spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

#         #     output_df = spark.sql(f"""MERGE INTO {adb_consumption_catlog_schema}.`{object_name}` AS target
#         #                             USING (with source_data as (select * from source_df_view) 
#         #                             select * from source_data) source
#         #                             ON {join_condition}
#         #                             WHEN MATCHED and target.ETL_HASH_COL <> source.ETL_HASH_COL and target.CURRENT_FLAG == '1' THEN
#         #                             UPDATE SET
#         #                                 target.ETL_UPDATED_BY = '{updated_by}'    
#         #                                 ,target.ETL_UPDATED_DATE = source.ETL_INSERTED_DATE 
#         #                                 ,target.CURRENT_FLAG = '0'
#         #                                 ,target.EFFECTIVETODATE = '{load_to_date_minus_one_day}'
#         #                                 WHEN NOT MATCHED THEN
#         #                                 INSERT *
#         #                             """)
#         #     # Reading existing delta table data to insert new data of updates
#         #     delta_table = DeltaTable.convertToDelta(spark, f"{adb_consumption_catlog_schema}.{object_name}").toDF().select("ETL_HASH_COL")
           
#         #     # Perform a left anti-join to filter out records from source_df present in delta_table
#         #     source_df_filtered = source_df.alias("updates").join(
#         #         delta_table.alias("existing"),
#         #         (col("updates.ETL_HASH_COL") == col("existing.ETL_HASH_COL")) ,
#         #         "left_anti"
#         #     )

#         #     source_df_filtered_count = source_df_filtered.count()
#         #     print("Delta table count", delta_table.count(), "New inserts count", source_df_filtered_count)

#         #     # Insert new historical data only
#         #     source_df_filtered.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{adb_consumption_catlog_schema}.{object_name}")
           
#         #     print(f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}")
#         #     logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
#         #     return source_df_Count + source_df_filtered_count
#         if not (delta_table_exists.isEmpty()) :
#             # join_condition = " AND ".join([f"source.{key} = target.{key} " for key in business_key.split(',')]) 
#             join_condition = " AND ".join([f"source.merge_key_{index} = target.{key} " for index, key in enumerate(business_key.split(','))]) 
#             innerjoin_condition = " AND ".join([f"raw_inner.{key} = d.{key}" for key in business_key.split(',')]) 
#             mergekey_values = " , ".join([f"{key} as merge_key_{index}" for index, key in enumerate(business_key.split(','))])
#             nulljoinkey = " , ".join([f"null as merge_key_{index}" for index, key in enumerate(business_key.split(','))])

#             print("join_condition", join_condition)

#             source_df.createOrReplaceTempView("source_df_view")
#             source_df_Count = source_df.count()
#             print("source_df Columns", source_df.columns,"source_df Recs for upsert/insert into table", source_df_Count)

#             # Enable automatic schema evolution
#             spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

#             dataloadquery = f"""
#                         MERGE INTO {adb_consumption_catlog_schema}.`{object_name}` target
#                         USING
#                             (with raw_data
#                                 AS(select * from source_df_view)
#                                 select {mergekey_values}, *
#                                 FROM raw_data
#                                 union all select {nulljoinkey},raw_inner.*
#                                 FROM raw_data raw_inner
#                                 join {adb_consumption_catlog_schema}.`{object_name}` d
#                                     on {innerjoin_condition}
#                                     AND raw_inner.ETL_HASH_COL<>d.ETL_HASH_COL
#                                 ) source
#                                 ON {join_condition}
#                                 WHEN MATCHED AND source.ETL_HASH_COL<>target.ETL_HASH_COL
#                                 THEN UPDATE SET
#                                         target.ETL_UPDATED_BY = '{updated_by}'    
#                                         ,target.ETL_UPDATED_DATE = source.ETL_INSERTED_DATE 
#                                         ,target.CURRENT_FLAG = '0'
#                                         ,target.EFFECTIVETODATE = '{load_to_date_minus_one_day}'
#                                 WHEN NOT MATCHED THEN INSERT ({",".join([f"{key}" for index, key in enumerate(source_df.columns)])}) VALUES ({",".join([f"source.{key}" for index, key in enumerate(source_df.columns)])})  """
#             print(dataloadquery)
#             output_df = spark.sql(dataloadquery)
            
           
#             print(f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}")
#             logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
#             return source_df_Count + source_df_filtered_count
#         else:
#             # If Delta table does not exist, create a new Delta table and write the source data
#             print("source_df Columns", source_df.columns,"source_df Recs for upsert/insert into table", source_df.count())

#             source_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{adb_consumption_catlog_schema}.{object_name}")
#             # .option("path", delta_table_path)
            
#             print(f"In SCD Type 2, the curated delta table has been successfully loaded for {adb_consumption_catlog_schema}.{object_name}")
#             logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully loaded for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
#             return source_df.count()
#     except Exception as e:
#         logger(logger_level_error, f"An error occurred in the handle_scd-2 function of nb_consumption_common_config  notebook: {str(e)}", execution_log_list, filename)
#         print(*execution_log_list,sep='\n')
#         # Handle the exception or display the error message as needed
#         raise Exception("An error occurred in the handle_scd-2 function of nb_consumption_common_config  notebook:", str(e))
#         return LoadCount

# COMMAND ----------

# DBTITLE 1,SCD type 2 Fact Function
"""
    This function handles Slowly Changing Dimension (SCD) Type 2 operations.
    Args:
    source_df (DataFrame): The source incremental data.
    table_name (str): The name of full snapshot table.
    Returns:
    str: A message indicating whether the operation was successful.
"""

def handle_scd_type_2_fact(source_df, adb_consumption_catlog_schema, object_name, business_key, updated_by, load_to_date, crcColList, src_type, desti_path, object_source, adb_consumption_dest_url):
    try:
        LoadCount = 0
        source_df_filtered_count=0
        # Update effective_from_date minus 1 day of load_to_date
        new_time = datetime.now(timezone("Asia/Kolkata")).strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=0)
        load_to_date_minus_one_day = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

        print(f"{adb_consumption_catlog_schema}.`{object_name}`")

        adb_curated_catalog = adb_consumption_catlog_schema.split(".")[0]
        table_schema = adb_consumption_catlog_schema.split(".")[1]

        # Construct the Delta table path
        delta_table_path = f"{adb_consumption_dest_url}/{desti_path}"

        # Convert the table to DeltaTable
        delta_table_exists = spark.sql(f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_name}"')

        print(delta_table_exists,f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_name}"')

        # Get all columns except those specified in column_to_exclude_frm_scd
        selected_columns = [col_name for col_name in source_df.columns if col_name not in MetaColList]

        # sha2(concatenated_string_column, 256)
        load_to_date_for_new_data = load_to_date[:11] + "00:00:00Z"

        # source_df = source_df.withColumn("ETL_HASH_COL", sha2(concat_ws("",*[col(val) for val in [ elem for elem in crcColList if elem not in ["CURRENT_FLAG","EFFECTIVEFROMDATE","EFFECTIVETODATE"] ]]),256).cast('string')).cache()

        source_df = source_df.withColumn("ETL_HASH_COL", sha2(concat_ws("",*[col(val) for val in [ elem for elem in sorted(crcColList) if elem not in ["CURRENT_FLAG","EFFECTIVEFROMDATE","EFFECTIVETODATE"] ]]),256).cast('string')).cache()
        source_df.printSchema()

        if not (delta_table_exists.isEmpty()) :
            # join_condition = " AND ".join([f"source.{key} = target.{key} " for key in business_key.split(',')]) 
            join_condition = " AND ".join([f"source.merge_key_{index} = target.{key} " for index, key in enumerate(business_key.split(','))]) 
            innerjoin_condition = " AND ".join([f"raw_inner.{key} = d.{key}" for key in business_key.split(',')]) 
            mergekey_values = " , ".join([f"{key} as merge_key_{index}" for index, key in enumerate(business_key.split(','))])
            nulljoinkey = " , ".join([f"null as merge_key_{index}" for index, key in enumerate(business_key.split(','))])

            print("join_condition", join_condition)

            source_df.createOrReplaceTempView("source_df_view")
            # Enable automatic schema evolution
            spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

            dataloadquery = f"""
                        MERGE INTO {adb_consumption_catlog_schema}.`{object_name}` target
                        USING
                            (with raw_data
                                AS(select * from source_df_view)
                                select {mergekey_values}, *
                                FROM raw_data
                                union all select {nulljoinkey},raw_inner.*
                                FROM raw_data raw_inner
                                join {adb_consumption_catlog_schema}.`{object_name}` d
                                    on {innerjoin_condition}
                                    AND d.CURRENT_FLAG = '1'
                                    AND raw_inner.ETL_HASH_COL<>d.ETL_HASH_COL
                                ) source
                                ON {join_condition}
                                WHEN MATCHED AND target.CURRENT_FLAG = '1' AND source.ETL_HASH_COL<>target.ETL_HASH_COL
                                THEN UPDATE SET
                                        target.ETL_UPDATED_BY = '{updated_by}'    
                                        ,target.ETL_UPDATED_DATE = source.ETL_INSERTED_DATE 
                                        ,target.CURRENT_FLAG = '0'
                                        ,target.EFFECTIVETODATE = '{load_to_date_minus_one_day}'
                                WHEN NOT MATCHED THEN INSERT ({",".join([f"{key}" for index, key in enumerate(source_df.columns)])}) VALUES ({",".join([f"source.{key}" for index, key in enumerate(source_df.columns)])})  """
            print(dataloadquery)
            output_df = spark.sql(dataloadquery)
            merge_metrics = output_df.select("num_updated_rows", "num_inserted_rows", "num_deleted_rows").collect()[0]
            num_inserted_rows = merge_metrics["num_inserted_rows"]
           
            print(f"In SCD Type 2 Fact, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}")
            logger(logger_level_info, f"In SCD Type 2 Fact, the curated delta table has been successfully upserted for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
            return num_inserted_rows
        else:
            source_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{adb_consumption_catlog_schema}.{object_name}")
            # .option("path", delta_table_path)
            
            print(f"In SCD Type 2 Fact, the curated delta table has been successfully loaded for {adb_consumption_catlog_schema}.{object_name}")
            logger(logger_level_info, f"In SCD Type 2 Fact, the curated delta table has been successfully loaded for {adb_consumption_catlog_schema}.{object_name}", execution_log_list, filename)
            num_append_record = spark.sql(f"SELECT COUNT(*) FROM {adb_consumption_catlog_schema}.`{object_name}`")
            return num_append_record
    except Exception as e:
        logger(logger_level_error, f"An error occurred in the handle_scd-2 fact function of nb_consumption_common_config  notebook: {str(e)}", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        # Handle the exception or display the error message as needed
        raise Exception("An error occurred in the handle_scd-2 fact function of nb_consumption_common_config  notebook:", str(e))
        return LoadCount