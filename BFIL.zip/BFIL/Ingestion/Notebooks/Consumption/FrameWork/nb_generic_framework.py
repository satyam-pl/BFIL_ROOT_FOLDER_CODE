# Databricks notebook source
# DBTITLE 1,FrameWork
def FrameWork(TargetTable,BusinessTable,Start_date,End_date,DBG_FLG):
    print(f"Running {TargetTable} for dates {Start_date} to {End_date}")

    cte,cte_list,vallist,df_list=[],[],[],[]
    debugList=[]
    try:
        ConfigDF, CreateConfig,JoinConfigDF,UniqueKeyValues,list_agg_df,mappingdict,JoinConfigDFValue,renameFields = loadconfig(TargetTable,BusinessTable,DBG_FLG)
        print()
        logger(logger_level_info, f"Start_date and End_date of TargetTable {Start_date},{End_date}", execution_log_list, filename)
    except Exception as e:
        print("Framework Config Failed to Load", f"loadconfig({TargetTable},{BusinessTable})")
        raise Exception(f"Framework Config Failed to Load", str(e))
        
    # ConfigDF.show()
    print("UniqueKeyValues", UniqueKeyValues)

    dfCounts=[]
    # Create DataFrame from the Delta table schema
    for unqvalue in UniqueKeyValues:
        uniqueValdf,dfvalueList_Com,dfvalueList,unionstrval= [] ,[] ,[],""

        # collect values per primary key for filter in future
        try:
            uniquePKColumns = ConfigDF.filter((col("UniqueKeys") == unqvalue) ).select(["Business","DBName","TableName","UniqueKeys","UniqueKeysAlias"]).collect()

        except Exception as e:
            print("Exception Occured",e)
            print(f"Detailed traceback:\n{traceback.format_exc()}")
            logger(logger_level_info, f"Detailed traceback:\n{traceback.format_exc()}", execution_log_list, filename)
            df = None
            renameFields = None
            dfCount = None
            raise Exception(f"Exception Occured in uniquePKColumns", str(e))

        # Get data from delta table (Future pick from ADLS) into spark df to generate unique PK Values
        
        for value in uniquePKColumns:
            dfname = "_".join([value["TableName"], "df"])
            
            try:
                exec(dfname+f'= spark.sql("select {value["UniqueKeysAlias"]} from {SRCSCH}.`{value["DBName"]}-{value["TableName"]}` where ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'\")')
                dfvalueList.append(dfname)
            except:
                print("FAIED ------ at unqkeys",f'= spark.sql("select {value["UniqueKeysAlias"]} from {SRCSCH}.`{value["DBName"]}-{value["TableName"]}` where ETL_LAST_UPDATED_DATE >= \'{Start_date}\' and ETL_LAST_UPDATED_DATE <= \'{End_date}\'\")')
                pass

        if dfvalueList:
            try:
                # Union all unique pk values df for collecting distinct values
                for val in dfvalueList[1:]:
                    unionstrval = Unionstr(unionstrval, val)

                unqval_df = eval(f'{dfvalueList[0]}' + unionstrval).distinct()
                unqval_df_Count = unqval_df.count()
            except Exception as e:
                print("Exception Occured",e)
                print(f"Detailed traceback:\n{traceback.format_exc()}")
                logger(logger_level_info, f"Detailed traceback:\n{traceback.format_exc()}", execution_log_list, filename)
                df = None
                renameFields = None
                dfCount = None
                raise Exception(f"Exception Occured in Union of dataframes", str(e))

            print("No of Unique Key for",unqvalue, "key are", unqval_df.count())

        else:
            unqval_df_Count=0
            pass


        for value in uniquePKColumns:
            DB_NAME = value["DBName"]
            TABLE_NAME = value["TableName"]
            dfname = "__".join([TABLE_NAME, "df"])
            mapgetvalue = TABLE_NAME.upper() + ","+ DB_NAME

            try:                    
                exec(dfname+f"= spark.sql(\"select {mappingdict.get(mapgetvalue)[0]['ORG']} from {SRCSCH}.`{DB_NAME}-{TABLE_NAME}` where ETL_IS_ACTIVE = 1\") ")
                print("SUCCESS", f"select {mappingdict.get(mapgetvalue)[0]['ORG']} from {SRCSCH}.`{DB_NAME}-{TABLE_NAME}` where ETL_IS_ACTIVE = 1")
            except Exception as e1:
                print("FAILED at getting table", f"select {mappingdict.get(mapgetvalue)[0]['ORG']} from {SRCSCH}.`{DB_NAME}-{TABLE_NAME}` where ETL_IS_ACTIVE = 1")
                logger(logger_level_info, f"Exception Occured while reading {dfname} from delta source { str(e1)}", execution_log_list, filename)
                continue
                # raise Exception(f"Exception Occured while reading {dfname} from delta source", str(e1))

            exec(dfname+ f"= RenameCols({dfname})") 
            unqval_df = RenameCols(unqval_df)
            print("unqval_df_Count", unqval_df_Count)

            if unqval_df_Count>0:
                unqval_df = unqval_df
            else:
                unqval_df = createemptyPysparkDF()
                unqval_df = unqval_df.withColumn(unqvalue, lit(None))
            try:
                print("Count of table taken forward prior join", eval(dfname).count())
                exec(dfname+f"= {dfname}.join(unqval_df, unqval_df.{unqvalue.upper()} == {dfname}.{unqvalue.upper()}, \"inner\").select({dfname}[\"*\"])")
                print("Count of table taken forward", eval(dfname).count())
            except Exception as e2:
                print(f"= {dfname}.join(unqval_df, unqval_df.{unqvalue.upper()} == {dfname}.{unqvalue.upper()}, \"inner\").select({dfname}[\"*\"])")
                print("unqval_df Columns", unqval_df.columns)
                print(f"{dfname} Columns", eval(dfname).columns)
                logger(logger_level_info, f"Exception Occured while filtering source dataframes against selected values { str(e2)}", execution_log_list, filename)
                raise Exception(f"Exception Occured while filtering source dataframes against selected values", str(e2))

            df_list.append(dfname)
    
    try:
        masterdf = masterdValue(JoinConfigDF)
        basetablecount = eval(masterdf.replace("__","_")).count()
    except Exception as e:
        basetablecount=0
        print(f"Exception Occured whilelooking for base df { str(e)}")
        logger(logger_level_info, f"Exception Occured whilelooking for base df { str(e)}", execution_log_list, filename)
        #raise Exception(f"Exception Occured whilelooking for base df", str(e))

    if basetablecount:
        print("JoinConfigDFValue",JoinConfigDFValue)
        print("df_list", [E2.replace('__df', '') for E2 in [E1 for E1 in df_list if E1 != masterdf]])

        # for val in df_list:
        #     print(val, eval(val).count())
        try:
            JoinStrValue = ""
            for val in JoinConfigDFValue:
                if val['TableName'] in [E2.replace('__df', '') for E2 in [E1 for E1 in df_list if E1 != masterdf]]:
                    JoinStrValue = joinStr(JoinStrValue,"__".join([val['TableName'], "df"]),f"['{val['JoinID']}']",val['JoinType'])
            print(masterdf+JoinStrValue)
            df = eval(masterdf+JoinStrValue)
            df = repartitioning_SKID(df)
            dfCount = df.count()
            # print("dfCount initail", dfCount, df.count())

        except Exception as e:
            print("Exception Occured",e)
            print(f"Detailed traceback:\n{traceback.format_exc()}")
            df = None
            renameFields = None
            dfCount = None
            logger(logger_level_info, f"Exception Occured in framework while join { str(e)}", execution_log_list, filename)
            raise Exception(f"Exception Occured in framework while join", str(e))
    else:
        df = createemptyPysparkDF()
        renameFields = None
        dfCount = basetablecount
        print(f"Exception in base table {masterdf} as count is {basetablecount}")
        logger(logger_level_info, f"Exception in base table {masterdf} as count is {basetablecount}", execution_log_list, filename)
        #raise Exception(f"Exception in base table {masterdf} as count is {basetablecount}")

    
    



    # print("dfCount before return", dfCount, df.count())
    return df,renameFields, dfCount

