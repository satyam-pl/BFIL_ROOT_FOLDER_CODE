# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

curated_schema = dbutils.widgets.get("curated_schema")

# COMMAND ----------

df = spark.sql(f"""select case when split(Curated_Table_Name,'-')[0] = 'pragati' then 'pragati_s1' else split(Curated_Table_Name,'-')[0] end as object_source,split(Curated_Table_Name,'-')[1] as object_name,max(PK_Column_Name) as PK_Column_Name,array_join(collect_set(PK_Value), ',') as PK_Values, cast(cast(max(CreatedDateTime) as Date) as varchar(20)) as load_to_date, cast(date_add(cast(max(CreatedDateTime) as Date),-1) as VarChar(20)) as load_from_date from {curated_schema}.`azuresource-p_backdated_deletedrecords` where Status = 'Pending' group by Curated_Table_Name""")

# COMMAND ----------

try:
    df = df.toPandas()
    # Convert Pandas DataFrame to JSON
    df_json = df.to_json(orient="records")    
    # Convert JSON string to a dictionary
    df_dict = json.loads(df_json)
    dbutils.notebook.exit({"output_to_adf": df_dict})
except Exception as e:
    print(f"An error occurred while converting deletion records into json: {str(e)}")