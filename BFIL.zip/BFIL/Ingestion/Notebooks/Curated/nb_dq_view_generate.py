# Databricks notebook source
# MAGIC %md
# MAGIC Data Source Verification:
# MAGIC
# MAGIC Ensure that the data is being correctly fetched from the following tables:
# MAGIC edp_datasharing_dev.bfil.dq_detailed_report
# MAGIC edp_datasharing_dev.bfil.pl_exec_log
# MAGIC edp_datasharing_dev.bfil.pl_src_sys_detail
# MAGIC edp_datasharing_dev.bfil.dq_summary
# MAGIC Verify that all necessary data sources are accessible and contain the expected data formats and columns.
# MAGIC Data Transformation Steps:
# MAGIC
# MAGIC Step 1: dq_counts CTE (Common Table Expression)
# MAGIC
# MAGIC Action: Count the number of failed records for each Data Quality (DQ) rule, grouped by DQ name, source system, table name, column name, generation date, error code, and ETL audit ID.
# MAGIC Verification:
# MAGIC Check that the DQ_NAME, SOURCE_SYSTEM, TABLE_NAME, and COLUMN_NAME columns are converted to uppercase.
# MAGIC Verify the DQ_GENERATION_DATE is cast to date type.
# MAGIC Ensure Failed_Records count is correctly calculated.
# MAGIC
# MAGIC Step 2: total_records CTE
# MAGIC
# MAGIC Action: Retrieve the total number of records processed for each table where the status is 'SUCCESS' and the layer name is 'CURATED'.
# MAGIC Verification:
# MAGIC Verify the distinct table names and corresponding total records are correctly fetched.
# MAGIC Ensure the join conditions between pl_exec_log, pl_src_sys_detail, and dq_detailed_report are accurate and only successful executions are considered.
# MAGIC
# MAGIC Step 3: failed_records CTE
# MAGIC
# MAGIC Action: Aggregate the failed records and total records for each combination of DQ name, source system, table name, column name, generation date, error code, and ETL audit ID.
# MAGIC Verification:
# MAGIC Confirm that the sum of Failed_Records is correctly calculated.
# MAGIC Ensure that the Total_Records is accurately fetched using the ANY_VALUE function.
# MAGIC
# MAGIC Step 4: flag_mapping CTE
# MAGIC
# MAGIC Action: Map each DQ rule to various data quality flags by joining with the dq_summary table on the error code.
# MAGIC Verification:
# MAGIC Verify the correctness of the join between failed_records and dq_summary.
# MAGIC Ensure the calculated Passed_Records (difference between Total_Records and Failed_Records) is accurate.
# MAGIC Check the mapping of the flags (Accuracy_FLAG, Completeness_FLAG, etc.) from dq_summary.
# MAGIC Final Select:
# MAGIC
# MAGIC Action: Select all columns from flag_mapping and order the results by DQ_NAME.
# MAGIC Verification:
# MAGIC Ensure the final dataset contains all the required columns and is ordered by DQ_NAME.
# MAGIC Performance Testing:
# MAGIC
# MAGIC Ensure the query performance is optimized with appropriate partitioning and caching.
# MAGIC Action: The resulting dataframe is repartitioned into 50 partitions and cached for performance.
# MAGIC Verification:
# MAGIC Check if the repartitioning is effective in distributing the data evenly.
# MAGIC Validate that the caching improves query performance on subsequent actions.
# MAGIC Data Quality Verification:
# MAGIC
# MAGIC Ensure that the data in the final dataframe adheres to the expected quality rules.
# MAGIC
# MAGIC Verify the accuracy, completeness, conformity, consistency, integrity, timeliness, and uniqueness flags as per the dq_summary mappings.
# MAGIC
# MAGIC Accuracy_FLAG:
# MAGIC
# MAGIC Meaning: This flag indicates whether the data values are correct and free from errors. Accurate data correctly represents the real-world entities it is intended to model.
# MAGIC Example: If a customer’s address is correctly recorded, the Accuracy_FLAG would be set to indicate high accuracy.
# MAGIC
# MAGIC Completeness_FLAG:
# MAGIC
# MAGIC Meaning: This flag assesses whether all required data is present. Completeness means that there are no missing values or records.
# MAGIC Example: If all mandatory fields in a dataset are filled out, the Completeness_FLAG would indicate completeness.
# MAGIC
# MAGIC Conformity_FLAG:
# MAGIC
# MAGIC Meaning: This flag checks if the data adheres to the specified format, standards, or syntax rules. Conformity ensures that data follows the defined rules and constraints.
# MAGIC Example: If a phone number is in the correct format (e.g., (123) 456-7890), the Conformity_FLAG would indicate conformity.
# MAGIC
# MAGIC Consistency_FLAG:
# MAGIC
# MAGIC Meaning: This flag indicates whether the data is consistent across different data sets and over time. Consistency means there are no contradictions in the data.
# MAGIC Example: If a customer’s birthdate is consistently recorded across multiple systems, the Consistency_FLAG would show consistency.
# MAGIC
# MAGIC Integrity_FLAG:
# MAGIC
# MAGIC Meaning: This flag assesses the data’s referential integrity, ensuring relationships between data elements are accurate and intact. Integrity ensures that data dependencies and relationships are maintained.
# MAGIC Example: If all foreign keys in a database correctly point to existing primary keys, the Integrity_FLAG would indicate data integrity.
# MAGIC
# MAGIC Timeliness_FLAG:
# MAGIC
# MAGIC Meaning: This flag measures whether the data is up-to-date and available when needed. Timeliness ensures that data is current and delivered within the required timeframe.
# MAGIC Example: If the data is updated daily as required, the Timeliness_FLAG would reflect timeliness.
# MAGIC
# MAGIC Uniqueness_FLAG:
# MAGIC
# MAGIC Meaning: This flag checks if there are any duplicate records in the dataset. Uniqueness ensures that each record is distinct and there are no repetitions.
# MAGIC Example: If each customer record is unique and there are no duplicates, the Uniqueness_FLAG would indicate uniqueness.

# COMMAND ----------

# DBTITLE 1,DQ View Creation
# dq_view_df = (
#     spark.sql(
#         """
# WITH deduplicated_dq_report AS (
#   SELECT
#     dq.DQ_NAME,
#     dq.SOURCE_SYSTEM,
#     dq.TABLE_NAME,
#     dq.DQ_COLUMN_NAME,
#     dq.PRIMARY_KEY,
#     dq.PRIMARY_KEY_VALUE,
#     dq.INVALID_VALUE,
#     dq.ETL_CHANGE_FLAG,
#     dq.ERROR_MESSAGE,
#     dq.AS_ON_DATE,
#     dq.ERROR_CODE,
#     dq.ETL_AUDIT_ID,
#     CAST(MAX(dq.DQ_GENERATION_DATE) AS DATE) AS DQ_GENERATION_DATE
#   FROM
#     edp_datasharing_prod.bfil.dq_detailed_report dq
#   GROUP BY
#     dq.DQ_NAME,
#     dq.SOURCE_SYSTEM,
#     dq.TABLE_NAME,
#     dq.DQ_COLUMN_NAME,
#     dq.PRIMARY_KEY,
#     dq.PRIMARY_KEY_VALUE,
#     dq.INVALID_VALUE,
#     dq.ETL_CHANGE_FLAG,
#     dq.ERROR_MESSAGE,
#     dq.AS_ON_DATE,
#     dq.ERROR_CODE,
#     dq.ETL_AUDIT_ID
# ),
# dq_counts AS (
#   SELECT
#     UPPER(dq.DQ_NAME) AS DQ_NAME,
#     UPPER(dq.SOURCE_SYSTEM) AS SOURCE_SYSTEM,
#     UPPER(dq.TABLE_NAME) AS TABLE_NAME,
#     UPPER(dq.DQ_COLUMN_NAME) AS COLUMN_NAME,
#     dq.DQ_GENERATION_DATE,
#     dq.ERROR_CODE,
#     dq.ETL_AUDIT_ID,
#     COUNT(*) AS Failed_Records
#   FROM
#     deduplicated_dq_report dq
#   GROUP BY
#     UPPER(dq.DQ_NAME),
#     UPPER(dq.SOURCE_SYSTEM),
#     UPPER(dq.TABLE_NAME),
#     UPPER(dq.DQ_COLUMN_NAME),
#     dq.DQ_GENERATION_DATE,
#     dq.ERROR_CODE,
#     dq.ETL_AUDIT_ID
# ),
# total_records_with_row_num AS (
#   SELECT
#     UPPER(detail.object_name) AS TABLE_NAME,
#     exec_log.source_row_count AS Total_Records,
#     exec_log.pipeline_runid,
#     CASE
#       WHEN UPPER(detail.object_source) LIKE 'PRAGATI_S%' THEN 'PRAGATI'
#       ELSE UPPER(detail.object_source)
#     END AS SOURCE_SYSTEM,
#     ROW_NUMBER() OVER (PARTITION BY UPPER(detail.object_name), exec_log.pipeline_runid ORDER BY exec_log.pipeline_runid) AS row_num
#   FROM
#     edp_synapse_prod.bfil_meta.pl_exec_log exec_log
#     JOIN edp_synapse_prod.bfil_meta.pl_src_sys_detail detail ON exec_log.src_object_id = detail.src_object_id
#     JOIN deduplicated_dq_report dq_report ON exec_log.pipeline_runid = dq_report.ETL_AUDIT_ID
#       AND UPPER(dq_report.SOURCE_SYSTEM) = CASE
#         WHEN UPPER(detail.object_source) LIKE 'PRAGATI_S%' THEN 'PRAGATI'
#         ELSE UPPER(detail.object_source)
#       END
#       AND UPPER(dq_report.TABLE_NAME) = UPPER(detail.object_name)
#   WHERE
#     detail.load_type != 'ONE TIME LOAD'
#     AND exec_log.status = 'SUCCESS'
#     AND exec_log.layer_name = 'CURATED'
# ),
# total_records AS (
#   SELECT
#     TABLE_NAME,
#     Total_Records,
#     pipeline_runid,
#     SOURCE_SYSTEM
#   FROM
#     total_records_with_row_num
#   WHERE
#     row_num = 1
# ),
# failed_records AS (
#   SELECT
#     dq.DQ_NAME,
#     dq.SOURCE_SYSTEM,
#     dq.TABLE_NAME,
#     dq.COLUMN_NAME,
#     dq.DQ_GENERATION_DATE,
#     CAST(SUM(dq.Failed_Records) AS INT) AS Failed_Records,
#     CAST(ANY_VALUE(total.Total_Records) AS INT) AS Total_Records,
#     dq.ERROR_CODE,
#     dq.ETL_AUDIT_ID
#   FROM
#     dq_counts dq
#     JOIN total_records total ON dq.TABLE_NAME = total.TABLE_NAME
#       AND dq.SOURCE_SYSTEM = total.SOURCE_SYSTEM
#       AND total.pipeline_runid = dq.ETL_AUDIT_ID
#   GROUP BY
#     dq.DQ_NAME,
#     dq.SOURCE_SYSTEM,
#     dq.TABLE_NAME,
#     dq.COLUMN_NAME,
#     dq.DQ_GENERATION_DATE,
#     dq.ERROR_CODE,
#     dq.ETL_AUDIT_ID
# ),
# flag_mapping AS (
#   SELECT
#     fr.DQ_NAME,
#     fr.SOURCE_SYSTEM,
#     fr.TABLE_NAME,
#     fr.COLUMN_NAME,
#     fr.DQ_GENERATION_DATE,
#     fr.ERROR_CODE,
#     fr.Total_Records,
#     fr.Failed_Records,
#     fr.Total_Records - fr.Failed_Records AS Passed_Records,
#     ds.Accuracy_FLAG,
#     ds.Completeness_FLAG,
#     ds.Conformity_FLAG,
#     ds.Consistency_FLAG,
#     ds.Integrity_FLAG,
#     ds.Timeliness_FLAG,
#     ds.Uniqueness_FLAG
#   FROM
#     failed_records fr
#     JOIN edp_datasharing_prod.bfil.dq_summary ds ON fr.ERROR_CODE = ds.ERROR_CODE
# )
# SELECT
#   *
# FROM
#   flag_mapping;"""
#     )
#     .repartition(50)
#     .cache()
# )

# COMMAND ----------

# DBTITLE 1,Phase 2 code
adb_datasharing_catlog_schema = "edp_datasharing_prod.bfil"
target_table_name = "dq_view_details"

# Enable Adaptive Query Execution
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", 200)

filter_date = spark.sql(f"""SELECT max(DQ_GENERATION_DATE) FROM {adb_datasharing_catlog_schema}.{target_table_name}""").first()[0]

# Generate the dq_view_df DataFrame as before
dq_view_df = (
    spark.sql(
        f"""
WITH deduplicated_dq_report AS (
  SELECT
    dq.DQ_NAME,
    dq.SOURCE_SYSTEM,
    dq.TABLE_NAME,
    dq.DQ_COLUMN_NAME,
    dq.PRIMARY_KEY,
    dq.PRIMARY_KEY_VALUE,
    dq.INVALID_VALUE,
    dq.ETL_CHANGE_FLAG,
    dq.ERROR_MESSAGE,
    dq.AS_ON_DATE,
    dq.ERROR_CODE,
    dq.ETL_AUDIT_ID,
    MAX(dq.DQ_GENERATION_DATE) AS DQ_GENERATION_DATE
  FROM
    edp_datasharing_prod.bfil.dq_detailed_report dq
  WHERE
    dq.DQ_GENERATION_DATE > '{filter_date}'
  GROUP BY
    dq.DQ_NAME,
    dq.SOURCE_SYSTEM,
    dq.TABLE_NAME,
    dq.DQ_COLUMN_NAME,
    dq.PRIMARY_KEY,
    dq.PRIMARY_KEY_VALUE,
    dq.INVALID_VALUE,
    dq.ETL_CHANGE_FLAG,
    dq.ERROR_MESSAGE,
    dq.AS_ON_DATE,
    dq.ERROR_CODE,
    dq.ETL_AUDIT_ID
),
dq_counts AS (
  SELECT
    UPPER(dq.DQ_NAME) AS DQ_NAME,
    UPPER(dq.SOURCE_SYSTEM) AS SOURCE_SYSTEM,
    UPPER(dq.TABLE_NAME) AS TABLE_NAME,
    UPPER(dq.DQ_COLUMN_NAME) AS COLUMN_NAME,
    dq.DQ_GENERATION_DATE,
    dq.AS_ON_DATE,
    dq.ERROR_CODE,
    dq.ETL_AUDIT_ID,
    COUNT(*) AS Failed_Records
  FROM
    deduplicated_dq_report dq
  GROUP BY
    UPPER(dq.DQ_NAME),
    UPPER(dq.SOURCE_SYSTEM),
    UPPER(dq.TABLE_NAME),
    UPPER(dq.DQ_COLUMN_NAME),
    dq.DQ_GENERATION_DATE,
    dq.AS_ON_DATE,
    dq.ERROR_CODE,
    dq.ETL_AUDIT_ID
),
total_records_with_row_num AS (
  SELECT
    UPPER(detail.object_name) AS TABLE_NAME,
    exec_log.source_row_count AS Total_Records,
    exec_log.pipeline_runid,
    CASE
      WHEN UPPER(detail.object_source) LIKE 'PRAGATI_S%' THEN 'PRAGATI'
      ELSE UPPER(detail.object_source)
    END AS SOURCE_SYSTEM,
    ROW_NUMBER() OVER (PARTITION BY UPPER(detail.object_name), exec_log.pipeline_runid ORDER BY exec_log.pipeline_runid) AS row_num
  FROM
    edp_synapse_prod.bfil_meta.pl_exec_log exec_log
    JOIN edp_synapse_prod.bfil_meta.pl_src_sys_detail detail ON exec_log.src_object_id = detail.src_object_id
    JOIN deduplicated_dq_report dq_report ON exec_log.pipeline_runid = dq_report.ETL_AUDIT_ID
      AND UPPER(dq_report.SOURCE_SYSTEM) = CASE
        WHEN UPPER(detail.object_source) LIKE 'PRAGATI_S%' THEN 'PRAGATI'
        ELSE UPPER(detail.object_source)
      END
      AND UPPER(dq_report.TABLE_NAME) = UPPER(detail.object_name)
  WHERE
    detail.load_type != 'ONE TIME LOAD'
    AND exec_log.status = 'SUCCESS'
    AND exec_log.layer_name = 'CURATED'
),
total_records AS (
  SELECT
    TABLE_NAME,
    Total_Records,
    pipeline_runid,
    SOURCE_SYSTEM
  FROM
    total_records_with_row_num
  WHERE
    row_num = 1
),
failed_records AS (
  SELECT
    dq.DQ_NAME,
    dq.SOURCE_SYSTEM,
    dq.TABLE_NAME,
    dq.COLUMN_NAME,
    dq.DQ_GENERATION_DATE,
    dq.AS_ON_DATE,
    CAST(SUM(dq.Failed_Records) AS INT) AS Failed_Records,
    CAST(ANY_VALUE(total.Total_Records) AS INT) AS Total_Records,
    dq.ERROR_CODE,
    dq.ETL_AUDIT_ID
  FROM
    dq_counts dq
    JOIN total_records total ON dq.TABLE_NAME = total.TABLE_NAME
      AND dq.SOURCE_SYSTEM = total.SOURCE_SYSTEM
      AND total.pipeline_runid = dq.ETL_AUDIT_ID
  GROUP BY
    dq.DQ_NAME,
    dq.SOURCE_SYSTEM,
    dq.TABLE_NAME,
    dq.COLUMN_NAME,
    dq.DQ_GENERATION_DATE,
    dq.AS_ON_DATE,
    dq.ERROR_CODE,
    dq.ETL_AUDIT_ID
),
flag_mapping AS (
  SELECT
    fr.DQ_NAME,
    fr.SOURCE_SYSTEM,
    fr.TABLE_NAME,
    fr.COLUMN_NAME,
    fr.DQ_GENERATION_DATE,
    fr.AS_ON_DATE,
    fr.ERROR_CODE,
    fr.Total_Records,
    fr.Failed_Records,
    fr.Total_Records - fr.Failed_Records AS Passed_Records,
    ds.Accuracy_FLAG,
    ds.Completeness_FLAG,
    ds.Conformity_FLAG,
    ds.Consistency_FLAG,
    ds.Integrity_FLAG,
    ds.Timeliness_FLAG,
    ds.Uniqueness_FLAG
  FROM
    failed_records fr
    JOIN edp_datasharing_prod.bfil.dq_summary ds ON fr.ERROR_CODE = ds.ERROR_CODE
)
SELECT
  *
FROM
  flag_mapping;"""
    )
    .repartition(50, "DQ_GENERATION_DATE")
    .cache()
)

dq_view_df.createOrReplaceTempView("dq_view") 

datasharing_catlog = adb_datasharing_catlog_schema.split(".")[0]
target_table_schema = adb_datasharing_catlog_schema.split(".")[1]

# Checking table is exist or not
delta_table_exists = spark.sql(f'SELECT * FROM {datasharing_catlog}.information_schema.tables WHERE table_schema = "{target_table_schema}" and table_name = "{target_table_name}"')

if not (delta_table_exists.isEmpty()) :
  # Check if the Delta table exists
  try:

      output_df = spark.sql(f"""
        MERGE INTO {adb_datasharing_catlog_schema}.{target_table_name} AS target
        USING dq_view AS source
        ON
        target.DQ_NAME = source.DQ_NAME AND
        target.SOURCE_SYSTEM = source.SOURCE_SYSTEM AND
        target.TABLE_NAME = source.TABLE_NAME AND
        target.AS_ON_DATE = source.AS_ON_DATE AND
        target.DQ_GENERATION_DATE = source.DQ_GENERATION_DATE
        WHEN NOT MATCHED THEN
        INSERT *
      """)
    
  except Exception as e:
    raise Exception(f"Error in merging new data to Delta table: {e}")
else:
    # Create the Delta table if it does not exist
    dq_view_df.write.format("delta").mode("append").saveAsTable(f"{adb_datasharing_catlog_schema}.{target_table_name}")

# Clear Cache to free memory
dq_view_df.unpersist()

# COMMAND ----------

# DBTITLE 1,Refresh Existing View
# dq_view_df.write.format("delta").mode("overwrite").saveAsTable(f"edp_datasharing_prod.bfil.dq_view_details")

# COMMAND ----------

# DBTITLE 1,Clear Cache
# Clear Cache to free memory
# dq_view_df.unpersist()