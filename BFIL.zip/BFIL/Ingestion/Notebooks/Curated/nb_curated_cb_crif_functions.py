# Databricks notebook source
filename='nb_curated_cb_crif_functions.dbc'

def crif_util_select(df_crif, *select_expr, drop_cols=None):
    try:
        # Apply select expression
        try:
            df_crif = df_crif.select("SK",*select_expr)
        except Exception as e:
            
            df_crif = df_crif.select(*select_expr)
        
        # Drop columns if specified
        if drop_cols:
            df_crif = df_crif.drop(*drop_cols)
            
    except Exception as e:
        logger(logger_level_info, f"Error in dynamic function of crif: {e} ",execution_log_list,filename)
        df_crif = None
    return df_crif


# COMMAND ----------

#contact
def crif_Contact(df_crif):
    try:
        combined_df=None
        if df_crif is not None:
            indv_responses_tags = df_crif.select("SK", explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
        
            grp_responses_tags = df_crif.select("SK", explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))

            fields = ['PHONES', 'ADDRESSES', 'EMAILS']
            for response_tags in [indv_responses_tags, grp_responses_tags]:
                for field in fields:
                    try:
                        # Extract the specified field and explode it
                        contact_df = response_tags.select("SK", 
                            explode_outer(
                                col(f"{response_tags.columns[1]}.{field}.{'PHONE' if field == 'PHONES' else 'ADDRESS' if field == 'ADDRESSES' else 'EMAIL'}")
                            ).alias("Value"))
                        contact_df = contact_df.filter(col("Value").isNotNull())
                        
                        # Add a Type column
                        contact_df = contact_df.withColumn("Type", lit("Phone" if field == "PHONES" else "Address" if field == "ADDRESSES" else "Email"))
                        

                        if combined_df is None:
                            combined_df = contact_df
                        else:
                            combined_df = combined_df.union(contact_df)
                    except Exception as e:
                        logger(logger_level_error, f"Error in contact: {e} ",execution_log_list,filename)
                        pass
            return combined_df
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in contact: {e} ",execution_log_list,filename)
        return None

# COMMAND ----------

#Relation
def crif_Relation(df_crif):
    try:
        if df_crif is not None: 
            indv_responses_tags = df_crif.select("SK", explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            
            grp_responses_tags = df_crif.select("SK", explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))


            df_relation_indv = indv_responses_tags.select("SK",col("Indv-responses.RELATIONS.RELATION")).select("SK",explode("Relation").alias("relation")).select("SK","relation.*")
            df_relation_grp = grp_responses_tags.select("SK",col("GRP-responses.RELATIONS.RELATION")).select("SK",explode("Relation").alias("relation")).select("SK","relation.*") 
            try:
                df_relation = df_relation_indv.union(df_relation_grp)
            except: 
                if df_relation_indv is not None:
                    df_relation = df_relation_indv
                elif df_relation_grp is not None:
                    df_relation = df_relation_grp
                else:
                    df_relation = None

            return df_relation

        else:           
            pass
            logger(logger_level_info, "Dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in relation : {e} " ,execution_log_list,filename)
        
        return None
        


# COMMAND ----------

#Groupdetails
def crif_Groupdetails(df_crif):
    try:
        if df_crif is not None:

            indv_responses_tags = df_crif.select("SK", explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            
            grp_responses_tags = df_crif.select("SK", explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))

            group_details_grp = grp_responses_tags.select("SK",col("GRP-responses.GROUP-DETAILS.*"))
            group_details_indv = indv_responses_tags.select("SK",col("Indv-responses.GROUP-DETAILS.*"))
            combined_group_details = group_details_grp.union(group_details_indv)
            return combined_group_details
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in group details: {e} " ,execution_log_list,filename)
        return None
    


# COMMAND ----------

#Variation
def crif_Variation(df_crif):
    try:
        variation_df = df_crif.select("SK", "PERSONAL-INFO-VARIATION.*")
        if variation_df is not None:
            def find_nested_types(schema, prefix=""):
                struct_cols = []
                array_cols = []
                string_cols = []

                for field in schema.fields:
                    col_name = prefix + field.name

                    if isinstance(field.dataType, StructType):
                        struct_cols.append(col_name)
                        # Check if the struct has nested fields
                        nested_field = field.dataType
                        if len(nested_field.fields) > 0:
                            if isinstance(nested_field.fields[0].dataType, ArrayType):
                                array_cols.append(col_name)
                            elif isinstance(nested_field.fields[0].dataType, StructType):
                                struct_cols.append(col_name)
                            else:
                                string_cols.append(col_name)

                    elif isinstance(field.dataType, ArrayType) and isinstance(field.dataType.elementType, StructType):
                        array_cols.append(col_name)
                    elif isinstance(field.dataType, ArrayType):
                        array_cols.append(col_name)
                    elif isinstance(field.dataType, StringType):
                        string_cols.append(col_name)

                return struct_cols, array_cols, string_cols

            struct_cols, array_cols, string_cols = find_nested_types(variation_df.schema)

            merged_df = spark.createDataFrame([], schema="`SK` Integer, `REPORTED-DATE` STRING, `VALUE` STRING, `TYPE` STRING")

            for col_name in array_cols:
                sub_df = variation_df.select("SK", explode(col(f"{col_name}.VARIATION"))).select("SK", col("col.*")).withColumn("TYPE", lit(col_name))
                merged_df = merged_df.union(sub_df)

            remaining_struct_cols = [col_name for col_name in struct_cols if col_name not in array_cols]
            for col_name in remaining_struct_cols:
                sub_df = variation_df.select("SK", f"{col_name}.VARIATION.*").withColumn("TYPE", lit(col_name))
                merged_df = merged_df.union(sub_df).dropDuplicates()

            return merged_df

        else:
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list, filename)
    except Exception as e:
        logger(logger_level_error, f"Error in variations: {e} ", execution_log_list, filename)
        return None



# COMMAND ----------

#loandetails
def crif_Loan_details(df_crif):
    try:
        if df_crif is not None:
            indv_responses_tags = df_crif.select("SK", explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            
            grp_responses_tags = df_crif.select("SK", explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))
            try:
                loandetails_indv = indv_responses_tags.select("SK", col("Indv-responses.LOAN-DETAIL.*"))
                loandetails_grp = grp_responses_tags.select("SK", col("GRP-responses.LOAN-DETAIL.*"))
                combined_df = loandetails_indv.unionByName(loandetails_grp, allowMissingColumns=True)
                
                df_loandetails_responses = df_crif.select("SK", explode("RESPONSES.RESPONSE.LOAN-DETAILS").alias("Loan-details")) \
                .select("SK", "Loan-details.*") \
                .drop("LINKED-ACCOUNTS", "SECURITY-DETAILS")
                                                    
                df_loandetail = combined_df.unionByName(df_loandetails_responses, allowMissingColumns=True)
                
            except Exception as e:
                if loandetails_indv is not None and loandetails_grp is None:
                    df_loandetail = loandetails_indv
                elif loandetails_grp is not None and loandetails_indv is None:
                    df_loandetail = loandetails_grp
                elif df_loandetails_responses is not None:
                    df_loandetail = df_loandetails_responses
                else:
                    df_loandetail = None
   
            return df_loandetail
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in loandetaisl: {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

# ##Ids
def crif_Ids(df_crif):
    try:
        if df_crif is not None:
            indv_responses_tags = df_crif.select("SK", explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            
            grp_responses_tags = df_crif.select("SK", explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))
            # indv_responses_tags =crif_util_select(df_crif.select("SK",explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses")),"Indv-responses.*")
                        
            # grp_responses_tags = crif_util_select(df_crif.select("SK",explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses")),"GRP-responses.*")

            ids_indv = indv_responses_tags.select("SK", col("Indv-responses.IDS.ID").alias("ids")).select("SK", explode("ids").alias("id")).select("SK", col("id.*")) 
            ids_grp = grp_responses_tags.select("SK", col("GRP-responses.IDS.ID").alias("ids")).select("SK", explode("ids").alias("id")).select("SK", col("id.*"))

            if ids_grp and ids_indv is not None:
                combined_ids = ids_grp.union(ids_indv)
            elif ids_indv is not None:
                combined_ids = ids_indv
            elif ids_grp is not None:
                combined_ids = ids_grp
            else:
                combined_ids = None

            return combined_ids
        else:           
            pass
            logger(logger_level_info, "Dataframe has no data ", execution_log_list,filename)  
    except Exception as e:
        logger(logger_level_error, f"Error in Ids: {e} " ,execution_log_list,filename)
        return None
    

# COMMAND ----------

#Response_list
def crif_Responselist(df_crif):
    try:
        if df_crif is not None:
            df_respoonselist_indv = df_crif.select("SK", col("INDV-RESPONSES.INDV-RESPONSE-LIST.*")) \
                .select("SK", explode("INDV-RESPONSE").alias("indv-response")) \
                .select("SK", "indv-response.*") \
                .withColumn("List-Type", lit("INDV-RESPONSE")) \
                .drop("ADDRESSES", "PHONES", "GROUP-DETAILS", "IDS", "LOAN-DETAIL", "RELATIONS") \

            df_respoonselist_grp= df_crif.select("SK", col("GRP-RESPONSES.GRP-RESPONSE-LIST.*")) \
                .select("SK", explode("GRP-RESPONSE").alias("grp-response")) \
                .select("SK", "grp-response.*") \
                .withColumn("List-Type", lit("GRP-RESPONSE")) \
                .drop("ADDRESSES", "PHONES", "GROUP-DETAILS", "IDS", "LOAN-DETAIL", "RELATIONS") \
            
            if df_respoonselist_grp is not None and df_respoonselist_indv is not None:
                df_response_list = df_respoonselist_indv.unionByName(df_respoonselist_grp, allowMissingColumns=True)
            elif df_respoonselist_grp is not None or df_respoonselist_indv is None :
                df_response_list = df_respoonselist_grp
            elif df_respoonselist_indv is not None or df_respoonselist_grp is None:
                df_response_list = df_respoonselist_indv
            else:
                df_response_list = None

            return df_response_list
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in responselist: {e} " ,execution_log_list,filename)
        return None
    

# COMMAND ----------

#response     
def crif_Response(df_crif):
    try:
        if df_crif is not None:
            df_responses_grp = df_crif.select("SK", "GRP-RESPONSES.SUMMARY", "GRP-RESPONSES.PRIMARY-SUMMARY", "GRP-RESPONSES.SECONDARY-SUMMARY")
            df_responses_indv = df_crif.select("SK", "INDV-RESPONSES.SUMMARY", "INDV-RESPONSES.PRIMARY-SUMMARY", "INDV-RESPONSES.SECONDARY-SUMMARY")

            selcolList = ["SECONDARY-SUMMARY", "PRIMARY-SUMMARY", "SUMMARY"]
            for colname in selcolList:
                tempL = df_responses_grp.select(f"{colname}.*").columns
                for col_name in tempL:
                    prefix = "SEC_" if colname == selcolList[0] else "PRI_" if colname == selcolList[1] else "SUM_"
                    df_responses_grp = df_responses_grp.select("*",f"{colname}.*")
                    df_responses_grp = df_responses_grp.withColumnRenamed(col_name, f"{prefix}{col_name}").drop(*tempL)
            df_responses_grp = df_responses_grp.withColumn("RESPONSE_TYPE", lit("GRP-RESPONSE"))
            for colname in selcolList:
                tempL = df_responses_indv.select(f"{colname}.*").columns
                for col_name in tempL:
                    prefix = "SEC_" if colname == selcolList[0] else "PRI_" if colname == selcolList[1] else "SUM_"
                    df_responses_indv = df_responses_indv.select("*",f"{colname}.*")
                    df_responses_indv = df_responses_indv.withColumnRenamed(col_name, f"{prefix}{col_name}").drop(*tempL)

            df_responses_indv = df_responses_indv.withColumn("RESPONSE_TYPE", lit("INDV-RESPONSE"))

            df_response = df_responses_indv.unionByName(df_responses_grp, allowMissingColumns=True).drop("SUMMARY", "PRIMARY-SUMMARY", "SECONDARY-SUMMARY")

            return df_response
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in responses: {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

#comment
def crif_Comment(df_crif):
    try:
        if df_crif is not None:
            if "Comment" in df_crif.columns:
                df_comment = df_crif.select("SK","COMMENT.*")
            else:
                df_comment = None
            return df_comment
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in comment: {e} " ,execution_log_list,filename)
        return None
