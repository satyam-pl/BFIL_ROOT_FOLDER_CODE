# Databricks notebook source
##################################### All Data Quality Framework Functions #######################################

# COMMAND ----------

# Declaring the notebook name
filename = 'nb_dq_functions.dbc'

# COMMAND ----------

# This DQ function identifies the records where the specified column having date values '1900-01-01' as bad records and replaces them with NULL values.
# This rule will actually change the source/incremental data i.e. replacement invalid dates with NULL

# This DQ function identifies the records where the specified column having date values '1900-01-01' as bad records and replaces them with NULL values.
# This rule will actually change the source/incremental data i.e. replacement invalid dates with NULL


def dq_incorrect_date(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):

    try:
        # Fetching dq_rule_parameters
        rule_param_json = json.loads(dq_rule_parameters)

        # Extract column_name list
        column_name = rule_param_json.get("column_name", [])

        # Regular expression pattern for validating date_pattern
        date_pattern = r"^1900-01-01.*$"

        # Column to identify invalid date
        invalid_date_values = when(
            col(str(column_name[0])).rlike(date_pattern),
            date_format(col(column_name[0]), timestamp_format),
        ).otherwise(None)

        # Setting error message based on the presence of invalid records
        error_message = f"{column_name[0]} should not be 1900-01-01 changed it to null"

        detailed_report_df = (
            df.withColumn(
                "PRIMARY_KEY_VALUE",
                when(invalid_date_values.isNotNull(), concat_ws(" | ", *business_key)),
            )
            .withColumn(
                "ERROR_MESSAGE",
                when(invalid_date_values.isNotNull(), lit(error_message)).otherwise(
                    None
                ),
            )
            .filter(col("ERROR_MESSAGE").isNotNull())
        )

        # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid mobile numbers
        detailed_report_df = (
            detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
            .withColumn("INVALID_VALUE", lit(invalid_date_values).cast("string"))
            .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
            .withColumn("SOURCE_SYSTEM", lit(source_db))
            .withColumn("TABLE_NAME", lit(source_table))
            .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
            .withColumn(
                "ERROR_CODE",
                when(col("ERROR_MESSAGE") == error_message, lit("100")),
            )
            .withColumn("AS_ON_DATE", lit(load_to_date))
            .withColumn(
                "DQ_GENERATION_DATE",
                lit(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                ),
            )
            .select(
                "ETL_AUDIT_ID",
                "DQ_NAME",
                "DQ_COLUMN_NAME",
                "SOURCE_SYSTEM",
                "TABLE_NAME",
                "PRIMARY_KEY",
                "PRIMARY_KEY_VALUE",
                "INVALID_VALUE",
                "ETL_CHANGE_FLAG",
                "ERROR_MESSAGE",
                "ERROR_CODE",
                "AS_ON_DATE",
                "DQ_GENERATION_DATE",
            )
        )

        logger(
            logger_level_info,
            f"All data checks for the DQ_INVALID_DATE_CHECK DQ rule have been done for table: {source_table}.",
            execution_log_list,
            filename,
        )

    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the DQ_INVALID_DATE_CHECK DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the DQ_INVALID_DATE_CHECK DQ rule function.", e
        )

    if not detailed_report_df.isEmpty():

        try:
            # Write the data to the table using the JDBC connection and append mode
            logger(
                logger_level_info,
                f"For DQ_INVALID_DATE_CHECK, dq_detailed_report has been updated for table: {source_table}.",
                execution_log_list,
                filename,
            )

            column_to_transform = column_name[0]

            # Find the original column name in the DataFrame
            original_column_name = next(
                col_name
                for col_name in df.columns
                if col_name.lower() == column_to_transform
            )

            # Apply transformation to the specified column while preserving its original case
            df = df.withColumn(
                original_column_name,
                when(col(original_column_name).rlike(date_pattern), lit(None))
                .otherwise(col(original_column_name))
                .alias(column_to_transform),
            )

            # Overwrite hash values of changed data
            column_to_exclude_frm_scd.extend(
                [
                    "ETL_CHANGE_FLAG",
                    "ETL_DQ_FINAL_STATUS",
                    "ETL_DQ_ERROR",
                    "ETL_EXEC_LOG_ID",
                    "ETL_CREATED_BY",
                    "ETL_CREATED_DATE",
                    "ETL_LAST_UPDATED_BY",
                    "ETL_LAST_UPDATED_DATE",
                    "ETL_AUDIT_ID",
                    "ETL_IS_ACTIVE",
                    "ETL_EFFECTIVE_FROM_DATE",
                    "ETL_EFFECTIVE_TO_DATE",
                    "ETL_HASH_COL",
                ]
            )

            # Get all columns except those specified in column_to_exclude_frm_scd
            selected_columns = [
                col_name
                for col_name in source_data_df.columns
                if col_name not in column_to_exclude_frm_scd
            ]

            # Concatenate values from selected columns into a single string
            concatenated_string_column = concat_ws(
                "|", *[col(col_name) for col_name in selected_columns]
            )

            # Generate SHA-256 hash for the concatenated string
            df = df.withColumn("ETL_HASH_COL", sha2(concatenated_string_column, 256))

        except Exception as e:
            # Call the logger function with a log level and message
            logger(
                logger_level_error,
                f"An error occurred while re-calculating hash value after executing DQ_INVALID_DATE data quality rule.",
                execution_log_list,
                filename,
            )
            print(*execution_log_list, sep="\n")
            raise Exception(
                f"An error occurred while re-calculating hash value after executing DQ_INVALID_DATE data quality rule.",
                e,
            )

    return df, detailed_report_df

# COMMAND ----------

# This DQ function identifies the records where the specified column having invalid pincode values as bad records.
# For checking the invalid values, it will check for a pattern where the pincode should have exactly 6 digits and first digit cannot be zero


def dq_pincode_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):

    try:
        # Fetching dq_rule_parameters
        rule_param_json = json.loads(dq_rule_parameters)

        # Extract column_name list
        column_name = rule_param_json.get("column_name", [])

        # Regular expression pattern for validating pin_pattern
        pin_pattern = r"^[1-9][0-9]{5}$"

        # Column to identify invalid pin code
        invalid_pin_code = when(
            ~col(str(column_name[0])).rlike(pin_pattern), col(str(column_name[0]))
        ).otherwise(None)

        error_message = f"{column_name[0]} has invalid pin code."

        detailed_report_df = (
            df.withColumn(
                "PRIMARY_KEY_VALUE",
                when(
                    (col(column_name[0]).isNull() | (trim(col(column_name[0])) == "")),
                    lit(concat_ws(" | ", *business_key)),
                ).otherwise(
                    when(invalid_pin_code.isNotNull(), concat_ws(" | ", *business_key))
                ),
            )
            .withColumn(
                "ERROR_MESSAGE",
                when(
                    (col(column_name[0]).isNull() | (trim(col(column_name[0])) == "")),
                    lit(f"{column_name[0]} has NULL or BLANK value."),
                ).otherwise(when(invalid_pin_code.isNotNull(), lit(error_message))),
            )
            .filter(col("ERROR_MESSAGE").isNotNull())
        )

        detailed_report_df = (
            detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
            .withColumn(
                "INVALID_VALUE",
                when(
                    invalid_pin_code.isNotNull(), col(column_name[0]).cast("string")
                ).otherwise(None),
            )
            .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
            .withColumn("SOURCE_SYSTEM", lit(source_db))
            .withColumn("TABLE_NAME", lit(source_table))
            .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
            .withColumn(
                "ERROR_CODE",
                when(col("ERROR_MESSAGE") == error_message, lit("102")).otherwise(
                    lit("111")
                ),
            )
            .withColumn("AS_ON_DATE", lit(load_to_date))
            .withColumn(
                "DQ_GENERATION_DATE",
                lit(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                ),
            )
            .select(
                "ETL_AUDIT_ID",
                "DQ_NAME",
                "DQ_COLUMN_NAME",
                "SOURCE_SYSTEM",
                "TABLE_NAME",
                "PRIMARY_KEY",
                "PRIMARY_KEY_VALUE",
                "INVALID_VALUE",
                "ETL_CHANGE_FLAG",
                "ERROR_MESSAGE",
                "ERROR_CODE",
                "AS_ON_DATE",
                "DQ_GENERATION_DATE",
            )
        )

        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been done for table: {source_table}.",
            execution_log_list,
            filename,
        )

    except Exception as e:
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# This DQ function identifies the records where the specified column having invalid mobile values as bad records.
# For checking the invalid values, it will check for a pattern where the mobile numbers can be of length 11 or 10 digits  length with only numerical records.


def dq_mobile_length_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):

    try:
        # Fetching dq_rule_parameters
        rule_param_json = json.loads(dq_rule_parameters)

        # Extract column_name list
        column_name = rule_param_json.get("column_name", [])

        # Regular expression pattern for validating mobile_pattern
        mobile_pattern = r"^[0]{0,1}[6,7,8,9]\d{9}$"

        # Column to identify invalid pin code
        invalid_mobile = when(
            ~col(str(column_name[0])).rlike(mobile_pattern),
            col(str(column_name[0])),
        ).otherwise(None)

        error_message = f"{column_name[0]} has invalid length it should be 10 digit and follow the standard."

        detailed_report_df = (
            df.withColumn(
                "PRIMARY_KEY_VALUE",
                when(
                    (col(column_name[0]).isNull() | (trim(col(column_name[0])) == "")),
                    lit(concat_ws(" | ", *business_key)),
                ).otherwise(
                    when(invalid_mobile.isNotNull(), concat_ws(" | ", *business_key))
                ),
            )
            .withColumn(
                "ERROR_MESSAGE",
                when(
                    (col(column_name[0]).isNull() | (trim(col(column_name[0])) == "")),
                    lit(f"{column_name[0]} has NULL or BLANK value."),
                ).otherwise(when(invalid_mobile.isNotNull(), lit(error_message))),
            )
            .filter(col("ERROR_MESSAGE").isNotNull())
        )

        detailed_report_df = (
            detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
            .withColumn(
                "INVALID_VALUE",
                when(
                    invalid_mobile.isNotNull(), col(column_name[0]).cast("string")
                ).otherwise(lit(None)),
            )
            .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
            .withColumn("SOURCE_SYSTEM", lit(source_db))
            .withColumn("TABLE_NAME", lit(source_table))
            .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
            .withColumn(
                "ERROR_CODE",
                when(col("ERROR_MESSAGE") == error_message, lit("103")).otherwise(
                    lit("111")
                ),
            )
            .withColumn("AS_ON_DATE", lit(load_to_date))
            .withColumn(
                "DQ_GENERATION_DATE",
                lit(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                ),
            )
            .select(
                "ETL_AUDIT_ID",
                "DQ_NAME",
                "DQ_COLUMN_NAME",
                "SOURCE_SYSTEM",
                "TABLE_NAME",
                "PRIMARY_KEY",
                "PRIMARY_KEY_VALUE",
                "INVALID_VALUE",
                "ETL_CHANGE_FLAG",
                "ERROR_MESSAGE",
                "ERROR_CODE",
                "AS_ON_DATE",
                "DQ_GENERATION_DATE",
            )
        )

        logger(
            logger_level_info,
            f"All data checks for the '{source_dq_rule_name}' DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# This DQ function identifies the records where the difference between column 2 and column 1 of the rule parameters is less than 16 years and 57 years as bad records. It means when the records are created, the client age should not be less than 16 and not greater than 57.


def dq_dob_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        # Fetching dq_rule_parameters
        rules_parameters = json.loads(dq_rule_parameters)
        column_name = rules_parameters.get("column_name", [])
        age_limit = rules_parameters.get("age_limits", [])

        invalid_values = when(
            (date_diff(col(column_name[1]), col(column_name[0])) / 365 < age_limit[0])
            | (
                date_diff(col(column_name[1]), col(column_name[0])) / 365 > age_limit[1]
            ),
            col(column_name[0]),
        ).otherwise(None)

        error_message = f"{column_name[0]} has value less than {age_limit[0]} years or greater than {age_limit[1]} years as on the date value in {column_name[1]}."

        detailed_report_df = (
            df.withColumn(
                "PRIMARY_KEY_VALUE",
                when(
                    (col(column_name[0]).isNull() | (trim(col(column_name[0])) == "")),
                    lit(concat_ws(" | ", *business_key)),
                )
                .when(
                    (col(column_name[1]).isNull() | (trim(col(column_name[1])) == "")),
                    lit(concat_ws(" | ", *business_key)),
                )
                .otherwise(
                    when(invalid_values.isNotNull(), concat_ws(" | ", *business_key))
                ),
            )
            .withColumn(
                "ERROR_MESSAGE",
                when(
                    (col(column_name[0]).isNull() | (trim(col(column_name[0])) == "")),
                    lit(f"{column_name[0]} has NULL or BLANK value."),
                )
                .when(
                    (col(column_name[1]).isNull() | (trim(col(column_name[1])) == "")),
                    lit(f"{column_name[1]} has NULL or BLANK value."),
                )
                .otherwise(when(invalid_values.isNotNull(), lit(error_message))),
            )
            .filter(col("ERROR_MESSAGE").isNotNull())
        )

        detailed_report_df = (
            detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
            .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
            .withColumn("SOURCE_SYSTEM", lit(source_db))
            .withColumn("TABLE_NAME", lit(source_table))
            .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
            .withColumn(
                "ERROR_CODE",
                when(col("ERROR_MESSAGE") == error_message, lit("104")).otherwise(
                    lit("111")
                ),
            )
            .withColumn(
                "INVALID_VALUE",
                concat_ws(
                    " | ",
                    when(col(column_name[0]).isNull(), lit("NULL")).otherwise(
                        date_format(col(column_name[0]), timestamp_format)
                    ),
                    when(col(column_name[1]).isNull(), lit("NULL")).otherwise(
                        date_format(col(column_name[1]), timestamp_format)
                    ),
                ),
            )
            .withColumn("AS_ON_DATE", lit(load_to_date))
            .withColumn(
                "DQ_GENERATION_DATE",
                lit(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                ),
            )
            .select(
                "ETL_AUDIT_ID",
                "DQ_NAME",
                "DQ_COLUMN_NAME",
                "SOURCE_SYSTEM",
                "TABLE_NAME",
                "PRIMARY_KEY",
                "PRIMARY_KEY_VALUE",
                "INVALID_VALUE",
                "ETL_CHANGE_FLAG",
                "ERROR_MESSAGE",
                "ERROR_CODE",
                "AS_ON_DATE",
                "DQ_GENERATION_DATE",
            )
        )

        logger(
            logger_level_info,
            f"All data check for DQ_DOB_CHECK dq rule has been done for table : {source_table}",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in DQ_DOB_CHECK dq rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(f"An error occurred in DQ_DOB_CHECK dq rule function.", e)

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC column should not contain double quotes and should not contain special characters

# COMMAND ----------

# The Rule checks the value in the column 1 is matching with the input regex pattern.
def dq_pattern_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        # Extracting required parameters from JSON
        rules_parameter = ast.literal_eval(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        pattern = rules_parameter.get("pattern", [])
        # Check if column_name or pattern is None or empty
        if (
            column_name[0] is None
            or column_name[0] == ""
            or pattern[0] is None
            or pattern[0] == ""
        ):
            logger(
                logger_level_info,
                f"Invalid input parameters for DQ rule '{source_dq_rule_name}'. Please check the parameters config for table '{source_table}'",
                execution_log_list,
                filename,
            )
        else:
            # Filter the DataFrame to get matching records
            filter_condition = col(column_name[0]).rlike(pattern[0])
            non_matching_records_df = df.filter(filter_condition)

            # Setting error message based on the presence of invalid records
            error_message = f"The value in column '{column_name[0]}' does not match the required pattern."

            # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid records
            detailed_report_df = (
                non_matching_records_df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(filter_condition.isNotNull(), concat_ws(" | ", *business_key)),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(filter_condition.isNotNull(), lit(error_message)).otherwise(
                        None
                    ),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            # Adding additional columns to detailed_report_df
            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("105")),
                )
                .withColumn("INVALID_VALUE", col(column_name[0]).cast("string"))
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

        # Logging completion of DQ pattern check
        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC "if KYCtype ='IDP6' then kycnumber length should be 12,
# MAGIC if KYCtype ='IDP8' then kycnumber length should be 10,
# MAGIC if KYCtype ='IDP14' then kycnumber length should be 10"
# MAGIC

# COMMAND ----------

# The Rule checks the following conditions:
# if KYCtype ='IDP6' then kycnumber length should be 12,
# if KYCtype ='IDP8' then kycnumber length should be 10,
# if KYCtype ='IDP14' then kycnumber length should be 10
def dq_kyc_number_length_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        rules_parameter = json.loads(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        comparison_operator = rules_parameter.get("comparison_operator", [])

        # Check if column_name or comparison_operator is None, empty, or invalid
        if (
            any(col is None or col == "" for col in column_name)
            or any(op is None or op == "" for op in comparison_operator)
            or any(op not in dir(operator) for op in comparison_operator)
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            # Column to identify invalid pan card numbers
            invalid_values = (
                when(
                    (col(column_name[1]) == "IDP6")
                    & (
                        getattr(operator, comparison_operator[0])(
                            length(col(column_name[0])), 12
                        )
                    ),
                    col(column_name[0]),
                )
                .when(
                    (col(column_name[1]) == "IDP8")
                    & (
                        getattr(operator, comparison_operator[0])(
                            length(col(column_name[0])), 10
                        )
                    ),
                    col(column_name[0]),
                )
                .when(
                    (col(column_name[1]) == "IDP14")
                    & (
                        getattr(operator, comparison_operator[0])(
                            length(col(column_name[0])), 10
                        )
                    ),
                    col(column_name[0]),
                )
                .otherwise(None)
            )

            # Setting error message based on the presence of invalid records
            error_message = f"for the value in column {column_name[1]} the length of value in {column_name[0]} is invalid."

            # Conditionally populate ERROR_MESSAGE column based on the rule
            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    )
                    .when(
                        (
                            col(column_name[1]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    )
                    .otherwise(
                        when(
                            invalid_values.isNotNull(), concat_ws(" | ", *business_key)
                        )
                    ),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(f"{column_name[0]} has NULL or BLANK value."),
                    )
                    .when(
                        (
                            col(column_name[1]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(f"{column_name[1]} has NULL or BLANK value."),
                    )
                    .otherwise(when(invalid_values.isNotNull(), lit(error_message))),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            # Adding metadata columns
            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("106")).otherwise(
                        lit("111")
                    ),
                )
                .withColumn(
                    "INVALID_VALUE",
                    concat(
                        col(column_name[1]).cast("string"),
                        lit(" | "),
                        col(column_name[0]).cast("string"),
                    ),
                )
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

            logger(
                logger_level_info,
                f"All data check for dq_kyc_number_length_check dq rule has been done for table : {source_table}",
                execution_log_list,
                filename,
            )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in DQ_kyc_number_length_check dq rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in DQ_kyc_number_length_check dq rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC column values should not be less than required length

# COMMAND ----------

# The Rule will check the length of the value in column1 with the input operator and the required length
def dq_length_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        rules_parameter = json.loads(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        comparison_operator = rules_parameter.get("comparison_operator", [])
        required_length = rules_parameter.get("required_length", [])

        # Check if column_name or comparison_operator or required_length is None, empty, or invalid
        if (
            any(col is None or col == "" for col in column_name)
            or any(op is None or op == "" for op in comparison_operator)
            or any(op not in dir(operator) for op in comparison_operator)
            or any(col is None or col == "" for col in required_length)
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            invalid_values = when(
                getattr(operator, comparison_operator[0])(
                    length(col(column_name[0])), required_length[0]
                ),
                col(column_name[0]),
            ).otherwise(None)

            # Setting error message based on the presence of invalid records
            error_message = (
                f"{column_name[0]} length is less than {required_length[0]}."
            )

            # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on columns containing invalid values
            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    ).otherwise(
                        when(
                            invalid_values.isNotNull(), concat_ws(" | ", *business_key)
                        )
                    ),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(f"{column_name[0]} has NULL or BLANK value."),
                    ).otherwise(when(invalid_values.isNotNull(), lit(error_message))),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("107")).otherwise(
                        lit("111")
                    ),
                )
                .withColumn("INVALID_VALUE", col(column_name[0]).cast("string"))
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

            logger(
                logger_level_info,
                f"All data check for DQ_length_check dq rule has been done for table : {source_table}",
                execution_log_list,
                filename,
            )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in DQ_length_check dq rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(f"An error occurred in DQ_length_check dq rule function.", e)

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC Column should contain only allowed values

# COMMAND ----------

# The rule will check the column1 should have the values only from the values in required_values input.
def dq_allowed_values_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    detailed_report_df = None
    try:
        # Extracting required parameters
        rules_parameter = json.loads(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        required_values = rules_parameter.get("required_values", [])
        capitalized_values = [value.upper() for value in required_values]

        if any(col is None or col == "" for col in column_name) or any(
            rv is None or rv == "" for rv in required_values
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            df = df.withColumn("upper_values", upper(col(column_name[0])))
            invalid_values = when(
                ~col("upper_values").isin(*capitalized_values), col(column_name[0])
            ).otherwise(None)

            # Setting error message based on the presence of invalid records
            error_message = f"{column_name[0]} has values other than these values: {capitalized_values}"

            # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid values
            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    ).otherwise(
                        when(
                            invalid_values.isNotNull(), concat_ws(" | ", *business_key)
                        )
                    ),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(f"{column_name[0]} has NULL or BLANK value."),
                    ).otherwise(when(invalid_values.isNotNull(), lit(error_message))),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            df = df.drop(col("upper_values"))

            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("108")).otherwise(
                        lit("111")
                    ),
                )
                .withColumn("INVALID_VALUE", col(column_name[0]).cast("string"))
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC When one column is not null, then another column should not be null.

# COMMAND ----------

# The rule will check if the value in column1 is not null then column2 should not have null values.
def dq_corresponding_value_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        # Extracting required parameters
        rules_parameter = json.loads(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        if any(col is None or col == "" for col in column_name):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            # Column to identify invalid values
            invalid_values = when(
                ((col(column_name[0]).isNotNull()) & (trim(col(column_name[0])) != ""))
                & ~(
                    col(column_name[1]).isNotNull() & (trim(col(column_name[1])) != "")
                ),
                col(column_name[0]),
            ).otherwise(None)

            # Error message
            error_message = f"{column_name[0]} has a value(not Null) and {column_name[1]} is null or blank."

            # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on the rule
            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(invalid_values.isNotNull(), concat_ws(" | ", *business_key)),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(invalid_values.isNotNull(), lit(error_message)).otherwise(
                        None
                    ),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

        # Setting up the rest of the columns
        detailed_report_df = (
            detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
            .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
            .withColumn("SOURCE_SYSTEM", lit(source_db))
            .withColumn("TABLE_NAME", lit(source_table))
            .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
            .withColumn(
                "ERROR_CODE",
                when(col("ERROR_MESSAGE") == error_message, lit("109")),
            )
            .withColumn(
                "INVALID_VALUE",
                concat_ws(
                    " | ",
                    when(col(column_name[0]).isNull(), lit("NULL")).otherwise(
                        col(column_name[0]).cast("string")
                    ),
                    when(col(column_name[1]).isNull(), lit("NULL")).otherwise(
                        to_timestamp(col(column_name[1]), timestamp_format)
                    ),
                ),
            )
            .withColumn("AS_ON_DATE", lit(load_to_date))
            .withColumn(
                "DQ_GENERATION_DATE",
                lit(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                ),
            )
            .select(
                "ETL_AUDIT_ID",
                "DQ_NAME",
                "DQ_COLUMN_NAME",
                "SOURCE_SYSTEM",
                "TABLE_NAME",
                "PRIMARY_KEY",
                "PRIMARY_KEY_VALUE",
                "INVALID_VALUE",
                "ETL_CHANGE_FLAG",
                "ERROR_MESSAGE",
                "ERROR_CODE",
                "AS_ON_DATE",
                "DQ_GENERATION_DATE",
            )
        )

        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC Approved date should be between fromdate and todate
# MAGIC

# COMMAND ----------

# The rule will check if date value in column3 is less than(operator1) column1 and greater than(operator2) column2
def dq_date_between_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        # Extracting required parameters
        rules_parameter = json.loads(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        comparison_operator = rules_parameter.get("comparison_operator", [])
        lower_comparison_operator = [str(op).lower() for op in comparison_operator]
        if (
            any(col is None or col == "" for col in column_name)
            or any(op is None or op == "" for op in comparison_operator)
            or any(op not in dir(operator) for op in comparison_operator)
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:

            # writing invalid values in invalid_values varaible
            invalid_values = when(
                (
                    (
                        getattr(operator, lower_comparison_operator[0])(
                            to_timestamp(col(column_name[2]), timestamp_format),
                            to_timestamp(col(column_name[0]), timestamp_format),
                        )
                    )
                    | (
                        getattr(operator, lower_comparison_operator[1])(
                            to_timestamp(col(column_name[2]), timestamp_format),
                            to_timestamp(col(column_name[1]), timestamp_format),
                        )
                    )
                ),
                col(column_name[2]),
            ).otherwise(None)

            operator_full_form1 = lookup_for_comparison_operator.get(
                comparison_operator[0]
            )
            operator_full_form2 = lookup_for_comparison_operator.get(
                comparison_operator[1]
            )

            # Setting error message based on the presence of invalid records
            error_message = f"{column_name[2]} is either {operator_full_form1} {column_name[0]} or {operator_full_form2} {column_name[1]}."

            # Conditionally populate PRIMARY_KEY_VALUE and ERROR_MESSAGE columns based on the rule
            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    )
                    .when(
                        (
                            col(column_name[1]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    )
                    .when(
                        (
                            col(column_name[1]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    )
                    .otherwise(
                        when(
                            invalid_values.isNotNull(), concat_ws(" | ", *business_key)
                        )
                    ),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(f"{column_name[0]} has NULL or BLANK value."),
                    )
                    .when(
                        (
                            col(column_name[1]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(f"{column_name[1]} has NULL or BLANK value."),
                    )
                    .when(
                        (
                            col(column_name[2]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(f"{column_name[2]} has NULL or BLANK value."),
                    )
                    .otherwise(when(invalid_values.isNotNull(), lit(error_message))),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

        # Setting up the rest of the columns
        detailed_report_df = (
            detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
            .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
            .withColumn("SOURCE_SYSTEM", lit(source_db))
            .withColumn("TABLE_NAME", lit(source_table))
            .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
            .withColumn(
                "ERROR_CODE",
                when(col("ERROR_MESSAGE") == error_message, lit("110")).otherwise(
                    lit("111")
                ),
            )
            .withColumn(
                "INVALID_VALUE",
                concat_ws(
                    " | ",
                    when(col(column_name[0]).isNull(), lit("NULL")).otherwise(
                        date_format(col(column_name[0]), timestamp_format)
                    ),
                    when(col(column_name[1]).isNull(), lit("NULL")).otherwise(
                        date_format(col(column_name[1]), timestamp_format)
                    ),
                    when(col(column_name[2]).isNull(), lit("NULL")).otherwise(
                        date_format(col(column_name[2]), timestamp_format)
                    ),
                ),
            )
            .withColumn("AS_ON_DATE", lit(load_to_date))
            .withColumn(
                "DQ_GENERATION_DATE",
                lit(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                ),
            )
            .select(
                "ETL_AUDIT_ID",
                "DQ_NAME",
                "DQ_COLUMN_NAME",
                "SOURCE_SYSTEM",
                "TABLE_NAME",
                "PRIMARY_KEY",
                "PRIMARY_KEY_VALUE",
                "INVALID_VALUE",
                "ETL_CHANGE_FLAG",
                "ERROR_MESSAGE",
                "ERROR_CODE",
                "AS_ON_DATE",
                "DQ_GENERATION_DATE",
            )
        )

        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC column should not contain null and blank values

# COMMAND ----------

# The rule checks for null and blank values in the clumn1. The rule can be customised if we want to check only for null or blanks or both.
def dq_null_and_blank_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    detailed_report_df = None
    try:
        # Fetching dq_rule_parameters
        rule_param_json = json.loads(dq_rule_parameters)

        # Extract column_name list
        column_name = rule_param_json.get("column_name", [])
        required_checks = rule_param_json.get("required_checks", [])
        uppercased_values = [value.upper() for value in required_checks]
        if any(col is None or col == "" for col in column_name) or not all(
            value in ["NULL", "BLANK"] for value in uppercased_values
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            if (
                len(required_checks) > 1
            ):  # Check if required_checks has at least two elements
                if uppercased_values[0] == "NULL" and uppercased_values[1] == "BLANK":

                    error_message = f"{column_name[0]} has NULL or BLANK value."

                    # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid values
                    detailed_report_df = (
                        df.withColumn(
                            "PRIMARY_KEY_VALUE",
                            when(
                                (
                                    col(column_name[0]).isNull()
                                    | (trim(col(column_name[0])) == "")
                                ),
                                lit(concat_ws(" | ", *business_key)),
                            ).otherwise(None),
                        )
                        .withColumn(
                            "ERROR_MESSAGE",
                            when(
                                (
                                    col(column_name[0]).isNull()
                                    | (trim(col(column_name[0])) == "")
                                ),
                                lit(f"{column_name[0]} has NULL or BLANK value."),
                            ).otherwise(None),
                        )
                        .filter(col("ERROR_MESSAGE").isNotNull())
                    )

            elif uppercased_values[0] == "NULL":

                error_message = f"{column_name[0]} has null value."

                # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid values
                detailed_report_df = (
                    df.withColumn(
                        "PRIMARY_KEY_VALUE",
                        when(
                            (col(column_name[0]).isNull()),
                            lit(concat_ws(" | ", *business_key)),
                        ).otherwise(None),
                    )
                    .withColumn(
                        "ERROR_MESSAGE",
                        when(
                            (col(column_name[0]).isNull()),
                            lit(f"{column_name[0]} has null value."),
                        ).otherwise(None),
                    )
                    .filter(col("ERROR_MESSAGE").isNotNull())
                )

            elif uppercased_values[0] == "BLANK":

                error_message = f"{column_name[0]} has blank value."

                # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid values
                detailed_report_df = (
                    df.withColumn(
                        "PRIMARY_KEY_VALUE",
                        when(
                            (trim(col(column_name[0])) == ""),
                            lit(concat_ws(" | ", *business_key)),
                        ).otherwise(None),
                    )
                    .withColumn(
                        "ERROR_MESSAGE",
                        when(
                            (trim(col(column_name[0])) == ""),
                            lit(f"{column_name[0]} has blank value."),
                        ).otherwise(None),
                    )
                    .filter(col("ERROR_MESSAGE").isNotNull())
                )

        detailed_report_df = (
            detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
            .withColumn("INVALID_VALUE", col(column_name[0]).cast("string"))
            .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
            .withColumn("SOURCE_SYSTEM", lit(source_db))
            .withColumn("TABLE_NAME", lit(source_table))
            .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
            .withColumn(
                "ERROR_CODE", when(col("ERROR_MESSAGE") == error_message, lit("111"))
            )
            .withColumn("AS_ON_DATE", lit(load_to_date))
            .withColumn(
                "DQ_GENERATION_DATE",
                lit(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                ),
            )
            .select(
                "ETL_AUDIT_ID",
                "DQ_NAME",
                "DQ_COLUMN_NAME",
                "SOURCE_SYSTEM",
                "TABLE_NAME",
                "PRIMARY_KEY",
                "PRIMARY_KEY_VALUE",
                "INVALID_VALUE",
                "ETL_CHANGE_FLAG",
                "ERROR_MESSAGE",
                "ERROR_CODE",
                "AS_ON_DATE",
                "DQ_GENERATION_DATE",
            )
        )

        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC if 3 columns has 3 values then there should be a value in fourth column

# COMMAND ----------

# The rule will check if date values in Column1, column2 & column3 Is not null, then isloanclosed is not null
def dq_is_closed_date_mandatory_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        # Extracting required parameters
        rules_parameters = json.loads(dq_rule_parameters)
        column_name = rules_parameters.get("column_name", [])

        # Check if column_name is None, empty, or invalid
        if any(col is None or col == "" for col in column_name):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            # Filtering  to identify to invalid records
            invalid_records = df.filter(
                (
                    col(column_name[0]).isNotNull()
                    | col(column_name[1]).isNotNull()
                    | col(column_name[2]).isNotNull()
                )
                & col(column_name[3]).isNull()
            )

            # setting up error message
            error_message = f"if {column_name[0]} or {column_name[1]} or {column_name[2]} is not null or blank then {column_name[3]} should not be null or blank."

            detailed_report_df = (
                invalid_records.withColumn(
                    "PRIMARY_KEY_VALUE", concat_ws(" | ", *business_key)
                )
                .withColumn("ERROR_MESSAGE", lit(error_message))
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("112")),
                )
                .withColumn(
                    "INVALID_VALUE",
                    concat_ws(
                        " | ",
                        when(col(column_name[0]).isNull(), lit("NULL")).otherwise(
                            date_format(col(column_name[0]), timestamp_format)
                        ),
                        when(col(column_name[1]).isNull(), lit("NULL")).otherwise(
                            date_format(col(column_name[1]), timestamp_format)
                        ),
                        when(col(column_name[2]).isNull(), lit("NULL")).otherwise(
                            date_format(col(column_name[2]), timestamp_format)
                        ),
                        when(col(column_name[3]).isNull(), lit("NULL")).otherwise(
                            col(column_name[3]).cast("string")
                        ),
                    ),
                )
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

            logger(
                logger_level_info,
                f"All data checks for the '{source_dq_rule_name}' DQ rule have been completed for the table: {source_table}.",
                execution_log_list,
                filename,
            )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# MAGIC %md
# MAGIC amount should be equal to princiapl+interset

# COMMAND ----------

# The rule will check for check sum where input column1 value is equals to (or any other operator) summation of values in column2 & column3.
def dq_amount_consistency_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameter,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        rules_parameter = json.loads(dq_rule_parameter)
        column_name = rules_parameter.get("column_name", [])
        comparison_operator = rules_parameter.get("comparison_operator", [])
        additional_filters = rules_parameter.get("additional_filters", [])

        # Check if column_name or comparison_operator is None, empty, or invalid
        if (
            any(col is None or col == "" for col in column_name)
            or any(col is None or col == "" for col in additional_filters)
            or any(op is None or op == "" for op in comparison_operator)
            or any(op not in dir(operator) for op in comparison_operator)
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            # Apply additional filters to the DataFrame based on the provided filters.
            filtered_df = df
            for filter_item in additional_filters:
                key = filter_item.get("key")
                values = filter_item.get("value")
                if key and values:
                    values_lower = [val.lower() for val in values]
                    filtered_df = filtered_df.filter(lower(col(key)).isin(values_lower))

            # Check if Amount is same as principal+interset or not
            invalid_values = when(
                getattr(operator, comparison_operator[0])(
                    col(column_name[0]), col(column_name[1]) + col(column_name[2])
                ),
                col(column_name[0]),
            ).otherwise(None)

            error_message = (
                f"{column_name[0]} not equal to {column_name[1]} + {column_name[2]}."
            )

            # Conditionally populate PRIMARY_KEY_VALUE and ERROR_MESSAGE columns based on the amount check
            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(invalid_values.isNotNull(), concat_ws(" | ", *business_key)),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(invalid_values.isNotNull(), lit(error_message)).otherwise(
                        None
                    ),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("113")),
                )
                .withColumn(
                    "INVALID_VALUE",
                    concat_ws(
                        " | ",
                        col(column_name[0]).cast("string"),
                        col(column_name[1]).cast("string"),
                        col(column_name[2]).cast("string"),
                    ),
                )
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

            logger(
                logger_level_info,
                f"All data check for DQ_amount_consistency_check dq rule has been done for table : {source_table}",
                execution_log_list,
                filename,
            )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in DQ_amount_consistency_check dq rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in DQ_amount_consistency_check dq rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# The Rule will check the relation between the date values in column1 & column2 with the input operator.
def dq_date_relation_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):

    try:
        # Extracting rule parameters
        rules_parameter = json.loads(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        comparison_operator = rules_parameter.get("comparison_operator", [])
        comparison_format = rules_parameter.get("comparison_format", [])

        # Check if column_name or comparison_operator is None, empty, or invalid
        if (
            any(col is None or col == "" for col in column_name)
            or any(col is None or col == "" for col in comparison_format)
            or any(op is None or op == "" for op in comparison_operator)
            or any(op not in dir(operator) for op in comparison_operator)
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            # Example comparison operator
            operator_full_form = lookup_for_comparison_operator.get(
                comparison_operator[0]
            )

            if comparison_format[0] == "date":
                # Constructing the INVALID_VALUE column
                invalid_values = when(
                    getattr(operator, comparison_operator[0])(
                        to_date(col(column_name[0])), to_date(col(column_name[1]))
                    ),
                    col(column_name[0]),
                ).otherwise(None)

            elif comparison_format[0] == "datetime":
                # Constructing the INVALID_VALUE column
                invalid_values = when(
                    getattr(operator, comparison_operator[0])(
                        col(column_name[0]), col(column_name[1])
                    ),
                    col(column_name[0]),
                ).otherwise(None)

            error_message = f"{column_name[0]} is {operator_full_form} {column_name[1]}"

            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    )
                    .when(
                        (
                            col(column_name[1]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    )
                    .otherwise(
                        when(
                            invalid_values.isNotNull(), concat_ws(" | ", *business_key)
                        )
                    ),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(f"{column_name[0]} has NULL or BLANK value."),
                    )
                    .when(
                        (
                            col(column_name[1]).isNull()
                            | (trim(col(column_name[1])) == "")
                        ),
                        lit(f"{column_name[1]} has NULL or BLANK value."),
                    )
                    .otherwise(when(invalid_values.isNotNull(), lit(error_message))),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn("PRIMARY_KEY_VALUE", col("PRIMARY_KEY_VALUE"))
                .withColumn("ERROR_MESSAGE", col("ERROR_MESSAGE"))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE").rlike(error_message), lit("114")).otherwise(
                        lit("111")
                    ),
                )
                .withColumn(
                    "INVALID_VALUE",
                    concat_ws(
                        " | ",
                        when(col(column_name[0]).isNull(), lit("NULL")).otherwise(
                            date_format(col(column_name[0]), timestamp_format)
                        ),
                        when(col(column_name[1]).isNull(), lit("NULL")).otherwise(
                            date_format(col(column_name[1]), timestamp_format)
                        ),
                    ),
                )
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

            logger(
                logger_level_info,
                f"All data checks for the '{source_dq_rule_name}' DQ rule have been completed for the table: {source_table}.",
                execution_log_list,
                filename,
            )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# The rule check compares the value in column 1 with the input operator with the inout required value.
def dq_value_relation_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):
    try:
        # Extracting required parameters
        rules_parameter = json.loads(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])
        comparison_operator = rules_parameter.get("comparison_operator", [])
        lower_comparison_operator = [str(op).lower() for op in comparison_operator]
        required_value = rules_parameter.get("required_value", [])

        # Check if column_name or comparison_operator is None, empty, or invalid
        if (
            any(col is None or col == "" for col in column_name)
            or any(op is None or op == "" for op in comparison_operator)
            or any(op not in dir(operator) for op in comparison_operator)
        ):
            logger(
                logger_level_info,
                f"the input parameters has a invalid value for {source_dq_rule_name} please check the parameters config : {source_table}",
                execution_log_list,
                filename,
            )
        else:
            required_value_decimal = Decimal(required_value[0])
            # Create invalid_values condition
            invalid_values = when(
                getattr(operator, lower_comparison_operator[0])(
                    col(column_name[0]), lit(required_value_decimal)
                ),
                col(column_name[0]),
            ).otherwise(None)
            operator_full_form = lookup_for_comparison_operator.get(
                comparison_operator[0]
            )

            # Setting error message based on the presence of invalid records
            error_message = (
                f"{column_name[0]} is {operator_full_form} {required_value[0]}."
            )

            # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid values
            detailed_report_df = (
                df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(concat_ws(" | ", *business_key)),
                    ).otherwise(
                        when(
                            invalid_values.isNotNull(), concat_ws(" | ", *business_key)
                        )
                    ),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(
                        (
                            col(column_name[0]).isNull()
                            | (trim(col(column_name[0])) == "")
                        ),
                        lit(f"{column_name[0]} has NULL or BLANK value."),
                    ).otherwise(when(invalid_values.isNotNull(), lit(error_message))),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("115")).otherwise(
                        lit("111")
                    ),
                )
                .withColumn("INVALID_VALUE", col(column_name[0]).cast("string"))
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df

# COMMAND ----------

# The rule will check for the invalid aadhar numbers in the input column name. It will check that the column should have only 12 digits and all 12 digits cannot have same value
def dq_aadhar_check(
    df,
    source_db,
    source_table,
    source_dq_rule_name,
    dq_rule_parameters,
    business_key,
    load_to_date,
    column_to_exclude_frm_scd,
):

    try:
        # Extracting required parameters from JSON
        rules_parameter = ast.literal_eval(dq_rule_parameters)
        column_name = rules_parameter.get("column_name", [])

        # Check if column_name or pattern is None or empty
        if column_name[0] is None or column_name[0] == "":
            logger(
                logger_level_info,
                f"Invalid input parameters for DQ rule {source_dq_rule_name}. Please check the parameters config for table {source_table}",
                execution_log_list,
                filename,
            )
        else:
            # Filter the DataFrame to get matching records
            pattern = r"^(?!(\d)\1{11})\d{12}$"
            filter_condition = ~col(column_name[0]).rlike(pattern)
            non_matching_records_df = df.filter(filter_condition)

            # Setting error message based on the presence of invalid records
            error_message = f"The value in column {column_name[0]} does not match the required pattern."

            # Conditionally populate INVALID_VALUE and ERROR_MESSAGE columns based on invalid records
            detailed_report_df = (
                non_matching_records_df.withColumn(
                    "PRIMARY_KEY_VALUE",
                    when(
                        filter_condition.isNotNull(),
                        concat_ws(" | ", *business_key),
                    ).otherwise(None),
                )
                .withColumn(
                    "ERROR_MESSAGE",
                    when(filter_condition.isNotNull(), lit(error_message)).otherwise(
                        None
                    ),
                )
                .filter(col("ERROR_MESSAGE").isNotNull())
            )

            # Adding additional columns to detailed_report_df
            detailed_report_df = (
                detailed_report_df.withColumn("DQ_NAME", lit(source_dq_rule_name))
                .withColumn("DQ_COLUMN_NAME", lit(" | ".join(column_name)))
                .withColumn("SOURCE_SYSTEM", lit(source_db))
                .withColumn("TABLE_NAME", lit(source_table))
                .withColumn("PRIMARY_KEY", lit(" | ".join(business_key)))
                .withColumn(
                    "ERROR_CODE",
                    when(col("ERROR_MESSAGE") == error_message, lit("116")),
                )
                .withColumn("INVALID_VALUE", col(column_name[0]).cast("string"))
                .withColumn("AS_ON_DATE", lit(load_to_date))
                .withColumn(
                    "DQ_GENERATION_DATE",
                    lit(
                        datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                    ),
                )
                .select(
                    "ETL_AUDIT_ID",
                    "DQ_NAME",
                    "DQ_COLUMN_NAME",
                    "SOURCE_SYSTEM",
                    "TABLE_NAME",
                    "PRIMARY_KEY",
                    "PRIMARY_KEY_VALUE",
                    "INVALID_VALUE",
                    "ETL_CHANGE_FLAG",
                    "ERROR_MESSAGE",
                    "ERROR_CODE",
                    "AS_ON_DATE",
                    "DQ_GENERATION_DATE",
                )
            )

        # Logging completion of DQ pattern check
        logger(
            logger_level_info,
            f"All data checks for the {source_dq_rule_name} DQ rule have been completed for the table: {source_table}.",
            execution_log_list,
            filename,
        )
    except Exception as e:
        # Call the logger function with a log level and message
        logger(
            logger_level_error,
            f"An error occurred in the {source_dq_rule_name} DQ rule function.",
            execution_log_list,
            filename,
        )
        print(*execution_log_list, sep="\n")
        raise Exception(
            f"An error occurred in the {source_dq_rule_name} DQ rule function.", e
        )

    return df, detailed_report_df