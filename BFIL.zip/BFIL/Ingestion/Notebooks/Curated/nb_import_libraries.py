# Databricks notebook source
# Importing required libraries
from pyspark.sql.functions import col, lit, when, count, date_format, concat_ws, collect_list, trim, split, lower, concat, length, array, date_diff, to_date, unix_timestamp, from_unixtime, upper, to_timestamp, explode, explode_outer, regexp_extract, regexp_replace, regexp_extract_all, from_json, create_map, monotonically_increasing_id, first, json_tuple, row_number, sha2
from pyspark.sql.window import Window
import re, json, hashlib, ast, inspect, pytz, time, operator
from datetime import datetime, timedelta
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType, DoubleType, BooleanType, DateType, TimestampType, ArrayType, MapType, ByteType, ShortType, LongType, DecimalType
from delta.tables import DeltaTable
from inspect import currentframe, getframeinfo
from decimal import Decimal
import zipfile
from io import BytesIO
import io
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from concurrent.futures import ThreadPoolExecutor