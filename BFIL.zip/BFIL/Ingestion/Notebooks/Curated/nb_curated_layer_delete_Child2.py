# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

table_name = dbutils.widgets.get("table_name").lower()
curated_schema = dbutils.widgets.get("curated_schema")

# COMMAND ----------

df2 = spark.sql(f"""select DATEADD(CAST(DATEADD(minute,30,DATEADD(hour,5,CURRENT_TIMESTAMP)) AS DATE),-2);""")
df3 = spark.sql(f"""select CAST(DATEADD(minute,30,DATEADD(hour,5,CURRENT_TIMESTAMP)) AS DATE);""")
load_to_date = str(df2.collect()[0][0]) + 'T23:59:59Z'
current_ts = df3.collect()[0][0]

# COMMAND ----------

try:
    update_df = spark.sql(f"""
                          Update {curated_schema}.`azuresource-p_backdated_deletedrecords` set Status = 'SUCCESS',StatusUpdatedOn = {current_ts} where Status = 'Pending' and Curated_Table_Name in ({table_name}); 
                          """)
except Exception as e:
    raise Exception(f"An unexpected error occurred:", e)

# COMMAND ----------

try:
    update_df = update_df.toPandas()
    # Convert Pandas DataFrame to JSON
    df_json = update_df.to_json(orient="records")    
    # Convert JSON string to a dictionary
    df_dict = json.loads(df_json)
    dbutils.notebook.exit({"Updated the status for the deletion handling for the tables {table_name} with the following records:": df_dict})
except Exception as e:
    print(f"An error occurred while providing the output from the notebook: {str(e)}")

# COMMAND ----------

# MAGIC %md
# MAGIC