# Databricks notebook source
filename="nb_curated_cb_equifax"
def equifax_util_select(df_equifax, *select_expr, drop_cols=None):
    try:
        # Apply select expression
        try:
            df_equifax = df_equifax.select("SK",*select_expr)
        except Exception as e:
            df_equifax = df_equifax.select(*select_expr)
        # Drop columns if specified
        if drop_cols:
            df_equifax = df_equifax.drop(*drop_cols)
        else:
            pass
            
    except Exception as e:
        logger(logger_level_error, "dataframe has no data ", execution_log_list,filename)
        print(f"An error occurred: {e}")
        df_equifax = None
    return df_equifax

# COMMAND ----------

def equifax_utils_union(df_equifax, tag_list):
    df_default = None
    for col in tag_list:
        try:

            df_new = df_equifax.select("SK", f"{col}.*")
            columns_to_check = [col_name for col_name in df_new.columns if col_name != "SK"]

            condition = " AND ".join(f"({col_name} != '' OR {col_name} IS NOT NULL)" for col_name in columns_to_check)
       
            df_new = df_new.filter(condition)
            df_new=df_new.withColumn("Type", lit(col))

           
        except:
            df_new = df_equifax.select("SK",f"EquifaxScore.{col}.Score.*")
            columns_to_check = [col_name for col_name in df_new.columns if col_name != "SK"]

            condition = " AND ".join(f"({col_name} != '' OR {col_name} IS NOT NULL)" for col_name in columns_to_check)
       
            df_new = df_new.filter(condition)
            df_new=df_new.withColumn("Type", lit(col))
            
        if df_default is None:
            df_default = df_new
        else:
            df_default = df_default.union(df_new)
    return df_default

# COMMAND ----------

def equifax_InquiryRequestInfo(df_equifax):
    try:
        if df_equifax is not None:
            df_inquriyrequest=df_equifax.select("SK","InquiryRequestInfo.*")

            df_inquriyrequest=df_inquriyrequest.select("*","RequestAccountDetails.*").drop("FamilyDetails","InquiryAddresses","InquiryCommonAccountDetails","InquiryPhones","RequestAccountDetails","_xmlns")
            
            return df_inquriyrequest
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in InquiryRequest : {e} " ,execution_log_list,filename)
        return None

# COMMAND ----------

#identityinfo
def equifax_Identityinfo(df_equifax):
    try:
        df_result = None
        if df_equifax is not None:
            df_reportdata=equifax_util_select(df_equifax,"ReportData.*", drop_cols=["_xmlns"])
            
            df_id=df_reportdata.select("SK","IDAndContactInfo.IdentityInfo.*")
            for col_name in [item for item in df_id.columns if item != 'SK']:
                df_new = df_id.select("SK", f"{col_name}.*").withColumn("Type", lit(col_name))
                if df_result is None:
                    df_result = df_new
                else:
                    df_result = df_result.union(df_new)
            df_result=df_result.drop("_seq")
            df_result = df_result.filter(col("IdNumber").isNotNull())
           
            return df_result
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        print(f"Error in identityinfo : {e}")
        logger(logger_level_error, f"Error in identityinfo : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

#accountsummary
def equifax_AccountSummary(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=equifax_util_select(df_equifax,"ReportData.*","InquiryResponseHeader.CustRefField", drop_cols=["_xmlns"])
            df_accountsummary=df_reportdata.select("SK","CustRefField","AccountsSummary.ConsolidateCreditSummary.*")
            colList = ["Retail", "OverAll", "Microfinance"]
            for colname in colList:
                tempL = df_accountsummary.select(f"{colname}.*").columns
                
                for col_name in tempL:
                    prefix = "_Rtl" if colname == colList[0] else "_OverAll" if colname == colList[1] else "_Mfi"
                    df_accountsummary = df_accountsummary.select("*",f"{colname}.*")
                  
                    df_accountsummary = df_accountsummary.withColumnRenamed(col_name, f"{col_name}{prefix}").drop(*tempL)
            df_accountsummary=df_accountsummary.drop("Retail", "OverAll", "Microfinance")
            return df_accountsummary
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in AccountSummary : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def equifax_Accounthistory(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=equifax_util_select(df_equifax,"ReportData.*", drop_cols=["_xmlns"])
            df_mfi=equifax_util_select(df_reportdata.select("SK",explode("Accounts.Microfinances.Account").alias("mfi_account")),"mfi_account.*",drop_cols=["_seq"])
            df_retails =equifax_util_select(df_reportdata.select("SK",explode("Accounts.Retails.Account").alias("Retails_account")),"Retails_account.*",drop_cols=["_seq"])
        
            microfinances_df = (
                df_mfi.select("SK","AccountNumber",explode("History24Months.Month").alias("month"))
                .select("SK","AccountNumber","month.*")
                .withColumn("Type", lit("MFI"))
               
            )
         
            retail_df = (
                df_retails.select("SK","AccountNumber",explode("History48Months.Month").alias("month"))
                .select("SK","AccountNumber","month.*")
                .withColumn("Type", lit("RTL"))
                
            )
           
            if microfinances_df is not None and retail_df is not None:
                df_accounthistory = microfinances_df.union(retail_df)
            elif microfinances_df is not None:
                df_accounthistory = microfinances_df
            elif retail_df is not None:
                df_accounthistory = retail_df
            else:
                df_accounthistory = None
          
            return df_accounthistory

        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list, filename)
    except Exception as e:
        print( f"Error in Accounthistory : {e} ")
        logger(logger_level_error, f"Error in Accounthistory : {e} ", execution_log_list, filename)
        return None


# COMMAND ----------


def equifax_Microfinance(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=equifax_util_select(df_equifax,"ReportData.*","InquiryResponseHeader.CustRefField", drop_cols=["_xmlns"])
            df_mfi=equifax_util_select(df_reportdata.select("SK","CustRefField",explode("Accounts.Microfinances.Account").alias("mfi_account")),"CustRefField","mfi_account.*",drop_cols=["_seq"])
            selected_columns = [col(column) for column in df_mfi.columns if column not in ["KeyPerson", "Nominee", "History24Months", "AdditionalMFIDetails", "_seq"]]
            # Select nested struct columns using wildcard '*' and alias them appropriately
            selected_columns.extend([col("AdditionalMFIDetails.MFIIdentification.*"),
                                    col("KeyPerson.Name").alias("KeyPerson_nm"),
                                    col("KeyPerson.RelationType").alias("KeyPerson_RelationType"),
                                    col("Nominee.Name").alias("Nominee_nm"),
                                    col("Nominee.RelationType").alias("Nominee_RelationType")])
            df_microfinance = df_mfi.select(selected_columns)
            return df_microfinance
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_error, f"Error in Microfinanace : {e} " ,execution_log_list,filename)
        return None
