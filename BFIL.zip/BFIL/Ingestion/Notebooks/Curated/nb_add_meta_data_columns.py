# Databricks notebook source
# Extra columns has been added into source data frame based on requirement.
def add_meta_data_into_source_df(source_data_df, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, load_to_date, business_key) :

    # Declaring the notebook name
    filename = 'nb_add_meta_data_columns.dbc'

    try :
        # Defining current timestamp
        current_timestamp = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

        # Define current ETL User ID
        etl_user_id = spark.sql('SELECT current_user() AS user').collect()[0]['user']

        # Get all columns except those specified in column_to_exclude_frm_scd
        selected_columns = [col_name for col_name in source_data_df.columns if col_name not in column_to_exclude_frm_scd]

        # Concatenate values from selected columns into a single string
        concatenated_string_column = concat_ws("|", *[col(col_name) for col_name in selected_columns])

        # If necessary, handle different save types (SCD-1, SCD-2, etc.)
        if (dest_save_type == "SCD-1") or (dest_save_type == "SCD-2"):
            # Generate SHA-256 hash for the concatenated string
            source_df = source_data_df.withColumn("ETL_HASH_COL", sha2(concatenated_string_column, 256))
        else:
            source_df = source_data_df.withColumn("ETL_HASH_COL", lit(None).cast("string"))

        # Adding additional meta data columns and default values to the source data frame 
        source_data_df = source_df.withColumn("ETL_CHANGE_FLAG", lit("I"))\
                                        .withColumn("ETL_DQ_FINAL_STATUS", lit("1"))\
                                        .withColumn("ETL_DQ_ERROR", lit(None).cast("string"))\
                                        .withColumn("ETL_EXEC_LOG_ID", lit(exec_log_id).cast("string"))\
                                        .withColumn("ETL_CREATED_BY", lit(etl_user_id))\
                                        .withColumn("ETL_CREATED_DATE", lit(current_timestamp))\
                                        .withColumn("ETL_LAST_UPDATED_BY", lit(etl_user_id))\
                                        .withColumn("ETL_LAST_UPDATED_DATE", lit(current_timestamp))\
                                        .withColumn("ETL_AUDIT_ID", lit(pipeline_run_id).cast("string"))\
                                        .withColumn("ETL_IS_ACTIVE",lit("1"))
        
        if dest_save_type == "SCD-1" :

            # Check if the table is a history table
            if object_name != target_object_name:
          
                # Update effective_from_date minus 1 day of load_to_date
                new_time = datetime.strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=1)
                load_to_date_minus_one_day = new_time.strftime('%Y-%m-%dT%H:%M:%SZ')

                source_data_df = source_data_df.withColumn("ETL_IS_ACTIVE",lit("0"))\
                    .withColumn("ETL_CHANGE_FLAG", lit("U"))\
                    .withColumn("ETL_EFFECTIVE_FROM_DATE", lit("1990-01-01T00:00:00Z"))\
                    .withColumn("ETL_EFFECTIVE_TO_DATE", lit(load_to_date_minus_one_day))

        if dest_save_type == "SCD-2" :

            # Update effective_from_date as 1990-01-01T00:00:00Z
            source_data_df = source_data_df.withColumn("ETL_EFFECTIVE_FROM_DATE", lit("1990-01-01T00:00:00Z"))\
                                            .withColumn("ETL_EFFECTIVE_TO_DATE", lit("9999-12-31T23:59:59Z"))

        return source_data_df
    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"An error occurred while creating a DataFrame from input files with metadata columns.", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception(f"An unexpected error occurred:", e)