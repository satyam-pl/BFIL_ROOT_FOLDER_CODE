# Databricks notebook source
# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

table_name = dbutils.widgets.get("table_name")
scd_type = dbutils.widgets.get("scd_type")
pk_col = dbutils.widgets.get("pk_col")
pk_values = dbutils.widgets.get("pk_values")
curated_schema = dbutils.widgets.get("curated_schema")

# COMMAND ----------

df2 = spark.sql(f"""select DATEADD(CAST(DATEADD(minute,30,DATEADD(hour,5,CURRENT_TIMESTAMP)) AS DATE),-2);""")
df3 = spark.sql(f"""select CAST(DATEADD(minute,30,DATEADD(hour,5,CURRENT_TIMESTAMP)) AS DATE);""")
load_to_date = str(df2.collect()[0][0]) + 'T23:59:59Z'
current_ts = df3.collect()[0][0]

# COMMAND ----------

try:
    if scd_type == 'SCD-1':
        #Deactivating the records in the delta table
        update_df = spark.sql(f"""
                          Update {table_name} set etl_is_active = '0',ETL_CHANGE_FLAG = 'D' where {pk_col} in ({pk_values}) and etl_is_active = '1'; 
                          """)
    elif scd_type == 'SCD-2':
        #Deactivating the records in the delta table
        update_df = spark.sql(f"""
                          Update {table_name} set etl_is_active = '0',etl_change_flag = 'D',etl_effective_to_date = '{load_to_date}' where {pk_col} in ({pk_values}) and etl_is_active = '1'; 
                          """)
except Exception as e:
    raise Exception(f"An unexpected error occurred:", e)

# COMMAND ----------

try:
    update_df = update_df.toPandas()
    # Convert Pandas DataFrame to JSON
    df_json = update_df.to_json(orient="records")    
    # Convert JSON string to a dictionary
    df_dict = json.loads(df_json)
    dbutils.notebook.exit({"Updated the ETL_IS_ACTIVE for the table {table_name} with the following records:": df_dict})
except Exception as e:
    print(f"An error occurred while providing the output from the notebook: {str(e)}")

# COMMAND ----------

# MAGIC %md
# MAGIC