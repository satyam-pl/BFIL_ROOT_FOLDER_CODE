# Databricks notebook source
filename='nb_curated_cb_main_function.dbc'
def extract_string_columns(df):
    try:
        string_columns = []
        for field in df.schema.fields:
            if isinstance(field.dataType, StringType):
                string_columns.append(field.name)
        return string_columns
    except Exception as e:
        logger(logger_level_error, f"Error occurred during:extract_string_columns", execution_log_list, filename)
        raise Exception("Error occurred during execution", str(e))
        return None


# COMMAND ----------

def date_retrieval_func(source_path,other_info_02):
    try:
        flag = 0
        
        # Regex pattern to match the cutoff date in other_info_02
        pattern_other_info02 = r'\b\d{2}-\d{2}-\d{4}\b'
       
        match_other_info02 = re.search(pattern_other_info02, other_info_02)
        logger(logger_level_info, f"{match_other_info02}", execution_log_list, filename)
 
        
        if match_other_info02:
            cutoff_date_str = match_other_info02.group(0)
            cutoff_date = datetime.strptime(cutoff_date_str, "%m-%d-%Y")
        else:
            raise Exception("No valid cutoff date found in other_info_02")
            
        # List files in the source path
        file_list = dbutils.fs.ls(source_path)
        
        # Iterate over the file list
        for file_info in file_list:

            # Check if the file is a zip file
            if file_info.name.endswith(".zip"):
                pattern = r'\d{8}'  # Matches 8 digits together

                match = re.search(pattern, file_info.name)
                
                if match:
                    # Extract the matched date
                    date_str = match.group(0)
                    
             
                    # Format the date as MM-DD-YYYY
                    formatted_date = f"{date_str[0:2]}-{date_str[2:4]}-{date_str[4:8]}"
                    file_date = datetime.strptime(formatted_date, "%m-%d-%Y")
                    logger(logger_level_info, f"file_date={file_date}", execution_log_list, filename)
                    
                    if file_date <= cutoff_date:
                        flag = 1
                        return flag
                else:
                    logger(logger_level_info, "No date pattern found in the zip file name.", execution_log_list, filename)
                   
             
        return flag
    except Exception as e:
        logger(logger_level_error, f"Error occurred during:date_retrieval_func", execution_log_list, filename)
        raise Exception("Error occurred during execution", str(e))
        return None


# COMMAND ----------

def fillwithNone(df):
    for c in df.columns:
        df = df.withColumn(c, when((col(c) == "") | (col(c) == ''), None).otherwise(col(c)))
    return df

# COMMAND ----------


def main_crif(df_crif,desti_path):
    try:

        spark.sql(f"USE {adb_curated_catlog_schema}")
        instant_function_names =["crif_util_select","crif_Contact", "crif_Relation", "crif_Groupdetails", "crif_Variation", "crif_Loan_details", "crif_Ids", "crif_Responselist", "crif_Response", "crif_Comment"]
        
        tags = {
            "crif_Header": (df_crif,"HEADER.*","TYPE",[]),
            "crif_Request": (df_crif, 'REQUEST.*', ["IDS", "ADDRESSES", "PHONES", "EMAILS"]),
            "crif_ALERT": (df_crif,'ALERTS.ALERT.*',[]),
            "crif_Inquiryhistory": (df_crif.select("SK",explode("INQUIRY-HISTORY.HISTORY").alias("history")),"history.*",[]),
            "crif_linked_accounts": (df_crif.select("SK", explode("RESPONSES.RESPONSE").alias("response")).select("SK",explode( "response.LOAN-DETAILS.LINKED-ACCOUNTS.ACCOUNT-DETAILS").alias("linkedaccountdetails")),"linkedaccountdetails.*",[]),
            "crif_Score": (df_crif,"SCORES.SCORE.*",[]),
            "crif_securitydetails": (df_crif.select("SK", explode("RESPONSES.RESPONSE.LOAN-DETAILS.SECURITY-DETAILS.SECURITY-DETAIL").alias("Security_details")).select("SK", explode("Security_details").alias("Security_detail_new")),"Security_detail_new.*",[]),
            "crif_Account_Summary" : (df_crif.select("SK","ACCOUNTS-SUMMARY.*"),"DERIVED-ATTRIBUTES.*","PRIMARY-ACCOUNTS-SUMMARY.*","SECONDARY-ACCOUNTS-SUMMARY.*",[]),
            "crif_Secondary_Matches": (df_crif,"SECONDARY-MATCHES.*",[]),
            "crif_statusdetails": (df_crif.select("SK",explode("STATUS-DETAILS.STATUS").alias("status")),"status.ERRORS.ERROR.*","status.*",["ERRORS"]),
        }

        for function_name in instant_function_names:
            try:
                function = globals()[function_name]
                if function_name == "crif_util_select":
                    for tag_name, (df, *tag_args, drop_cols) in tags.items():
                        df_result = crif_util_select(df, *tag_args, drop_cols=drop_cols)
                        if df_result is not None:
                            df_result = df_result.dropna(subset=[col_name for col_name in df_result.columns if col_name != "SK"], how='all')
                            
                            string_columns = extract_string_columns(df_result)
                            df_result = df_result.dropDuplicates()
                            df_result =df_result.select(*[regexp_replace(c, '\\\\', '').alias(c) if c in string_columns else col(c) for c in df_result.columns])
                            df_result = df_result.select(*[col(c).alias(c.replace("-", "_").lstrip("_")) for c in df_result.columns])


                            
                
                            source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, load_to_date, "business_key")
                            new_table_name=f"{tag_name}"
                            new_table_name=new_table_name.upper()
                            delta_path=desti_path+"/"+new_table_name
                        
                           

                            source_data_df = fillwithNone(source_data_df)
                            source_data_df.write.format("delta").mode("append").option("mergeSchema","true").option("path",delta_path).saveAsTable(new_table_name)

                            logger(logger_level_info, f"{new_table_name} table is created", execution_log_list, filename)
                        else:
                            logger(logger_level_error, f"{tag_name} doesn't have required columns.", execution_log_list, filename)
                            
                else:
                    df_result = function(df_crif)
                    if df_result is not None:
                        df_result=df_result.dropna(subset=[col_name for col_name in df_result.columns if col_name != "SK"],how='all')
                        string_columns = extract_string_columns(df_result)
                        df_result = df_result.dropDuplicates()
                        
                        df_result =df_result.select(*[regexp_replace(c, '\\\\', '').alias(c) if c in string_columns else col(c) for c in df_result.columns])
                        df_result = df_result.select(*[col(c).alias(c.replace("-", "_").lstrip("_")) for c in df_result.columns])
                        


                        source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, load_to_date, "business_key")
                        new_table_name = function_name
                        new_table_name=new_table_name.upper()
                        delta_path=desti_path+"/"+new_table_name
                        source_data_df = fillwithNone(source_data_df)
                        
                        source_data_df.write.format("delta").mode("append").option("mergeSchema","true").option("path",delta_path).saveAsTable(new_table_name)
                        logger(logger_level_info, f"{new_table_name} table is created", execution_log_list, filename)
                    else:
                        logger(logger_level_error, f"{function} doesn't have required columns.", execution_log_list, filename)
            except Exception as e:
                logger(logger_level_error, f"Error occurred during: {e}", execution_log_list, filename)
                raise Exception("Error occurred during execution", str(e))


    except Exception as e:
        logger(logger_level_error, f"Error occurred during execution: {e}", execution_log_list, filename)
        raise Exception("Error occurred during execution", str(e))


# COMMAND ----------

def main_equifax(df_equifax, desti_path):
    try:
        spark.sql(f"USE {adb_curated_catlog_schema}")
        df_request=equifax_util_select(df_equifax,"InquiryRequestInfo.*", drop_cols=["_xmlns"])
        df_reportdata=equifax_util_select(df_equifax,"ReportData.*", drop_cols=["_xmlns"])
        df_mfi=equifax_util_select(df_reportdata.select("SK",explode("Accounts.Microfinances.Account").alias("mfi_account")),"mfi_account.*",drop_cols=["_seq"])

        instant_function_names = [ "equifax_util_select","equifax_Identityinfo", "equifax_utils_union","equifax_InquiryRequestInfo","equifax_AccountSummary", "equifax_Accounthistory", "equifax_Microfinance"]
        tags = {
            "equifax_InquiryResponseHeader": (df_equifax, "InquiryResponseHeader.*","TYPE", ["_xmlns"]),
            "equifax_familydetails": (df_request.withColumn("additionaldetails", explode("FamilyDetails.AdditionalNameInfo")), "additionaldetails.*", ["_seq"]),
            "equifax_InquiryAddresses": (df_request, "InquiryAddresses.InquiryAddress.*", ["_seq"]),
            "equifax_InquiryPhones": (df_request, "InquiryPhones.InquiryPhone.*", ["_seq"]),
            "equifax_inquirycommonaccountDetails": (df_request, "InquiryCommonAccountDetails.InquiryAccount.*", ["_seq"]),
            "equifax_EmailAddressInfo": (df_reportdata, "IDAndContactInfo.EmailAddressInfo.*", ["_seq"]),
            "equifax_IncomeDetails":(df_reportdata.select("SK",explode("IncomeDetails").alias("incomedetails")), "incomedetails.*", ["_seq"]),
            "equifax_Enquiries": (df_reportdata.select("SK",explode("Enquiries").alias("enquiries")), "enquiries.*", ["_seq"]),
            "equifax_AddressInfo": (df_reportdata.select("SK",explode("IDAndContactInfo.AddressInfo").alias("addressinfo")), "addressinfo.*", ["_seq"]),
            "equifax_PhoneInfo":(df_reportdata.select("SK",explode("IDAndContactInfo.PhoneInfo").alias("phoneinfo")), "phoneinfo.*", ["_seq"]),
            "equifax_MfiAddress": (df_reportdata.select("SK",explode("Accounts.Microfinances.Account").alias("Account")).select("SK",explode("Account.AdditionalMFIDetails.MFIAddress.AdditionalAddressDetails").alias("Adidtionaladdressdetails")), "Adidtionaladdressdetails.*", ["_seq"]),
            "equifax_MfiPhone": (df_reportdata.select("SK",explode("Accounts.Microfinances.Account.AdditionalMFIDetails.Phone").alias("phone")).select("SK",explode("phone").alias("phonecol")), "phonecol.*", ["_seq"]),
            "equifax_Report_data": (df_reportdata, "IDAndContactInfo.PersonalInfo.*","IDAndContactInfo.PersonalInfo.Name.*","IDAndContactInfo.PersonalInfo.Age.*","IDAndContactInfo.PersonalInfo.AliasNameInfo.*","Error.*", ["Age","AliasNameInfo","Name"]),
            "equifax_Retails":(df_equifax.select("SK","InquiryResponseHeader.CustRefField","ReportData.*").select("SK","CustRefField",explode("Accounts.Retails.Account").alias("Retails_account")),"CustRefField","Retails_account.*",["History48Months","_seq"])
      
        }
        tags_for_union={
            "equifax_Relationship":(df_mfi, ["KeyPerson","Nominee"]),
            "equifax_Score":(df_reportdata,["MFI","Retail"])
        }
        for function_name in instant_function_names:
            try:
                function = globals()[function_name]
                
                if function_name == "equifax_util_select":
                    for tag_name, (df, *tag_args, drop_cols) in tags.items():
                        df_result = equifax_util_select(df, *tag_args, drop_cols=drop_cols)
                        if df_result is not None:
                            df_result=df_result.dropna(subset=[col_name for col_name in df_result.columns if col_name != "SK"],how='all')
                            string_columns = extract_string_columns(df_result)
                            df_result = df_result.dropDuplicates()
                            

                            df_result =df_result.select(*[regexp_replace(c, '\\\\', '').alias(c) if c in string_columns else col(c) for c in df_result.columns])
                            df_result = df_result.select(*[col(c).alias(c.replace("-", "_").lstrip("_")) for c in df_result.columns])

                            source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, load_to_date, "business_key")
                            new_table_name=f"{tag_name}"
                            
                            new_table_name=new_table_name.upper()
                            delta_path=desti_path+"/"+new_table_name

                            source_data_df = fillwithNone(source_data_df)                            
                            
                            source_data_df.write.format("delta").mode("append").option("mergeSchema","true").option("path",delta_path).saveAsTable(new_table_name)
                            logger(logger_level_info, f"{new_table_name} table is created", execution_log_list, filename)
                        else:
                            
                            logger(logger_level_error, f"{new_table_name} doesn't have required columns.", execution_log_list, filename)

                elif function_name == "equifax_utils_union":
                    for tag_name, (df, relation_list) in tags_for_union.items():
                        df_result = equifax_utils_union(df, relation_list)
                        if df_result is not None:
                            df_result=df_result.dropna(subset=[col_name for col_name in df_result.columns if col_name != "SK"],how='all')
                    
                            string_columns = extract_string_columns(df_result)
                            df_result = df_result.dropDuplicates()
                        
                            df_result =df_result.select(*[regexp_replace(c, '\\\\', '').alias(c) if c in string_columns else col(c) for c in df_result.columns])
                            df_result = df_result.select(*[col(c).alias(c.replace("-", "_").lstrip("_")) for c in df_result.columns])                          

                                
                            source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, load_to_date, "business_key")
                            new_table_name=f"{tag_name}"
                            new_table_name=new_table_name.upper()
                            delta_path=desti_path+"/"+new_table_name

                            source_data_df = fillwithNone(source_data_df)
                        
                            source_data_df.write.format("delta").mode("append").option("mergeSchema","true").option("path",delta_path).saveAsTable(new_table_name)
                            logger(logger_level_info, f"{new_table_name} table is created", execution_log_list, filename)
                        else:
                            logger(logger_level_error, f"Operation doesn't have required columns.", execution_log_list, filename)
                    
                else:
                    df_result = function(df_equifax)
                    if df_result is not None:
                        df_result=df_result.dropna(subset=[col_name for col_name in df_result.columns if col_name != "SK"],how='all')

                        string_columns = extract_string_columns(df_result)
                        df_result = df_result.dropDuplicates()
                        df_result =df_result.select(*[regexp_replace(c, '\\\\', '').alias(c) if c in string_columns else col(c) for c in df_result.columns])
                        df_result = df_result.select(*[col(c).alias(c.replace("-", "_").lstrip("_")) for c in df_result.columns])


                        source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, load_to_date, "business_key")
                        new_table_name=function_name
                        new_table_name=new_table_name.upper()
                        delta_path=desti_path+"/"+new_table_name

                        source_data_df = fillwithNone(source_data_df)
            
                        source_data_df.write.format("delta").mode("append").option("mergeSchema","true").option("path",delta_path).saveAsTable(new_table_name)
                        logger(logger_level_info, f"{new_table_name} table is created", execution_log_list, filename)
                    else:
                       
                        logger(logger_level_error, f"Operation doesn't have required columns.", execution_log_list, filename)
            except Exception as e:
                logger(logger_level_error, f"Error occurred during: {e}", execution_log_list, filename)
                raise Exception("Error occurred during execution", str(e))
    except Exception as e:
        logger(logger_level_error, f"Error occurred during execution: {e}", execution_log_list, filename)
        raise Exception("Error occurred during execution: ", str(e))

