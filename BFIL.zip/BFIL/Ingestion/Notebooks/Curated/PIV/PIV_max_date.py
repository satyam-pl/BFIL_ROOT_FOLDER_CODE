# Databricks notebook source
df = spark.sql(f"""
               select databasename,Azure_table_name,layer_name,max(load_to_date) as max_load_to_date
from
(
SELECT a.databasename,a.target_object_name as table_name,
a.object_source||'..'||target_object_name as SQL_table_name,
lower(a.databasename||'-'||a.target_object_name) as Azure_table_name,
a.Load_Type as SQL_Table_Type,
a.dest_save_type as Azure_Table_TYPE,
a.source_row_count as SQL_Record_Count,
a.destination_row_count as Azure_Record_Count,
a.layer_name,
a.load_from_date,
cast(a.load_to_date as date)
 
FROM
(
SELECT CASE WHEN B.object_source LIKE 'Pragati%' then 'pragati' else b.object_source end as databasename,
a.load_to_date,
b.object_source,
b.target_object_name,case when B.load_type = 'ONE TIME LOAD' then 'Type 1' when B.load_type = 'FULL LOAD' then 'Type 2' when B.load_type = 'TRANSACTIONAL' then 'Type 3' when  B.load_type = 'INCREMENTAL' then 'Type 4' end as Load_Type
,b.dest_save_type,a.source_row_count,A.destination_row_count,a.load_from_date,a.layer_name
FROM edp_synapse_prod.bfil_meta.pl_exec_log A INNER JOIN edp_synapse_prod.bfil_meta.pl_src_sys_detail B ON A.src_object_id =B.src_object_id
) A
) where layer_name in ('CURATED','RAW') group by 1,2,3;
""")

df.display()

# COMMAND ----------

path = "abfss://mart-layer@iblprodadls01.dfs.core.windows.net/BFIL-MART/PIV-RECON/PIV_MAX_DATE"
df.write.format("delta").mode("append").option("mergeSchema", "true").option("path",path).saveAsTable(f"edp_bfil_prod.bfil_mart.piv_max_date")