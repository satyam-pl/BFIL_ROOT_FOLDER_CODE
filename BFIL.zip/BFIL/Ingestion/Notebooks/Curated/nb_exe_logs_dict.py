# Databricks notebook source
# Declaring the notebook name
filename = 'nb_exe_logs_dict.dbc'

# COMMAND ----------

try:
    def get_logs_dictionary(src_object_id, start_timestamp, end_timestamp, status, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, error_log):
        # Calculate the duration by subtracting end_time from start_time
        duration = end_timestamp - start_timestamp

        # Get the duration in seconds as an integer
        duration_seconds = int(duration.total_seconds())

        # Data formation for logger
        log_dict = {
            "exec_batch_id": "",
            "src_object_id": str(src_object_id),
            "layer_name": "CURATED",
            "start_datetime": start_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ'),
            "end_datetime": end_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ'),
            "task_duration": str(duration_seconds),
            "status": str(status),
            "load_from_date": str(load_from_date),
            "load_to_date": str(load_to_date),
            "load_from_id": "NA",
            "load_to_id": "NA",
            "pipeline_name": str(pipeline_name),
            "pipeline_runid": str(pipeline_run_id),
            "pipeline_trigger_name": str(pipeline_trigger_name),
            "source_row_count": str(source_row_count),
            "destination_row_count": str(destination_row_count),
            "error_log": str(error_log),
            "cons_tbl_name": ""
        }

        # Fetching adls storage account key from Azure Key vault by utilising secret scope
        logger(logger_level_info, f"The logs dictionary has been created successfully to pass it to ADF.", execution_log_list, filename)

        return [log_dict] 
 
except Exception as e:
    # Call the logger function with a log level and message
    logger(logger_level_error, f"Error while creating into append update log dictionary for ADF pipeline.", execution_log_list, filename)
    print(*execution_log_list, sep='\n')
    raise Exception(f"An unexpected error occurred:", e)