# Databricks notebook source
filename="nb_curated_cb_surrogate_key_increment.dbc"

# COMMAND ----------

def add_sk_column(df, max_sk_value=None):
    spark.sql(f"use {adb_curated_catlog_schema}")
    if 'SK' not in df.columns:
        if max_sk_value is None:
            # Check if the table exists
            table_exists = spark.sql("SHOW TABLES LIKE 'crif_header'").count() > 0
            if table_exists:
                print("Table exists")
                # Fetch maximum 'SK' value from the header table
                max_sk_value_df = spark.sql("SELECT MAX(SK) AS max_sk FROM crif_header")
    
                max_sk_value_row = max_sk_value_df.first()
                print(max_sk_value_row)
                if max_sk_value_row["max_sk"] is not None:  # Check if result is not null
                    max_sk_value = max_sk_value_row["max_sk"]
      
                else:
                    print("Max SK value is null, setting it to 1")
                    max_sk_value = 0
          
            else:
                # If table does not exist, set max_sk_value to 0
                max_sk_value = 0
            

        df = df.withColumn("SK", F.row_number().over(Window.orderBy(F.monotonically_increasing_id())) + (max_sk_value if max_sk_value is not None else 0))
    return df

# COMMAND ----------

def add_sk_column_equifax(df, max_sk_value=None):
    spark.sql(f"use {adb_curated_catlog_schema}")
    if 'SK' not in df.columns:
        if max_sk_value is None:
            # Check if the table exists
            table_exists = spark.sql("SHOW TABLES LIKE 'equifax_InquiryResponseHeader'").count() > 0
            if table_exists:
               
                max_sk_value_df = spark.sql("SELECT MAX(SK) AS max_sk FROM equifax_InquiryResponseHeader")
    
                max_sk_value_row = max_sk_value_df.first()
                print(max_sk_value_row)
                if max_sk_value_row["max_sk"] is not None:  # Check if result is not null
                    max_sk_value = max_sk_value_row["max_sk"]
      
                else:
                    print("Max SK value is null, setting it to 1")
                    max_sk_value = 0
          
            else:
                # If table does not exist, set max_sk_value to 0
                max_sk_value = 0
            

        df = df.withColumn("SK", F.row_number().over(Window.orderBy(F.monotonically_increasing_id())) + (max_sk_value if max_sk_value is not None else 0))
    return df