# Databricks notebook source
!pip install azure-storage-blob

# COMMAND ----------

from azure.storage.blob import BlobServiceClient

filename="nb_curated_cb_unzip.dbc"
def unzip(desti_container,source_path,account_url,cb_sas_url,target_blob_path):
    try:
        adls_sas_url = dbutils.secrets.get(scope = adb_secret_scope_name, key = cb_sas_url)
        adls_sas_token = adls_sas_url.split('?')[1]
      
        
        blob_service_client = BlobServiceClient(account_url, credential=adls_sas_token)
        blob_list = blob_service_client.get_container_client(desti_container).list_blobs(name_starts_with=source_path)
        # Initialize counter
        file_count = 0
        if not blob_list:
            logger(logger_level_error, f"No files to unzip ", execution_log_list, filename)
            
        else: 
            for blob in blob_list:
                zip_content = blob_service_client.get_blob_client(desti_container, blob.name).download_blob().readall()
                
                # Create a target container client
                target_container_client = blob_service_client.get_container_client(desti_container)

                # # Open the zip file
                with zipfile.ZipFile(BytesIO(zip_content), 'r') as zip_file:
                    # Iterate over XML files in the zip archive
                    for file_info in zip_file.infolist():
                        if file_info.filename.endswith('.xml'):
                            # Read the XML content
                            with zip_file.open(file_info) as xml_file:
                                xml_content = xml_file.read()
                                
                                # Construct the target blob path
                               
                                target_blob_name = target_blob_path + file_info.filename.split('/')[-1]
                                
                                # Upload the XML content to the target blob path
                                target_blob_client = target_container_client.get_blob_client(target_blob_name)
                                target_blob_client.upload_blob(xml_content, overwrite=True)
                                # Increment file count
                                file_count += 1
                                
                            
        return file_count
    except Exception as e:
        logger(logger_level_error, f"An error occurred in the doing unzip of files   : {str(e)}", execution_log_list, filename)
        raise Exception("An error occurred in the doing unzip of files :", str(e))
        return None


# COMMAND ----------

def extract_xml_files(binary_zip):
    xml_data_list = []
    with zipfile.ZipFile(io.BytesIO(binary_zip), 'r') as zip_ref:
        for file_name in zip_ref.namelist():
            if file_name.endswith('.xml'):
                xml_data = zip_ref.read(file_name).decode('utf-8')
                xml_data_list.append((file_name, xml_data))
    return xml_data_list
 
def write_xml_to_adls(file_name, xml_data, target_blob_path):
    if not target_blob_path.endswith('/'):
        target_blob_path += '/'
    output_path = f"{target_blob_path}{file_name}"
    dbutils.fs.put(output_path, xml_data, True)
    print(f"Content of {file_name} has been written to {output_path}")
 
def unzip_without_sas_url(source_path, target_blob_path):
    file_count = 0
    binary_zip_df = spark.read.format("binaryFile").load(source_path).select("content")
    binary_zip_data = binary_zip_df.first()[0]
    # binary_zip_data = binary_zip_df.collect()[0][0]
    xml_files = extract_xml_files(binary_zip_data)
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(write_xml_to_adls, file_name, xml_data, target_blob_path) for file_name, xml_data in xml_files]
        for future in futures:
            future.result()
            file_count += 1
    return file_count