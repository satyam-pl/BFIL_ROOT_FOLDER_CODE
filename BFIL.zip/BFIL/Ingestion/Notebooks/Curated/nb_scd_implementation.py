# Databricks notebook source
# Declaring the notebook name
filename = 'nb_scd_implementation.dbc'

# COMMAND ----------

"""
    This function handles Slowly Changing Dimension (SCD) Type 1 operations.
    Args:
    source_df (DataFrame): The source incremental data.
    table_name (str): The name of the Snapshot table.
    Returns:
    str: A message indicating whether the operation was successful.
"""
def handle_scd_type_1(source_df, desti_path, object_name, primary_key, updated_by, load_type, object_source, adb_curated_dest_url, adb_curated_catlog_schema, other_info_02, delivery_frequency, load_to_date):

    try:

        # Construct the Delta table path
        delta_table_path = adb_curated_dest_url + "/" + desti_path
        
        adb_curated_catalog = adb_curated_catlog_schema.split(".")[0]
        table_schema = adb_curated_catlog_schema.split(".")[1]
        table_name = object_source + "-" + object_name

        # Convert the table to DeltaTable
        delta_table_exists = spark.sql(f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_source}-{object_name}"')

        # Checking load type
        if (load_type in ["INCREMENTAL", "FULL LOAD"]) and ((primary_key is not None and (isinstance(primary_key, str) and primary_key.strip() != '')) or (isinstance(primary_key, list) and len(primary_key) != 0)):
            
            if not (delta_table_exists.isEmpty()) :

                # columns to avoid while updating records
                columns_to_exclude = ['ETL_CREATED_DATE','ETL_HASH_COL','ETL_CHANGE_FLAG','ETL_LAST_UPDATED_BY','ETL_LAST_UPDATED_DATE']

                updated_date = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

                # Check if primary_key is a single primary key or a list of primary keys
                if isinstance(primary_key, str):
                    join_condition = f"target.{primary_key} = source.{primary_key} AND target.ETL_IS_ACTIVE = '1'"
                    primary_key_columns = primary_key
                    primary_keys_to_exclude = primary_key
                elif isinstance(primary_key, (list, tuple)):
                    join_condition = " AND ".join([f"target.{key} = source.{key}" for key in primary_key]) + " AND target.ETL_IS_ACTIVE = '1'"
                    primary_key_columns = ", ".join(primary_key)
                    primary_keys_to_exclude = primary_key

                # Get the schema of the Delta table directly
                delta_table_schema = spark.table(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`").schema
                delta_table_columns = [field.name for field in delta_table_schema.fields]

                # Create a dictionary to map columns to be updated, excluding columns that should not be updated
                update_condition = ", ".join([f"target.{column} = source.{column}" for column in delta_table_columns if column not in columns_to_exclude and column not in primary_keys_to_exclude])

                # Create a Secure View on top of Incremental data
                source_df.createOrReplaceTempView("source_df_view") 

                # Enable automatic schema evolution
                spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")  
                    
                #SQL merge         
                output_df = spark.sql(f"""MERGE INTO {adb_curated_catlog_schema}.`{object_source}-{object_name}` AS target
                                    USING source_df_view AS source
                                    ON {join_condition}
                                    WHEN MATCHED and target.ETL_HASH_COL != source.ETL_HASH_COL and target.ETL_IS_ACTIVE == '1' THEN
                                    UPDATE SET
                                        {update_condition},
                                        target.ETL_CHANGE_FLAG = 'U',
                                        target.ETL_LAST_UPDATED_BY = '{updated_by}',   
                                        target.ETL_HASH_COL = source.ETL_HASH_COL,
                                        target.ETL_LAST_UPDATED_DATE = '{updated_date}' 
                                    WHEN NOT MATCHED THEN
                                    INSERT *
                                    """) 
                
                # if load_type == "FULL LOAD":
                #     # Delete records from the target table that are not present in the source table
                #     delete_df = spark.sql(f"""DELETE FROM {adb_curated_catlog_schema}.`{object_source}-{object_name}`
                #                             WHERE ({primary_key_columns}) NOT IN (
                #                             SELECT {primary_key_columns} FROM source_df_view
                #                             )
                #                         """)

                logger(logger_level_info, f"In SCD Type 1, the curated delta table has been successfully upserted: {object_name}.", execution_log_list, filename)
                return "success"
        
        # Checking load type
        if load_type == "FULL LOAD" and (primary_key is None or (isinstance(primary_key, str) and primary_key.strip() == '') or (isinstance(primary_key, list) and len(primary_key) == 0)):

            # For FULL LOAD load type truncate and load 
            max_retries = 10  # Maximum number of retries
            retry_delay = 50  # Delay between retries in seconds

            retry_count = 0
            success = False

            while retry_count < max_retries and not success:
                try:
                    # overwrite the exisiting table schema details like comments, tags on to the incremental data dataframe
                    source_df = overwriting_schema(adb_curated_catalog, table_schema, table_name, source_df)
                    # If Delta table is exist, overwrite Delta table and write the source data
                    source_df.write.format("delta").mode("overwrite").option("overwriteSchema", "True").option("mergeSchema", "true").saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")
                    logger(logger_level_info, f"In SCD Type 1, the curated delta table has been successfully overwrite for load type {load_type} and for table {object_name}.", execution_log_list, filename)
                    success = True
                    return "success"
                except Exception as e:
                    retry_count += 1
                    logger(logger_level_error, f"An error occurred. Retrying in {retry_delay} seconds...", execution_log_list, filename)
                    time.sleep(retry_delay)

            if not success:
                logger(logger_level_error, f"Failed to execute the command after maximum retries is {max_retries}", execution_log_list, filename)
                raise Exception(f"Failed to execute the command after maximum retries is {max_retries}")

        else :

            if delivery_frequency != "DAILY" :

                # Construct the base query
                base_query = f""" DELETE FROM {adb_curated_catlog_schema}.`{object_source}-{object_name}`
                            WHERE TO_DATE({other_info_02}) > DATE_SUB(TO_DATE('{load_to_date}'), {delivery_frequency})"""    

                # Execute the query
                delete_df = spark.sql(base_query)

                logger(logger_level_info, f"In SCD Type 1, the curated delta table has been successfully clean data using {base_query} for {load_type}, {load_to_date} and for table {object_name}.", execution_log_list, filename)

            # If Delta table is exist appending source data
            source_df.write.format("delta").mode("append").option("mergeSchema", "true").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")

            logger(logger_level_info, f"In SCD Type 1, the curated delta table has been successfully appended for load type {load_type} and for table {object_name}.", execution_log_list, filename)
            return "success"
        
    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"There is an error in the SCD Type 1 operation.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)

# COMMAND ----------

"""
    This function handles Slowly Changing Dimension (SCD) Type 2 operations.
    Args:
    source_df (DataFrame): The source incremental data.
    table_name (str): The name of full snapshot table.
    Returns:
    str: A message indicating whether the operation was successful.
"""

def handle_scd_type_2(source_df, desti_path, object_name, business_key, updated_by, load_to_date, object_source, adb_curated_dest_url, src_type, history_extra_columns, load_type):

    try:
        # Update effective_from_date minus 1 day of load_to_date
        new_time = datetime.strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=1)
        load_to_date_minus_one_day = new_time.strftime('%Y-%m-%dT%H:%M:%SZ')

        # Construct the Delta table path
        delta_table_path = adb_curated_dest_url + "/" + desti_path

        adb_curated_catalog = adb_curated_catlog_schema.split(".")[0]
        table_schema = adb_curated_catlog_schema.split(".")[1]

        # Convert the table to DeltaTable
        delta_table_exists = spark.sql(f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_source}-{object_name}"')

        if not (delta_table_exists.isEmpty()) :

            load_to_date_for_new_data = load_to_date[:11] + "00:00:00Z"

            source_df = source_df.withColumn("ETL_IS_ACTIVE", lit("1"))\
                                .withColumn("ETL_EFFECTIVE_FROM_DATE", lit(load_to_date_for_new_data))\
                                .withColumn("ETL_EFFECTIVE_TO_DATE", lit("9999-12-31T23:59:59Z"))

            # Check if business_key is a single primary key or a list of primary keys
            if isinstance(business_key, str):
                join_condition = f"target.{business_key} = source.{business_key} AND target.ETL_IS_ACTIVE = '1'"
                primary_key_columns = business_key
            elif isinstance(business_key, (list, tuple)):
                join_condition = " AND ".join([f"target.{key} = source.{key}" for key in business_key]) + " AND target.ETL_IS_ACTIVE = '1'"
                primary_key_columns = ", ".join(business_key)

            source_df.createOrReplaceTempView("source_df_view")   

            # Enable automatic schema evolution
            spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 

            if src_type != 'rdbms-view' and src_type != 'rdbms-view-multisource':

                output_df = spark.sql(f"""MERGE INTO {adb_curated_catlog_schema}.`{object_source}-{object_name}` AS target
                                        USING source_df_view AS source
                                        ON {join_condition}
                                        WHEN MATCHED and target.ETL_HASH_COL != source.ETL_HASH_COL and target.ETL_IS_ACTIVE == '1' THEN
                                        UPDATE SET
                                            target.ETL_LAST_UPDATED_BY = '{updated_by}',    
                                            target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE, 
                                            target.ETL_IS_ACTIVE = '0',
                                            target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                                        WHEN NOT MATCHED THEN
                                        INSERT *
                                        """)
                
            elif src_type == 'rdbms-view' or src_type == 'rdbms-view-multisource' :

                # Create a dictionary to map columns to be updated
                update_condition = ", ".join([f"target.{column} = source.{column}" for column in source_df.columns if column in history_extra_columns])

                output_df = spark.sql(f"""MERGE INTO {adb_curated_catlog_schema}.`{object_source}-{object_name}` AS target
                                        USING source_df_view AS source
                                        ON {join_condition}
                                        WHEN MATCHED and target.ETL_HASH_COL != source.ETL_HASH_COL and target.ETL_IS_ACTIVE == '1' THEN
                                        UPDATE SET
                                            {update_condition},
                                            target.ETL_LAST_UPDATED_BY = '{updated_by}',    
                                            target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE, 
                                            target.ETL_IS_ACTIVE = '0',
                                            target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                                        WHEN NOT MATCHED THEN
                                        INSERT *
                                        """) 
                
                # Set the values as None for specified columns
                for column in history_extra_columns:
                    if column in source_df.columns:
                        source_df = source_df.withColumn(column, lit(None))

            if load_type == "FULL LOAD":

                # inactive records from the target table that are not present in the source table
                spark.sql(f"""MERGE INTO {adb_curated_catlog_schema}.`{object_source}-{object_name}` AS target
                                USING (
                                SELECT {primary_key_columns}, ETL_CREATED_DATE FROM {adb_curated_catlog_schema}.`{object_source}-{object_name}` WHERE    
                                ETL_IS_ACTIVE = '1'
                                EXCEPT
                                SELECT {primary_key_columns}, ETL_CREATED_DATE FROM source_df_view
                                ) AS source
                                ON {join_condition}
                                WHEN MATCHED AND target.ETL_IS_ACTIVE = '1' THEN
                                UPDATE SET
                                    target.ETL_CHANGE_FLAG = 'D',
                                    target.ETL_LAST_UPDATED_BY = '{updated_by}',
                                    target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE,
                                    target.ETL_IS_ACTIVE = '0',
                                    target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                """)
                
            # Reading existing delta table data to insert new data of updates
            delta_table = DeltaTable.convertToDelta(spark, f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`").toDF().select("ETL_HASH_COL", "ETL_IS_ACTIVE")

            # Perform a left anti-join to filter out records from source_df present in delta_table
            source_df_filtered = source_df.alias("updates").join(
                delta_table.alias("existing"),
                (col("updates.ETL_HASH_COL") == col("existing.ETL_HASH_COL")) & (col("updates.ETL_IS_ACTIVE") == col("existing.ETL_IS_ACTIVE")),
                "left_anti"
            )

            source_df_filtered = source_df_filtered.withColumn("ETL_CHANGE_FLAG", lit("U"))

            # Insert new historical data only
            source_df_filtered.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")
            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully upserted for {object_name}.", execution_log_list, filename)
            return "success"

        else:

            # If Delta table does not exist, create a new Delta table and write the source data
            source_df.write.format("delta").mode("append").option("mergeSchema", "true").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")

            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully loaded for {object_name}.", execution_log_list, filename)
            return "success"

    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"There was an error in the SCD Type 2 operation.", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception(f"An unexpected error occurred:", e)

# COMMAND ----------

"""
    This function handles Slowly Changing Dimension (SCD) Type 2 operations for type 4 with delete.
    Args:
    source_df (DataFrame): The source incremental data.
    table_name (str): The name of full snapshot table.
    Returns:
    str: A message indicating whether the operation was successful.
"""

def handle_scd_type_2_delete(source_df, desti_path, object_name, business_key, updated_by, load_to_date, object_source, adb_curated_dest_url, src_type, history_extra_columns, load_type):
    filename = "scd.dbc"
    try:
        # Update effective_from_date minus 1 day of load_to_date
        new_time = datetime.strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=1)
        load_to_date_minus_one_day = new_time.strftime('%Y-%m-%dT%H:%M:%SZ')

        # Construct the Delta table path
        delta_table_path = adb_curated_dest_url + "/" + desti_path

        adb_curated_catalog = adb_curated_catlog_schema.split(".")[0]
        table_schema = adb_curated_catlog_schema.split(".")[1]

        # Convert the table to DeltaTable
        delta_table_exists = spark.sql(f'SELECT * FROM {adb_curated_catalog}.information_schema.tables WHERE table_schema = "{table_schema}" and table_name = "{object_source}-{object_name}"')

        if not (delta_table_exists.isEmpty()) :

            load_to_date_for_new_data = load_to_date[:11] + "00:00:00Z"

            source_df = source_df.withColumn("ETL_EFFECTIVE_FROM_DATE", lit(load_to_date_for_new_data))\
                                .withColumn("ETL_EFFECTIVE_TO_DATE", lit("9999-12-31T23:59:59Z"))

            try:
                source_df = source_df.withColumn("ETL_IS_ACTIVE", when(col("Source_Change_Flag") == "D", "0").otherwise(col("ETL_IS_ACTIVE")))
            except Exception as e:
                # Call the logger function with a log level and message
                logger(logger_level_error, f"There was an error in the SCD Type 2 operation.", execution_log_list, filename)
                print(*execution_log_list, sep='\n')
                raise Exception(f"An error occurred in the SCD Type 2 operation Source_Change_Flag column is missing in source data. Error: {e}")

            # Check if business_key is a single primary key or a list of primary keys
            if isinstance(business_key, str):
                join_condition = f"target.{business_key} = source.{business_key} AND target.ETL_IS_ACTIVE = '1'"
                primary_key_columns = business_key
            elif isinstance(business_key, (list, tuple)):
                join_condition = " AND ".join([f"target.{key} = source.{key}" for key in business_key]) + " AND target.ETL_IS_ACTIVE = '1'"
                primary_key_columns = ", ".join(business_key)

            source_df.createOrReplaceTempView("source_df_view")   

            # Enable automatic schema evolution
            spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 

            if src_type != 'rdbms-view' and src_type != 'rdbms-view-multisource':

                output_df = spark.sql(f"""MERGE INTO {adb_curated_catlog_schema}.`{object_source}-{object_name}` AS target
                                        USING source_df_view AS source
                                        ON {join_condition}
                                        WHEN MATCHED and target.ETL_HASH_COL != source.ETL_HASH_COL and target.ETL_IS_ACTIVE == '1' and source.Source_Change_Flag != 'D' THEN
                                        UPDATE SET
                                            target.ETL_LAST_UPDATED_BY = '{updated_by}',    
                                            target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE, 
                                            target.ETL_IS_ACTIVE = '0',
                                            target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                                        WHEN MATCHED AND target.ETL_IS_ACTIVE == '1' and source.Source_Change_Flag == 'D' THEN
                                        UPDATE SET
                                            target.ETL_CHANGE_FLAG = 'D',
                                            target.ETL_LAST_UPDATED_BY = '{updated_by}',    
                                            target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE, 
                                            target.ETL_IS_ACTIVE = '0',
                                            target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                                        WHEN NOT MATCHED THEN
                                        INSERT *
                                        """)
                
            elif src_type == 'rdbms-view' or src_type == 'rdbms-view-multisource' :

                # Create a dictionary to map columns to be updated
                update_condition = ", ".join([f"target.{column} = source.{column}" for column in source_df.columns if column in history_extra_columns])

                output_df = spark.sql(f"""MERGE INTO {adb_curated_catlog_schema}.`{object_source}-{object_name}` AS target
                                        USING source_df_view AS source
                                        ON {join_condition}
                                        WHEN MATCHED and target.ETL_HASH_COL != source.ETL_HASH_COL and target.ETL_IS_ACTIVE == '1' and source.Source_Change_Flag != 'D' THEN
                                        UPDATE SET
                                            {update_condition},
                                            target.ETL_LAST_UPDATED_BY = '{updated_by}',    
                                            target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE, 
                                            target.ETL_IS_ACTIVE = '0',
                                            target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                                        WHEN MATCHED AND target.ETL_IS_ACTIVE == '1' and source.Source_Change_Flag == 'D' THEN
                                        UPDATE SET
                                            target.ETL_CHANGE_FLAG = 'D',
                                            target.ETL_LAST_UPDATED_BY = '{updated_by}',    
                                            target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE, 
                                            target.ETL_IS_ACTIVE = '0',
                                            target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                                        WHEN NOT MATCHED THEN
                                        INSERT *
                                        """) 
                
                # Set the values as None for specified columns
                for column in history_extra_columns:
                    if column in source_df.columns:
                        source_df = source_df.withColumn(column, lit(None))

            if load_type == "FULL LOAD":
                # inactive records from the target table that are not present in the source table
                spark.sql(f"""MERGE INTO {adb_curated_catlog_schema}.`{object_source}-{object_name}` AS target
                                USING (
                                SELECT {primary_key_columns}, ETL_CREATED_DATE FROM {adb_curated_catlog_schema}.`{object_source}-{object_name}` WHERE    
                                ETL_IS_ACTIVE = '1'
                                EXCEPT
                                SELECT {primary_key_columns}, ETL_CREATED_DATE FROM source_df_view
                                ) AS source
                                ON {join_condition}
                                WHEN MATCHED AND target.ETL_IS_ACTIVE = '1' THEN
                                UPDATE SET
                                    target.ETL_CHANGE_FLAG = 'D',
                                    target.ETL_LAST_UPDATED_BY = '{updated_by}',
                                    target.ETL_LAST_UPDATED_DATE = source.ETL_CREATED_DATE,
                                    target.ETL_IS_ACTIVE = '0',
                                    target.ETL_EFFECTIVE_TO_DATE = '{load_to_date_minus_one_day}'
                """)
                
            # Reading existing delta table data to insert new data of updates
            delta_table = DeltaTable.convertToDelta(spark, f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`").toDF().select("ETL_HASH_COL", "ETL_IS_ACTIVE")

            # Perform a left anti-join to filter out records from source_df present in delta_table
            source_df_filtered = source_df.alias("updates").join(
                delta_table.alias("existing"),
                (col("updates.ETL_HASH_COL") == col("existing.ETL_HASH_COL")) & (col("updates.ETL_IS_ACTIVE") == col("existing.ETL_IS_ACTIVE")),
                "left_anti"
            )

            source_df_filtered = source_df_filtered.withColumn("ETL_CHANGE_FLAG", lit("U"))

            # Insert new historical data only
            source_df_filtered.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")
            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully upserted for {object_name} and load type is {load_type}.", execution_log_list, filename)
            return "success"

        else:
            # If Delta table does not exist, create a new Delta table and write the source data
            source_df.write.format("delta").mode("append").option("mergeSchema", "true").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")

            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully loaded for {object_name} and load type is {load_type}.", execution_log_list, filename)
            return "success"

    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"There was an error in the SCD Type 2 operation.", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception(f"An unexpected error occurred:", e)